/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElementValueEnumConstValue
/*    */   implements ElementValue
/*    */ {
/*    */   protected String descriptor;
/*    */   protected String constName;
/*    */   
/*    */   public ElementValueEnumConstValue(String descriptor, String constName) {
/* 15 */     this.descriptor = descriptor;
/* 16 */     this.constName = constName;
/*    */   }
/*    */   
/*    */   public String getDescriptor() {
/* 20 */     return this.descriptor;
/*    */   }
/*    */   
/*    */   public String getConstName() {
/* 24 */     return this.constName;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(ElementValueVisitor visitor) {
/* 29 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/ElementValueEnumConstValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */