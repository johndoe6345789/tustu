/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElementValuePair
/*    */ {
/*    */   protected String elementName;
/*    */   protected ElementValue elementValue;
/*    */   
/*    */   public ElementValuePair(String elementName, ElementValue elementValue) {
/* 15 */     this.elementName = elementName;
/* 16 */     this.elementValue = elementValue;
/*    */   }
/*    */   
/*    */   public String getElementName() {
/* 20 */     return this.elementName;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends ElementValue> T getElementValue() {
/* 25 */     return (T)this.elementValue;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/ElementValuePair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */