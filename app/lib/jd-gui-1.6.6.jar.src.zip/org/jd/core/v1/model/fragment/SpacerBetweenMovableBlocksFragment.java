/*    */ package org.jd.core.v1.model.fragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpacerBetweenMovableBlocksFragment
/*    */   extends FlexibleFragment
/*    */ {
/*    */   public SpacerBetweenMovableBlocksFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label) {
/* 13 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label);
/*    */   }
/*    */   
/*    */   public void setInitialLineCount(int initialLineCount) {
/* 17 */     this.initialLineCount = this.lineCount = initialLineCount;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(FragmentVisitor visitor) {
/* 22 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/fragment/SpacerBetweenMovableBlocksFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */