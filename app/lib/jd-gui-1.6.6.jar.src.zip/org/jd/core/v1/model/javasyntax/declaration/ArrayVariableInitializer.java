/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import org.jd.core.v1.model.javasyntax.type.Type;
/*    */ import org.jd.core.v1.util.DefaultList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayVariableInitializer
/*    */   extends DefaultList<VariableInitializer>
/*    */   implements VariableInitializer
/*    */ {
/*    */   protected Type type;
/*    */   
/*    */   public ArrayVariableInitializer(Type type) {
/* 17 */     this.type = type;
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 21 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getLineNumber() {
/* 26 */     return isEmpty() ? 0 : get(0).getLineNumber();
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 31 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/ArrayVariableInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */