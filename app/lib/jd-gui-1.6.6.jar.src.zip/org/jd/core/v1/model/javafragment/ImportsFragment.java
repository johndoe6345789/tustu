/*     */ package org.jd.core.v1.model.javafragment;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import org.jd.core.v1.model.fragment.FlexibleFragment;
/*     */ import org.jd.core.v1.util.DefaultList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImportsFragment
/*     */   extends FlexibleFragment
/*     */   implements JavaFragment
/*     */ {
/*  19 */   protected static final ImportCountComparator COUNT_COMPARATOR = new ImportCountComparator();
/*     */   
/*  21 */   protected final HashMap<String, Import> importMap = new HashMap<>();
/*     */   
/*     */   public ImportsFragment(int weight) {
/*  24 */     super(0, -1, -1, weight, "Imports");
/*     */   }
/*     */   
/*     */   public void addImport(String internalName, String qualifiedName) {
/*  28 */     Import imp = this.importMap.get(internalName);
/*     */     
/*  30 */     if (imp == null) {
/*  31 */       this.importMap.put(internalName, new Import(internalName, qualifiedName));
/*     */     } else {
/*  33 */       imp.incCounter();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  38 */     return this.importMap.isEmpty();
/*     */   }
/*     */   
/*     */   public void initLineCounts() {
/*  42 */     this.maximalLineCount = this.initialLineCount = this.lineCount = this.importMap.size();
/*     */   }
/*     */   
/*     */   public boolean contains(String internalName) {
/*  46 */     return this.importMap.containsKey(internalName);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLineCount() {
/*  51 */     assert this.lineCount != -1 : "Call initLineCounts() before";
/*  52 */     return this.lineCount;
/*     */   }
/*     */   
/*     */   public Collection<Import> getImports() {
/*  56 */     int lineCount = getLineCount();
/*  57 */     int size = this.importMap.size();
/*     */     
/*  59 */     if (lineCount < size) {
/*  60 */       DefaultList<Import> imports = new DefaultList<>(this.importMap.values());
/*     */       
/*  62 */       imports.sort(COUNT_COMPARATOR);
/*     */ 
/*     */       
/*  65 */       imports.subList(lineCount, size).clear();
/*     */       
/*  67 */       return imports;
/*     */     } 
/*  69 */     return this.importMap.values();
/*     */   }
/*     */   
/*     */   public static class Import
/*     */   {
/*     */     protected String internalName;
/*     */     protected String qualifiedName;
/*     */     protected int counter;
/*     */     
/*     */     public Import(String internalName, String qualifiedName) {
/*  79 */       this.internalName = internalName;
/*  80 */       this.qualifiedName = qualifiedName;
/*  81 */       this.counter = 1;
/*     */     }
/*     */     
/*     */     public String getInternalName() {
/*  85 */       return this.internalName;
/*     */     }
/*     */     public String getQualifiedName() {
/*  88 */       return this.qualifiedName;
/*     */     }
/*     */     public int getCounter() {
/*  91 */       return this.counter;
/*     */     }
/*     */     public void incCounter() {
/*  94 */       this.counter++;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(JavaFragmentVisitor visitor) {
/* 100 */     visitor.visit(this);
/*     */   }
/*     */   
/*     */   protected static class ImportCountComparator implements Comparator<Import> {
/*     */     public int compare(ImportsFragment.Import tr1, ImportsFragment.Import tr2) {
/* 105 */       return tr2.getCounter() - tr1.getCounter();
/*     */     }
/*     */     public boolean equals(Object obj) {
/* 108 */       return equals(obj);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javafragment/ImportsFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */