/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeInnerClasses
/*    */   implements Attribute
/*    */ {
/*    */   protected InnerClass[] classes;
/*    */   
/*    */   public AttributeInnerClasses(InnerClass[] classes) {
/* 14 */     this.classes = classes;
/*    */   }
/*    */   
/*    */   public InnerClass[] getInnerClasses() {
/* 18 */     return this.classes;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/AttributeInnerClasses.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */