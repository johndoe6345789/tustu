/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.jd.core.v1.model.fragment.FlexibleFragment;
/*    */ import org.jd.core.v1.model.token.AbstractNopTokenVisitor;
/*    */ import org.jd.core.v1.model.token.EndBlockToken;
/*    */ import org.jd.core.v1.model.token.LineNumberToken;
/*    */ import org.jd.core.v1.model.token.StartBlockToken;
/*    */ import org.jd.core.v1.model.token.TextToken;
/*    */ import org.jd.core.v1.model.token.Token;
/*    */ import org.jd.core.v1.service.fragmenter.javasyntaxtojavafragment.visitor.StatementVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TokensFragment
/*    */   extends FlexibleFragment
/*    */   implements JavaFragment
/*    */ {
/* 20 */   public static final TokensFragment COMMA = new TokensFragment(new Token[] { TextToken.COMMA });
/* 21 */   public static final TokensFragment SEMICOLON = new TokensFragment(new Token[] { TextToken.SEMICOLON });
/* 22 */   public static final TokensFragment START_DECLARATION_OR_STATEMENT_BLOCK = new TokensFragment(new Token[] { StartBlockToken.START_DECLARATION_OR_STATEMENT_BLOCK });
/* 23 */   public static final TokensFragment END_DECLARATION_OR_STATEMENT_BLOCK = new TokensFragment(new Token[] { EndBlockToken.END_DECLARATION_OR_STATEMENT_BLOCK });
/* 24 */   public static final TokensFragment END_DECLARATION_OR_STATEMENT_BLOCK_SEMICOLON = new TokensFragment(new Token[] { EndBlockToken.END_DECLARATION_OR_STATEMENT_BLOCK, TextToken.SEMICOLON });
/* 25 */   public static final TokensFragment RETURN_SEMICOLON = new TokensFragment(new Token[] { StatementVisitor.RETURN, TextToken.SEMICOLON });
/*    */   
/*    */   protected List<Token> tokens;
/*    */   
/*    */   public TokensFragment(Token... tokens) {
/* 30 */     this(Arrays.asList(tokens));
/*    */   }
/*    */   
/*    */   public TokensFragment(List<Token> tokens) {
/* 34 */     this(getLineCount(tokens), tokens);
/*    */   }
/*    */   
/*    */   protected TokensFragment(int lineCount, List<Token> tokens) {
/* 38 */     super(lineCount, lineCount, lineCount, 0, "Tokens");
/* 39 */     this.tokens = tokens;
/*    */   }
/*    */   
/*    */   public List<Token> getTokens() {
/* 43 */     return this.tokens;
/*    */   }
/*    */   
/*    */   protected static int getLineCount(List<Token> tokens) {
/* 47 */     LineCountVisitor visitor = new LineCountVisitor();
/*    */     
/* 49 */     for (Token token : tokens) {
/* 50 */       token.accept(visitor);
/*    */     }
/*    */     
/* 53 */     return visitor.lineCount;
/*    */   }
/*    */   
/*    */   protected static class LineCountVisitor extends AbstractNopTokenVisitor {
/* 57 */     public int lineCount = 0;
/*    */ 
/*    */     
/*    */     public void visit(LineNumberToken token) {
/* 61 */       this.lineCount++;
/* 62 */       assert token.getLineNumber() == 0 : "LineNumberToken cannot have a known line number. Uses 'LineNumberTokensFragment' instead";
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 68 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javafragment/TokensFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */