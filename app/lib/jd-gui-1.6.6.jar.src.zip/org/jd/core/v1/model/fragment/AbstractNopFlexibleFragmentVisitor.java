package org.jd.core.v1.model.fragment;

public abstract class AbstractNopFlexibleFragmentVisitor implements FragmentVisitor {
  public void visit(EndFlexibleBlockFragment fragment) {}
  
  public void visit(EndMovableBlockFragment fragment) {}
  
  public void visit(StartFlexibleBlockFragment fragment) {}
  
  public void visit(StartMovableBlockFragment fragment) {}
  
  public void visit(FixedFragment fragment) {}
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/fragment/AbstractNopFlexibleFragmentVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */