/*    */ package org.jd.core.v1.model.fragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StartMovableBlockFragment
/*    */   extends FlexibleFragment
/*    */ {
/*    */   protected int type;
/*    */   
/*    */   public StartMovableBlockFragment(int type) {
/* 14 */     super(0, 0, 0, 0, "Start movable block");
/* 15 */     this.type = type;
/*    */   }
/*    */   
/*    */   public int getType() {
/* 19 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 24 */     return "{start-movable-block}";
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(FragmentVisitor visitor) {
/* 29 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/fragment/StartMovableBlockFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */