/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeCode
/*    */   implements Attribute
/*    */ {
/*    */   protected int maxStack;
/*    */   protected int maxLocals;
/*    */   protected byte[] code;
/*    */   protected CodeException[] exceptionTable;
/*    */   protected Map<String, Attribute> attributes;
/*    */   
/*    */   public AttributeCode(int maxStack, int maxLocals, byte[] code, CodeException[] exceptionTable, Map<String, Attribute> attributes) {
/* 20 */     this.maxStack = maxStack;
/* 21 */     this.maxLocals = maxLocals;
/* 22 */     this.code = code;
/* 23 */     this.exceptionTable = exceptionTable;
/* 24 */     this.attributes = attributes;
/*    */   }
/*    */   
/*    */   public int getMaxStack() {
/* 28 */     return this.maxStack;
/*    */   }
/*    */   
/*    */   public int getMaxLocals() {
/* 32 */     return this.maxLocals;
/*    */   }
/*    */   
/*    */   public byte[] getCode() {
/* 36 */     return this.code;
/*    */   }
/*    */   
/*    */   public CodeException[] getExceptionTable() {
/* 40 */     return this.exceptionTable;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends Attribute> T getAttribute(String name) {
/* 45 */     return (this.attributes == null) ? null : (T)this.attributes.get(name);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/AttributeCode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */