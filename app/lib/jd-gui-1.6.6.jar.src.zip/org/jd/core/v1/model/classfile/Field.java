/*    */ package org.jd.core.v1.model.classfile;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.jd.core.v1.model.classfile.attribute.Attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Field
/*    */ {
/*    */   protected int accessFlags;
/*    */   protected String name;
/*    */   protected String descriptor;
/*    */   protected Map<String, Attribute> attributes;
/*    */   
/*    */   public Field(int accessFlags, String name, String descriptor, Map<String, Attribute> attributes) {
/* 21 */     this.accessFlags = accessFlags;
/* 22 */     this.name = name;
/* 23 */     this.descriptor = descriptor;
/* 24 */     this.attributes = attributes;
/*    */   }
/*    */   
/*    */   public int getAccessFlags() {
/* 28 */     return this.accessFlags;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 32 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getDescriptor() {
/* 36 */     return this.descriptor;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends Attribute> T getAttribute(String name) {
/* 41 */     return (this.attributes == null) ? null : (T)this.attributes.get(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 46 */     return "Field{" + this.name + " " + this.descriptor + "}";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/Field.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */