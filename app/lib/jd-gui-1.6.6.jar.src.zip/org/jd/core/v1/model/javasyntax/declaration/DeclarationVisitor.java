package org.jd.core.v1.model.javasyntax.declaration;

public interface DeclarationVisitor {
  void visit(AnnotationDeclaration paramAnnotationDeclaration);
  
  void visit(ArrayVariableInitializer paramArrayVariableInitializer);
  
  void visit(BodyDeclaration paramBodyDeclaration);
  
  void visit(ClassDeclaration paramClassDeclaration);
  
  void visit(ConstructorDeclaration paramConstructorDeclaration);
  
  void visit(EnumDeclaration paramEnumDeclaration);
  
  void visit(EnumDeclaration.Constant paramConstant);
  
  void visit(ExpressionVariableInitializer paramExpressionVariableInitializer);
  
  void visit(FieldDeclaration paramFieldDeclaration);
  
  void visit(FieldDeclarator paramFieldDeclarator);
  
  void visit(FieldDeclarators paramFieldDeclarators);
  
  void visit(FormalParameter paramFormalParameter);
  
  void visit(FormalParameters paramFormalParameters);
  
  void visit(InstanceInitializerDeclaration paramInstanceInitializerDeclaration);
  
  void visit(InterfaceDeclaration paramInterfaceDeclaration);
  
  void visit(LocalVariableDeclaration paramLocalVariableDeclaration);
  
  void visit(LocalVariableDeclarator paramLocalVariableDeclarator);
  
  void visit(LocalVariableDeclarators paramLocalVariableDeclarators);
  
  void visit(MethodDeclaration paramMethodDeclaration);
  
  void visit(MemberDeclarations paramMemberDeclarations);
  
  void visit(ModuleDeclaration paramModuleDeclaration);
  
  void visit(StaticInitializerDeclaration paramStaticInitializerDeclaration);
  
  void visit(TypeDeclarations paramTypeDeclarations);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/DeclarationVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */