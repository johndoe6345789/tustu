/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModuleInfo
/*    */ {
/*    */   protected String name;
/*    */   protected int flags;
/*    */   protected String version;
/*    */   
/*    */   public ModuleInfo(String name, int flags, String version) {
/* 16 */     this.name = name;
/* 17 */     this.flags = flags;
/* 18 */     this.version = version;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 22 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getFlags() {
/* 26 */     return this.flags;
/*    */   }
/*    */   
/*    */   public String getVersion() {
/* 30 */     return this.version;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     StringBuilder sb = new StringBuilder();
/*    */     
/* 37 */     sb.append("ModuleInfo{name=").append(this.name);
/* 38 */     sb.append(", flags=").append(this.flags);
/*    */     
/* 40 */     if (this.version != null) {
/* 41 */       sb.append(", version=").append(this.version);
/*    */     }
/*    */     
/* 44 */     return sb.append("}").toString();
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/ModuleInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */