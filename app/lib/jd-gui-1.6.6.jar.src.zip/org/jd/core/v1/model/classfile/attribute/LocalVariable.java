/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVariable
/*    */ {
/*    */   protected int startPc;
/*    */   protected int length;
/*    */   protected String name;
/*    */   protected String descriptor;
/*    */   protected int index;
/*    */   
/*    */   public LocalVariable(int startPc, int length, String name, String descriptor, int index) {
/* 18 */     this.startPc = startPc;
/* 19 */     this.length = length;
/* 20 */     this.name = name;
/* 21 */     this.descriptor = descriptor;
/* 22 */     this.index = index;
/*    */   }
/*    */   
/*    */   public int getStartPc() {
/* 26 */     return this.startPc;
/*    */   }
/*    */   
/*    */   public int getLength() {
/* 30 */     return this.length;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 34 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getDescriptor() {
/* 38 */     return this.descriptor;
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 42 */     return this.index;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 47 */     StringBuilder sb = new StringBuilder();
/*    */     
/* 49 */     sb.append("LocalVariable{index=").append(this.index);
/* 50 */     sb.append(", name=").append(this.name);
/* 51 */     sb.append(", descriptor=").append(this.descriptor);
/* 52 */     sb.append(", startPc=").append(this.startPc);
/* 53 */     sb.append(", length=").append(this.length);
/*    */     
/* 55 */     return sb.append("}").toString();
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/LocalVariable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */