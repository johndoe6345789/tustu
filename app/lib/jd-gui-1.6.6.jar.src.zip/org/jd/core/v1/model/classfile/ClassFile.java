/*    */ package org.jd.core.v1.model.classfile;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.jd.core.v1.model.classfile.attribute.Attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassFile
/*    */ {
/*    */   protected int majorVersion;
/*    */   protected int minorVersion;
/*    */   protected int accessFlags;
/*    */   protected String internalTypeName;
/*    */   protected String superTypeName;
/*    */   protected String[] interfaceTypeNames;
/*    */   protected Field[] fields;
/*    */   protected Method[] methods;
/*    */   protected Map<String, Attribute> attributes;
/*    */   protected ClassFile outerClassFile;
/*    */   protected List<ClassFile> innerClassFiles;
/*    */   
/*    */   public ClassFile(int majorVersion, int minorVersion, int accessFlags, String internalTypeName, String superTypeName, String[] interfaceTypeNames, Field[] fields, Method[] methods, Map<String, Attribute> attributes) {
/* 31 */     this.majorVersion = majorVersion;
/* 32 */     this.minorVersion = minorVersion;
/* 33 */     this.accessFlags = accessFlags;
/* 34 */     this.internalTypeName = internalTypeName;
/* 35 */     this.superTypeName = superTypeName;
/* 36 */     this.interfaceTypeNames = interfaceTypeNames;
/* 37 */     this.fields = fields;
/* 38 */     this.methods = methods;
/* 39 */     this.attributes = attributes;
/*    */   }
/*    */   
/*    */   public int getMinorVersion() {
/* 43 */     return this.minorVersion;
/*    */   }
/*    */   public int getMajorVersion() {
/* 46 */     return this.majorVersion;
/*    */   }
/*    */   
/*    */   public int getAccessFlags() {
/* 50 */     return this.accessFlags;
/*    */   }
/*    */   public void setAccessFlags(int accessFlags) {
/* 53 */     this.accessFlags = accessFlags;
/*    */   }
/*    */   
/*    */   public String getInternalTypeName() {
/* 57 */     return this.internalTypeName;
/*    */   }
/*    */   
/*    */   public String getSuperTypeName() {
/* 61 */     return this.superTypeName;
/*    */   }
/*    */   
/*    */   public String[] getInterfaceTypeNames() {
/* 65 */     return this.interfaceTypeNames;
/*    */   }
/*    */   
/*    */   public Field[] getFields() {
/* 69 */     return this.fields;
/*    */   }
/*    */   
/*    */   public Method[] getMethods() {
/* 73 */     return this.methods;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends Attribute> T getAttribute(String name) {
/* 78 */     return (this.attributes == null) ? null : (T)this.attributes.get(name);
/*    */   }
/*    */   
/*    */   public ClassFile getOuterClassFile() {
/* 82 */     return this.outerClassFile;
/*    */   }
/*    */   
/*    */   public void setOuterClassFile(ClassFile outerClassFile) {
/* 86 */     this.outerClassFile = outerClassFile;
/*    */   }
/*    */   
/*    */   public List<ClassFile> getInnerClassFiles() {
/* 90 */     return this.innerClassFiles;
/*    */   }
/*    */   
/*    */   public void setInnerClassFiles(List<ClassFile> innerClassFiles) {
/* 94 */     this.innerClassFiles = innerClassFiles;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 99 */     return "ClassFile{" + this.internalTypeName + "}";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/ClassFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */