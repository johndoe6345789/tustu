/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BootstrapMethod
/*    */ {
/*    */   protected int bootstrapMethodRef;
/*    */   protected int[] bootstrapArguments;
/*    */   
/*    */   public BootstrapMethod(int bootstrapMethodRef, int[] bootstrapArguments) {
/* 15 */     this.bootstrapMethodRef = bootstrapMethodRef;
/* 16 */     this.bootstrapArguments = bootstrapArguments;
/*    */   }
/*    */   
/*    */   public int getBootstrapMethodRef() {
/* 20 */     return this.bootstrapMethodRef;
/*    */   }
/*    */   
/*    */   public int[] getBootstrapArguments() {
/* 24 */     return this.bootstrapArguments;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/BootstrapMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */