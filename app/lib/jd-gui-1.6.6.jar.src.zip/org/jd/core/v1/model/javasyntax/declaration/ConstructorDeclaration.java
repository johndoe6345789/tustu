/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import org.jd.core.v1.model.javasyntax.reference.BaseAnnotationReference;
/*    */ import org.jd.core.v1.model.javasyntax.statement.BaseStatement;
/*    */ import org.jd.core.v1.model.javasyntax.type.BaseType;
/*    */ import org.jd.core.v1.model.javasyntax.type.BaseTypeParameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstructorDeclaration
/*    */   implements MemberDeclaration
/*    */ {
/*    */   protected BaseAnnotationReference annotationReferences;
/*    */   protected int flags;
/*    */   protected BaseTypeParameter typeParameters;
/*    */   protected BaseFormalParameter formalParameters;
/*    */   protected BaseType exceptionTypes;
/*    */   protected String descriptor;
/*    */   protected BaseStatement statements;
/*    */   
/*    */   public ConstructorDeclaration(int flags, BaseFormalParameter formalParameters, String descriptor, BaseStatement statements) {
/* 25 */     this.flags = flags;
/* 26 */     this.formalParameters = formalParameters;
/* 27 */     this.descriptor = descriptor;
/* 28 */     this.statements = statements;
/*    */   }
/*    */   
/*    */   public ConstructorDeclaration(BaseAnnotationReference annotationReferences, int flags, BaseTypeParameter typeParameters, BaseFormalParameter formalParameters, BaseType exceptionTypes, String descriptor, BaseStatement statements) {
/* 32 */     this.annotationReferences = annotationReferences;
/* 33 */     this.flags = flags;
/* 34 */     this.typeParameters = typeParameters;
/* 35 */     this.formalParameters = formalParameters;
/* 36 */     this.exceptionTypes = exceptionTypes;
/* 37 */     this.descriptor = descriptor;
/* 38 */     this.statements = statements;
/*    */   }
/*    */   
/*    */   public int getFlags() {
/* 42 */     return this.flags;
/*    */   }
/*    */   
/*    */   public BaseAnnotationReference getAnnotationReferences() {
/* 46 */     return this.annotationReferences;
/*    */   }
/*    */   
/*    */   public BaseTypeParameter getTypeParameters() {
/* 50 */     return this.typeParameters;
/*    */   }
/*    */   
/*    */   public BaseFormalParameter getFormalParameters() {
/* 54 */     return this.formalParameters;
/*    */   }
/*    */   
/*    */   public BaseType getExceptionTypes() {
/* 58 */     return this.exceptionTypes;
/*    */   }
/*    */   
/*    */   public String getDescriptor() {
/* 62 */     return this.descriptor;
/*    */   }
/*    */   
/*    */   public BaseStatement getStatements() {
/* 66 */     return this.statements;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 71 */     visitor.visit(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 76 */     return "ConstructorDeclaration{" + this.descriptor + "}";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/ConstructorDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */