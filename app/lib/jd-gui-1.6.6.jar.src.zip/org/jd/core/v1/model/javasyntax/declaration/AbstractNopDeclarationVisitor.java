package org.jd.core.v1.model.javasyntax.declaration;

public abstract class AbstractNopDeclarationVisitor implements DeclarationVisitor {
  public void visit(AnnotationDeclaration declaration) {}
  
  public void visit(ArrayVariableInitializer declaration) {}
  
  public void visit(BodyDeclaration declaration) {}
  
  public void visit(ClassDeclaration declaration) {}
  
  public void visit(ConstructorDeclaration declaration) {}
  
  public void visit(EnumDeclaration declaration) {}
  
  public void visit(EnumDeclaration.Constant declaration) {}
  
  public void visit(ExpressionVariableInitializer declaration) {}
  
  public void visit(FieldDeclaration declaration) {}
  
  public void visit(FieldDeclarator declaration) {}
  
  public void visit(FieldDeclarators declarations) {}
  
  public void visit(FormalParameter declaration) {}
  
  public void visit(FormalParameters declarations) {}
  
  public void visit(InstanceInitializerDeclaration declaration) {}
  
  public void visit(InterfaceDeclaration declaration) {}
  
  public void visit(LocalVariableDeclaration declaration) {}
  
  public void visit(LocalVariableDeclarator declarator) {}
  
  public void visit(LocalVariableDeclarators declarators) {}
  
  public void visit(MemberDeclarations declarations) {}
  
  public void visit(MethodDeclaration declaration) {}
  
  public void visit(ModuleDeclaration declarations) {}
  
  public void visit(StaticInitializerDeclaration declaration) {}
  
  public void visit(TypeDeclarations declaration) {}
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/AbstractNopDeclarationVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */