/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import org.jd.core.v1.model.javasyntax.reference.BaseAnnotationReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationDeclaration
/*    */   extends TypeDeclaration
/*    */ {
/*    */   protected BaseFieldDeclarator annotationDeclarators;
/*    */   
/*    */   public AnnotationDeclaration(BaseAnnotationReference annotationReferences, int flags, String internalName, String name, BaseFieldDeclarator annotationDeclarators, BodyDeclaration bodyDeclaration) {
/* 16 */     super(annotationReferences, flags, internalName, name, bodyDeclaration);
/* 17 */     this.annotationDeclarators = annotationDeclarators;
/*    */   }
/*    */   
/*    */   public BaseFieldDeclarator getAnnotationDeclarators() {
/* 21 */     return this.annotationDeclarators;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 26 */     visitor.visit(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 31 */     return "AnnotationDeclaration{" + this.internalTypeName + "}";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/AnnotationDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */