/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ import org.jd.core.v1.model.fragment.SpacerBetweenMovableBlocksFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpacerBetweenMembersFragment
/*    */   extends SpacerBetweenMovableBlocksFragment
/*    */   implements JavaFragment
/*    */ {
/*    */   public SpacerBetweenMembersFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label) {
/* 15 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 20 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javafragment/SpacerBetweenMembersFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */