/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InnerClass
/*    */ {
/*    */   protected String innerTypeName;
/*    */   protected String outerTypeName;
/*    */   protected String innerName;
/*    */   protected int innerAccessFlags;
/*    */   
/*    */   public InnerClass(String innerTypeName, String outerTypeName, String innerName, int innerAccessFlags) {
/* 17 */     this.innerTypeName = innerTypeName;
/* 18 */     this.outerTypeName = outerTypeName;
/* 19 */     this.innerName = innerName;
/* 20 */     this.innerAccessFlags = innerAccessFlags;
/*    */   }
/*    */   
/*    */   public String getInnerTypeName() {
/* 24 */     return this.innerTypeName;
/*    */   }
/*    */   
/*    */   public String getOuterTypeName() {
/* 28 */     return this.outerTypeName;
/*    */   }
/*    */   
/*    */   public String getInnerName() {
/* 32 */     return this.innerName;
/*    */   }
/*    */   
/*    */   public int getInnerAccessFlags() {
/* 36 */     return this.innerAccessFlags;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/InnerClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */