/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeModulePackages
/*    */   implements Attribute
/*    */ {
/*    */   protected String[] packageNames;
/*    */   
/*    */   public AttributeModulePackages(String[] packageNames) {
/* 14 */     this.packageNames = packageNames;
/*    */   }
/*    */   
/*    */   public String[] getPackageNames() {
/* 18 */     return this.packageNames;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/AttributeModulePackages.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */