/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeSourceFile
/*    */   implements Attribute
/*    */ {
/*    */   protected String sourceFile;
/*    */   
/*    */   public AttributeSourceFile(String sourceFile) {
/* 14 */     this.sourceFile = sourceFile;
/*    */   }
/*    */   
/*    */   public String getSourceFile() {
/* 18 */     return this.sourceFile;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/AttributeSourceFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */