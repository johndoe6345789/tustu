/*    */ package org.jd.core.v1.model.fragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndMovableBlockFragment
/*    */   extends FlexibleFragment
/*    */ {
/*    */   public EndMovableBlockFragment() {
/* 12 */     super(0, 0, 0, 0, "End movable block");
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 17 */     return "{end-movable-block}";
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(FragmentVisitor visitor) {
/* 22 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/fragment/EndMovableBlockFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */