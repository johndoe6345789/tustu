/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ConstantValue
/*    */   extends Constant
/*    */ {
/*    */   protected ConstantValue(byte tag) {
/* 12 */     super(tag);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/constant/ConstantValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */