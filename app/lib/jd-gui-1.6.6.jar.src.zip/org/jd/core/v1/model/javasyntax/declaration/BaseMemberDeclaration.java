package org.jd.core.v1.model.javasyntax.declaration;

import org.jd.core.v1.util.Base;

public interface BaseMemberDeclaration extends Declaration, Base<MemberDeclaration> {}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/BaseMemberDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */