/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import org.jd.core.v1.model.javasyntax.reference.BaseAnnotationReference;
/*    */ import org.jd.core.v1.model.javasyntax.type.BaseType;
/*    */ import org.jd.core.v1.model.javasyntax.type.BaseTypeParameter;
/*    */ import org.jd.core.v1.model.javasyntax.type.ObjectType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassDeclaration
/*    */   extends InterfaceDeclaration
/*    */ {
/*    */   protected ObjectType superType;
/*    */   
/*    */   public ClassDeclaration(int flags, String internalName, String name, BodyDeclaration bodyDeclaration) {
/* 19 */     super((BaseAnnotationReference)null, flags, internalName, name, (BaseTypeParameter)null, (BaseType)null, bodyDeclaration);
/*    */   }
/*    */   
/*    */   public ClassDeclaration(BaseAnnotationReference annotationReferences, int flags, String internalName, String name, BaseTypeParameter typeParameters, ObjectType superType, BaseType interfaces, BodyDeclaration bodyDeclaration) {
/* 23 */     super(annotationReferences, flags, internalName, name, typeParameters, interfaces, bodyDeclaration);
/* 24 */     this.superType = superType;
/*    */   }
/*    */   
/*    */   public ObjectType getSuperType() {
/* 28 */     return this.superType;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 33 */     visitor.visit(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 38 */     return "ClassDeclaration{" + this.internalTypeName + "}";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/ClassDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */