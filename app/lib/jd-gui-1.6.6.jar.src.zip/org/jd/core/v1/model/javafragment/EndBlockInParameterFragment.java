/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndBlockInParameterFragment
/*    */   extends EndBlockFragment
/*    */   implements JavaFragment
/*    */ {
/*    */   public EndBlockInParameterFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label, StartBlockFragment start) {
/* 12 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label, start);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 17 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javafragment/EndBlockInParameterFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */