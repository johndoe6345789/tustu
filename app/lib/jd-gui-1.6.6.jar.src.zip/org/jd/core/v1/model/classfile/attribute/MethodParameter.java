/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodParameter
/*    */ {
/*    */   protected String name;
/*    */   protected int access;
/*    */   
/*    */   public MethodParameter(String name, int access) {
/* 15 */     this.name = name;
/* 16 */     this.access = access;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 20 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getAccess() {
/* 24 */     return this.access;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 29 */     StringBuilder sb = new StringBuilder();
/*    */     
/* 31 */     sb.append("Parameter{name=").append(this.name);
/* 32 */     sb.append(", access=").append(this.access);
/*    */     
/* 34 */     return sb.append("}").toString();
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/MethodParameter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */