/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import org.jd.core.v1.model.javasyntax.reference.BaseAnnotationReference;
/*    */ import org.jd.core.v1.model.javasyntax.type.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldDeclaration
/*    */   implements MemberDeclaration
/*    */ {
/*    */   protected BaseAnnotationReference annotationReferences;
/*    */   protected int flags;
/*    */   protected Type type;
/*    */   protected BaseFieldDeclarator fieldDeclarators;
/*    */   
/*    */   public FieldDeclaration(int flags, Type type, BaseFieldDeclarator fieldDeclarators) {
/* 20 */     this.flags = flags;
/* 21 */     this.type = type;
/* 22 */     this.fieldDeclarators = fieldDeclarators;
/* 23 */     fieldDeclarators.setFieldDeclaration(this);
/*    */   }
/*    */   
/*    */   public FieldDeclaration(BaseAnnotationReference annotationReferences, int flags, Type type, BaseFieldDeclarator fieldDeclarators) {
/* 27 */     this.flags = flags;
/* 28 */     this.annotationReferences = annotationReferences;
/* 29 */     this.type = type;
/* 30 */     this.fieldDeclarators = fieldDeclarators;
/* 31 */     fieldDeclarators.setFieldDeclaration(this);
/*    */   }
/*    */   
/*    */   public int getFlags() {
/* 35 */     return this.flags;
/*    */   }
/*    */   
/*    */   public BaseAnnotationReference getAnnotationReferences() {
/* 39 */     return this.annotationReferences;
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 43 */     return this.type;
/*    */   }
/*    */   
/*    */   public BaseFieldDeclarator getFieldDeclarators() {
/* 47 */     return this.fieldDeclarators;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 52 */     if (this == o) return true; 
/* 53 */     if (!(o instanceof FieldDeclaration)) return false;
/*    */     
/* 55 */     FieldDeclaration that = (FieldDeclaration)o;
/*    */     
/* 57 */     if (this.flags != that.flags) return false; 
/* 58 */     if ((this.annotationReferences != null) ? !this.annotationReferences.equals(that.annotationReferences) : (that.annotationReferences != null))
/* 59 */       return false; 
/* 60 */     if (!this.fieldDeclarators.equals(that.fieldDeclarators)) return false; 
/* 61 */     if (!this.type.equals(that.type)) return false;
/*    */     
/* 63 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 68 */     int result = 327494460 + this.flags;
/* 69 */     result = 31 * result + ((this.annotationReferences != null) ? this.annotationReferences.hashCode() : 0);
/* 70 */     result = 31 * result + this.type.hashCode();
/* 71 */     result = 31 * result + this.fieldDeclarators.hashCode();
/* 72 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 77 */     visitor.visit(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 82 */     return "FieldDeclaration{" + this.type + " " + this.fieldDeclarators + "}";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/FieldDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */