/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LineNumber
/*    */ {
/*    */   protected int startPc;
/*    */   protected int lineNumber;
/*    */   
/*    */   public LineNumber(int startPc, int lineNumber) {
/* 15 */     this.startPc = startPc;
/* 16 */     this.lineNumber = lineNumber;
/*    */   }
/*    */   
/*    */   public int getStartPc() {
/* 20 */     return this.startPc;
/*    */   }
/*    */   
/*    */   public int getLineNumber() {
/* 24 */     return this.lineNumber;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 29 */     return "LineNumber{startPc=" + this.startPc + ", lineNumber=" + this.lineNumber + "}";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/LineNumber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */