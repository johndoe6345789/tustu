/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Annotations
/*    */   implements Attribute
/*    */ {
/*    */   protected Annotation[] annotations;
/*    */   
/*    */   public Annotations(Annotation[] annotations) {
/* 14 */     this.annotations = annotations;
/*    */   }
/*    */   
/*    */   public Annotation[] getAnnotations() {
/* 18 */     return this.annotations;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/Annotations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */