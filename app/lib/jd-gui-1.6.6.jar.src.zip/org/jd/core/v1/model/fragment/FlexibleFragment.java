/*    */ package org.jd.core.v1.model.fragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FlexibleFragment
/*    */   implements Fragment
/*    */ {
/*    */   protected final int minimalLineCount;
/*    */   protected int maximalLineCount;
/*    */   protected int initialLineCount;
/*    */   protected int lineCount;
/*    */   protected final int weight;
/*    */   protected final String label;
/*    */   
/*    */   public FlexibleFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label) {
/* 19 */     this.minimalLineCount = minimalLineCount;
/* 20 */     this.maximalLineCount = maximalLineCount;
/* 21 */     this.initialLineCount = this.lineCount = lineCount;
/* 22 */     this.weight = weight;
/* 23 */     this.label = label;
/*    */   }
/*    */   
/*    */   public void resetLineCount() {
/* 27 */     this.lineCount = this.initialLineCount;
/*    */   }
/*    */   
/*    */   public int getMinimalLineCount() {
/* 31 */     return this.minimalLineCount;
/*    */   }
/*    */   
/*    */   public int getMaximalLineCount() {
/* 35 */     return this.maximalLineCount;
/*    */   }
/*    */   
/*    */   public int getInitialLineCount() {
/* 39 */     return this.initialLineCount;
/*    */   }
/*    */   
/*    */   public int getLineCount() {
/* 43 */     return this.lineCount;
/*    */   }
/*    */   
/*    */   public int getWeight() {
/* 47 */     return this.weight;
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 51 */     return this.label;
/*    */   }
/*    */   
/*    */   public boolean incLineCount(boolean force) {
/* 55 */     if (this.lineCount < this.maximalLineCount) {
/* 56 */       this.lineCount++;
/* 57 */       return true;
/*    */     } 
/* 59 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean decLineCount(boolean force) {
/* 64 */     if (this.lineCount > this.minimalLineCount) {
/* 65 */       this.lineCount--;
/* 66 */       return true;
/*    */     } 
/* 68 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 74 */     return "{minimal-line-count=" + getMinimalLineCount() + ", maximal-line-count=" + 
/* 75 */       getMaximalLineCount() + ", initial-line-count=" + 
/* 76 */       getInitialLineCount() + ", line-count=" + 
/* 77 */       getLineCount() + ", weight=" + 
/* 78 */       getWeight() + (
/* 79 */       (getLabel() != null) ? (", label='" + this.label + "'}") : "}");
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(FragmentVisitor visitor) {
/* 84 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/fragment/FlexibleFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */