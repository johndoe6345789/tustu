/*    */ package org.jd.core.v1.model.classfile;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.jd.core.v1.model.classfile.attribute.Attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Method
/*    */ {
/*    */   protected int accessFlags;
/*    */   protected String name;
/*    */   protected String descriptor;
/*    */   protected Map<String, Attribute> attributes;
/*    */   protected ConstantPool constants;
/*    */   
/*    */   public Method(int accessFlags, String name, String descriptor, Map<String, Attribute> attributes, ConstantPool constants) {
/* 22 */     this.accessFlags = accessFlags;
/* 23 */     this.name = name;
/* 24 */     this.descriptor = descriptor;
/* 25 */     this.attributes = attributes;
/* 26 */     this.constants = constants;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getAccessFlags() {
/* 33 */     return this.accessFlags;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 37 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getDescriptor() {
/* 41 */     return this.descriptor;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends Attribute> T getAttribute(String name) {
/* 46 */     return (this.attributes == null) ? null : (T)this.attributes.get(name);
/*    */   }
/*    */   
/*    */   public ConstantPool getConstants() {
/* 50 */     return this.constants;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 55 */     return "Method{" + this.name + " " + this.descriptor + "}";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/Method.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */