/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Annotation
/*    */ {
/*    */   protected String descriptor;
/*    */   protected ElementValuePair[] elementValuePairs;
/*    */   
/*    */   public Annotation(String descriptor, ElementValuePair[] elementValuePairs) {
/* 15 */     this.descriptor = descriptor;
/* 16 */     this.elementValuePairs = elementValuePairs;
/*    */   }
/*    */   
/*    */   public String getDescriptor() {
/* 20 */     return this.descriptor;
/*    */   }
/*    */   
/*    */   public ElementValuePair[] getElementValuePairs() {
/* 24 */     return this.elementValuePairs;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/Annotation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */