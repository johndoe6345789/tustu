/*    */ package org.jd.core.v1.model.fragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EndFlexibleBlockFragment
/*    */   extends StartFlexibleBlockFragment
/*    */ {
/*    */   protected EndFlexibleBlockFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label) {
/* 12 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(FragmentVisitor visitor) {
/* 17 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/fragment/EndFlexibleBlockFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */