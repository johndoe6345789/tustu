/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BodyDeclaration
/*    */   implements Declaration
/*    */ {
/*    */   protected String internalTypeName;
/*    */   protected BaseMemberDeclaration memberDeclarations;
/*    */   
/*    */   public BodyDeclaration(String internalTypeName, BaseMemberDeclaration memberDeclarations) {
/* 15 */     this.internalTypeName = internalTypeName;
/* 16 */     this.memberDeclarations = memberDeclarations;
/*    */   }
/*    */   
/*    */   public String getInternalTypeName() {
/* 20 */     return this.internalTypeName;
/*    */   }
/*    */   
/*    */   public BaseMemberDeclaration getMemberDeclarations() {
/* 24 */     return this.memberDeclarations;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 29 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/BodyDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */