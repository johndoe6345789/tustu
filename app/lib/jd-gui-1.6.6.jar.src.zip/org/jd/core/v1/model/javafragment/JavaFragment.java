package org.jd.core.v1.model.javafragment;

public interface JavaFragment {
  void accept(JavaFragmentVisitor paramJavaFragmentVisitor);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javafragment/JavaFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */