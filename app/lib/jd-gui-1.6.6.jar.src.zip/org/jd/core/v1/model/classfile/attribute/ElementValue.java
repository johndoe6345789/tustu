package org.jd.core.v1.model.classfile.attribute;

public interface ElementValue {
  void accept(ElementValueVisitor paramElementValueVisitor);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/ElementValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */