/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantUtf8
/*    */   extends ConstantValue
/*    */ {
/*    */   protected String value;
/*    */   
/*    */   public ConstantUtf8(String value) {
/* 14 */     super((byte)1);
/* 15 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 19 */     return this.value;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/constant/ConstantUtf8.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */