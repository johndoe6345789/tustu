/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ import org.jd.core.v1.model.fragment.FlexibleFragment;
/*    */ import org.jd.core.v1.model.fragment.StartFlexibleBlockFragment;
/*    */ import org.jd.core.v1.util.DefaultList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StartStatementsBlockFragment
/*    */   extends StartFlexibleBlockFragment
/*    */   implements JavaFragment
/*    */ {
/*    */   protected Group group;
/*    */   
/*    */   public StartStatementsBlockFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label) {
/* 18 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label);
/* 19 */     this.group = new Group(this);
/*    */   }
/*    */   
/*    */   public StartStatementsBlockFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label, Group group) {
/* 23 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label);
/* 24 */     this.group = group;
/* 25 */     group.add(this);
/*    */   }
/*    */   
/*    */   public Group getGroup() {
/* 29 */     return this.group;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 34 */     visitor.visit(this);
/*    */   }
/*    */   
/*    */   public static class Group {
/* 38 */     protected DefaultList<FlexibleFragment> fragments = new DefaultList<>();
/* 39 */     protected int minimalLineCount = Integer.MAX_VALUE;
/*    */     
/*    */     Group(FlexibleFragment fragment) {
/* 42 */       this.fragments.add(fragment);
/*    */     }
/*    */     
/*    */     void add(FlexibleFragment fragment) {
/* 46 */       this.fragments.add(fragment);
/*    */     }
/*    */     
/*    */     public int getMinimalLineCount() {
/* 50 */       if (this.minimalLineCount == Integer.MAX_VALUE) {
/* 51 */         for (FlexibleFragment fragment : this.fragments) {
/* 52 */           if (this.minimalLineCount > fragment.getLineCount()) {
/* 53 */             this.minimalLineCount = fragment.getLineCount();
/*    */           }
/*    */         } 
/*    */       }
/* 57 */       return this.minimalLineCount;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javafragment/StartStatementsBlockFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */