/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PackageInfo
/*    */ {
/*    */   protected String internalName;
/*    */   protected int flags;
/*    */   protected String[] moduleInfoNames;
/*    */   
/*    */   public PackageInfo(String internalName, int flags, String[] moduleInfoNames) {
/* 16 */     this.internalName = internalName;
/* 17 */     this.flags = flags;
/* 18 */     this.moduleInfoNames = moduleInfoNames;
/*    */   }
/*    */   
/*    */   public String getInternalName() {
/* 22 */     return this.internalName;
/*    */   }
/*    */   
/*    */   public int getFlags() {
/* 26 */     return this.flags;
/*    */   }
/*    */   
/*    */   public String[] getModuleInfoNames() {
/* 30 */     return this.moduleInfoNames;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     StringBuilder sb = new StringBuilder();
/*    */     
/* 37 */     sb.append("PackageInfo{internalName=").append(this.internalName);
/* 38 */     sb.append(", flags=").append(this.flags);
/*    */     
/* 40 */     if (this.moduleInfoNames != null) {
/* 41 */       sb.append(", moduleInfoNames=").append(this.moduleInfoNames);
/*    */     }
/*    */     
/* 44 */     return sb.append("}").toString();
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/PackageInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */