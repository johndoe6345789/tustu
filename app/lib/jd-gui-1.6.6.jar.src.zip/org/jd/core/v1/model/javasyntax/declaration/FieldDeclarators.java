/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.jd.core.v1.util.DefaultList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldDeclarators
/*    */   extends DefaultList<FieldDeclarator>
/*    */   implements BaseFieldDeclarator
/*    */ {
/*    */   public FieldDeclarators() {}
/*    */   
/*    */   public FieldDeclarators(int capacity) {
/* 18 */     super(capacity);
/*    */   }
/*    */   
/*    */   public FieldDeclarators(Collection<FieldDeclarator> collection) {
/* 22 */     super(collection);
/* 23 */     assert collection != null && collection.size() > 1 : "Uses 'FieldDeclarator' instead";
/*    */   }
/*    */ 
/*    */   
/*    */   public FieldDeclarators(FieldDeclarator declarator, FieldDeclarator... declarators) {
/* 28 */     super(declarator, declarators);
/* 29 */     assert declarators != null && declarators.length > 0 : "Uses 'FieldDeclarator' instead";
/*    */   }
/*    */ 
/*    */   
/*    */   public void setFieldDeclaration(FieldDeclaration fieldDeclaration) {
/* 34 */     for (FieldDeclarator fieldDeclarator : this) {
/* 35 */       fieldDeclarator.setFieldDeclaration(fieldDeclaration);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 41 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/FieldDeclarators.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */