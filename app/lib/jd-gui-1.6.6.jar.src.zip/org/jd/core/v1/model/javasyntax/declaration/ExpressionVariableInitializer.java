/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ import org.jd.core.v1.model.javasyntax.expression.Expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpressionVariableInitializer
/*    */   implements VariableInitializer
/*    */ {
/*    */   protected Expression expression;
/*    */   
/*    */   public ExpressionVariableInitializer(Expression expression) {
/* 16 */     this.expression = expression;
/*    */   }
/*    */   
/*    */   public Expression getExpression() {
/* 20 */     return this.expression;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getLineNumber() {
/* 25 */     return this.expression.getLineNumber();
/*    */   }
/*    */   
/*    */   public void setExpression(Expression expression) {
/* 29 */     this.expression = expression;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 34 */     if (this == o) return true; 
/* 35 */     if (!(o instanceof ExpressionVariableInitializer)) return false;
/*    */     
/* 37 */     ExpressionVariableInitializer that = (ExpressionVariableInitializer)o;
/*    */     
/* 39 */     if ((this.expression != null) ? !this.expression.equals(that.expression) : (that.expression != null)) return false;
/*    */     
/* 41 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 46 */     return 25107399 + ((this.expression != null) ? this.expression.hashCode() : 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 51 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/ExpressionVariableInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */