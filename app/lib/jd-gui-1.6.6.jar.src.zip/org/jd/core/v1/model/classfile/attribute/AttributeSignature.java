/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeSignature
/*    */   implements Attribute
/*    */ {
/*    */   protected String signature;
/*    */   
/*    */   public AttributeSignature(String signature) {
/* 14 */     this.signature = signature;
/*    */   }
/*    */   
/*    */   public String getSignature() {
/* 18 */     return this.signature;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 23 */     return "AttributeSignature{signature=" + this.signature + "}";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/AttributeSignature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */