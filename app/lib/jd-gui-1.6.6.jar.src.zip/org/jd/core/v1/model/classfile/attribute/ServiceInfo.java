/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServiceInfo
/*    */ {
/*    */   protected String interfaceTypeName;
/*    */   protected String[] implementationTypeNames;
/*    */   
/*    */   public ServiceInfo(String interfaceTypeName, String[] implementationTypeNames) {
/* 15 */     this.interfaceTypeName = interfaceTypeName;
/* 16 */     this.implementationTypeNames = implementationTypeNames;
/*    */   }
/*    */   
/*    */   public String getInterfaceTypeName() {
/* 20 */     return this.interfaceTypeName;
/*    */   }
/*    */   
/*    */   public String[] getImplementationTypeNames() {
/* 24 */     return this.implementationTypeNames;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 29 */     StringBuilder sb = new StringBuilder();
/*    */     
/* 31 */     sb.append("ServiceInfo{interfaceTypeName=").append(this.interfaceTypeName);
/*    */     
/* 33 */     if (this.implementationTypeNames != null) {
/* 34 */       sb.append(", implementationTypeNames=").append(this.implementationTypeNames);
/*    */     }
/*    */     
/* 37 */     return sb.append("}").toString();
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/ServiceInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */