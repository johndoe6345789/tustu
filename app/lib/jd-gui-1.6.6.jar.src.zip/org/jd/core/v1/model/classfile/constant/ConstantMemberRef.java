/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantMemberRef
/*    */   extends Constant
/*    */ {
/*    */   protected int classIndex;
/*    */   protected int nameAndTypeIndex;
/*    */   
/*    */   public ConstantMemberRef(int classIndex, int nameAndTypeIndex) {
/* 18 */     super((byte)19);
/* 19 */     this.classIndex = classIndex;
/* 20 */     this.nameAndTypeIndex = nameAndTypeIndex;
/*    */   }
/*    */   
/*    */   public int getClassIndex() {
/* 24 */     return this.classIndex;
/*    */   }
/*    */   
/*    */   public int getNameAndTypeIndex() {
/* 28 */     return this.nameAndTypeIndex;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/constant/ConstantMemberRef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */