/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElementValueAnnotationValue
/*    */   implements ElementValue
/*    */ {
/*    */   protected Annotation annotationValue;
/*    */   
/*    */   public ElementValueAnnotationValue(Annotation annotationValue) {
/* 14 */     this.annotationValue = annotationValue;
/*    */   }
/*    */   
/*    */   public Annotation getAnnotationValue() {
/* 18 */     return this.annotationValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(ElementValueVisitor visitor) {
/* 23 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/ElementValueAnnotationValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */