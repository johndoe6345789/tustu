/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Constant
/*    */ {
/*    */   public static final byte CONSTANT_Unknown = 0;
/*    */   public static final byte CONSTANT_Utf8 = 1;
/*    */   public static final byte CONSTANT_Integer = 3;
/*    */   public static final byte CONSTANT_Float = 4;
/*    */   public static final byte CONSTANT_Long = 5;
/*    */   public static final byte CONSTANT_Double = 6;
/*    */   public static final byte CONSTANT_Class = 7;
/*    */   public static final byte CONSTANT_String = 8;
/*    */   public static final byte CONSTANT_FieldRef = 9;
/*    */   public static final byte CONSTANT_MethodRef = 10;
/*    */   public static final byte CONSTANT_InterfaceMethodRef = 11;
/*    */   public static final byte CONSTANT_NameAndType = 12;
/*    */   public static final byte CONSTANT_MethodHandle = 15;
/*    */   public static final byte CONSTANT_MethodType = 16;
/*    */   public static final byte CONSTANT_InvokeDynamic = 18;
/*    */   public static final byte CONSTANT_MemberRef = 19;
/*    */   protected byte tag;
/*    */   
/*    */   public Constant(byte tag) {
/* 31 */     this.tag = tag;
/*    */   }
/*    */   
/*    */   public byte getTag() {
/* 35 */     return this.tag;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/constant/Constant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */