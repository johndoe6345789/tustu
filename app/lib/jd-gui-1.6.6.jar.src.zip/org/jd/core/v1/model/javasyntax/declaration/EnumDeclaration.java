/*     */ package org.jd.core.v1.model.javasyntax.declaration;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.jd.core.v1.model.javasyntax.expression.BaseExpression;
/*     */ import org.jd.core.v1.model.javasyntax.reference.BaseAnnotationReference;
/*     */ import org.jd.core.v1.model.javasyntax.type.BaseType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnumDeclaration
/*     */   extends TypeDeclaration
/*     */ {
/*     */   protected BaseType interfaces;
/*     */   protected List<Constant> constants;
/*     */   
/*     */   public EnumDeclaration(int flags, String internalName, String name, List<Constant> constants, BodyDeclaration bodyDeclaration) {
/*  21 */     super(null, flags, internalName, name, bodyDeclaration);
/*  22 */     this.constants = constants;
/*     */   }
/*     */   
/*     */   public EnumDeclaration(BaseAnnotationReference annotationReferences, int flags, String internalName, String name, BaseType interfaces, List<Constant> constants, BodyDeclaration bodyDeclaration) {
/*  26 */     super(annotationReferences, flags, internalName, name, bodyDeclaration);
/*  27 */     this.interfaces = interfaces;
/*  28 */     this.constants = constants;
/*     */   }
/*     */   
/*     */   public BaseType getInterfaces() {
/*  32 */     return this.interfaces;
/*     */   }
/*     */   
/*     */   public List<Constant> getConstants() {
/*  36 */     return this.constants;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(DeclarationVisitor visitor) {
/*  41 */     visitor.visit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  46 */     return "EnumDeclaration{" + this.internalTypeName + "}";
/*     */   }
/*     */   
/*     */   public static class Constant implements Declaration {
/*     */     protected int lineNumber;
/*     */     protected BaseAnnotationReference annotationReferences;
/*     */     protected String name;
/*     */     protected BaseExpression arguments;
/*     */     protected BodyDeclaration bodyDeclaration;
/*     */     
/*     */     public Constant(String name) {
/*  57 */       this.name = name;
/*     */     }
/*     */     
/*     */     public Constant(int lineNumber, String name) {
/*  61 */       this.lineNumber = lineNumber;
/*  62 */       this.name = name;
/*     */     }
/*     */     
/*     */     public Constant(String name, BaseExpression arguments) {
/*  66 */       this.name = name;
/*  67 */       this.arguments = arguments;
/*     */     }
/*     */     
/*     */     public Constant(int lineNumber, String name, BaseExpression arguments) {
/*  71 */       this.lineNumber = lineNumber;
/*  72 */       this.name = name;
/*  73 */       this.arguments = arguments;
/*     */     }
/*     */     
/*     */     public Constant(int lineNumber, String name, BaseExpression arguments, BodyDeclaration bodyDeclaration) {
/*  77 */       this.lineNumber = lineNumber;
/*  78 */       this.name = name;
/*  79 */       this.arguments = arguments;
/*  80 */       this.bodyDeclaration = bodyDeclaration;
/*     */     }
/*     */     
/*     */     public Constant(int lineNumber, BaseAnnotationReference annotationReferences, String name, BaseExpression arguments, BodyDeclaration bodyDeclaration) {
/*  84 */       this.lineNumber = lineNumber;
/*  85 */       this.annotationReferences = annotationReferences;
/*  86 */       this.name = name;
/*  87 */       this.arguments = arguments;
/*  88 */       this.bodyDeclaration = bodyDeclaration;
/*     */     }
/*     */     
/*     */     public int getLineNumber() {
/*  92 */       return this.lineNumber;
/*     */     }
/*     */     
/*     */     public BaseAnnotationReference getAnnotationReferences() {
/*  96 */       return this.annotationReferences;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 100 */       return this.name;
/*     */     }
/*     */     
/*     */     public BaseExpression getArguments() {
/* 104 */       return this.arguments;
/*     */     }
/*     */     
/*     */     public void setArguments(BaseExpression arguments) {
/* 108 */       this.arguments = arguments;
/*     */     }
/*     */     
/*     */     public BodyDeclaration getBodyDeclaration() {
/* 112 */       return this.bodyDeclaration;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(DeclarationVisitor visitor) {
/* 117 */       visitor.visit(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/EnumDeclaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */