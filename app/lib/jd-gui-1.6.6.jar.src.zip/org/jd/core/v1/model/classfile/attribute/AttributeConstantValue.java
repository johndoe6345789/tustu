/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ import org.jd.core.v1.model.classfile.constant.ConstantValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeConstantValue
/*    */   implements Attribute
/*    */ {
/*    */   protected ConstantValue constantValue;
/*    */   
/*    */   public AttributeConstantValue(ConstantValue constantValue) {
/* 16 */     this.constantValue = constantValue;
/*    */   }
/*    */   
/*    */   public ConstantValue getConstantValue() {
/* 20 */     return this.constantValue;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/AttributeConstantValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */