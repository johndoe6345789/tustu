/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ import org.jd.core.v1.model.fragment.EndFlexibleBlockFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndStatementsBlockFragment
/*    */   extends EndFlexibleBlockFragment
/*    */   implements JavaFragment
/*    */ {
/*    */   protected final StartStatementsBlockFragment.Group group;
/*    */   
/*    */   public EndStatementsBlockFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label, StartStatementsBlockFragment.Group group) {
/* 16 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label);
/* 17 */     this.group = group;
/* 18 */     group.add(this);
/*    */   }
/*    */   
/*    */   public StartStatementsBlockFragment.Group getGroup() {
/* 22 */     return this.group;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 27 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javafragment/EndStatementsBlockFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */