/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ import org.jd.core.v1.model.fragment.EndMovableBlockFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndMovableJavaBlockFragment
/*    */   extends EndMovableBlockFragment
/*    */   implements JavaFragment
/*    */ {
/* 13 */   public static final EndMovableJavaBlockFragment END_MOVABLE_BLOCK = new EndMovableJavaBlockFragment();
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 17 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javafragment/EndMovableJavaBlockFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */