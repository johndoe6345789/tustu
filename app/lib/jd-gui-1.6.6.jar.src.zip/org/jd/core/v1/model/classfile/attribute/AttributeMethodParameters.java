/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeMethodParameters
/*    */   implements Attribute
/*    */ {
/*    */   protected MethodParameter[] parameters;
/*    */   
/*    */   public AttributeMethodParameters(MethodParameter[] parameters) {
/* 14 */     this.parameters = parameters;
/*    */   }
/*    */   
/*    */   public MethodParameter[] getParameters() {
/* 18 */     return this.parameters;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/AttributeMethodParameters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */