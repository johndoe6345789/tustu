/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeModule
/*    */   implements Attribute
/*    */ {
/*    */   protected String name;
/*    */   protected int flags;
/*    */   protected String version;
/*    */   protected ModuleInfo[] requires;
/*    */   protected PackageInfo[] exports;
/*    */   protected PackageInfo[] opens;
/*    */   protected String[] uses;
/*    */   protected ServiceInfo[] provides;
/*    */   
/*    */   public AttributeModule(String name, int flags, String version, ModuleInfo[] requires, PackageInfo[] exports, PackageInfo[] opens, String[] uses, ServiceInfo[] provides) {
/* 23 */     this.name = name;
/* 24 */     this.flags = flags;
/* 25 */     this.version = version;
/* 26 */     this.requires = requires;
/* 27 */     this.exports = exports;
/* 28 */     this.opens = opens;
/* 29 */     this.uses = uses;
/* 30 */     this.provides = provides;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 34 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getFlags() {
/* 38 */     return this.flags;
/*    */   }
/*    */   
/*    */   public String getVersion() {
/* 42 */     return this.version;
/*    */   }
/*    */   
/*    */   public ModuleInfo[] getRequires() {
/* 46 */     return this.requires;
/*    */   }
/*    */   
/*    */   public PackageInfo[] getExports() {
/* 50 */     return this.exports;
/*    */   }
/*    */   
/*    */   public PackageInfo[] getOpens() {
/* 54 */     return this.opens;
/*    */   }
/*    */   
/*    */   public String[] getUses() {
/* 58 */     return this.uses;
/*    */   }
/*    */   
/*    */   public ServiceInfo[] getProvides() {
/* 62 */     return this.provides;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/AttributeModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */