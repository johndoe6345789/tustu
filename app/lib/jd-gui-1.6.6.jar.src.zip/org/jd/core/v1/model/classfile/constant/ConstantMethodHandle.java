/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantMethodHandle
/*    */   extends Constant
/*    */ {
/*    */   protected int referenceKind;
/*    */   protected int referenceIndex;
/*    */   
/*    */   public ConstantMethodHandle(int referenceKind, int referenceIndex) {
/* 15 */     super((byte)15);
/* 16 */     this.referenceKind = referenceKind;
/* 17 */     this.referenceIndex = referenceIndex;
/*    */   }
/*    */   
/*    */   public int getReferenceKind() {
/* 21 */     return this.referenceKind;
/*    */   }
/*    */   
/*    */   public int getReferenceIndex() {
/* 25 */     return this.referenceIndex;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/constant/ConstantMethodHandle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */