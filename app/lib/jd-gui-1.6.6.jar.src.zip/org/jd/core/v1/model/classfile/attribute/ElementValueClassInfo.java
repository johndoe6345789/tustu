/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElementValueClassInfo
/*    */   implements ElementValue
/*    */ {
/*    */   protected String classInfo;
/*    */   
/*    */   public ElementValueClassInfo(String classInfo) {
/* 14 */     this.classInfo = classInfo;
/*    */   }
/*    */   
/*    */   public String getClassInfo() {
/* 18 */     return this.classInfo;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(ElementValueVisitor visitor) {
/* 23 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/ElementValueClassInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */