/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ import org.jd.core.v1.model.classfile.constant.ConstantValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElementValuePrimitiveType
/*    */   implements ElementValue
/*    */ {
/*    */   protected int type;
/*    */   protected ConstantValue constValue;
/*    */   
/*    */   public ElementValuePrimitiveType(int type, ConstantValue constValue) {
/* 20 */     this.type = type;
/* 21 */     this.constValue = constValue;
/*    */   }
/*    */   
/*    */   public int getType() {
/* 25 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends ConstantValue> T getConstValue() {
/* 30 */     return (T)this.constValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(ElementValueVisitor visitor) {
/* 35 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/ElementValuePrimitiveType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */