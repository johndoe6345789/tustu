package org.jd.core.v1.model.javafragment;

public interface JavaFragmentVisitor {
  void visit(EndBodyFragment paramEndBodyFragment);
  
  void visit(EndBlockInParameterFragment paramEndBlockInParameterFragment);
  
  void visit(EndBlockFragment paramEndBlockFragment);
  
  void visit(EndBodyInParameterFragment paramEndBodyInParameterFragment);
  
  void visit(EndMovableJavaBlockFragment paramEndMovableJavaBlockFragment);
  
  void visit(EndSingleStatementBlockFragment paramEndSingleStatementBlockFragment);
  
  void visit(EndStatementsBlockFragment paramEndStatementsBlockFragment);
  
  void visit(ImportsFragment paramImportsFragment);
  
  void visit(LineNumberTokensFragment paramLineNumberTokensFragment);
  
  void visit(SpacerBetweenMembersFragment paramSpacerBetweenMembersFragment);
  
  void visit(SpacerFragment paramSpacerFragment);
  
  void visit(SpaceSpacerFragment paramSpaceSpacerFragment);
  
  void visit(StartBlockFragment paramStartBlockFragment);
  
  void visit(StartBodyFragment paramStartBodyFragment);
  
  void visit(StartMovableJavaBlockFragment paramStartMovableJavaBlockFragment);
  
  void visit(StartSingleStatementBlockFragment paramStartSingleStatementBlockFragment);
  
  void visit(StartStatementsBlockFragment paramStartStatementsBlockFragment);
  
  void visit(StartStatementsDoWhileBlockFragment paramStartStatementsDoWhileBlockFragment);
  
  void visit(StartStatementsInfiniteForBlockFragment paramStartStatementsInfiniteForBlockFragment);
  
  void visit(StartStatementsInfiniteWhileBlockFragment paramStartStatementsInfiniteWhileBlockFragment);
  
  void visit(StartStatementsTryBlockFragment paramStartStatementsTryBlockFragment);
  
  void visit(TokensFragment paramTokensFragment);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javafragment/JavaFragmentVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */