/*    */ package org.jd.core.v1.model.classfile.attribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CodeException
/*    */ {
/*    */   protected int index;
/*    */   protected int startPc;
/*    */   protected int endPc;
/*    */   protected int handlerPc;
/*    */   protected int catchType;
/*    */   
/*    */   public CodeException(int index, int startPc, int endPc, int handlerPc, int catchType) {
/* 18 */     this.index = index;
/* 19 */     this.startPc = startPc;
/* 20 */     this.endPc = endPc;
/* 21 */     this.handlerPc = handlerPc;
/* 22 */     this.catchType = catchType;
/*    */   }
/*    */   
/*    */   public int getStartPc() {
/* 26 */     return this.startPc;
/*    */   }
/*    */   
/*    */   public int getEndPc() {
/* 30 */     return this.endPc;
/*    */   }
/*    */   
/*    */   public int getHandlerPc() {
/* 34 */     return this.handlerPc;
/*    */   }
/*    */   
/*    */   public int getCatchType() {
/* 38 */     return this.catchType;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 43 */     if (this == o) return true; 
/* 44 */     if (o == null || getClass() != o.getClass()) return false;
/*    */     
/* 46 */     CodeException that = (CodeException)o;
/*    */     
/* 48 */     if (this.startPc != that.startPc) return false; 
/* 49 */     return (this.endPc == that.endPc);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 54 */     return 969815374 + 31 * this.startPc + this.endPc;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     return "CodeException{index=" + this.index + ", startPc=" + this.startPc + ", endPc=" + this.endPc + ", handlerPc=" + this.handlerPc + ", catchType=" + this.catchType + "}";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/CodeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */