package org.jd.core.v1.model.classfile.attribute;

public interface ElementValueVisitor {
  void visit(ElementValuePrimitiveType paramElementValuePrimitiveType);
  
  void visit(ElementValueClassInfo paramElementValueClassInfo);
  
  void visit(ElementValueAnnotationValue paramElementValueAnnotationValue);
  
  void visit(ElementValueEnumConstValue paramElementValueEnumConstValue);
  
  void visit(ElementValueArrayValue paramElementValueArrayValue);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/attribute/ElementValueVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */