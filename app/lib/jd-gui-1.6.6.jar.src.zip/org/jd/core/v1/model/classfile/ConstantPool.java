/*    */ package org.jd.core.v1.model.classfile;
/*    */ 
/*    */ import org.jd.core.v1.model.classfile.constant.Constant;
/*    */ import org.jd.core.v1.model.classfile.constant.ConstantClass;
/*    */ import org.jd.core.v1.model.classfile.constant.ConstantString;
/*    */ import org.jd.core.v1.model.classfile.constant.ConstantUtf8;
/*    */ import org.jd.core.v1.model.classfile.constant.ConstantValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantPool
/*    */ {
/*    */   protected Constant[] constants;
/*    */   
/*    */   public ConstantPool(Constant[] constants) {
/* 17 */     this.constants = constants;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends Constant> T getConstant(int index) {
/* 22 */     return (T)this.constants[index];
/*    */   }
/*    */   
/*    */   public String getConstantTypeName(int index) {
/* 26 */     ConstantClass cc = (ConstantClass)this.constants[index];
/* 27 */     ConstantUtf8 cutf8 = (ConstantUtf8)this.constants[cc.getNameIndex()];
/* 28 */     return cutf8.getValue();
/*    */   }
/*    */   
/*    */   public String getConstantString(int index) {
/* 32 */     ConstantString cString = (ConstantString)this.constants[index];
/* 33 */     ConstantUtf8 cutf8 = (ConstantUtf8)this.constants[cString.getStringIndex()];
/* 34 */     return cutf8.getValue();
/*    */   }
/*    */   
/*    */   public String getConstantUtf8(int index) {
/* 38 */     ConstantUtf8 cutf8 = (ConstantUtf8)this.constants[index];
/* 39 */     return cutf8.getValue();
/*    */   }
/*    */   
/*    */   public ConstantValue getConstantValue(int index) {
/* 43 */     Constant constant = this.constants[index];
/*    */     
/* 45 */     if (constant != null && constant.getTag() == 8) {
/* 46 */       constant = this.constants[((ConstantString)constant).getStringIndex()];
/*    */     }
/*    */     
/* 49 */     return (ConstantValue)constant;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 54 */     return "ConstantPool";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/ConstantPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */