/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ import org.jd.core.v1.model.fragment.StartMovableBlockFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StartMovableJavaBlockFragment
/*    */   extends StartMovableBlockFragment
/*    */   implements JavaFragment
/*    */ {
/* 13 */   public static final StartMovableJavaBlockFragment START_MOVABLE_TYPE_BLOCK = new StartMovableJavaBlockFragment(1);
/* 14 */   public static final StartMovableJavaBlockFragment START_MOVABLE_FIELD_BLOCK = new StartMovableJavaBlockFragment(2);
/* 15 */   public static final StartMovableJavaBlockFragment START_MOVABLE_METHOD_BLOCK = new StartMovableJavaBlockFragment(3);
/*    */   
/*    */   protected StartMovableJavaBlockFragment(int type) {
/* 18 */     super(type);
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 23 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javafragment/StartMovableJavaBlockFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */