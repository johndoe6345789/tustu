/*    */ package org.jd.core.v1.model.javasyntax.declaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldDeclarator
/*    */   implements BaseFieldDeclarator
/*    */ {
/*    */   protected FieldDeclaration fieldDeclaration;
/*    */   protected String name;
/*    */   protected int dimension;
/*    */   protected VariableInitializer variableInitializer;
/*    */   
/*    */   public FieldDeclarator(String name) {
/* 17 */     this.name = name;
/*    */   }
/*    */   
/*    */   public FieldDeclarator(String name, VariableInitializer variableInitializer) {
/* 21 */     this.name = name;
/* 22 */     this.variableInitializer = variableInitializer;
/*    */   }
/*    */   
/*    */   public FieldDeclarator(String name, int dimension, VariableInitializer variableInitializer) {
/* 26 */     this.name = name;
/* 27 */     this.dimension = dimension;
/* 28 */     this.variableInitializer = variableInitializer;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setFieldDeclaration(FieldDeclaration fieldDeclaration) {
/* 33 */     this.fieldDeclaration = fieldDeclaration;
/*    */   }
/*    */   
/*    */   public FieldDeclaration getFieldDeclaration() {
/* 37 */     return this.fieldDeclaration;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 41 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getDimension() {
/* 45 */     return this.dimension;
/*    */   }
/*    */   
/*    */   public VariableInitializer getVariableInitializer() {
/* 49 */     return this.variableInitializer;
/*    */   }
/*    */   
/*    */   public void setVariableInitializer(VariableInitializer variableInitializer) {
/* 53 */     this.variableInitializer = variableInitializer;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 58 */     if (this == o) return true; 
/* 59 */     if (!(o instanceof FieldDeclarator)) return false;
/*    */     
/* 61 */     FieldDeclarator that = (FieldDeclarator)o;
/*    */     
/* 63 */     if (this.dimension != that.dimension) return false; 
/* 64 */     if (!this.name.equals(that.name)) return false; 
/* 65 */     if ((this.variableInitializer != null) ? !this.variableInitializer.equals(that.variableInitializer) : (that.variableInitializer != null)) {
/* 66 */       return false;
/*    */     }
/* 68 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 73 */     int result = 544278669 + this.name.hashCode();
/* 74 */     result = 31 * result + this.dimension;
/* 75 */     result = 31 * result + ((this.variableInitializer != null) ? this.variableInitializer.hashCode() : 0);
/* 76 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(DeclarationVisitor visitor) {
/* 81 */     visitor.visit(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 86 */     return "FieldDeclarator{" + this.name + "}";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/FieldDeclarator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */