package org.jd.core.v1.model.fragment;

public interface FragmentVisitor {
  void visit(FlexibleFragment paramFlexibleFragment);
  
  void visit(EndFlexibleBlockFragment paramEndFlexibleBlockFragment);
  
  void visit(EndMovableBlockFragment paramEndMovableBlockFragment);
  
  void visit(SpacerBetweenMovableBlocksFragment paramSpacerBetweenMovableBlocksFragment);
  
  void visit(StartFlexibleBlockFragment paramStartFlexibleBlockFragment);
  
  void visit(StartMovableBlockFragment paramStartMovableBlockFragment);
  
  void visit(FixedFragment paramFixedFragment);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/fragment/FragmentVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */