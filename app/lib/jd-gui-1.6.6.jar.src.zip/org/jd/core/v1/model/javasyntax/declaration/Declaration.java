package org.jd.core.v1.model.javasyntax.declaration;

public interface Declaration {
  public static final int FLAG_PUBLIC = 1;
  
  public static final int FLAG_PRIVATE = 2;
  
  public static final int FLAG_PROTECTED = 4;
  
  public static final int FLAG_STATIC = 8;
  
  public static final int FLAG_FINAL = 16;
  
  public static final int FLAG_SYNCHRONIZED = 32;
  
  public static final int FLAG_SUPER = 32;
  
  public static final int FLAG_OPEN = 32;
  
  public static final int FLAG_TRANSITIVE = 32;
  
  public static final int FLAG_VOLATILE = 64;
  
  public static final int FLAG_BRIDGE = 64;
  
  public static final int FLAG_STATIC_PHASE = 64;
  
  public static final int FLAG_TRANSIENT = 128;
  
  public static final int FLAG_VARARGS = 128;
  
  public static final int FLAG_NATIVE = 256;
  
  public static final int FLAG_INTERFACE = 512;
  
  public static final int FLAG_ABSTRACT = 1024;
  
  public static final int FLAG_STRICT = 2048;
  
  public static final int FLAG_SYNTHETIC = 4096;
  
  public static final int FLAG_ANNOTATION = 8192;
  
  public static final int FLAG_ENUM = 16384;
  
  public static final int FLAG_MODULE = 32768;
  
  public static final int FLAG_MANDATED = 32768;
  
  public static final int FLAG_DEFAULT = 65536;
  
  void accept(DeclarationVisitor paramDeclarationVisitor);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javasyntax/declaration/Declaration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */