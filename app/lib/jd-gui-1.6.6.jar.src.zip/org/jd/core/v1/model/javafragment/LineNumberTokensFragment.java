/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.jd.core.v1.model.fragment.FixedFragment;
/*    */ import org.jd.core.v1.model.token.AbstractNopTokenVisitor;
/*    */ import org.jd.core.v1.model.token.LineNumberToken;
/*    */ import org.jd.core.v1.model.token.NewLineToken;
/*    */ import org.jd.core.v1.model.token.Token;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LineNumberTokensFragment
/*    */   extends FixedFragment
/*    */   implements JavaFragment
/*    */ {
/*    */   protected List<Token> tokens;
/*    */   
/*    */   public LineNumberTokensFragment(Token... tokens) {
/* 24 */     this(Arrays.asList(tokens));
/*    */   }
/*    */   
/*    */   public LineNumberTokensFragment(List<Token> tokens) {
/* 28 */     super(searchFirstLineNumber(tokens), searchLastLineNumber(tokens));
/* 29 */     assert this.firstLineNumber != 0 : "Uses 'TokensFragment' instead";
/* 30 */     this.tokens = tokens;
/*    */   }
/*    */   
/*    */   public List<Token> getTokens() {
/* 34 */     return this.tokens;
/*    */   }
/*    */   
/*    */   protected static int searchFirstLineNumber(List<Token> tokens) {
/* 38 */     SearchLineNumberVisitor visitor = new SearchLineNumberVisitor();
/*    */     
/* 40 */     for (Token token : tokens) {
/* 41 */       token.accept(visitor);
/*    */       
/* 43 */       if (visitor.lineNumber != 0) {
/* 44 */         return visitor.lineNumber - visitor.newLineCounter;
/*    */       }
/*    */     } 
/*    */     
/* 48 */     return 0;
/*    */   }
/*    */   
/*    */   protected static int searchLastLineNumber(List<Token> tokens) {
/* 52 */     SearchLineNumberVisitor visitor = new SearchLineNumberVisitor();
/* 53 */     int index = tokens.size();
/*    */     
/* 55 */     while (index-- > 0) {
/* 56 */       ((Token)tokens.get(index)).accept(visitor);
/*    */       
/* 58 */       if (visitor.lineNumber != 0) {
/* 59 */         return visitor.lineNumber + visitor.newLineCounter;
/*    */       }
/*    */     } 
/*    */     
/* 63 */     return 0;
/*    */   }
/*    */   
/*    */   protected static class SearchLineNumberVisitor extends AbstractNopTokenVisitor {
/*    */     public int lineNumber;
/*    */     public int newLineCounter;
/*    */     
/*    */     public void reset() {
/* 71 */       this.lineNumber = 0;
/* 72 */       this.newLineCounter = 0;
/*    */     }
/*    */ 
/*    */     
/*    */     public void visit(LineNumberToken token) {
/* 77 */       this.lineNumber = token.getLineNumber();
/*    */     }
/*    */ 
/*    */     
/*    */     public void visit(NewLineToken token) {
/* 82 */       this.newLineCounter++;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 88 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javafragment/LineNumberTokensFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */