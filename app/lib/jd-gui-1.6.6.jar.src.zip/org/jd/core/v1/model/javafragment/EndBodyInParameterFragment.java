/*    */ package org.jd.core.v1.model.javafragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EndBodyInParameterFragment
/*    */   extends EndBodyFragment
/*    */   implements JavaFragment
/*    */ {
/*    */   public EndBodyInParameterFragment(int minimalLineCount, int lineCount, int maximalLineCount, int weight, String label, StartBodyFragment startBodyFragment) {
/* 12 */     super(minimalLineCount, lineCount, maximalLineCount, weight, label, startBodyFragment);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean incLineCount(boolean force) {
/* 17 */     if (this.lineCount < this.maximalLineCount) {
/* 18 */       this.lineCount++;
/* 19 */       return true;
/*    */     } 
/* 21 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean decLineCount(boolean force) {
/* 27 */     if (this.lineCount > this.minimalLineCount) {
/* 28 */       this.lineCount--;
/* 29 */       return true;
/*    */     } 
/* 31 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void accept(JavaFragmentVisitor visitor) {
/* 37 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/javafragment/EndBodyInParameterFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */