/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantInteger
/*    */   extends ConstantValue
/*    */ {
/*    */   protected int value;
/*    */   
/*    */   public ConstantInteger(int value) {
/* 14 */     super((byte)3);
/* 15 */     this.value = value;
/*    */   }
/*    */   
/*    */   public int getValue() {
/* 19 */     return this.value;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/constant/ConstantInteger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */