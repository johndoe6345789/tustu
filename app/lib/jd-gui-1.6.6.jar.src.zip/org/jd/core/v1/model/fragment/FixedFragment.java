/*    */ package org.jd.core.v1.model.fragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FixedFragment
/*    */   implements Fragment
/*    */ {
/*    */   protected final int firstLineNumber;
/*    */   protected final int lastLineNumber;
/*    */   
/*    */   public FixedFragment(int firstLineNumber, int lastLineNumber) {
/* 15 */     this.firstLineNumber = firstLineNumber;
/* 16 */     this.lastLineNumber = lastLineNumber;
/*    */   }
/*    */   
/*    */   public int getFirstLineNumber() {
/* 20 */     return this.firstLineNumber;
/*    */   }
/*    */   
/*    */   public int getLastLineNumber() {
/* 24 */     return this.lastLineNumber;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 29 */     return "{first-line-number=" + this.firstLineNumber + ", last-line-number=" + this.lastLineNumber + "}";
/*    */   }
/*    */ 
/*    */   
/*    */   public void accept(FragmentVisitor visitor) {
/* 34 */     visitor.visit(this);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/fragment/FixedFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */