/*    */ package org.jd.core.v1.model.classfile.constant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantNameAndType
/*    */   extends Constant
/*    */ {
/*    */   protected int nameIndex;
/*    */   protected int descriptorIndex;
/*    */   
/*    */   public ConstantNameAndType(int nameIndex, int descriptorIndex) {
/* 15 */     super((byte)12);
/* 16 */     this.nameIndex = nameIndex;
/* 17 */     this.descriptorIndex = descriptorIndex;
/*    */   }
/*    */   
/*    */   public int getNameIndex() {
/* 21 */     return this.nameIndex;
/*    */   }
/*    */   
/*    */   public int getDescriptorIndex() {
/* 25 */     return this.descriptorIndex;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/model/classfile/constant/ConstantNameAndType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */