package org.jd.core.v1.api.loader;

public interface Loader {
  boolean canLoad(String paramString);
  
  byte[] load(String paramString) throws LoaderException;
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/api/loader/Loader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */