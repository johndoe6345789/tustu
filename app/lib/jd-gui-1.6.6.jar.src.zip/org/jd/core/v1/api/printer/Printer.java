package org.jd.core.v1.api.printer;

public interface Printer {
  public static final int TYPE = 1;
  
  public static final int FIELD = 2;
  
  public static final int METHOD = 3;
  
  public static final int CONSTRUCTOR = 4;
  
  public static final int PACKAGE = 5;
  
  public static final int MODULE = 6;
  
  public static final int UNKNOWN_LINE_NUMBER = 0;
  
  public static final int COMMENT = 1;
  
  public static final int JAVADOC = 2;
  
  public static final int ERROR = 3;
  
  public static final int IMPORT_STATEMENTS = 4;
  
  void start(int paramInt1, int paramInt2, int paramInt3);
  
  void end();
  
  void printText(String paramString);
  
  void printNumericConstant(String paramString);
  
  void printStringConstant(String paramString1, String paramString2);
  
  void printKeyword(String paramString);
  
  void printDeclaration(int paramInt, String paramString1, String paramString2, String paramString3);
  
  void printReference(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4);
  
  void indent();
  
  void unindent();
  
  void startLine(int paramInt);
  
  void endLine();
  
  void extraLine(int paramInt);
  
  void startMarker(int paramInt);
  
  void endMarker(int paramInt);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/api/printer/Printer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */