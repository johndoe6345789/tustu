package org.jd.core.v1.api;

import java.util.Map;
import org.jd.core.v1.api.loader.Loader;
import org.jd.core.v1.api.printer.Printer;

public interface Decompiler {
  void decompile(Loader paramLoader, Printer paramPrinter, String paramString) throws Exception;
  
  void decompile(Loader paramLoader, Printer paramPrinter, String paramString, Map<String, Object> paramMap) throws Exception;
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/api/Decompiler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */