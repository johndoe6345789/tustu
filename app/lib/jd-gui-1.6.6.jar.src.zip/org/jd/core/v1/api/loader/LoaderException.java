/*    */ package org.jd.core.v1.api.loader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoaderException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 9506606333927794L;
/*    */   
/*    */   public LoaderException() {}
/*    */   
/*    */   public LoaderException(String msg) {
/* 15 */     super(msg);
/*    */   } public LoaderException(Throwable cause) {
/* 17 */     super(cause);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/jd/core/v1/api/loader/LoaderException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */