/*    */ package org.abego.treelayout;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Configuration<TreeNode>
/*    */ {
/*    */   Location getRootLocation();
/*    */   
/*    */   AlignmentInLevel getAlignmentInLevel();
/*    */   
/*    */   double getGapBetweenLevels(int paramInt);
/*    */   
/*    */   double getGapBetweenNodes(TreeNode paramTreeNode1, TreeNode paramTreeNode2);
/*    */   
/*    */   public enum Location
/*    */   {
/* 51 */     Top, Left, Bottom, Right;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum AlignmentInLevel
/*    */   {
/* 87 */     Center, TowardsRoot, AwayFromRoot;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/abego/treelayout/Configuration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */