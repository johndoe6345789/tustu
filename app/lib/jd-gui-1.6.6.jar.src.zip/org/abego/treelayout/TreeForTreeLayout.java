package org.abego.treelayout;

public interface TreeForTreeLayout<TreeNode> {
  TreeNode getRoot();
  
  boolean isLeaf(TreeNode paramTreeNode);
  
  boolean isChildOfParent(TreeNode paramTreeNode1, TreeNode paramTreeNode2);
  
  Iterable<TreeNode> getChildren(TreeNode paramTreeNode);
  
  Iterable<TreeNode> getChildrenReverse(TreeNode paramTreeNode);
  
  TreeNode getFirstChild(TreeNode paramTreeNode);
  
  TreeNode getLastChild(TreeNode paramTreeNode);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/abego/treelayout/TreeForTreeLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */