/*     */ package org.abego.treelayout.util;
/*     */ 
/*     */ import org.abego.treelayout.Configuration;
/*     */ import org.abego.treelayout.internal.util.Contract;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultConfiguration<TreeNode>
/*     */   implements Configuration<TreeNode>
/*     */ {
/*     */   private final double gapBetweenLevels;
/*     */   private final double gapBetweenNodes;
/*     */   private final Configuration.Location location;
/*     */   private Configuration.AlignmentInLevel alignmentInLevel;
/*     */   
/*     */   public DefaultConfiguration(double gapBetweenLevels, double gapBetweenNodes, Configuration.Location location, Configuration.AlignmentInLevel alignmentInLevel) {
/*  61 */     Contract.checkArg((gapBetweenLevels >= 0.0D), "gapBetweenLevels must be >= 0");
/*  62 */     Contract.checkArg((gapBetweenNodes >= 0.0D), "gapBetweenNodes must be >= 0");
/*     */     
/*  64 */     this.gapBetweenLevels = gapBetweenLevels;
/*  65 */     this.gapBetweenNodes = gapBetweenNodes;
/*  66 */     this.location = location;
/*  67 */     this.alignmentInLevel = alignmentInLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultConfiguration(double gapBetweenLevels, double gapBetweenNodes, Configuration.Location location) {
/*  78 */     this(gapBetweenLevels, gapBetweenNodes, location, Configuration.AlignmentInLevel.Center);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultConfiguration(double gapBetweenLevels, double gapBetweenNodes) {
/*  91 */     this(gapBetweenLevels, gapBetweenNodes, Configuration.Location.Top, Configuration.AlignmentInLevel.Center);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getGapBetweenLevels(int nextLevel) {
/* 102 */     return this.gapBetweenLevels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getGapBetweenNodes(TreeNode node1, TreeNode node2) {
/* 112 */     return this.gapBetweenNodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Configuration.Location getRootLocation() {
/* 122 */     return this.location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Configuration.AlignmentInLevel getAlignmentInLevel() {
/* 132 */     return this.alignmentInLevel;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/abego/treelayout/util/DefaultConfiguration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */