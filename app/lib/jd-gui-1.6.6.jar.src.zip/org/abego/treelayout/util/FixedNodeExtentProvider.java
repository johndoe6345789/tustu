/*    */ package org.abego.treelayout.util;
/*    */ 
/*    */ import org.abego.treelayout.NodeExtentProvider;
/*    */ import org.abego.treelayout.internal.util.Contract;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixedNodeExtentProvider<T>
/*    */   implements NodeExtentProvider<T>
/*    */ {
/*    */   private final double width;
/*    */   private final double height;
/*    */   
/*    */   public FixedNodeExtentProvider(double width, double height) {
/* 59 */     Contract.checkArg((width >= 0.0D), "width must be >= 0");
/* 60 */     Contract.checkArg((height >= 0.0D), "height must be >= 0");
/*    */     
/* 62 */     this.width = width;
/* 63 */     this.height = height;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FixedNodeExtentProvider() {
/* 70 */     this(0.0D, 0.0D);
/*    */   }
/*    */ 
/*    */   
/*    */   public double getWidth(T treeNode) {
/* 75 */     return this.width;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getHeight(T treeNode) {
/* 80 */     return this.height;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/abego/treelayout/util/FixedNodeExtentProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */