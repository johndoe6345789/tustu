/*     */ package org.abego.treelayout.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.abego.treelayout.internal.util.Contract;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultTreeForTreeLayout<TreeNode>
/*     */   extends AbstractTreeForTreeLayout<TreeNode>
/*     */ {
/*     */   private List<TreeNode> emptyList;
/*     */   
/*     */   private List<TreeNode> getEmptyList() {
/*  64 */     if (this.emptyList == null) {
/*  65 */       this.emptyList = new ArrayList<TreeNode>();
/*     */     }
/*  67 */     return this.emptyList;
/*     */   }
/*     */   
/*  70 */   private Map<TreeNode, List<TreeNode>> childrenMap = new HashMap<TreeNode, List<TreeNode>>();
/*  71 */   private Map<TreeNode, TreeNode> parents = new HashMap<TreeNode, TreeNode>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultTreeForTreeLayout(TreeNode root) {
/*  80 */     super(root);
/*     */   }
/*     */ 
/*     */   
/*     */   public TreeNode getParent(TreeNode node) {
/*  85 */     return this.parents.get(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<TreeNode> getChildrenList(TreeNode node) {
/*  90 */     List<TreeNode> result = this.childrenMap.get(node);
/*  91 */     return (result == null) ? getEmptyList() : result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNode(TreeNode node) {
/* 100 */     return (node == getRoot() || this.parents.containsKey(node));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChild(TreeNode parentNode, TreeNode node) {
/* 110 */     Contract.checkArg(hasNode(parentNode), "parentNode is not in the tree");
/* 111 */     Contract.checkArg(!hasNode(node), "node is already in the tree");
/*     */     
/* 113 */     List<TreeNode> list = this.childrenMap.get(parentNode);
/* 114 */     if (list == null) {
/* 115 */       list = new ArrayList<TreeNode>();
/* 116 */       this.childrenMap.put(parentNode, list);
/*     */     } 
/* 118 */     list.add(node);
/* 119 */     this.parents.put(node, parentNode);
/*     */   }
/*     */   
/*     */   public void addChildren(TreeNode parentNode, TreeNode... nodes) {
/* 123 */     for (TreeNode node : nodes)
/* 124 */       addChild(parentNode, node); 
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/abego/treelayout/util/DefaultTreeForTreeLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */