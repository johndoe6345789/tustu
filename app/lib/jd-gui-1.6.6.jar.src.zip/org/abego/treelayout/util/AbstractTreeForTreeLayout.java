/*     */ package org.abego.treelayout.util;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.abego.treelayout.TreeForTreeLayout;
/*     */ import org.abego.treelayout.internal.util.java.lang.IterableUtil;
/*     */ import org.abego.treelayout.internal.util.java.util.ListUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTreeForTreeLayout<TreeNode>
/*     */   implements TreeForTreeLayout<TreeNode>
/*     */ {
/*     */   private final TreeNode root;
/*     */   
/*     */   public abstract TreeNode getParent(TreeNode paramTreeNode);
/*     */   
/*     */   public abstract List<TreeNode> getChildrenList(TreeNode paramTreeNode);
/*     */   
/*     */   public AbstractTreeForTreeLayout(TreeNode root) {
/*  85 */     this.root = root;
/*     */   }
/*     */ 
/*     */   
/*     */   public TreeNode getRoot() {
/*  90 */     return this.root;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLeaf(TreeNode node) {
/*  95 */     return getChildrenList(node).isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isChildOfParent(TreeNode node, TreeNode parentNode) {
/* 100 */     return (getParent(node) == parentNode);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<TreeNode> getChildren(TreeNode node) {
/* 105 */     return getChildrenList(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<TreeNode> getChildrenReverse(TreeNode node) {
/* 110 */     return IterableUtil.createReverseIterable(getChildrenList(node));
/*     */   }
/*     */ 
/*     */   
/*     */   public TreeNode getFirstChild(TreeNode parentNode) {
/* 115 */     return getChildrenList(parentNode).get(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public TreeNode getLastChild(TreeNode parentNode) {
/* 120 */     return ListUtil.getLast(getChildrenList(parentNode));
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/abego/treelayout/util/AbstractTreeForTreeLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */