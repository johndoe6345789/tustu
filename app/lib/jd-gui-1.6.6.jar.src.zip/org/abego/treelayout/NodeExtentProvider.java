package org.abego.treelayout;

public interface NodeExtentProvider<TreeNode> {
  double getWidth(TreeNode paramTreeNode);
  
  double getHeight(TreeNode paramTreeNode);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/abego/treelayout/NodeExtentProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */