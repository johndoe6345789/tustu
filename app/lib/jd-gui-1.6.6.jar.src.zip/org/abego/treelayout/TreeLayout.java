/*     */ package org.abego.treelayout;
/*     */ 
/*     */ import java.awt.geom.Point2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.abego.treelayout.internal.util.Contract;
/*     */ import org.abego.treelayout.internal.util.java.lang.string.StringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeLayout<TreeNode>
/*     */ {
/*     */   private final TreeForTreeLayout<TreeNode> tree;
/*     */   private final NodeExtentProvider<TreeNode> nodeExtentProvider;
/*     */   private final Configuration<TreeNode> configuration;
/*     */   
/*     */   public TreeForTreeLayout<TreeNode> getTree() {
/*  95 */     return this.tree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NodeExtentProvider<TreeNode> getNodeExtentProvider() {
/* 107 */     return this.nodeExtentProvider;
/*     */   }
/*     */   
/*     */   private double getNodeHeight(TreeNode node) {
/* 111 */     return this.nodeExtentProvider.getHeight(node);
/*     */   }
/*     */   
/*     */   private double getNodeWidth(TreeNode node) {
/* 115 */     return this.nodeExtentProvider.getWidth(node);
/*     */   }
/*     */   
/*     */   private double getWidthOrHeightOfNode(TreeNode treeNode, boolean returnWidth) {
/* 119 */     return returnWidth ? getNodeWidth(treeNode) : getNodeHeight(treeNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double getNodeThickness(TreeNode treeNode) {
/* 134 */     return getWidthOrHeightOfNode(treeNode, !isLevelChangeInYAxis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double getNodeSize(TreeNode treeNode) {
/* 148 */     return getWidthOrHeightOfNode(treeNode, isLevelChangeInYAxis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Configuration<TreeNode> getConfiguration() {
/* 160 */     return this.configuration;
/*     */   }
/*     */   
/*     */   private boolean isLevelChangeInYAxis() {
/* 164 */     Configuration.Location rootLocation = this.configuration.getRootLocation();
/* 165 */     return (rootLocation == Configuration.Location.Top || rootLocation == Configuration.Location.Bottom);
/*     */   }
/*     */   
/*     */   private int getLevelChangeSign() {
/* 169 */     Configuration.Location rootLocation = this.configuration.getRootLocation();
/* 170 */     return (rootLocation == Configuration.Location.Bottom || rootLocation == Configuration.Location.Right) ? -1 : 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 177 */   private double boundsLeft = Double.MAX_VALUE;
/* 178 */   private double boundsRight = Double.MIN_VALUE;
/* 179 */   private double boundsTop = Double.MAX_VALUE;
/* 180 */   private double boundsBottom = Double.MIN_VALUE;
/*     */   
/*     */   private void updateBounds(TreeNode node, double centerX, double centerY) {
/* 183 */     double width = getNodeWidth(node);
/* 184 */     double height = getNodeHeight(node);
/* 185 */     double left = centerX - width / 2.0D;
/* 186 */     double right = centerX + width / 2.0D;
/* 187 */     double top = centerY - height / 2.0D;
/* 188 */     double bottom = centerY + height / 2.0D;
/* 189 */     if (this.boundsLeft > left) {
/* 190 */       this.boundsLeft = left;
/*     */     }
/* 192 */     if (this.boundsRight < right) {
/* 193 */       this.boundsRight = right;
/*     */     }
/* 195 */     if (this.boundsTop > top) {
/* 196 */       this.boundsTop = top;
/*     */     }
/* 198 */     if (this.boundsBottom < bottom) {
/* 199 */       this.boundsBottom = bottom;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle2D getBounds() {
/* 212 */     return new Rectangle2D.Double(0.0D, 0.0D, this.boundsRight - this.boundsLeft, this.boundsBottom - this.boundsTop);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean useIdentity;
/*     */   
/* 219 */   private final List<Double> sizeOfLevel = new ArrayList<Double>();
/*     */   
/*     */   private void calcSizeOfLevels(TreeNode node, int level) {
/*     */     double oldSize;
/* 223 */     if (this.sizeOfLevel.size() <= level) {
/* 224 */       this.sizeOfLevel.add(Double.valueOf(0.0D));
/* 225 */       oldSize = 0.0D;
/*     */     } else {
/* 227 */       oldSize = ((Double)this.sizeOfLevel.get(level)).doubleValue();
/*     */     } 
/*     */     
/* 230 */     double size = getNodeThickness(node);
/*     */     
/* 232 */     if (oldSize < size) {
/* 233 */       this.sizeOfLevel.set(level, Double.valueOf(size));
/*     */     }
/*     */     
/* 236 */     if (!this.tree.isLeaf(node))
/* 237 */       for (TreeNode child : this.tree.getChildren(node)) {
/* 238 */         calcSizeOfLevels(child, level + 1);
/*     */       } 
/*     */   }
/*     */   
/*     */   private final Map<TreeNode, Double> mod;
/*     */   private final Map<TreeNode, TreeNode> thread;
/*     */   private final Map<TreeNode, Double> prelim;
/*     */   private final Map<TreeNode, Double> change;
/*     */   private final Map<TreeNode, Double> shift;
/*     */   
/*     */   public int getLevelCount() {
/* 249 */     return this.sizeOfLevel.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<TreeNode, TreeNode> ancestor;
/*     */   
/*     */   private final Map<TreeNode, Integer> number;
/*     */   
/*     */   private final Map<TreeNode, Point2D> positions;
/*     */   
/*     */   private Map<TreeNode, Rectangle2D.Double> nodeBounds;
/*     */ 
/*     */   
/*     */   public double getSizeOfLevel(int level) {
/* 264 */     Contract.checkArg((level >= 0), "level must be >= 0");
/* 265 */     Contract.checkArg((level < getLevelCount()), "level must be < levelCount");
/*     */     
/* 267 */     return ((Double)this.sizeOfLevel.get(level)).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class NormalizedPosition
/*     */     extends Point2D
/*     */   {
/*     */     private double x_relativeToRoot;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private double y_relativeToRoot;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NormalizedPosition(double x_relativeToRoot, double y_relativeToRoot) {
/* 289 */       setLocation(x_relativeToRoot, y_relativeToRoot);
/*     */     }
/*     */ 
/*     */     
/*     */     public double getX() {
/* 294 */       return this.x_relativeToRoot - TreeLayout.this.boundsLeft;
/*     */     }
/*     */ 
/*     */     
/*     */     public double getY() {
/* 299 */       return this.y_relativeToRoot - TreeLayout.this.boundsTop;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setLocation(double x_relativeToRoot, double y_relativeToRoot) {
/* 305 */       this.x_relativeToRoot = x_relativeToRoot;
/* 306 */       this.y_relativeToRoot = y_relativeToRoot;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double getMod(TreeNode node) {
/* 325 */     Double d = this.mod.get(node);
/* 326 */     return (d != null) ? d.doubleValue() : 0.0D;
/*     */   }
/*     */   
/*     */   private void setMod(TreeNode node, double d) {
/* 330 */     this.mod.put(node, Double.valueOf(d));
/*     */   }
/*     */   
/*     */   private TreeNode getThread(TreeNode node) {
/* 334 */     TreeNode n = this.thread.get(node);
/* 335 */     return (n != null) ? n : null;
/*     */   }
/*     */   
/*     */   private void setThread(TreeNode node, TreeNode thread) {
/* 339 */     this.thread.put(node, thread);
/*     */   }
/*     */   
/*     */   private TreeNode getAncestor(TreeNode node) {
/* 343 */     TreeNode n = this.ancestor.get(node);
/* 344 */     return (n != null) ? n : node;
/*     */   }
/*     */   
/*     */   private void setAncestor(TreeNode node, TreeNode ancestor) {
/* 348 */     this.ancestor.put(node, ancestor);
/*     */   }
/*     */   
/*     */   private double getPrelim(TreeNode node) {
/* 352 */     Double d = this.prelim.get(node);
/* 353 */     return (d != null) ? d.doubleValue() : 0.0D;
/*     */   }
/*     */   
/*     */   private void setPrelim(TreeNode node, double d) {
/* 357 */     this.prelim.put(node, Double.valueOf(d));
/*     */   }
/*     */   
/*     */   private double getChange(TreeNode node) {
/* 361 */     Double d = this.change.get(node);
/* 362 */     return (d != null) ? d.doubleValue() : 0.0D;
/*     */   }
/*     */   
/*     */   private void setChange(TreeNode node, double d) {
/* 366 */     this.change.put(node, Double.valueOf(d));
/*     */   }
/*     */   
/*     */   private double getShift(TreeNode node) {
/* 370 */     Double d = this.shift.get(node);
/* 371 */     return (d != null) ? d.doubleValue() : 0.0D;
/*     */   }
/*     */   
/*     */   private void setShift(TreeNode node, double d) {
/* 375 */     this.shift.put(node, Double.valueOf(d));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double getDistance(TreeNode v, TreeNode w) {
/* 389 */     double sizeOfNodes = getNodeSize(v) + getNodeSize(w);
/*     */     
/* 391 */     double distance = sizeOfNodes / 2.0D + this.configuration.getGapBetweenNodes(v, w);
/*     */     
/* 393 */     return distance;
/*     */   }
/*     */   
/*     */   private TreeNode nextLeft(TreeNode v) {
/* 397 */     return this.tree.isLeaf(v) ? getThread(v) : this.tree.getFirstChild(v);
/*     */   }
/*     */   
/*     */   private TreeNode nextRight(TreeNode v) {
/* 401 */     return this.tree.isLeaf(v) ? getThread(v) : this.tree.getLastChild(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getNumber(TreeNode node, TreeNode parentNode) {
/* 413 */     Integer n = this.number.get(node);
/* 414 */     if (n == null) {
/* 415 */       int i = 1;
/* 416 */       for (TreeNode child : this.tree.getChildren(parentNode)) {
/* 417 */         this.number.put(child, Integer.valueOf(i++));
/*     */       }
/* 419 */       n = this.number.get(node);
/*     */     } 
/*     */     
/* 422 */     return n.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TreeNode ancestor(TreeNode vIMinus, TreeNode v, TreeNode parentOfV, TreeNode defaultAncestor) {
/* 436 */     TreeNode ancestor = getAncestor(vIMinus);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 442 */     return this.tree.isChildOfParent(ancestor, parentOfV) ? ancestor : defaultAncestor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void moveSubtree(TreeNode wMinus, TreeNode wPlus, TreeNode parent, double shift) {
/* 449 */     int subtrees = getNumber(wPlus, parent) - getNumber(wMinus, parent);
/* 450 */     setChange(wPlus, getChange(wPlus) - shift / subtrees);
/* 451 */     setShift(wPlus, getShift(wPlus) + shift);
/* 452 */     setChange(wMinus, getChange(wMinus) + shift / subtrees);
/* 453 */     setPrelim(wPlus, getPrelim(wPlus) + shift);
/* 454 */     setMod(wPlus, getMod(wPlus) + shift);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TreeNode apportion(TreeNode v, TreeNode defaultAncestor, TreeNode leftSibling, TreeNode parentOfV) {
/* 499 */     TreeNode w = leftSibling;
/* 500 */     if (w == null)
/*     */     {
/* 502 */       return defaultAncestor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 509 */     TreeNode vOPlus = v;
/* 510 */     TreeNode vIPlus = v;
/* 511 */     TreeNode vIMinus = w;
/*     */ 
/*     */ 
/*     */     
/* 515 */     TreeNode vOMinus = this.tree.getFirstChild(parentOfV);
/*     */     
/* 517 */     Double sIPlus = Double.valueOf(getMod(vIPlus));
/* 518 */     Double sOPlus = Double.valueOf(getMod(vOPlus));
/* 519 */     Double sIMinus = Double.valueOf(getMod(vIMinus));
/* 520 */     Double sOMinus = Double.valueOf(getMod(vOMinus));
/*     */     
/* 522 */     TreeNode nextRightVIMinus = nextRight(vIMinus);
/* 523 */     TreeNode nextLeftVIPlus = nextLeft(vIPlus);
/*     */     
/* 525 */     while (nextRightVIMinus != null && nextLeftVIPlus != null) {
/* 526 */       vIMinus = nextRightVIMinus;
/* 527 */       vIPlus = nextLeftVIPlus;
/* 528 */       vOMinus = nextLeft(vOMinus);
/* 529 */       vOPlus = nextRight(vOPlus);
/* 530 */       setAncestor(vOPlus, v);
/* 531 */       double shift = getPrelim(vIMinus) + sIMinus.doubleValue() - getPrelim(vIPlus) + sIPlus.doubleValue() + getDistance(vIMinus, vIPlus);
/*     */ 
/*     */ 
/*     */       
/* 535 */       if (shift > 0.0D) {
/* 536 */         moveSubtree(ancestor(vIMinus, v, parentOfV, defaultAncestor), v, parentOfV, shift);
/*     */         
/* 538 */         sIPlus = Double.valueOf(sIPlus.doubleValue() + shift);
/* 539 */         sOPlus = Double.valueOf(sOPlus.doubleValue() + shift);
/*     */       } 
/* 541 */       sIMinus = Double.valueOf(sIMinus.doubleValue() + getMod(vIMinus));
/* 542 */       sIPlus = Double.valueOf(sIPlus.doubleValue() + getMod(vIPlus));
/* 543 */       sOMinus = Double.valueOf(sOMinus.doubleValue() + getMod(vOMinus));
/* 544 */       sOPlus = Double.valueOf(sOPlus.doubleValue() + getMod(vOPlus));
/*     */       
/* 546 */       nextRightVIMinus = nextRight(vIMinus);
/* 547 */       nextLeftVIPlus = nextLeft(vIPlus);
/*     */     } 
/*     */     
/* 550 */     if (nextRightVIMinus != null && nextRight(vOPlus) == null) {
/* 551 */       setThread(vOPlus, nextRightVIMinus);
/* 552 */       setMod(vOPlus, getMod(vOPlus) + sIMinus.doubleValue() - sOPlus.doubleValue());
/*     */     } 
/*     */     
/* 555 */     if (nextLeftVIPlus != null && nextLeft(vOMinus) == null) {
/* 556 */       setThread(vOMinus, nextLeftVIPlus);
/* 557 */       setMod(vOMinus, getMod(vOMinus) + sIPlus.doubleValue() - sOMinus.doubleValue());
/* 558 */       defaultAncestor = v;
/*     */     } 
/* 560 */     return defaultAncestor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void executeShifts(TreeNode v) {
/* 569 */     double shift = 0.0D;
/* 570 */     double change = 0.0D;
/* 571 */     for (TreeNode w : this.tree.getChildrenReverse(v)) {
/* 572 */       change += getChange(w);
/* 573 */       setPrelim(w, getPrelim(w) + shift);
/* 574 */       setMod(w, getMod(w) + shift);
/* 575 */       shift = shift + getShift(w) + change;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void firstWalk(TreeNode v, TreeNode leftSibling) {
/* 589 */     if (this.tree.isLeaf(v)) {
/*     */ 
/*     */       
/* 592 */       TreeNode w = leftSibling;
/* 593 */       if (w != null)
/*     */       {
/*     */         
/* 596 */         setPrelim(v, getPrelim(w) + getDistance(v, w));
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 602 */       TreeNode defaultAncestor = this.tree.getFirstChild(v);
/* 603 */       TreeNode previousChild = null;
/* 604 */       for (TreeNode treeNode : this.tree.getChildren(v)) {
/* 605 */         firstWalk(treeNode, previousChild);
/* 606 */         defaultAncestor = apportion(treeNode, defaultAncestor, previousChild, v);
/*     */         
/* 608 */         previousChild = treeNode;
/*     */       } 
/* 610 */       executeShifts(v);
/* 611 */       double midpoint = (getPrelim(this.tree.getFirstChild(v)) + getPrelim(this.tree.getLastChild(v))) / 2.0D;
/*     */       
/* 613 */       TreeNode w = leftSibling;
/* 614 */       if (w != null) {
/*     */ 
/*     */         
/* 617 */         setPrelim(v, getPrelim(w) + getDistance(v, w));
/* 618 */         setMod(v, getPrelim(v) - midpoint);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 623 */         setPrelim(v, midpoint);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void secondWalk(TreeNode v, double m, int level, double levelStart) {
/* 642 */     double y, levelChangeSign = getLevelChangeSign();
/* 643 */     boolean levelChangeOnYAxis = isLevelChangeInYAxis();
/* 644 */     double levelSize = getSizeOfLevel(level);
/*     */     
/* 646 */     double x = getPrelim(v) + m;
/*     */ 
/*     */     
/* 649 */     Configuration.AlignmentInLevel alignment = this.configuration.getAlignmentInLevel();
/* 650 */     if (alignment == Configuration.AlignmentInLevel.Center) {
/* 651 */       y = levelStart + levelChangeSign * levelSize / 2.0D;
/* 652 */     } else if (alignment == Configuration.AlignmentInLevel.TowardsRoot) {
/* 653 */       y = levelStart + levelChangeSign * getNodeThickness(v) / 2.0D;
/*     */     } else {
/* 655 */       y = levelStart + levelSize - levelChangeSign * getNodeThickness(v) / 2.0D;
/*     */     } 
/*     */ 
/*     */     
/* 659 */     if (!levelChangeOnYAxis) {
/* 660 */       double t = x;
/* 661 */       x = y;
/* 662 */       y = t;
/*     */     } 
/*     */     
/* 665 */     this.positions.put(v, new NormalizedPosition(x, y));
/*     */ 
/*     */     
/* 668 */     updateBounds(v, x, y);
/*     */ 
/*     */     
/* 671 */     if (!this.tree.isLeaf(v)) {
/* 672 */       double nextLevelStart = levelStart + (levelSize + this.configuration.getGapBetweenLevels(level + 1)) * levelChangeSign;
/*     */ 
/*     */       
/* 675 */       for (TreeNode w : this.tree.getChildren(v)) {
/* 676 */         secondWalk(w, m + getMod(v), level + 1, nextLevelStart);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<TreeNode, Rectangle2D.Double> getNodeBounds() {
/* 696 */     if (this.nodeBounds == null) {
/* 697 */       this.nodeBounds = this.useIdentity ? new IdentityHashMap<TreeNode, Rectangle2D.Double>() : new HashMap<TreeNode, Rectangle2D.Double>();
/*     */       
/* 699 */       for (Map.Entry<TreeNode, Point2D> entry : this.positions.entrySet()) {
/* 700 */         TreeNode node = entry.getKey();
/* 701 */         Point2D pos = entry.getValue();
/* 702 */         double w = getNodeWidth(node);
/* 703 */         double h = getNodeHeight(node);
/* 704 */         double x = pos.getX() - w / 2.0D;
/* 705 */         double y = pos.getY() - h / 2.0D;
/* 706 */         this.nodeBounds.put(node, new Rectangle2D.Double(x, y, w, h));
/*     */       } 
/*     */     } 
/* 709 */     return this.nodeBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TreeLayout(TreeForTreeLayout<TreeNode> tree, NodeExtentProvider<TreeNode> nodeExtentProvider, Configuration<TreeNode> configuration, boolean useIdentity) {
/* 729 */     this.tree = tree;
/* 730 */     this.nodeExtentProvider = nodeExtentProvider;
/* 731 */     this.configuration = configuration;
/* 732 */     this.useIdentity = useIdentity;
/*     */     
/* 734 */     if (this.useIdentity) {
/* 735 */       this.mod = new IdentityHashMap<TreeNode, Double>();
/* 736 */       this.thread = new IdentityHashMap<TreeNode, TreeNode>();
/* 737 */       this.prelim = new IdentityHashMap<TreeNode, Double>();
/* 738 */       this.change = new IdentityHashMap<TreeNode, Double>();
/* 739 */       this.shift = new IdentityHashMap<TreeNode, Double>();
/* 740 */       this.ancestor = new IdentityHashMap<TreeNode, TreeNode>();
/* 741 */       this.number = new IdentityHashMap<TreeNode, Integer>();
/* 742 */       this.positions = new IdentityHashMap<TreeNode, Point2D>();
/*     */     } else {
/* 744 */       this.mod = new HashMap<TreeNode, Double>();
/* 745 */       this.thread = new HashMap<TreeNode, TreeNode>();
/* 746 */       this.prelim = new HashMap<TreeNode, Double>();
/* 747 */       this.change = new HashMap<TreeNode, Double>();
/* 748 */       this.shift = new HashMap<TreeNode, Double>();
/* 749 */       this.ancestor = new HashMap<TreeNode, TreeNode>();
/* 750 */       this.number = new HashMap<TreeNode, Integer>();
/* 751 */       this.positions = new HashMap<TreeNode, Point2D>();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 759 */     TreeNode r = tree.getRoot();
/* 760 */     firstWalk(r, null);
/* 761 */     calcSizeOfLevels(r, 0);
/* 762 */     secondWalk(r, -getPrelim(r), 0, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TreeLayout(TreeForTreeLayout<TreeNode> tree, NodeExtentProvider<TreeNode> nodeExtentProvider, Configuration<TreeNode> configuration) {
/* 768 */     this(tree, nodeExtentProvider, configuration, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addUniqueNodes(Map<TreeNode, TreeNode> nodes, TreeNode newNode) {
/* 775 */     if (nodes.put(newNode, newNode) != null) {
/* 776 */       throw new RuntimeException(String.format("Node used more than once in tree: %s", new Object[] { newNode }));
/*     */     }
/*     */     
/* 779 */     for (TreeNode n : this.tree.getChildren(newNode)) {
/* 780 */       addUniqueNodes(nodes, n);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkTree() {
/* 796 */     Map<TreeNode, TreeNode> nodes = this.useIdentity ? new IdentityHashMap<TreeNode, TreeNode>() : new HashMap<TreeNode, TreeNode>();
/*     */ 
/*     */ 
/*     */     
/* 800 */     addUniqueNodes(nodes, this.tree.getRoot());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void dumpTree(PrintStream output, TreeNode node, int indent, DumpConfiguration dumpConfiguration) {
/* 808 */     StringBuilder sb = new StringBuilder();
/* 809 */     for (int i = 0; i < indent; i++) {
/* 810 */       sb.append(dumpConfiguration.indent);
/*     */     }
/*     */     
/* 813 */     if (dumpConfiguration.includeObjectToString) {
/* 814 */       sb.append("[");
/* 815 */       sb.append(node.getClass().getName() + "@" + Integer.toHexString(node.hashCode()));
/*     */       
/* 817 */       if (node.hashCode() != System.identityHashCode(node)) {
/* 818 */         sb.append("/identityHashCode:");
/* 819 */         sb.append(Integer.toHexString(System.identityHashCode(node)));
/*     */       } 
/* 821 */       sb.append("]");
/*     */     } 
/*     */     
/* 824 */     sb.append(StringUtil.quote((node != null) ? node.toString() : null));
/*     */     
/* 826 */     if (dumpConfiguration.includeNodeSize) {
/* 827 */       sb.append(" (size: ");
/* 828 */       sb.append(getNodeWidth(node));
/* 829 */       sb.append("x");
/* 830 */       sb.append(getNodeHeight(node));
/* 831 */       sb.append(")");
/*     */     } 
/*     */     
/* 834 */     output.println(sb.toString());
/*     */     
/* 836 */     for (TreeNode n : this.tree.getChildren(node)) {
/* 837 */       dumpTree(output, n, indent + 1, dumpConfiguration);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DumpConfiguration
/*     */   {
/*     */     public final String indent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean includeNodeSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean includeObjectToString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DumpConfiguration(String indent, boolean includeNodeSize, boolean includePointer) {
/* 868 */       this.indent = indent;
/* 869 */       this.includeNodeSize = includeNodeSize;
/* 870 */       this.includeObjectToString = includePointer;
/*     */     }
/*     */     
/*     */     public DumpConfiguration() {
/* 874 */       this("    ", false, false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dumpTree(PrintStream printStream, DumpConfiguration dumpConfiguration) {
/* 887 */     dumpTree(printStream, this.tree.getRoot(), 0, dumpConfiguration);
/*     */   }
/*     */   
/*     */   public void dumpTree(PrintStream printStream) {
/* 891 */     dumpTree(printStream, new DumpConfiguration());
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/abego/treelayout/TreeLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */