/*    */ package org.abego.treelayout.internal.util.java.lang;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.abego.treelayout.internal.util.java.util.IteratorUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IterableUtil
/*    */ {
/*    */   private static class ReverseIterable<T>
/*    */     implements Iterable<T>
/*    */   {
/*    */     private List<T> list;
/*    */     
/*    */     public ReverseIterable(List<T> list) {
/* 49 */       this.list = list;
/*    */     }
/*    */ 
/*    */     
/*    */     public Iterator<T> iterator() {
/* 54 */       return IteratorUtil.createReverseIterator(this.list);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> Iterable<T> createReverseIterable(List<T> list) {
/* 71 */     if (list.size() == 0) {
/* 72 */       return list;
/*    */     }
/*    */     
/* 75 */     return new ReverseIterable<T>(list);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/abego/treelayout/internal/util/java/lang/IterableUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */