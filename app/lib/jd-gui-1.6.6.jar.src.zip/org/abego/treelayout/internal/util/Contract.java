/*    */ package org.abego.treelayout.internal.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Contract
/*    */ {
/*    */   public static void checkArg(boolean isOK, String s) {
/* 43 */     if (!isOK) {
/* 44 */       throw new IllegalArgumentException(s);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void checkState(boolean isOK, String s) {
/* 49 */     if (!isOK)
/* 50 */       throw new IllegalStateException(s); 
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/abego/treelayout/internal/util/Contract.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */