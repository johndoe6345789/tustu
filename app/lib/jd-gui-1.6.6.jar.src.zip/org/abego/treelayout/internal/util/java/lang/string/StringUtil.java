/*     */ package org.abego.treelayout.internal.util.java.lang.string;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringUtil
/*     */ {
/*     */   public static String quote(String s, String nullResult) {
/*  46 */     if (s == null) {
/*  47 */       return nullResult;
/*     */     }
/*  49 */     StringBuffer result = new StringBuffer();
/*  50 */     result.append('"');
/*  51 */     int length = s.length();
/*  52 */     for (int i = 0; i < length; i++) {
/*  53 */       char c = s.charAt(i);
/*  54 */       switch (c) {
/*     */         case '\b':
/*  56 */           result.append("\\b");
/*     */           break;
/*     */         
/*     */         case '\f':
/*  60 */           result.append("\\f");
/*     */           break;
/*     */         
/*     */         case '\n':
/*  64 */           result.append("\\n");
/*     */           break;
/*     */         
/*     */         case '\r':
/*  68 */           result.append("\\r");
/*     */           break;
/*     */         
/*     */         case '\t':
/*  72 */           result.append("\\t");
/*     */           break;
/*     */         
/*     */         case '\\':
/*  76 */           result.append("\\\\");
/*     */           break;
/*     */         
/*     */         case '"':
/*  80 */           result.append("\\\"");
/*     */           break;
/*     */         
/*     */         default:
/*  84 */           if (c < ' ' || c >= '') {
/*  85 */             String n = Integer.toHexString(c);
/*  86 */             result.append("\\u");
/*  87 */             result.append("0000".substring(n.length()));
/*  88 */             result.append(n); break;
/*     */           } 
/*  90 */           result.append(c);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/*  95 */     result.append('"');
/*  96 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String quote(String s) {
/* 106 */     return quote(s, "null");
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/abego/treelayout/internal/util/java/lang/string/StringUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */