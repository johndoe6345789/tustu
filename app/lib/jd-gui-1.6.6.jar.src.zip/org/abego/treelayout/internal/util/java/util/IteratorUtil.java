/*    */ package org.abego.treelayout.internal.util.java.util;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.ListIterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IteratorUtil
/*    */ {
/*    */   private static class ReverseIterator<T>
/*    */     implements Iterator<T>
/*    */   {
/*    */     private ListIterator<T> listIterator;
/*    */     
/*    */     public ReverseIterator(List<T> list) {
/* 49 */       this.listIterator = list.listIterator(list.size());
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean hasNext() {
/* 54 */       return this.listIterator.hasPrevious();
/*    */     }
/*    */ 
/*    */     
/*    */     public T next() {
/* 59 */       return this.listIterator.previous();
/*    */     }
/*    */ 
/*    */     
/*    */     public void remove() {
/* 64 */       this.listIterator.remove();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> Iterator<T> createReverseIterator(List<T> list) {
/* 79 */     return new ReverseIterator<T>(list);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/abego/treelayout/internal/util/java/util/IteratorUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */