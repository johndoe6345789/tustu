/*     */ package org.fife.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PushbackInputStream;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnicodeReader
/*     */   extends Reader
/*     */ {
/*  50 */   private InputStreamReader internalIn = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String encoding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int BOM_SIZE = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnicodeReader(String file) throws IOException {
/*  78 */     this(new File(file));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnicodeReader(File file) throws IOException {
/*  95 */     this(new FileInputStream(file));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnicodeReader(File file, String defaultEncoding) throws IOException {
/* 115 */     this(new FileInputStream(file), defaultEncoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnicodeReader(InputStream in) throws IOException {
/* 128 */     this(in, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnicodeReader(InputStream in, String defaultEncoding) throws IOException {
/* 146 */     init(in, defaultEncoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 155 */     this.internalIn.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncoding() {
/* 168 */     return this.encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init(InputStream in, String defaultEncoding) throws IOException {
/*     */     int unread;
/* 183 */     PushbackInputStream tempIn = new PushbackInputStream(in, 4);
/*     */     
/* 185 */     byte[] bom = new byte[4];
/*     */     
/* 187 */     int n = tempIn.read(bom, 0, bom.length);
/*     */     
/* 189 */     if (bom[0] == 0 && bom[1] == 0 && bom[2] == -2 && bom[3] == -1) {
/*     */       
/* 191 */       this.encoding = "UTF-32BE";
/* 192 */       unread = n - 4;
/*     */     
/*     */     }
/* 195 */     else if (n == 4 && bom[0] == -1 && bom[1] == -2 && bom[2] == 0 && bom[3] == 0) {
/*     */ 
/*     */       
/* 198 */       this.encoding = "UTF-32LE";
/* 199 */       unread = n - 4;
/*     */     
/*     */     }
/* 202 */     else if (bom[0] == -17 && bom[1] == -69 && bom[2] == -65) {
/*     */ 
/*     */       
/* 205 */       this.encoding = "UTF-8";
/* 206 */       unread = n - 3;
/*     */     
/*     */     }
/* 209 */     else if (bom[0] == -2 && bom[1] == -1) {
/* 210 */       this.encoding = "UTF-16BE";
/* 211 */       unread = n - 2;
/*     */     
/*     */     }
/* 214 */     else if (bom[0] == -1 && bom[1] == -2) {
/* 215 */       this.encoding = "UTF-16LE";
/* 216 */       unread = n - 2;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 221 */       this.encoding = defaultEncoding;
/* 222 */       unread = n;
/*     */     } 
/*     */     
/* 225 */     if (unread > 0) {
/* 226 */       tempIn.unread(bom, n - unread, unread);
/*     */     }
/* 228 */     else if (unread < -1) {
/* 229 */       tempIn.unread(bom, 0, 0);
/*     */     } 
/*     */ 
/*     */     
/* 233 */     if (this.encoding == null) {
/* 234 */       this.internalIn = new InputStreamReader(tempIn);
/* 235 */       this.encoding = this.internalIn.getEncoding();
/*     */     } else {
/*     */       
/* 238 */       this.internalIn = new InputStreamReader(tempIn, this.encoding);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(char[] cbuf, int off, int len) throws IOException {
/* 258 */     return this.internalIn.read(cbuf, off, len);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/io/UnicodeReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */