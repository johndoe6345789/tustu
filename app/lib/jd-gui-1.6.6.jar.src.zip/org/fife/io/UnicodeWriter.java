/*     */ package org.fife.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnicodeWriter
/*     */   extends Writer
/*     */ {
/*     */   public static final String PROPERTY_WRITE_UTF8_BOM = "UnicodeWriter.writeUtf8BOM";
/*     */   private OutputStreamWriter internalOut;
/*  50 */   private static final byte[] UTF8_BOM = new byte[] { -17, -69, -65 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private static final byte[] UTF16LE_BOM = new byte[] { -1, -2 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private static final byte[] UTF16BE_BOM = new byte[] { -2, -1 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private static final byte[] UTF32LE_BOM = new byte[] { -1, -2, 0, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private static final byte[] UTF32BE_BOM = new byte[] { 0, 0, -2, -1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnicodeWriter(String fileName, String encoding) throws IOException {
/*  90 */     this(new FileOutputStream(fileName), encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnicodeWriter(File file, String encoding) throws IOException {
/* 104 */     this(new FileOutputStream(file), encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnicodeWriter(OutputStream out, String encoding) throws IOException {
/* 117 */     init(out, encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 128 */     this.internalOut.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 139 */     this.internalOut.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncoding() {
/* 150 */     return this.internalOut.getEncoding();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean getWriteUtf8BOM() {
/* 162 */     String prop = System.getProperty("UnicodeWriter.writeUtf8BOM");
/*     */     
/* 164 */     if (prop != null && Boolean.valueOf(prop).equals(Boolean.FALSE)) {
/* 165 */       return false;
/*     */     }
/* 167 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(OutputStream out, String encoding) throws IOException {
/* 181 */     this.internalOut = new OutputStreamWriter(out, encoding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     if ("UTF-8".equals(encoding)) {
/* 188 */       if (getWriteUtf8BOM()) {
/* 189 */         out.write(UTF8_BOM, 0, UTF8_BOM.length);
/*     */       }
/*     */     }
/* 192 */     else if ("UTF-16LE".equals(encoding)) {
/* 193 */       out.write(UTF16LE_BOM, 0, UTF16LE_BOM.length);
/*     */     }
/* 195 */     else if ("UTF-16BE".equals(encoding)) {
/* 196 */       out.write(UTF16BE_BOM, 0, UTF16BE_BOM.length);
/*     */     }
/* 198 */     else if ("UTF-32LE".equals(encoding)) {
/* 199 */       out.write(UTF32LE_BOM, 0, UTF32LE_BOM.length);
/*     */     }
/* 201 */     else if ("UTF-32".equals(encoding) || "UTF-32BE".equals(encoding)) {
/* 202 */       out.write(UTF32BE_BOM, 0, UTF32BE_BOM.length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setWriteUtf8BOM(boolean write) {
/* 216 */     System.setProperty("UnicodeWriter.writeUtf8BOM", 
/* 217 */         Boolean.toString(write));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(char[] cbuf, int off, int len) throws IOException {
/* 231 */     this.internalOut.write(cbuf, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int c) throws IOException {
/* 243 */     this.internalOut.write(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String str, int off, int len) throws IOException {
/* 257 */     this.internalOut.write(str, off, len);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/io/UnicodeWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */