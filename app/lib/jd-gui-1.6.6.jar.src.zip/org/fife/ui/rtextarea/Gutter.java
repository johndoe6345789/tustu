/*      */ package org.fife.ui.rtextarea;
/*      */ 
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.ComponentOrientation;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.ComponentAdapter;
/*      */ import java.awt.event.ComponentEvent;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.border.EmptyBorder;
/*      */ import javax.swing.event.DocumentEvent;
/*      */ import javax.swing.event.DocumentListener;
/*      */ import javax.swing.text.BadLocationException;
/*      */ import org.fife.ui.rsyntaxtextarea.ActiveLineRangeEvent;
/*      */ import org.fife.ui.rsyntaxtextarea.ActiveLineRangeListener;
/*      */ import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Gutter
/*      */   extends JPanel
/*      */ {
/*   74 */   public static final Color DEFAULT_ACTIVE_LINE_RANGE_COLOR = new Color(51, 153, 255);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RTextArea textArea;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private LineNumberList lineNumberList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Color lineNumberColor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int lineNumberingStartIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Font lineNumberFont;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IconRowHeader iconArea;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean iconRowHeaderInheritsGutterBackground;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FoldIndicator foldIndicator;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private transient TextAreaListener listener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Gutter(RTextArea textArea) {
/*  131 */     this.listener = new TextAreaListener();
/*  132 */     this.lineNumberColor = Color.gray;
/*  133 */     this.lineNumberFont = RTextArea.getDefaultFont();
/*  134 */     this.lineNumberingStartIndex = 1;
/*  135 */     this.iconRowHeaderInheritsGutterBackground = false;
/*      */     
/*  137 */     setTextArea(textArea);
/*  138 */     setLayout(new BorderLayout());
/*  139 */     if (this.textArea != null) {
/*      */ 
/*      */       
/*  142 */       setLineNumbersEnabled(true);
/*  143 */       if (this.textArea instanceof RSyntaxTextArea) {
/*  144 */         RSyntaxTextArea rsta = (RSyntaxTextArea)this.textArea;
/*  145 */         setFoldIndicatorEnabled(rsta.isCodeFoldingEnabled());
/*      */       } 
/*      */     } 
/*      */     
/*  149 */     setBorder(new GutterBorder(0, 0, 0, 1));
/*      */     
/*  151 */     Color bg = null;
/*  152 */     if (textArea != null) {
/*  153 */       bg = textArea.getBackground();
/*      */     }
/*  155 */     setBackground((bg != null) ? bg : Color.WHITE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GutterIconInfo addLineTrackingIcon(int line, Icon icon) throws BadLocationException {
/*  178 */     return addLineTrackingIcon(line, icon, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GutterIconInfo addLineTrackingIcon(int line, Icon icon, String tip) throws BadLocationException {
/*  201 */     int offs = this.textArea.getLineStartOffset(line);
/*  202 */     return addOffsetTrackingIcon(offs, icon, tip);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GutterIconInfo addOffsetTrackingIcon(int offs, Icon icon) throws BadLocationException {
/*  222 */     return addOffsetTrackingIcon(offs, icon, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GutterIconInfo addOffsetTrackingIcon(int offs, Icon icon, String tip) throws BadLocationException {
/*  243 */     return this.iconArea.addOffsetTrackingIcon(offs, icon, tip);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void clearActiveLineRange() {
/*  253 */     this.iconArea.clearActiveLineRange();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getActiveLineRangeColor() {
/*  264 */     return this.iconArea.getActiveLineRangeColor();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getArmedFoldBackground() {
/*  277 */     return this.foldIndicator.getFoldIconArmedBackground();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Icon getBookmarkIcon() {
/*  290 */     return this.iconArea.getBookmarkIcon();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GutterIconInfo[] getBookmarks() {
/*  302 */     return this.iconArea.getBookmarks();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getBorderColor() {
/*  313 */     return ((GutterBorder)getBorder()).getColor();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getFoldBackground() {
/*  324 */     return this.foldIndicator.getFoldIconBackground();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getFoldIndicatorForeground() {
/*  335 */     return this.foldIndicator.getForeground();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getIconRowHeaderInheritsGutterBackground() {
/*  347 */     return this.iconRowHeaderInheritsGutterBackground;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getLineNumberColor() {
/*  358 */     return this.lineNumberColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getLineNumberFont() {
/*  369 */     return this.lineNumberFont;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLineNumberingStartIndex() {
/*  381 */     return this.lineNumberingStartIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getLineNumbersEnabled() {
/*  391 */     for (int i = 0; i < getComponentCount(); i++) {
/*  392 */       if (getComponent(i) == this.lineNumberList) {
/*  393 */         return true;
/*      */       }
/*      */     } 
/*  396 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getShowCollapsedRegionToolTips() {
/*  408 */     return this.foldIndicator.getShowCollapsedRegionToolTips();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GutterIconInfo[] getTrackingIcons(Point p) throws BadLocationException {
/*  422 */     int offs = this.textArea.viewToModel(new Point(0, p.y));
/*  423 */     int line = this.textArea.getLineOfOffset(offs);
/*  424 */     return this.iconArea.getTrackingIcons(line);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFoldIndicatorEnabled() {
/*  435 */     for (int i = 0; i < getComponentCount(); i++) {
/*  436 */       if (getComponent(i) == this.foldIndicator) {
/*  437 */         return true;
/*      */       }
/*      */     } 
/*  440 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBookmarkingEnabled() {
/*  451 */     return this.iconArea.isBookmarkingEnabled();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIconRowHeaderEnabled() {
/*  461 */     for (int i = 0; i < getComponentCount(); i++) {
/*  462 */       if (getComponent(i) == this.iconArea) {
/*  463 */         return true;
/*      */       }
/*      */     } 
/*  466 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAllTrackingIcons() {
/*  477 */     this.iconArea.removeAllTrackingIcons();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeTrackingIcon(GutterIconInfo tag) {
/*  492 */     this.iconArea.removeTrackingIcon(tag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setActiveLineRangeColor(Color color) {
/*  505 */     this.iconArea.setActiveLineRangeColor(color);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setActiveLineRange(int startLine, int endLine) {
/*  518 */     this.iconArea.setActiveLineRange(startLine, endLine);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArmedFoldBackground(Color bg) {
/*  532 */     this.foldIndicator.setFoldIconArmedBackground(bg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBookmarkIcon(Icon icon) {
/*  545 */     this.iconArea.setBookmarkIcon(icon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBookmarkingEnabled(boolean enabled) {
/*  559 */     this.iconArea.setBookmarkingEnabled(enabled);
/*  560 */     if (enabled && !isIconRowHeaderEnabled()) {
/*  561 */       setIconRowHeaderEnabled(true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBorderColor(Color color) {
/*  573 */     ((GutterBorder)getBorder()).setColor(color);
/*  574 */     repaint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setComponentOrientation(ComponentOrientation o) {
/*  587 */     if (getBorder() instanceof GutterBorder)
/*      */     {
/*  589 */       if (o.isLeftToRight()) {
/*  590 */         ((GutterBorder)getBorder()).setEdges(0, 0, 0, 1);
/*      */       } else {
/*      */         
/*  593 */         ((GutterBorder)getBorder()).setEdges(0, 1, 0, 0);
/*      */       } 
/*      */     }
/*  596 */     super.setComponentOrientation(o);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFoldIcons(Icon collapsedIcon, Icon expandedIcon) {
/*  609 */     if (this.foldIndicator != null) {
/*  610 */       this.foldIndicator.setFoldIcons(collapsedIcon, expandedIcon);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFoldIndicatorEnabled(boolean enabled) {
/*  622 */     if (this.foldIndicator != null) {
/*  623 */       if (enabled) {
/*  624 */         add(this.foldIndicator, "After");
/*      */       } else {
/*      */         
/*  627 */         remove(this.foldIndicator);
/*      */       } 
/*  629 */       revalidate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFoldBackground(Color bg) {
/*  642 */     if (bg == null) {
/*  643 */       bg = FoldIndicator.DEFAULT_FOLD_BACKGROUND;
/*      */     }
/*  645 */     this.foldIndicator.setFoldIconBackground(bg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFoldIndicatorForeground(Color fg) {
/*  656 */     if (fg == null) {
/*  657 */       fg = FoldIndicator.DEFAULT_FOREGROUND;
/*      */     }
/*  659 */     this.foldIndicator.setForeground(fg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setIconRowHeaderEnabled(boolean enabled) {
/*  671 */     if (this.iconArea != null) {
/*  672 */       if (enabled) {
/*  673 */         add(this.iconArea, "Before");
/*      */       } else {
/*      */         
/*  676 */         remove(this.iconArea);
/*      */       } 
/*  678 */       revalidate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIconRowHeaderInheritsGutterBackground(boolean inherits) {
/*  693 */     if (inherits != this.iconRowHeaderInheritsGutterBackground) {
/*  694 */       this.iconRowHeaderInheritsGutterBackground = inherits;
/*  695 */       if (this.iconArea != null) {
/*  696 */         this.iconArea.setInheritsGutterBackground(inherits);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLineNumberColor(Color color) {
/*  709 */     if (color != null && !color.equals(this.lineNumberColor)) {
/*  710 */       this.lineNumberColor = color;
/*  711 */       if (this.lineNumberList != null) {
/*  712 */         this.lineNumberList.setForeground(color);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLineNumberFont(Font font) {
/*  725 */     if (font == null) {
/*  726 */       throw new IllegalArgumentException("font cannot be null");
/*      */     }
/*  728 */     if (!font.equals(this.lineNumberFont)) {
/*  729 */       this.lineNumberFont = font;
/*  730 */       if (this.lineNumberList != null) {
/*  731 */         this.lineNumberList.setFont(font);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLineNumberingStartIndex(int index) {
/*  746 */     if (index != this.lineNumberingStartIndex) {
/*  747 */       this.lineNumberingStartIndex = index;
/*  748 */       this.lineNumberList.setLineNumberingStartIndex(index);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setLineNumbersEnabled(boolean enabled) {
/*  760 */     if (this.lineNumberList != null) {
/*  761 */       if (enabled) {
/*  762 */         add(this.lineNumberList);
/*      */       } else {
/*      */         
/*  765 */         remove(this.lineNumberList);
/*      */       } 
/*  767 */       revalidate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShowCollapsedRegionToolTips(boolean show) {
/*  780 */     if (this.foldIndicator != null) {
/*  781 */       this.foldIndicator.setShowCollapsedRegionToolTips(show);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setTextArea(RTextArea textArea) {
/*  794 */     if (this.textArea != null) {
/*  795 */       this.listener.uninstall();
/*      */     }
/*      */     
/*  798 */     if (textArea != null) {
/*      */ 
/*      */       
/*  801 */       RTextAreaEditorKit kit = (RTextAreaEditorKit)textArea.getUI().getEditorKit(textArea);
/*      */       
/*  803 */       if (this.lineNumberList == null) {
/*  804 */         this.lineNumberList = kit.createLineNumberList(textArea);
/*  805 */         this.lineNumberList.setFont(getLineNumberFont());
/*  806 */         this.lineNumberList.setForeground(getLineNumberColor());
/*  807 */         this.lineNumberList.setLineNumberingStartIndex(
/*  808 */             getLineNumberingStartIndex());
/*      */       } else {
/*      */         
/*  811 */         this.lineNumberList.setTextArea(textArea);
/*      */       } 
/*  813 */       if (this.iconArea == null) {
/*  814 */         this.iconArea = kit.createIconRowHeader(textArea);
/*  815 */         this.iconArea.setInheritsGutterBackground(
/*  816 */             getIconRowHeaderInheritsGutterBackground());
/*      */       } else {
/*      */         
/*  819 */         this.iconArea.setTextArea(textArea);
/*      */       } 
/*  821 */       if (this.foldIndicator == null) {
/*  822 */         this.foldIndicator = new FoldIndicator(textArea);
/*      */       } else {
/*      */         
/*  825 */         this.foldIndicator.setTextArea(textArea);
/*      */       } 
/*      */       
/*  828 */       this.listener.install(textArea);
/*      */     } 
/*      */ 
/*      */     
/*  832 */     this.textArea = textArea;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean toggleBookmark(int line) throws BadLocationException {
/*  848 */     return this.iconArea.toggleBookmark(line);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBorder(Border border) {
/*  870 */     if (border instanceof GutterBorder) {
/*  871 */       super.setBorder(border);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class GutterBorder
/*      */     extends EmptyBorder
/*      */   {
/*      */     private Color color;
/*      */     private Rectangle visibleRect;
/*      */     
/*      */     public GutterBorder(int top, int left, int bottom, int right) {
/*  883 */       super(top, left, bottom, right);
/*  884 */       this.color = new Color(221, 221, 221);
/*  885 */       this.visibleRect = new Rectangle();
/*      */     }
/*      */     
/*      */     public Color getColor() {
/*  889 */       return this.color;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
/*  896 */       this.visibleRect = g.getClipBounds(this.visibleRect);
/*  897 */       if (this.visibleRect == null) {
/*  898 */         this.visibleRect = ((JComponent)c).getVisibleRect();
/*      */       }
/*      */       
/*  901 */       g.setColor(this.color);
/*  902 */       if (this.left == 1) {
/*  903 */         g.drawLine(0, this.visibleRect.y, 0, this.visibleRect.y + this.visibleRect.height);
/*      */       }
/*      */       else {
/*      */         
/*  907 */         g.drawLine(width - 1, this.visibleRect.y, width - 1, this.visibleRect.y + this.visibleRect.height);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void setColor(Color color) {
/*  914 */       this.color = color;
/*      */     }
/*      */     
/*      */     public void setEdges(int top, int left, int bottom, int right) {
/*  918 */       this.top = top;
/*  919 */       this.left = left;
/*  920 */       this.bottom = bottom;
/*  921 */       this.right = right;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class TextAreaListener
/*      */     extends ComponentAdapter
/*      */     implements DocumentListener, PropertyChangeListener, ActiveLineRangeListener
/*      */   {
/*      */     private boolean installed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private TextAreaListener() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void activeLineRangeChanged(ActiveLineRangeEvent e) {
/*  951 */       if (e.getMin() == -1) {
/*  952 */         Gutter.this.clearActiveLineRange();
/*      */       } else {
/*      */         
/*  955 */         Gutter.this.setActiveLineRange(e.getMin(), e.getMax());
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void changedUpdate(DocumentEvent e) {}
/*      */ 
/*      */     
/*      */     public void componentResized(ComponentEvent e) {
/*  964 */       Gutter.this.revalidate();
/*      */     }
/*      */     
/*      */     protected void handleDocumentEvent(DocumentEvent e) {
/*  968 */       for (int i = 0; i < Gutter.this.getComponentCount(); i++) {
/*      */         
/*  970 */         AbstractGutterComponent agc = (AbstractGutterComponent)Gutter.this.getComponent(i);
/*  971 */         agc.handleDocumentEvent(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void insertUpdate(DocumentEvent e) {
/*  977 */       handleDocumentEvent(e);
/*      */     }
/*      */     
/*      */     public void install(RTextArea textArea) {
/*  981 */       if (this.installed) {
/*  982 */         uninstall();
/*      */       }
/*  984 */       textArea.addComponentListener(this);
/*  985 */       textArea.getDocument().addDocumentListener(this);
/*  986 */       textArea.addPropertyChangeListener(this);
/*  987 */       if (textArea instanceof RSyntaxTextArea) {
/*  988 */         RSyntaxTextArea rsta = (RSyntaxTextArea)textArea;
/*  989 */         rsta.addActiveLineRangeListener(this);
/*  990 */         rsta.getFoldManager().addPropertyChangeListener(this);
/*      */       } 
/*  992 */       this.installed = true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void propertyChange(PropertyChangeEvent e) {
/*  998 */       String name = e.getPropertyName();
/*      */ 
/*      */ 
/*      */       
/* 1002 */       if ("font".equals(name) || "RSTA.syntaxScheme"
/* 1003 */         .equals(name)) {
/* 1004 */         for (int i = 0; i < Gutter.this.getComponentCount(); i++)
/*      */         {
/* 1006 */           AbstractGutterComponent agc = (AbstractGutterComponent)Gutter.this.getComponent(i);
/* 1007 */           agc.lineHeightsChanged();
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 1012 */       else if ("RSTA.codeFolding".equals(name)) {
/* 1013 */         boolean foldingEnabled = ((Boolean)e.getNewValue()).booleanValue();
/* 1014 */         if (Gutter.this.lineNumberList != null)
/*      */         {
/* 1016 */           Gutter.this.lineNumberList.updateCellWidths();
/*      */         }
/* 1018 */         Gutter.this.setFoldIndicatorEnabled(foldingEnabled);
/*      */ 
/*      */       
/*      */       }
/* 1022 */       else if ("FoldsUpdated".equals(name)) {
/* 1023 */         Gutter.this.repaint();
/*      */       
/*      */       }
/* 1026 */       else if ("document".equals(name)) {
/*      */         
/* 1028 */         RDocument old = (RDocument)e.getOldValue();
/* 1029 */         if (old != null) {
/* 1030 */           old.removeDocumentListener(this);
/*      */         }
/* 1032 */         RDocument newDoc = (RDocument)e.getNewValue();
/* 1033 */         if (newDoc != null) {
/* 1034 */           newDoc.addDocumentListener(this);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void removeUpdate(DocumentEvent e) {
/* 1042 */       handleDocumentEvent(e);
/*      */     }
/*      */     
/*      */     public void uninstall() {
/* 1046 */       if (this.installed) {
/* 1047 */         Gutter.this.textArea.removeComponentListener(this);
/* 1048 */         Gutter.this.textArea.getDocument().removeDocumentListener(this);
/* 1049 */         Gutter.this.textArea.removePropertyChangeListener(this);
/* 1050 */         if (Gutter.this.textArea instanceof RSyntaxTextArea) {
/* 1051 */           RSyntaxTextArea rsta = (RSyntaxTextArea)Gutter.this.textArea;
/* 1052 */           rsta.removeActiveLineRangeListener(this);
/* 1053 */           rsta.getFoldManager().removePropertyChangeListener(this);
/*      */         } 
/* 1055 */         this.installed = false;
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/Gutter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */