/*     */ package org.fife.ui.rtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.ToolTipManager;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.text.Position;
/*     */ import javax.swing.text.View;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IconRowHeader
/*     */   extends AbstractGutterComponent
/*     */   implements MouseListener
/*     */ {
/*     */   protected List<GutterIconImpl> trackingIcons;
/*     */   protected int width;
/*     */   private boolean bookmarkingEnabled;
/*     */   private Icon bookmarkIcon;
/*     */   protected Rectangle visibleRect;
/*     */   protected Insets textAreaInsets;
/*     */   protected int activeLineRangeStart;
/*     */   protected int activeLineRangeEnd;
/*     */   private Color activeLineRangeColor;
/*     */   private boolean inheritsGutterBackground;
/*     */   
/*     */   public IconRowHeader(RTextArea textArea) {
/* 121 */     super(textArea);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GutterIconInfo addOffsetTrackingIcon(int offs, Icon icon) throws BadLocationException {
/* 139 */     return addOffsetTrackingIcon(offs, icon, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GutterIconInfo addOffsetTrackingIcon(int offs, Icon icon, String tip) throws BadLocationException {
/* 161 */     if (offs < 0 || offs > this.textArea.getDocument().getLength()) {
/* 162 */       throw new BadLocationException("Offset " + offs + " not in " + "required range of 0-" + this.textArea
/* 163 */           .getDocument().getLength(), offs);
/*     */     }
/*     */     
/* 166 */     Position pos = this.textArea.getDocument().createPosition(offs);
/* 167 */     GutterIconImpl ti = new GutterIconImpl(icon, pos, tip);
/* 168 */     if (this.trackingIcons == null) {
/* 169 */       this.trackingIcons = new ArrayList<>(1);
/*     */     }
/* 171 */     int index = Collections.binarySearch((List)this.trackingIcons, ti);
/* 172 */     if (index < 0) {
/* 173 */       index = -(index + 1);
/*     */     }
/* 175 */     this.trackingIcons.add(index, ti);
/* 176 */     repaint();
/* 177 */     return ti;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearActiveLineRange() {
/* 187 */     if (this.activeLineRangeStart != -1 || this.activeLineRangeEnd != -1) {
/* 188 */       this.activeLineRangeStart = this.activeLineRangeEnd = -1;
/* 189 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getActiveLineRangeColor() {
/* 201 */     return this.activeLineRangeColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Icon getBookmarkIcon() {
/* 214 */     return this.bookmarkIcon;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GutterIconInfo[] getBookmarks() {
/* 226 */     List<GutterIconInfo> retVal = new ArrayList<>(1);
/*     */     
/* 228 */     if (this.trackingIcons != null) {
/* 229 */       for (int i = 0; i < this.trackingIcons.size(); i++) {
/* 230 */         GutterIconImpl ti = getTrackingIcon(i);
/* 231 */         if (ti.getIcon() == this.bookmarkIcon) {
/* 232 */           retVal.add(ti);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 237 */     GutterIconInfo[] array = new GutterIconInfo[retVal.size()];
/* 238 */     return retVal.<GutterIconInfo>toArray(array);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void handleDocumentEvent(DocumentEvent e) {
/* 248 */     int newLineCount = this.textArea.getLineCount();
/* 249 */     if (newLineCount != this.currentLineCount) {
/* 250 */       this.currentLineCount = newLineCount;
/* 251 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 261 */     int h = (this.textArea != null) ? this.textArea.getHeight() : 100;
/* 262 */     return new Dimension(this.width, h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToolTipText(MouseEvent e) {
/*     */     try {
/* 274 */       int line = viewToModelLine(e.getPoint());
/* 275 */       if (line > -1) {
/* 276 */         GutterIconInfo[] infos = getTrackingIcons(line);
/* 277 */         if (infos.length > 0)
/*     */         {
/* 279 */           return infos[infos.length - 1].getToolTip();
/*     */         }
/*     */       } 
/* 282 */     } catch (BadLocationException ble) {
/* 283 */       ble.printStackTrace();
/*     */     } 
/* 285 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected GutterIconImpl getTrackingIcon(int index) {
/* 290 */     return this.trackingIcons.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GutterIconInfo[] getTrackingIcons(int line) throws BadLocationException {
/* 305 */     List<GutterIconInfo> retVal = new ArrayList<>(1);
/*     */     
/* 307 */     if (this.trackingIcons != null) {
/* 308 */       int start = this.textArea.getLineStartOffset(line);
/* 309 */       int end = this.textArea.getLineEndOffset(line);
/* 310 */       if (line == this.textArea.getLineCount() - 1) {
/* 311 */         end++;
/*     */       }
/* 313 */       for (int i = 0; i < this.trackingIcons.size(); i++) {
/* 314 */         GutterIconImpl ti = getTrackingIcon(i);
/* 315 */         int offs = ti.getMarkedOffset();
/* 316 */         if (offs >= start && offs < end) {
/* 317 */           retVal.add(ti);
/*     */         }
/* 319 */         else if (offs >= end) {
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 325 */     GutterIconInfo[] array = new GutterIconInfo[retVal.size()];
/* 326 */     return retVal.<GutterIconInfo>toArray(array);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init() {
/* 334 */     super.init();
/*     */     
/* 336 */     this.visibleRect = new Rectangle();
/* 337 */     this.width = 16;
/* 338 */     addMouseListener(this);
/* 339 */     this.activeLineRangeStart = this.activeLineRangeEnd = -1;
/* 340 */     setActiveLineRangeColor((Color)null);
/*     */ 
/*     */ 
/*     */     
/* 344 */     updateBackground();
/*     */     
/* 346 */     ToolTipManager.sharedInstance().registerComponent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBookmarkingEnabled() {
/* 358 */     return this.bookmarkingEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void lineHeightsChanged() {
/* 367 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseExited(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent e) {
/* 388 */     if (this.bookmarkingEnabled && this.bookmarkIcon != null) {
/*     */       try {
/* 390 */         int line = viewToModelLine(e.getPoint());
/* 391 */         if (line > -1) {
/* 392 */           toggleBookmark(line);
/*     */         }
/* 394 */       } catch (BadLocationException ble) {
/* 395 */         ble.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintComponent(Graphics g) {
/* 412 */     if (this.textArea == null) {
/*     */       return;
/*     */     }
/*     */     
/* 416 */     this.visibleRect = g.getClipBounds(this.visibleRect);
/* 417 */     if (this.visibleRect == null) {
/* 418 */       this.visibleRect = getVisibleRect();
/*     */     }
/*     */     
/* 421 */     if (this.visibleRect == null) {
/*     */       return;
/*     */     }
/* 424 */     paintBackgroundImpl(g, this.visibleRect);
/*     */     
/* 426 */     if (this.textArea.getLineWrap()) {
/* 427 */       paintComponentWrapped(g);
/*     */       
/*     */       return;
/*     */     } 
/* 431 */     Document doc = this.textArea.getDocument();
/* 432 */     Element root = doc.getDefaultRootElement();
/* 433 */     this.textAreaInsets = this.textArea.getInsets(this.textAreaInsets);
/* 434 */     if (this.visibleRect.y < this.textAreaInsets.top) {
/* 435 */       this.visibleRect.height -= this.textAreaInsets.top - this.visibleRect.y;
/* 436 */       this.visibleRect.y = this.textAreaInsets.top;
/*     */     } 
/*     */ 
/*     */     
/* 440 */     int cellHeight = this.textArea.getLineHeight();
/* 441 */     int topLine = (this.visibleRect.y - this.textAreaInsets.top) / cellHeight;
/* 442 */     int bottomLine = Math.min(topLine + this.visibleRect.height / cellHeight + 1, root
/* 443 */         .getElementCount());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 448 */     int y = topLine * cellHeight + this.textAreaInsets.top;
/*     */     
/* 450 */     if ((this.activeLineRangeStart >= topLine && this.activeLineRangeStart <= bottomLine) || (this.activeLineRangeEnd >= topLine && this.activeLineRangeEnd <= bottomLine) || (this.activeLineRangeStart <= topLine && this.activeLineRangeEnd >= bottomLine)) {
/*     */ 
/*     */ 
/*     */       
/* 454 */       g.setColor(this.activeLineRangeColor);
/* 455 */       int firstLine = Math.max(this.activeLineRangeStart, topLine);
/* 456 */       int y1 = firstLine * cellHeight + this.textAreaInsets.top;
/* 457 */       int lastLine = Math.min(this.activeLineRangeEnd, bottomLine);
/* 458 */       int y2 = (lastLine + 1) * cellHeight + this.textAreaInsets.top - 1;
/*     */       
/* 460 */       int j = y1;
/* 461 */       while (j <= y2) {
/* 462 */         int yEnd = Math.min(y2, j + getWidth());
/* 463 */         int xEnd = yEnd - j;
/* 464 */         g.drawLine(0, j, xEnd, yEnd);
/* 465 */         j += 2;
/*     */       } 
/*     */       
/* 468 */       int i = 2;
/* 469 */       while (i < getWidth()) {
/* 470 */         int yEnd = y1 + getWidth() - i;
/* 471 */         g.drawLine(i, y1, getWidth(), yEnd);
/* 472 */         i += 2;
/*     */       } 
/*     */       
/* 475 */       if (firstLine == this.activeLineRangeStart) {
/* 476 */         g.drawLine(0, y1, getWidth(), y1);
/*     */       }
/* 478 */       if (lastLine == this.activeLineRangeEnd) {
/* 479 */         g.drawLine(0, y2, getWidth(), y2);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 484 */     if (this.trackingIcons != null) {
/* 485 */       int lastLine = bottomLine;
/* 486 */       for (int i = this.trackingIcons.size() - 1; i >= 0; i--) {
/* 487 */         GutterIconInfo ti = getTrackingIcon(i);
/* 488 */         int offs = ti.getMarkedOffset();
/* 489 */         if (offs >= 0 && offs <= doc.getLength()) {
/* 490 */           int line = root.getElementIndex(offs);
/* 491 */           if (line <= lastLine && line >= topLine) {
/* 492 */             Icon icon = ti.getIcon();
/* 493 */             if (icon != null) {
/* 494 */               int y2 = y + (line - topLine) * cellHeight;
/* 495 */               y2 += (cellHeight - icon.getIconHeight()) / 2;
/* 496 */               ti.getIcon().paintIcon(this, g, 0, y2);
/* 497 */               lastLine = line - 1;
/*     */             }
/*     */           
/* 500 */           } else if (line < topLine) {
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintBackgroundImpl(Graphics g, Rectangle visibleRect) {
/* 517 */     Color bg = getBackground();
/* 518 */     if (this.inheritsGutterBackground && getGutter() != null) {
/* 519 */       bg = getGutter().getBackground();
/*     */     }
/* 521 */     g.setColor(bg);
/* 522 */     g.fillRect(0, visibleRect.y, this.width, visibleRect.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintComponentWrapped(Graphics g) {
/* 562 */     RTextAreaUI ui = (RTextAreaUI)this.textArea.getUI();
/* 563 */     View v = ui.getRootView(this.textArea).getView(0);
/*     */     
/* 565 */     Document doc = this.textArea.getDocument();
/* 566 */     Element root = doc.getDefaultRootElement();
/* 567 */     int lineCount = root.getElementCount();
/* 568 */     int topPosition = this.textArea.viewToModel(new Point(this.visibleRect.x, this.visibleRect.y));
/*     */     
/* 570 */     int topLine = root.getElementIndex(topPosition);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 576 */     Rectangle visibleEditorRect = ui.getVisibleEditorRect();
/* 577 */     Rectangle r = getChildViewBounds(v, topLine, visibleEditorRect);
/*     */     
/* 579 */     int y = r.y;
/*     */     
/* 581 */     int visibleBottom = this.visibleRect.y + this.visibleRect.height;
/*     */ 
/*     */     
/* 584 */     int currentIcon = -1;
/* 585 */     if (this.trackingIcons != null) {
/* 586 */       for (int i = 0; i < this.trackingIcons.size(); i++) {
/* 587 */         GutterIconImpl icon = getTrackingIcon(i);
/* 588 */         int offs = icon.getMarkedOffset();
/* 589 */         if (offs >= 0 && offs <= doc.getLength()) {
/* 590 */           int line = root.getElementIndex(offs);
/* 591 */           if (line >= topLine) {
/* 592 */             currentIcon = i;
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 601 */     g.setColor(getForeground());
/* 602 */     int cellHeight = this.textArea.getLineHeight();
/* 603 */     while (y < visibleBottom) {
/*     */       
/* 605 */       r = getChildViewBounds(v, topLine, visibleEditorRect);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 618 */       if (currentIcon > -1) {
/*     */         
/* 620 */         GutterIconImpl toPaint = null;
/* 621 */         while (currentIcon < this.trackingIcons.size()) {
/* 622 */           GutterIconImpl ti = getTrackingIcon(currentIcon);
/* 623 */           int offs = ti.getMarkedOffset();
/* 624 */           if (offs >= 0 && offs <= doc.getLength()) {
/* 625 */             int line = root.getElementIndex(offs);
/* 626 */             if (line == topLine) {
/* 627 */               toPaint = ti;
/*     */             }
/* 629 */             else if (line > topLine) {
/*     */               break;
/*     */             } 
/*     */           } 
/* 633 */           currentIcon++;
/*     */         } 
/* 635 */         if (toPaint != null) {
/* 636 */           Icon icon = toPaint.getIcon();
/* 637 */           if (icon != null) {
/* 638 */             int y2 = y + (cellHeight - icon.getIconHeight()) / 2;
/* 639 */             icon.paintIcon(this, g, 0, y2);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 646 */       y += r.height;
/*     */ 
/*     */ 
/*     */       
/* 650 */       topLine++;
/* 651 */       if (topLine >= lineCount) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeTrackingIcon(Object tag) {
/* 668 */     if (this.trackingIcons != null && this.trackingIcons.remove(tag)) {
/* 669 */       repaint();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAllTrackingIcons() {
/* 681 */     if (this.trackingIcons != null && this.trackingIcons.size() > 0) {
/* 682 */       this.trackingIcons.clear();
/* 683 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeBookmarkTrackingIcons() {
/* 692 */     if (this.trackingIcons != null) {
/* 693 */       this.trackingIcons.removeIf(ti -> (ti.getIcon() == this.bookmarkIcon));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActiveLineRange(int startLine, int endLine) {
/* 706 */     if (startLine != this.activeLineRangeStart || endLine != this.activeLineRangeEnd) {
/*     */       
/* 708 */       this.activeLineRangeStart = startLine;
/* 709 */       this.activeLineRangeEnd = endLine;
/* 710 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActiveLineRangeColor(Color color) {
/* 724 */     if (color == null) {
/* 725 */       color = Gutter.DEFAULT_ACTIVE_LINE_RANGE_COLOR;
/*     */     }
/* 727 */     if (!color.equals(this.activeLineRangeColor)) {
/* 728 */       this.activeLineRangeColor = color;
/* 729 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBookmarkIcon(Icon icon) {
/* 744 */     removeBookmarkTrackingIcons();
/* 745 */     this.bookmarkIcon = icon;
/* 746 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBookmarkingEnabled(boolean enabled) {
/* 761 */     if (enabled != this.bookmarkingEnabled) {
/* 762 */       this.bookmarkingEnabled = enabled;
/* 763 */       if (!enabled) {
/* 764 */         removeBookmarkTrackingIcons();
/*     */       }
/* 766 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInheritsGutterBackground(boolean inherits) {
/* 780 */     if (inherits != this.inheritsGutterBackground) {
/* 781 */       this.inheritsGutterBackground = inherits;
/* 782 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTextArea(RTextArea textArea) {
/* 795 */     removeAllTrackingIcons();
/* 796 */     super.setTextArea(textArea);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean toggleBookmark(int line) throws BadLocationException {
/* 811 */     if (!isBookmarkingEnabled() || getBookmarkIcon() == null) {
/* 812 */       return false;
/*     */     }
/*     */     
/* 815 */     GutterIconInfo[] icons = getTrackingIcons(line);
/* 816 */     if (icons.length == 0) {
/* 817 */       int offs = this.textArea.getLineStartOffset(line);
/* 818 */       addOffsetTrackingIcon(offs, this.bookmarkIcon);
/* 819 */       return true;
/*     */     } 
/*     */     
/* 822 */     boolean found = false;
/* 823 */     for (GutterIconInfo icon : icons) {
/* 824 */       if (icon.getIcon() == this.bookmarkIcon) {
/* 825 */         removeTrackingIcon(icon);
/* 826 */         found = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 835 */     if (!found) {
/* 836 */       int offs = this.textArea.getLineStartOffset(line);
/* 837 */       addOffsetTrackingIcon(offs, this.bookmarkIcon);
/*     */     } 
/*     */     
/* 840 */     return !found;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateBackground() {
/* 851 */     Color bg = UIManager.getColor("Panel.background");
/* 852 */     if (bg == null) {
/* 853 */       bg = (new JPanel()).getBackground();
/*     */     }
/* 855 */     setBackground(bg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateUI() {
/* 864 */     super.updateUI();
/* 865 */     updateBackground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int viewToModelLine(Point p) throws BadLocationException {
/* 877 */     int offs = this.textArea.viewToModel(p);
/* 878 */     return (offs > -1) ? this.textArea.getLineOfOffset(offs) : -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class GutterIconImpl
/*     */     implements GutterIconInfo, Comparable<GutterIconInfo>
/*     */   {
/*     */     private Icon icon;
/*     */     
/*     */     private Position pos;
/*     */     
/*     */     private String toolTip;
/*     */ 
/*     */     
/*     */     GutterIconImpl(Icon icon, Position pos, String toolTip) {
/* 893 */       this.icon = icon;
/* 894 */       this.pos = pos;
/* 895 */       this.toolTip = toolTip;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(GutterIconInfo other) {
/* 900 */       if (other != null) {
/* 901 */         return this.pos.getOffset() - other.getMarkedOffset();
/*     */       }
/* 903 */       return -1;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 908 */       return (o == this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Icon getIcon() {
/* 913 */       return this.icon;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getMarkedOffset() {
/* 918 */       return this.pos.getOffset();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getToolTip() {
/* 923 */       return this.toolTip;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 928 */       return this.icon.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/IconRowHeader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */