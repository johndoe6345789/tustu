/*     */ package org.fife.ui.rtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LineHighlightManager
/*     */ {
/*     */   private RTextArea textArea;
/*     */   private List<LineHighlightInfo> lineHighlights;
/*     */   private LineHighlightInfoComparator comparator;
/*     */   
/*     */   LineHighlightManager(RTextArea textArea) {
/*  41 */     this.textArea = textArea;
/*  42 */     this.comparator = new LineHighlightInfoComparator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object addLineHighlight(int line, Color color) throws BadLocationException {
/*  58 */     int offs = this.textArea.getLineStartOffset(line);
/*     */     
/*  60 */     LineHighlightInfo lhi = new LineHighlightInfo(this.textArea.getDocument().createPosition(offs), color);
/*  61 */     if (this.lineHighlights == null) {
/*  62 */       this.lineHighlights = new ArrayList<>(1);
/*     */     }
/*  64 */     int index = Collections.binarySearch(this.lineHighlights, lhi, this.comparator);
/*  65 */     if (index < 0) {
/*  66 */       index = -(index + 1);
/*     */     }
/*  68 */     this.lineHighlights.add(index, lhi);
/*  69 */     repaintLine(lhi);
/*  70 */     return lhi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Object> getCurrentLineHighlightTags() {
/*  81 */     return (this.lineHighlights == null) ? Collections.<Object>emptyList() : new ArrayList(this.lineHighlights);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getLineHighlightCount() {
/*  92 */     return (this.lineHighlights == null) ? 0 : this.lineHighlights.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintLineHighlights(Graphics g) {
/* 103 */     int count = (this.lineHighlights == null) ? 0 : this.lineHighlights.size();
/* 104 */     if (count > 0) {
/*     */       
/* 106 */       int docLen = this.textArea.getDocument().getLength();
/* 107 */       Rectangle vr = this.textArea.getVisibleRect();
/* 108 */       int lineHeight = this.textArea.getLineHeight();
/*     */ 
/*     */       
/*     */       try {
/* 112 */         for (int i = 0; i < count; i++) {
/* 113 */           LineHighlightInfo lhi = this.lineHighlights.get(i);
/* 114 */           int offs = lhi.getOffset();
/* 115 */           if (offs >= 0 && offs <= docLen) {
/* 116 */             int y = this.textArea.yForLineContaining(offs);
/* 117 */             if (y > vr.y - lineHeight) {
/* 118 */               if (y < vr.y + vr.height) {
/* 119 */                 g.setColor(lhi.getColor());
/* 120 */                 g.fillRect(0, y, this.textArea.getWidth(), lineHeight);
/*     */               }
/*     */               else {
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/* 129 */       } catch (BadLocationException ble) {
/* 130 */         ble.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAllLineHighlights() {
/* 143 */     if (this.lineHighlights != null) {
/* 144 */       this.lineHighlights.clear();
/* 145 */       this.textArea.repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeLineHighlight(Object tag) {
/* 157 */     if (tag instanceof LineHighlightInfo) {
/* 158 */       this.lineHighlights.remove(tag);
/* 159 */       repaintLine((LineHighlightInfo)tag);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void repaintLine(LineHighlightInfo lhi) {
/* 170 */     int offs = lhi.getOffset();
/*     */     
/* 172 */     if (offs >= 0 && offs <= this.textArea.getDocument().getLength()) {
/*     */       try {
/* 174 */         int y = this.textArea.yForLineContaining(offs);
/* 175 */         if (y > -1) {
/* 176 */           this.textArea.repaint(0, y, this.textArea
/* 177 */               .getWidth(), this.textArea.getLineHeight());
/*     */         }
/* 179 */       } catch (BadLocationException ble) {
/* 180 */         ble.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class LineHighlightInfo
/*     */   {
/*     */     private Position offs;
/*     */     
/*     */     private Color color;
/*     */ 
/*     */     
/*     */     LineHighlightInfo(Position offs, Color c) {
/* 195 */       this.offs = offs;
/* 196 */       this.color = c;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object other) {
/* 201 */       if (other instanceof LineHighlightInfo) {
/* 202 */         LineHighlightInfo lhi2 = (LineHighlightInfo)other;
/* 203 */         return (getOffset() == lhi2.getOffset() && 
/* 204 */           getColor() == null) ? ((lhi2.getColor() == null)) : 
/* 205 */           getColor().equals(lhi2.getColor());
/*     */       } 
/* 207 */       return false;
/*     */     }
/*     */     
/*     */     public Color getColor() {
/* 211 */       return this.color;
/*     */     }
/*     */     
/*     */     public int getOffset() {
/* 215 */       return this.offs.getOffset();
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 220 */       return getOffset();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class LineHighlightInfoComparator
/*     */     implements Comparator<LineHighlightInfo>
/*     */   {
/*     */     private LineHighlightInfoComparator() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(LineHighlightManager.LineHighlightInfo lhi1, LineHighlightManager.LineHighlightInfo lhi2) {
/* 239 */       if (lhi1.getOffset() < lhi2.getOffset()) {
/* 240 */         return -1;
/*     */       }
/* 242 */       return (lhi1.getOffset() == lhi2.getOffset()) ? 0 : 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/LineHighlightManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */