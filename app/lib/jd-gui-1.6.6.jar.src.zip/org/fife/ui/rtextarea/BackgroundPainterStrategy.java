package org.fife.ui.rtextarea;

import java.awt.Graphics;
import java.awt.Rectangle;

public interface BackgroundPainterStrategy {
  void paint(Graphics paramGraphics, Rectangle paramRectangle);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/BackgroundPainterStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */