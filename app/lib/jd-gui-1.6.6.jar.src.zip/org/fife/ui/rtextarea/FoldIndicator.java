/*     */ package org.fife.ui.rtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JToolTip;
/*     */ import javax.swing.ToolTipManager;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.MouseInputAdapter;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.text.View;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
/*     */ import org.fife.ui.rsyntaxtextarea.Token;
/*     */ import org.fife.ui.rsyntaxtextarea.focusabletip.TipUtil;
/*     */ import org.fife.ui.rsyntaxtextarea.folding.Fold;
/*     */ import org.fife.ui.rsyntaxtextarea.folding.FoldManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FoldIndicator
/*     */   extends AbstractGutterComponent
/*     */ {
/*     */   private Insets textAreaInsets;
/*     */   private Rectangle visibleRect;
/*     */   private Fold foldWithOutlineShowing;
/*     */   private Color foldIconBackground;
/*     */   private Color foldIconArmedBackground;
/*     */   private Icon collapsedFoldIcon;
/*     */   private Icon expandedFoldIcon;
/*     */   private boolean mouseOverFoldIcon;
/*     */   private boolean paintFoldArmed;
/*     */   private boolean showFoldRegionTips;
/* 109 */   public static final Color DEFAULT_FOREGROUND = Color.gray;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public static final Color DEFAULT_FOLD_BACKGROUND = Color.white;
/*     */ 
/*     */ 
/*     */   
/*     */   private Listener listener;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int WIDTH = 12;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FoldIndicator(RTextArea textArea) {
/* 128 */     super(textArea);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JToolTip createToolTip() {
/* 141 */     JToolTip tip = super.createToolTip();
/* 142 */     Color textAreaBG = this.textArea.getBackground();
/* 143 */     if (textAreaBG != null && !Color.white.equals(textAreaBG)) {
/* 144 */       Color bg = TipUtil.getToolTipBackground();
/*     */ 
/*     */ 
/*     */       
/* 148 */       if (bg.getRed() >= 240 && bg.getGreen() >= 240 && bg.getBlue() >= 200) {
/* 149 */         tip.setBackground(textAreaBG);
/*     */       }
/*     */     } 
/* 152 */     return tip;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Fold findOpenFoldClosestTo(Point p) {
/* 158 */     Fold fold = null;
/* 159 */     this.mouseOverFoldIcon = false;
/*     */     
/* 161 */     RSyntaxTextArea rsta = (RSyntaxTextArea)this.textArea;
/* 162 */     if (rsta.isCodeFoldingEnabled()) {
/* 163 */       int offs = rsta.viewToModel(p);
/* 164 */       if (offs > -1) {
/*     */         try {
/* 166 */           int line = rsta.getLineOfOffset(offs);
/* 167 */           FoldManager fm = rsta.getFoldManager();
/* 168 */           fold = fm.getFoldForLine(line);
/* 169 */           if (fold != null) {
/*     */             
/* 171 */             this.mouseOverFoldIcon = true;
/*     */           } else {
/*     */             
/* 174 */             fold = fm.getDeepestOpenFoldContaining(offs);
/*     */           } 
/* 176 */         } catch (BadLocationException ble) {
/* 177 */           ble.printStackTrace();
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 182 */     return fold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getFoldIconArmedBackground() {
/* 197 */     return this.foldIconArmedBackground;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getFoldIconBackground() {
/* 210 */     return this.foldIconBackground;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 216 */     int h = (this.textArea != null) ? this.textArea.getHeight() : 100;
/* 217 */     return new Dimension(12, h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getShowCollapsedRegionToolTips() {
/* 229 */     return this.showFoldRegionTips;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getToolTipLocation(MouseEvent e) {
/* 247 */     String text = getToolTipText(e);
/* 248 */     if (text == null) {
/* 249 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 253 */     Point p = e.getPoint();
/* 254 */     p.y = p.y / this.textArea.getLineHeight() * this.textArea.getLineHeight();
/* 255 */     p.x = getWidth() + (this.textArea.getMargin()).left;
/* 256 */     Gutter gutter = getGutter();
/* 257 */     int gutterMargin = (gutter.getInsets()).right;
/* 258 */     p.x += gutterMargin;
/* 259 */     JToolTip tempTip = createToolTip();
/* 260 */     p.x -= (tempTip.getInsets()).left;
/* 261 */     p.y += 16;
/* 262 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToolTipText(MouseEvent e) {
/* 274 */     String text = null;
/*     */     
/* 276 */     RSyntaxTextArea rsta = (RSyntaxTextArea)this.textArea;
/* 277 */     if (rsta.isCodeFoldingEnabled()) {
/* 278 */       FoldManager fm = rsta.getFoldManager();
/* 279 */       int pos = rsta.viewToModel(new Point(0, e.getY()));
/* 280 */       if (pos >= 0) {
/* 281 */         int line = 0;
/*     */         try {
/* 283 */           line = rsta.getLineOfOffset(pos);
/* 284 */         } catch (BadLocationException ble) {
/* 285 */           ble.printStackTrace();
/* 286 */           return null;
/*     */         } 
/* 288 */         Fold fold = fm.getFoldForLine(line);
/* 289 */         if (fold != null && fold.isCollapsed()) {
/*     */           
/* 291 */           int endLine = fold.getEndLine();
/* 292 */           if (fold.getLineCount() > 25) {
/* 293 */             endLine = fold.getStartLine() + 25;
/*     */           }
/*     */           
/* 296 */           StringBuilder sb = new StringBuilder("<html><nobr>");
/* 297 */           while (line <= endLine && line < rsta.getLineCount()) {
/* 298 */             Token t = rsta.getTokenListForLine(line);
/* 299 */             while (t != null && t.isPaintable()) {
/* 300 */               t.appendHTMLRepresentation(sb, rsta, true, true);
/* 301 */               t = t.getNextToken();
/*     */             } 
/* 303 */             sb.append("<br>");
/* 304 */             line++;
/*     */           } 
/*     */           
/* 307 */           text = sb.toString();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 313 */     return text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void handleDocumentEvent(DocumentEvent e) {
/* 320 */     int newLineCount = this.textArea.getLineCount();
/* 321 */     if (newLineCount != this.currentLineCount) {
/* 322 */       this.currentLineCount = newLineCount;
/* 323 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init() {
/* 330 */     super.init();
/* 331 */     setForeground(DEFAULT_FOREGROUND);
/* 332 */     setFoldIconBackground(DEFAULT_FOLD_BACKGROUND);
/* 333 */     this.collapsedFoldIcon = new FoldIcon(true);
/* 334 */     this.expandedFoldIcon = new FoldIcon(false);
/* 335 */     this.listener = new Listener(this);
/* 336 */     this.visibleRect = new Rectangle();
/* 337 */     setShowCollapsedRegionToolTips(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void lineHeightsChanged() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintComponent(Graphics g) {
/* 350 */     if (this.textArea == null) {
/*     */       return;
/*     */     }
/*     */     
/* 354 */     this.visibleRect = g.getClipBounds(this.visibleRect);
/* 355 */     if (this.visibleRect == null) {
/* 356 */       this.visibleRect = getVisibleRect();
/*     */     }
/*     */     
/* 359 */     if (this.visibleRect == null) {
/*     */       return;
/*     */     }
/*     */     
/* 363 */     Color bg = getBackground();
/* 364 */     if (getGutter() != null) {
/* 365 */       bg = getGutter().getBackground();
/*     */     }
/* 367 */     g.setColor(bg);
/* 368 */     g.fillRect(0, this.visibleRect.y, getWidth(), this.visibleRect.height);
/*     */     
/* 370 */     RSyntaxTextArea rsta = (RSyntaxTextArea)this.textArea;
/* 371 */     if (!rsta.isCodeFoldingEnabled()) {
/*     */       return;
/*     */     }
/*     */     
/* 375 */     if (this.textArea.getLineWrap()) {
/* 376 */       paintComponentWrapped(g);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 383 */     this.textAreaInsets = this.textArea.getInsets(this.textAreaInsets);
/* 384 */     if (this.visibleRect.y < this.textAreaInsets.top) {
/* 385 */       this.visibleRect.height -= this.textAreaInsets.top - this.visibleRect.y;
/* 386 */       this.visibleRect.y = this.textAreaInsets.top;
/*     */     } 
/* 388 */     int cellHeight = this.textArea.getLineHeight();
/* 389 */     int topLine = (this.visibleRect.y - this.textAreaInsets.top) / cellHeight;
/*     */     
/* 391 */     int y = topLine * cellHeight + (cellHeight - this.collapsedFoldIcon.getIconHeight()) / 2;
/* 392 */     y += this.textAreaInsets.top;
/*     */ 
/*     */     
/* 395 */     FoldManager fm = rsta.getFoldManager();
/* 396 */     topLine += fm.getHiddenLineCountAbove(topLine, true);
/*     */     
/* 398 */     int width = getWidth();
/* 399 */     int x = width - 10;
/* 400 */     int line = topLine;
/*     */     
/* 402 */     boolean paintingOutlineLine = (this.foldWithOutlineShowing != null && this.foldWithOutlineShowing.containsLine(line));
/*     */     
/* 404 */     while (y < this.visibleRect.y + this.visibleRect.height) {
/* 405 */       if (paintingOutlineLine) {
/* 406 */         g.setColor(getForeground());
/* 407 */         int w2 = width / 2;
/* 408 */         if (line == this.foldWithOutlineShowing.getEndLine()) {
/* 409 */           int y2 = y + cellHeight / 2;
/* 410 */           g.drawLine(w2, y, w2, y2);
/* 411 */           g.drawLine(w2, y2, width - 2, y2);
/* 412 */           paintingOutlineLine = false;
/*     */         } else {
/*     */           
/* 415 */           g.drawLine(w2, y, w2, y + cellHeight);
/*     */         } 
/*     */       } 
/* 418 */       Fold fold = fm.getFoldForLine(line);
/* 419 */       if (fold != null) {
/* 420 */         if (fold == this.foldWithOutlineShowing) {
/* 421 */           if (!fold.isCollapsed()) {
/* 422 */             g.setColor(getForeground());
/* 423 */             int w2 = width / 2;
/* 424 */             g.drawLine(w2, y + cellHeight / 2, w2, y + cellHeight);
/* 425 */             paintingOutlineLine = true;
/*     */           } 
/* 427 */           if (this.mouseOverFoldIcon) {
/* 428 */             this.paintFoldArmed = true;
/*     */           }
/*     */         } 
/* 431 */         if (fold.isCollapsed()) {
/* 432 */           this.collapsedFoldIcon.paintIcon(this, g, x, y);
/*     */ 
/*     */           
/*     */           do {
/* 436 */             int hiddenLineCount = fold.getLineCount();
/* 437 */             if (hiddenLineCount == 0) {
/*     */               break;
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 443 */             line += hiddenLineCount;
/* 444 */             fold = fm.getFoldForLine(line);
/* 445 */           } while (fold != null && fold.isCollapsed());
/*     */         } else {
/*     */           
/* 448 */           this.expandedFoldIcon.paintIcon(this, g, x, y);
/*     */         } 
/* 450 */         this.paintFoldArmed = false;
/*     */       } 
/* 452 */       line++;
/* 453 */       y += cellHeight;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintComponentWrapped(Graphics g) {
/* 496 */     int width = getWidth();
/*     */     
/* 498 */     RTextAreaUI ui = (RTextAreaUI)this.textArea.getUI();
/* 499 */     View v = ui.getRootView(this.textArea).getView(0);
/* 500 */     Document doc = this.textArea.getDocument();
/* 501 */     Element root = doc.getDefaultRootElement();
/* 502 */     int topPosition = this.textArea.viewToModel(new Point(this.visibleRect.x, this.visibleRect.y));
/*     */     
/* 504 */     int topLine = root.getElementIndex(topPosition);
/* 505 */     int cellHeight = this.textArea.getLineHeight();
/* 506 */     FoldManager fm = ((RSyntaxTextArea)this.textArea).getFoldManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 512 */     Rectangle visibleEditorRect = ui.getVisibleEditorRect();
/* 513 */     Rectangle r = LineNumberList.getChildViewBounds(v, topLine, visibleEditorRect);
/*     */     
/* 515 */     int y = r.y;
/* 516 */     y += (cellHeight - this.collapsedFoldIcon.getIconHeight()) / 2;
/*     */     
/* 518 */     int visibleBottom = this.visibleRect.y + this.visibleRect.height;
/* 519 */     int x = width - 10;
/* 520 */     int line = topLine;
/*     */     
/* 522 */     boolean paintingOutlineLine = (this.foldWithOutlineShowing != null && this.foldWithOutlineShowing.containsLine(line));
/* 523 */     int lineCount = root.getElementCount();
/*     */     
/* 525 */     while (y < visibleBottom && line < lineCount) {
/*     */       
/* 527 */       int curLineH = (LineNumberList.getChildViewBounds(v, line, visibleEditorRect)).height;
/*     */ 
/*     */       
/* 530 */       if (paintingOutlineLine) {
/* 531 */         g.setColor(getForeground());
/* 532 */         int w2 = width / 2;
/* 533 */         if (line == this.foldWithOutlineShowing.getEndLine()) {
/* 534 */           int y2 = y + curLineH - cellHeight / 2;
/* 535 */           g.drawLine(w2, y, w2, y2);
/* 536 */           g.drawLine(w2, y2, width - 2, y2);
/* 537 */           paintingOutlineLine = false;
/*     */         } else {
/*     */           
/* 540 */           g.drawLine(w2, y, w2, y + curLineH);
/*     */         } 
/*     */       } 
/* 543 */       Fold fold = fm.getFoldForLine(line);
/* 544 */       if (fold != null) {
/* 545 */         if (fold == this.foldWithOutlineShowing) {
/* 546 */           if (!fold.isCollapsed()) {
/* 547 */             g.setColor(getForeground());
/* 548 */             int w2 = width / 2;
/* 549 */             g.drawLine(w2, y + cellHeight / 2, w2, y + curLineH);
/* 550 */             paintingOutlineLine = true;
/*     */           } 
/* 552 */           if (this.mouseOverFoldIcon) {
/* 553 */             this.paintFoldArmed = true;
/*     */           }
/*     */         } 
/* 556 */         if (fold.isCollapsed()) {
/* 557 */           this.collapsedFoldIcon.paintIcon(this, g, x, y);
/* 558 */           y += (LineNumberList.getChildViewBounds(v, line, visibleEditorRect)).height;
/*     */           
/* 560 */           line += fold.getLineCount() + 1;
/*     */         } else {
/*     */           
/* 563 */           this.expandedFoldIcon.paintIcon(this, g, x, y);
/* 564 */           y += curLineH;
/* 565 */           line++;
/*     */         } 
/* 567 */         this.paintFoldArmed = false;
/*     */         continue;
/*     */       } 
/* 570 */       y += curLineH;
/* 571 */       line++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int rowAtPoint(Point p) {
/* 580 */     int line = 0;
/*     */     
/*     */     try {
/* 583 */       int offs = this.textArea.viewToModel(p);
/* 584 */       if (offs > -1) {
/* 585 */         line = this.textArea.getLineOfOffset(offs);
/*     */       }
/* 587 */     } catch (BadLocationException ble) {
/* 588 */       ble.printStackTrace();
/*     */     } 
/*     */     
/* 591 */     return line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFoldIconArmedBackground(Color bg) {
/* 606 */     this.foldIconArmedBackground = bg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFoldIconBackground(Color bg) {
/* 619 */     this.foldIconBackground = bg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFoldIcons(Icon collapsedIcon, Icon expandedIcon) {
/* 632 */     this.collapsedFoldIcon = collapsedIcon;
/* 633 */     this.expandedFoldIcon = expandedIcon;
/* 634 */     revalidate();
/* 635 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShowCollapsedRegionToolTips(boolean show) {
/* 647 */     if (show != this.showFoldRegionTips) {
/* 648 */       if (show) {
/* 649 */         ToolTipManager.sharedInstance().registerComponent(this);
/*     */       } else {
/*     */         
/* 652 */         ToolTipManager.sharedInstance().unregisterComponent(this);
/*     */       } 
/* 654 */       this.showFoldRegionTips = show;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTextArea(RTextArea textArea) {
/* 664 */     if (this.textArea != null) {
/* 665 */       this.textArea.removePropertyChangeListener("RSTA.codeFolding", this.listener);
/*     */     }
/*     */     
/* 668 */     super.setTextArea(textArea);
/* 669 */     if (this.textArea != null) {
/* 670 */       this.textArea.addPropertyChangeListener("RSTA.codeFolding", this.listener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class FoldIcon
/*     */     implements Icon
/*     */   {
/*     */     private boolean collapsed;
/*     */ 
/*     */ 
/*     */     
/*     */     FoldIcon(boolean collapsed) {
/* 684 */       this.collapsed = collapsed;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getIconHeight() {
/* 689 */       return 8;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getIconWidth() {
/* 694 */       return 8;
/*     */     }
/*     */ 
/*     */     
/*     */     public void paintIcon(Component c, Graphics g, int x, int y) {
/* 699 */       Color bg = FoldIndicator.this.foldIconBackground;
/* 700 */       if (FoldIndicator.this.paintFoldArmed && FoldIndicator.this.foldIconArmedBackground != null) {
/* 701 */         bg = FoldIndicator.this.foldIconArmedBackground;
/*     */       }
/* 703 */       g.setColor(bg);
/* 704 */       g.fillRect(x, y, 8, 8);
/* 705 */       g.setColor(FoldIndicator.this.getForeground());
/* 706 */       g.drawRect(x, y, 8, 8);
/* 707 */       g.drawLine(x + 2, y + 4, x + 2 + 4, y + 4);
/* 708 */       if (this.collapsed) {
/* 709 */         g.drawLine(x + 4, y + 2, x + 4, y + 6);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class Listener
/*     */     extends MouseInputAdapter
/*     */     implements PropertyChangeListener
/*     */   {
/*     */     Listener(FoldIndicator fgc) {
/* 723 */       fgc.addMouseListener(this);
/* 724 */       fgc.addMouseMotionListener(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseClicked(MouseEvent e) {
/* 730 */       Point p = e.getPoint();
/* 731 */       int line = FoldIndicator.this.rowAtPoint(p);
/*     */       
/* 733 */       RSyntaxTextArea rsta = (RSyntaxTextArea)FoldIndicator.this.textArea;
/* 734 */       FoldManager fm = rsta.getFoldManager();
/*     */       
/* 736 */       Fold fold = fm.getFoldForLine(line);
/* 737 */       if (fold != null) {
/* 738 */         fold.toggleCollapsedState();
/* 739 */         FoldIndicator.this.getGutter().repaint();
/* 740 */         FoldIndicator.this.textArea.repaint();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseExited(MouseEvent e) {
/* 747 */       if (FoldIndicator.this.foldWithOutlineShowing != null) {
/* 748 */         FoldIndicator.this.foldWithOutlineShowing = null;
/* 749 */         FoldIndicator.this.mouseOverFoldIcon = false;
/* 750 */         FoldIndicator.this.repaint();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void mouseMoved(MouseEvent e) {
/* 756 */       boolean oldMouseOverFoldIcon = FoldIndicator.this.mouseOverFoldIcon;
/* 757 */       Fold newSelectedFold = FoldIndicator.this.findOpenFoldClosestTo(e.getPoint());
/* 758 */       if (newSelectedFold != FoldIndicator.this.foldWithOutlineShowing && newSelectedFold != null && 
/* 759 */         !newSelectedFold.isOnSingleLine()) {
/* 760 */         FoldIndicator.this.foldWithOutlineShowing = newSelectedFold;
/* 761 */         FoldIndicator.this.repaint();
/*     */       }
/* 763 */       else if (FoldIndicator.this.mouseOverFoldIcon != oldMouseOverFoldIcon) {
/* 764 */         FoldIndicator.this.repaint();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void propertyChange(PropertyChangeEvent e) {
/* 771 */       FoldIndicator.this.repaint();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/FoldIndicator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */