/*     */ package org.fife.ui.rtextarea;
/*     */ 
/*     */ import org.fife.ui.rsyntaxtextarea.DocumentRange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SearchResult
/*     */   implements Comparable<SearchResult>
/*     */ {
/*     */   private DocumentRange matchRange;
/*     */   private int count;
/*     */   private int markedCount;
/*     */   
/*     */   public SearchResult() {
/*  51 */     this(null, 0, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SearchResult(DocumentRange range, int count, int markedCount) {
/*  69 */     this.matchRange = range;
/*  70 */     this.count = count;
/*  71 */     this.markedCount = markedCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(SearchResult other) {
/*  84 */     if (other == null) {
/*  85 */       return 1;
/*     */     }
/*  87 */     if (other == this) {
/*  88 */       return 0;
/*     */     }
/*  90 */     int diff = this.count - other.count;
/*  91 */     if (diff != 0) {
/*  92 */       return diff;
/*     */     }
/*  94 */     diff = this.markedCount - other.markedCount;
/*  95 */     if (diff != 0) {
/*  96 */       return diff;
/*     */     }
/*  98 */     if (this.matchRange == null) {
/*  99 */       return (other.matchRange == null) ? 0 : -1;
/*     */     }
/* 101 */     return this.matchRange.compareTo(other.matchRange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 114 */     if (other == this) {
/* 115 */       return true;
/*     */     }
/* 117 */     if (other instanceof SearchResult) {
/* 118 */       return (compareTo((SearchResult)other) == 0);
/*     */     }
/* 120 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCount() {
/* 134 */     return this.count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMarkedCount() {
/* 146 */     return this.markedCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentRange getMatchRange() {
/* 162 */     return this.matchRange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 174 */     int hash = this.count + this.markedCount;
/* 175 */     if (this.matchRange != null) {
/* 176 */       hash += this.matchRange.hashCode();
/*     */     }
/* 178 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCount(int count) {
/* 192 */     this.count = count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarkedCount(int markedCount) {
/* 203 */     this.markedCount = markedCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMatchRange(DocumentRange range) {
/* 214 */     this.matchRange = range;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 225 */     return "[SearchResult: count=" + 
/* 226 */       getCount() + ", markedCount=" + 
/* 227 */       getMarkedCount() + ", matchRange=" + 
/* 228 */       getMatchRange() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean wasFound() {
/* 241 */     return (getCount() > 0);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/SearchResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */