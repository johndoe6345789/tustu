/*      */ package org.fife.ui.rtextarea;
/*      */ 
/*      */ import java.awt.Point;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.regex.PatternSyntaxException;
/*      */ import javax.swing.JTextArea;
/*      */ import javax.swing.text.BadLocationException;
/*      */ import javax.swing.text.Caret;
/*      */ import org.fife.ui.rsyntaxtextarea.DocumentRange;
/*      */ import org.fife.ui.rsyntaxtextarea.RSyntaxUtilities;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class SearchEngine
/*      */ {
/*      */   public static SearchResult find(JTextArea textArea, SearchContext context) {
/*   69 */     if (textArea instanceof RTextArea || context.getMarkAll()) {
/*   70 */       ((RTextArea)textArea).clearMarkAllHighlights();
/*      */     }
/*   72 */     boolean doMarkAll = (textArea instanceof RTextArea && context.getMarkAll());
/*      */     
/*   74 */     String text = context.getSearchFor();
/*   75 */     if (text == null || text.length() == 0) {
/*   76 */       if (doMarkAll) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*   81 */         List<DocumentRange> emptyRangeList = Collections.emptyList();
/*   82 */         ((RTextArea)textArea).markAll(emptyRangeList);
/*      */       } 
/*   84 */       return new SearchResult();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   91 */     Caret c = textArea.getCaret();
/*   92 */     boolean forward = context.getSearchForward();
/*      */     
/*   94 */     int start = forward ? Math.max(c.getDot(), c.getMark()) : Math.min(c.getDot(), c.getMark());
/*      */     
/*   96 */     String findIn = getFindInText(textArea, start, forward);
/*   97 */     if (findIn == null || findIn.length() == 0) {
/*   98 */       return new SearchResult();
/*      */     }
/*      */     
/*  101 */     int markAllCount = 0;
/*  102 */     if (doMarkAll)
/*      */     {
/*  104 */       markAllCount = markAllImpl((RTextArea)textArea, context).getMarkedCount();
/*      */     }
/*      */     
/*  107 */     SearchResult result = findImpl(findIn, context);
/*  108 */     if (result.wasFound() && !result.getMatchRange().isZeroLength()) {
/*      */ 
/*      */       
/*  111 */       textArea.getCaret().setSelectionVisible(true);
/*  112 */       if (forward && start > -1) {
/*  113 */         result.getMatchRange().translate(start);
/*      */       }
/*  115 */       RSyntaxUtilities.selectAndPossiblyCenter(textArea, result
/*  116 */           .getMatchRange(), true);
/*      */     } 
/*      */     
/*  119 */     result.setMarkedCount(markAllCount);
/*  120 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static SearchResult findImpl(String findIn, SearchContext context) {
/*  139 */     String text = context.getSearchFor();
/*  140 */     boolean forward = context.getSearchForward();
/*      */ 
/*      */     
/*  143 */     DocumentRange range = null;
/*  144 */     if (!context.isRegularExpression()) {
/*  145 */       int pos = getNextMatchPos(text, findIn, forward, context
/*  146 */           .getMatchCase(), context.getWholeWord());
/*  147 */       findIn = null;
/*  148 */       if (pos != -1) {
/*  149 */         range = new DocumentRange(pos, pos + text.length());
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  157 */       Point regExPos = null;
/*  158 */       int start = 0;
/*      */       do {
/*  160 */         regExPos = getNextMatchPosRegEx(text, findIn.substring(start), forward, context
/*  161 */             .getMatchCase(), context.getWholeWord());
/*  162 */         if (regExPos == null)
/*  163 */           continue;  if (regExPos.x != regExPos.y) {
/*  164 */           regExPos.translate(start, start);
/*  165 */           range = new DocumentRange(regExPos.x, regExPos.y);
/*      */         } else {
/*      */           
/*  168 */           start += regExPos.x + 1;
/*      */         }
/*      */       
/*  171 */       } while (start < findIn.length() && regExPos != null && range == null);
/*      */     } 
/*      */     
/*  174 */     if (range != null) {
/*  175 */       return new SearchResult(range, 1, 0);
/*      */     }
/*  177 */     return new SearchResult();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static CharSequence getFindInCharSequence(RTextArea textArea, int start, boolean forward) {
/*  196 */     RDocument doc = (RDocument)textArea.getDocument();
/*  197 */     int csStart = 0;
/*  198 */     int csEnd = 0;
/*  199 */     if (forward) {
/*  200 */       csStart = start;
/*  201 */       csEnd = doc.getLength();
/*      */     } else {
/*      */       
/*  204 */       csStart = 0;
/*  205 */       csEnd = start;
/*      */     } 
/*  207 */     return new RDocumentCharSequence(doc, csStart, csEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getFindInText(JTextArea textArea, int start, boolean forward) {
/*  221 */     String findIn = null;
/*      */     try {
/*  223 */       if (forward) {
/*  224 */         findIn = textArea.getText(start, textArea
/*  225 */             .getDocument().getLength() - start);
/*      */       } else {
/*      */         
/*  228 */         findIn = textArea.getText(0, start);
/*      */       } 
/*  230 */     } catch (BadLocationException ble) {
/*      */       
/*  232 */       ble.printStackTrace();
/*      */     } 
/*      */     
/*  235 */     return findIn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static List getMatches(Matcher m, String replaceStr) {
/*  270 */     ArrayList<Point> matches = new ArrayList();
/*  271 */     while (m.find()) {
/*  272 */       Point loc = new Point(m.start(), m.end());
/*  273 */       if (replaceStr == null) {
/*  274 */         matches.add(loc);
/*      */         continue;
/*      */       } 
/*  277 */       matches.add(new RegExReplaceInfo(m.group(0), loc.x, loc.y, 
/*  278 */             getReplacementText(m, replaceStr)));
/*      */     } 
/*      */     
/*  281 */     return matches;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getNextMatchPos(String searchFor, String searchIn, boolean forward, boolean matchCase, boolean wholeWord) {
/*  309 */     if (!matchCase) {
/*  310 */       return getNextMatchPosImpl(searchFor.toLowerCase(), searchIn
/*  311 */           .toLowerCase(), forward, matchCase, wholeWord);
/*      */     }
/*      */ 
/*      */     
/*  315 */     return getNextMatchPosImpl(searchFor, searchIn, forward, matchCase, wholeWord);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getNextMatchPosImpl(String searchFor, String searchIn, boolean goForward, boolean matchCase, boolean wholeWord) {
/*  342 */     if (wholeWord) {
/*  343 */       int len = searchFor.length();
/*  344 */       int temp = goForward ? 0 : searchIn.length();
/*  345 */       int tempChange = goForward ? 1 : -1;
/*      */       while (true) {
/*  347 */         if (goForward) {
/*  348 */           temp = searchIn.indexOf(searchFor, temp);
/*      */         } else {
/*      */           
/*  351 */           temp = searchIn.lastIndexOf(searchFor, temp);
/*      */         } 
/*  353 */         if (temp != -1) {
/*  354 */           if (isWholeWord(searchIn, temp, len)) {
/*  355 */             return temp;
/*      */           }
/*      */           
/*  358 */           temp += tempChange; continue;
/*      */         } 
/*      */         break;
/*      */       } 
/*  362 */       return temp;
/*      */     } 
/*      */ 
/*      */     
/*  366 */     return goForward ? searchIn.indexOf(searchFor) : searchIn
/*  367 */       .lastIndexOf(searchFor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Point getNextMatchPosRegEx(String regEx, CharSequence searchIn, boolean goForward, boolean matchCase, boolean wholeWord) {
/*  396 */     return (Point)getNextMatchPosRegExImpl(regEx, searchIn, goForward, matchCase, wholeWord, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object getNextMatchPosRegExImpl(String regEx, CharSequence searchIn, boolean goForward, boolean matchCase, boolean wholeWord, String replaceStr) {
/*  436 */     if (wholeWord) {
/*  437 */       regEx = "\\b" + regEx + "\\b";
/*      */     }
/*      */ 
/*      */     
/*  441 */     int flags = 8;
/*  442 */     flags = RSyntaxUtilities.getPatternFlags(matchCase, flags);
/*  443 */     Pattern pattern = null;
/*      */     try {
/*  445 */       pattern = Pattern.compile(regEx, flags);
/*  446 */     } catch (PatternSyntaxException pse) {
/*  447 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  451 */     Matcher m = pattern.matcher(searchIn);
/*      */ 
/*      */     
/*  454 */     if (goForward) {
/*  455 */       if (m.find()) {
/*  456 */         if (replaceStr == null) {
/*  457 */           return new Point(m.start(), m.end());
/*      */         }
/*      */         
/*  460 */         return new RegExReplaceInfo(m.group(0), m
/*  461 */             .start(), m.end(), 
/*  462 */             getReplacementText(m, replaceStr));
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  468 */       List<?> matches = getMatches(m, replaceStr);
/*  469 */       if (!matches.isEmpty()) {
/*  470 */         return matches.get(matches.size() - 1);
/*      */       }
/*      */     } 
/*      */     
/*  474 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static RegExReplaceInfo getRegExReplaceInfo(CharSequence searchIn, SearchContext context) {
/*  499 */     String replacement = context.getReplaceWith();
/*  500 */     if (replacement == null) {
/*  501 */       replacement = "";
/*      */     }
/*  503 */     String regex = context.getSearchFor();
/*  504 */     boolean goForward = context.getSearchForward();
/*  505 */     boolean matchCase = context.getMatchCase();
/*  506 */     boolean wholeWord = context.getWholeWord();
/*  507 */     return (RegExReplaceInfo)getNextMatchPosRegExImpl(regex, searchIn, goForward, matchCase, wholeWord, replacement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getReplacementText(Matcher m, CharSequence template) {
/*  542 */     int cursor = 0;
/*  543 */     StringBuilder result = new StringBuilder();
/*      */     
/*  545 */     while (cursor < template.length()) {
/*      */       
/*  547 */       char nextChar = template.charAt(cursor);
/*      */       
/*  549 */       if (nextChar == '\\') {
/*  550 */         nextChar = template.charAt(++cursor);
/*  551 */         switch (nextChar) {
/*      */           case 'n':
/*  553 */             nextChar = '\n';
/*      */             break;
/*      */           case 't':
/*  556 */             nextChar = '\t';
/*      */             break;
/*      */         } 
/*  559 */         result.append(nextChar);
/*  560 */         cursor++; continue;
/*      */       } 
/*  562 */       if (nextChar == '$') {
/*      */         
/*  564 */         cursor++;
/*      */ 
/*      */         
/*  567 */         int refNum = template.charAt(cursor) - 48;
/*  568 */         if (refNum < 0 || refNum > 9)
/*      */         {
/*      */ 
/*      */           
/*  572 */           throw new IndexOutOfBoundsException("No group " + template
/*  573 */               .charAt(cursor));
/*      */         }
/*  575 */         cursor++;
/*      */ 
/*      */         
/*  578 */         boolean done = false;
/*  579 */         while (!done && 
/*  580 */           cursor < template.length()) {
/*      */ 
/*      */           
/*  583 */           int nextDigit = template.charAt(cursor) - 48;
/*  584 */           if (nextDigit < 0 || nextDigit > 9) {
/*      */             break;
/*      */           }
/*  587 */           int newRefNum = refNum * 10 + nextDigit;
/*  588 */           if (m.groupCount() < newRefNum) {
/*  589 */             done = true;
/*      */             continue;
/*      */           } 
/*  592 */           refNum = newRefNum;
/*  593 */           cursor++;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  598 */         if (m.group(refNum) != null) {
/*  599 */           result.append(m.group(refNum));
/*      */         }
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  605 */       result.append(nextChar);
/*  606 */       cursor++;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  611 */     return result.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isWholeWord(CharSequence searchIn, int offset, int len) {
/*      */     boolean wsBefore;
/*      */     boolean wsAfter;
/*      */     try {
/*  627 */       wsBefore = !Character.isLetterOrDigit(searchIn.charAt(offset - 1));
/*  628 */     } catch (IndexOutOfBoundsException e) {
/*  629 */       wsBefore = true;
/*      */     } 
/*      */     
/*      */     try {
/*  633 */       wsAfter = !Character.isLetterOrDigit(searchIn.charAt(offset + len));
/*  634 */     } catch (IndexOutOfBoundsException e) {
/*  635 */       wsAfter = true;
/*      */     } 
/*      */     
/*  638 */     return (wsBefore && wsAfter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int makeMarkAndDotEqual(JTextArea textArea, boolean forward) {
/*  655 */     Caret c = textArea.getCaret();
/*      */     
/*  657 */     int val = forward ? Math.min(c.getDot(), c.getMark()) : Math.max(c.getDot(), c.getMark());
/*  658 */     c.setDot(val);
/*  659 */     return val;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SearchResult markAll(RTextArea textArea, SearchContext context) {
/*  678 */     textArea.clearMarkAllHighlights();
/*      */     
/*  680 */     return markAllImpl(textArea, context);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static SearchResult markAllImpl(RTextArea textArea, SearchContext context) {
/*  702 */     String toMark = context.getSearchFor();
/*  703 */     int markAllCount = 0;
/*      */ 
/*      */     
/*  706 */     if (context.getMarkAll() && toMark != null && toMark.length() > 0) {
/*      */ 
/*      */       
/*  709 */       List<DocumentRange> highlights = new ArrayList<>();
/*  710 */       context = context.clone();
/*  711 */       context.setSearchForward(true);
/*  712 */       context.setMarkAll(false);
/*      */       
/*  714 */       String findIn = textArea.getText();
/*  715 */       int start = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  721 */       if (!context.getMatchCase()) {
/*  722 */         context.setMatchCase(true);
/*  723 */         context.setSearchFor(toMark.toLowerCase());
/*  724 */         findIn = findIn.toLowerCase();
/*      */       } 
/*      */       
/*  727 */       SearchResult res = findImpl(findIn, context);
/*  728 */       while (res.wasFound()) {
/*  729 */         DocumentRange match = res.getMatchRange().translate(start);
/*  730 */         if (match.isZeroLength()) {
/*      */ 
/*      */ 
/*      */           
/*  734 */           start = match.getEndOffset() + 1;
/*  735 */           if (start > findIn.length()) {
/*      */             break;
/*      */           }
/*      */         } else {
/*      */           
/*  740 */           highlights.add(match);
/*  741 */           start = match.getEndOffset();
/*      */         } 
/*  743 */         res = findImpl(findIn.substring(start), context);
/*      */       } 
/*  745 */       textArea.markAll(highlights);
/*  746 */       markAllCount = highlights.size();
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  752 */       List<DocumentRange> empty = Collections.emptyList();
/*  753 */       textArea.markAll(empty);
/*      */     } 
/*      */     
/*  756 */     return new SearchResult(null, 0, markAllCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static SearchResult regexReplace(RTextArea textArea, SearchContext context) {
/*  786 */     Caret c = textArea.getCaret();
/*  787 */     boolean forward = context.getSearchForward();
/*  788 */     int start = makeMarkAndDotEqual(textArea, forward);
/*      */     
/*  790 */     CharSequence findIn = getFindInCharSequence(textArea, start, forward);
/*  791 */     if (findIn == null) {
/*  792 */       return new SearchResult();
/*      */     }
/*      */     
/*  795 */     int markAllCount = 0;
/*  796 */     if (context.getMarkAll()) {
/*  797 */       markAllCount = markAllImpl(textArea, context).getMarkedCount();
/*      */     }
/*      */ 
/*      */     
/*  801 */     RegExReplaceInfo info = getRegExReplaceInfo(findIn, context);
/*      */ 
/*      */     
/*  804 */     DocumentRange range = null;
/*  805 */     if (info != null) {
/*      */ 
/*      */ 
/*      */       
/*  809 */       c.setSelectionVisible(true);
/*      */       
/*  811 */       int matchStart = info.getStartIndex();
/*  812 */       int matchEnd = info.getEndIndex();
/*  813 */       if (forward) {
/*  814 */         matchStart += start;
/*  815 */         matchEnd += start;
/*      */       } 
/*  817 */       textArea.setSelectionStart(matchStart);
/*  818 */       textArea.setSelectionEnd(matchEnd);
/*  819 */       String replacement = info.getReplacement();
/*  820 */       textArea.replaceSelection(replacement);
/*      */ 
/*      */       
/*  823 */       int dot = matchStart + replacement.length();
/*  824 */       findIn = getFindInCharSequence(textArea, dot, forward);
/*  825 */       info = getRegExReplaceInfo(findIn, context);
/*  826 */       if (info != null) {
/*  827 */         matchStart = info.getStartIndex();
/*  828 */         matchEnd = info.getEndIndex();
/*  829 */         if (forward) {
/*  830 */           matchStart += dot;
/*  831 */           matchEnd += dot;
/*      */         } 
/*  833 */         range = new DocumentRange(matchStart, matchEnd);
/*      */       } else {
/*      */         
/*  836 */         range = new DocumentRange(dot, dot);
/*      */       } 
/*  838 */       RSyntaxUtilities.selectAndPossiblyCenter(textArea, range, true);
/*      */     } 
/*      */ 
/*      */     
/*  842 */     int count = (range != null) ? 1 : 0;
/*  843 */     return new SearchResult(range, count, markAllCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SearchResult replace(RTextArea textArea, SearchContext context) {
/*  868 */     if (context.getMarkAll()) {
/*  869 */       textArea.clearMarkAllHighlights();
/*      */     }
/*      */     
/*  872 */     String toFind = context.getSearchFor();
/*  873 */     if (toFind == null || toFind.length() == 0) {
/*  874 */       return new SearchResult();
/*      */     }
/*      */     
/*  877 */     textArea.beginAtomicEdit();
/*      */ 
/*      */     
/*      */     try {
/*  881 */       if (context.isRegularExpression()) {
/*  882 */         return regexReplace(textArea, context);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  891 */       makeMarkAndDotEqual(textArea, context.getSearchForward());
/*  892 */       SearchResult res = find(textArea, context);
/*      */       
/*  894 */       if (res.wasFound() && !res.getMatchRange().isZeroLength()) {
/*      */         DocumentRange range;
/*      */         
/*  897 */         String replacement = context.getReplaceWith();
/*  898 */         textArea.replaceSelection(replacement);
/*      */ 
/*      */         
/*  901 */         int dot = res.getMatchRange().getStartOffset();
/*  902 */         if (context.getSearchForward()) {
/*  903 */           int length = (replacement == null) ? 0 : replacement.length();
/*  904 */           dot += length;
/*      */         } 
/*  906 */         textArea.setCaretPosition(dot);
/*      */         
/*  908 */         SearchResult next = find(textArea, context);
/*      */         
/*  910 */         if (next.wasFound()) {
/*  911 */           range = next.getMatchRange();
/*      */         } else {
/*      */           
/*  914 */           range = new DocumentRange(dot, dot);
/*      */         } 
/*  916 */         res.setMatchRange(range);
/*  917 */         RSyntaxUtilities.selectAndPossiblyCenter(textArea, range, true);
/*      */       } 
/*      */ 
/*      */       
/*  921 */       return res;
/*      */     } finally {
/*      */       
/*  924 */       textArea.endAtomicEdit();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SearchResult replaceAll(RTextArea textArea, SearchContext context) {
/*  949 */     if (context.getMarkAll()) {
/*  950 */       textArea.clearMarkAllHighlights();
/*      */     }
/*      */     
/*  953 */     context.setSearchForward(true);
/*  954 */     String toFind = context.getSearchFor();
/*  955 */     if (toFind == null || toFind.length() == 0) {
/*  956 */       return new SearchResult();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  961 */     if (context.getMarkAll()) {
/*  962 */       context = context.clone();
/*  963 */       context.setMarkAll(false);
/*      */     } 
/*      */     
/*  966 */     SearchResult lastFound = null;
/*  967 */     int count = 0;
/*  968 */     textArea.beginAtomicEdit();
/*      */     
/*      */     try {
/*  971 */       int oldOffs = textArea.getCaretPosition();
/*  972 */       textArea.setCaretPosition(0);
/*  973 */       SearchResult res = replace(textArea, context);
/*      */       
/*  975 */       while (res.wasFound()) {
/*      */         
/*  977 */         lastFound = res;
/*  978 */         count++;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  983 */         if (res.getMatchRange().isZeroLength()) {
/*  984 */           if (res.getMatchRange().getStartOffset() == textArea
/*  985 */             .getDocument().getLength()) {
/*      */             break;
/*      */           }
/*      */           
/*  989 */           textArea.setCaretPosition(textArea.getCaretPosition() + 1);
/*      */         } 
/*      */ 
/*      */         
/*  993 */         res = replace(textArea, context);
/*      */       } 
/*      */ 
/*      */       
/*  997 */       if (lastFound == null) {
/*  998 */         textArea.setCaretPosition(oldOffs);
/*  999 */         lastFound = new SearchResult();
/*      */       } 
/*      */     } finally {
/*      */       
/* 1003 */       textArea.endAtomicEdit();
/*      */     } 
/*      */     
/* 1006 */     lastFound.setCount(count);
/* 1007 */     return lastFound;
/*      */   }
/*      */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/SearchEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */