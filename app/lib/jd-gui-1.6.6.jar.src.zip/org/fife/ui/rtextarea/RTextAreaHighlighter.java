/*     */ package org.fife.ui.rtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.plaf.TextUI;
/*     */ import javax.swing.plaf.basic.BasicTextUI;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Highlighter;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import javax.swing.text.LayeredHighlighter;
/*     */ import javax.swing.text.Position;
/*     */ import javax.swing.text.View;
/*     */ import org.fife.ui.rsyntaxtextarea.DocumentRange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTextAreaHighlighter
/*     */   extends BasicTextUI.BasicHighlighter
/*     */ {
/*     */   protected RTextArea textArea;
/*  58 */   private List<HighlightInfo> markAllHighlights = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object addMarkAllHighlight(int start, int end, Highlighter.HighlightPainter p) throws BadLocationException {
/*  74 */     Document doc = this.textArea.getDocument();
/*  75 */     TextUI mapper = this.textArea.getUI();
/*     */     
/*  77 */     HighlightInfoImpl i = new LayeredHighlightInfoImpl();
/*  78 */     i.setPainter(p);
/*  79 */     i.p0 = doc.createPosition(start);
/*     */ 
/*     */ 
/*     */     
/*  83 */     i.p1 = doc.createPosition(end - 1);
/*  84 */     this.markAllHighlights.add(i);
/*  85 */     mapper.damageRange(this.textArea, start, end);
/*  86 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clearMarkAllHighlights() {
/*  98 */     for (HighlightInfo info : this.markAllHighlights) {
/*  99 */       repaintListHighlight(info);
/*     */     }
/* 101 */     this.markAllHighlights.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deinstall(JTextComponent c) {
/* 110 */     this.textArea = null;
/* 111 */     this.markAllHighlights.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMarkAllHighlightCount() {
/* 122 */     return this.markAllHighlights.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DocumentRange> getMarkAllHighlightRanges() {
/* 134 */     List<DocumentRange> list = new ArrayList<>(this.markAllHighlights.size());
/* 135 */     for (HighlightInfo info : this.markAllHighlights) {
/* 136 */       int start = info.getStartOffset();
/* 137 */       int end = info.getEndOffset() + 1;
/* 138 */       DocumentRange range = new DocumentRange(start, end);
/* 139 */       list.add(range);
/*     */     } 
/* 141 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void install(JTextComponent c) {
/* 150 */     super.install(c);
/* 151 */     this.textArea = (RTextArea)c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintLayeredHighlights(Graphics g, int lineStart, int lineEnd, Shape viewBounds, JTextComponent editor, View view) {
/* 170 */     paintListLayered(g, lineStart, lineEnd, viewBounds, editor, view, this.markAllHighlights);
/*     */     
/* 172 */     super.paintLayeredHighlights(g, lineStart, lineEnd, viewBounds, editor, view);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintListLayered(Graphics g, int lineStart, int lineEnd, Shape viewBounds, JTextComponent editor, View view, List<? extends HighlightInfo> highlights) {
/* 180 */     for (int i = highlights.size() - 1; i >= 0; i--) {
/* 181 */       HighlightInfo tag = highlights.get(i);
/* 182 */       if (tag instanceof LayeredHighlightInfo) {
/* 183 */         LayeredHighlightInfo lhi = (LayeredHighlightInfo)tag;
/* 184 */         int highlightStart = lhi.getStartOffset();
/* 185 */         int highlightEnd = lhi.getEndOffset() + 1;
/* 186 */         if ((lineStart < highlightStart && lineEnd > highlightStart) || (lineStart >= highlightStart && lineStart < highlightEnd))
/*     */         {
/* 188 */           lhi.paintLayeredHighlights(g, lineStart, lineEnd, viewBounds, editor, view);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void repaintListHighlight(HighlightInfo info) {
/* 198 */     if (info instanceof LayeredHighlightInfoImpl) {
/* 199 */       LayeredHighlightInfoImpl lhi = (LayeredHighlightInfoImpl)info;
/* 200 */       if (lhi.width > 0 && lhi.height > 0) {
/* 201 */         this.textArea.repaint(lhi.x, lhi.y, lhi.width, lhi.height);
/*     */       }
/*     */     } else {
/*     */       
/* 205 */       TextUI ui = this.textArea.getUI();
/* 206 */       ui.damageRange(this.textArea, info.getStartOffset(), info.getEndOffset());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface HighlightInfo
/*     */     extends Highlighter.Highlight {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface LayeredHighlightInfo
/*     */     extends HighlightInfo
/*     */   {
/*     */     void paintLayeredHighlights(Graphics param1Graphics, int param1Int1, int param1Int2, Shape param1Shape, JTextComponent param1JTextComponent, View param1View);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class HighlightInfoImpl
/*     */     implements HighlightInfo
/*     */   {
/*     */     private Position p0;
/*     */ 
/*     */ 
/*     */     
/*     */     private Position p1;
/*     */ 
/*     */ 
/*     */     
/*     */     private Highlighter.HighlightPainter painter;
/*     */ 
/*     */ 
/*     */     
/*     */     public Color getColor() {
/* 244 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getStartOffset() {
/* 249 */       return this.p0.getOffset();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getEndOffset() {
/* 254 */       return this.p1.getOffset();
/*     */     }
/*     */ 
/*     */     
/*     */     public Highlighter.HighlightPainter getPainter() {
/* 259 */       return this.painter;
/*     */     }
/*     */     
/*     */     public void setStartOffset(Position startOffset) {
/* 263 */       this.p0 = startOffset;
/*     */     }
/*     */     
/*     */     public void setEndOffset(Position endOffset) {
/* 267 */       this.p1 = endOffset;
/*     */     }
/*     */     
/*     */     public void setPainter(Highlighter.HighlightPainter painter) {
/* 271 */       this.painter = painter;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class LayeredHighlightInfoImpl
/*     */     extends HighlightInfoImpl
/*     */     implements LayeredHighlightInfo
/*     */   {
/*     */     public int x;
/*     */ 
/*     */ 
/*     */     
/*     */     public int y;
/*     */ 
/*     */ 
/*     */     
/*     */     public int width;
/*     */ 
/*     */ 
/*     */     
/*     */     public int height;
/*     */ 
/*     */ 
/*     */     
/*     */     void union(Shape bounds) {
/* 299 */       if (bounds == null) {
/*     */         return;
/*     */       }
/*     */       
/* 303 */       Rectangle alloc = (bounds instanceof Rectangle) ? (Rectangle)bounds : bounds.getBounds();
/* 304 */       if (this.width == 0 || this.height == 0) {
/* 305 */         this.x = alloc.x;
/* 306 */         this.y = alloc.y;
/* 307 */         this.width = alloc.width;
/* 308 */         this.height = alloc.height;
/*     */       } else {
/*     */         
/* 311 */         this.width = Math.max(this.x + this.width, alloc.x + alloc.width);
/* 312 */         this.height = Math.max(this.y + this.height, alloc.y + alloc.height);
/* 313 */         this.x = Math.min(this.x, alloc.x);
/* 314 */         this.width -= this.x;
/* 315 */         this.y = Math.min(this.y, alloc.y);
/* 316 */         this.height -= this.y;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void paintLayeredHighlights(Graphics g, int p0, int p1, Shape viewBounds, JTextComponent editor, View view) {
/* 327 */       int start = getStartOffset();
/* 328 */       int end = getEndOffset();
/* 329 */       end++;
/*     */       
/* 331 */       p0 = Math.max(start, p0);
/* 332 */       p1 = Math.min(end, p1);
/* 333 */       if (getColor() != null && 
/* 334 */         getPainter() instanceof ChangeableHighlightPainter) {
/* 335 */         ((ChangeableHighlightPainter)getPainter()).setPaint(getColor());
/*     */       }
/*     */ 
/*     */       
/* 339 */       union(((LayeredHighlighter.LayerPainter)getPainter()).paintLayer(g, p0, p1, viewBounds, editor, view));
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/RTextAreaHighlighter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */