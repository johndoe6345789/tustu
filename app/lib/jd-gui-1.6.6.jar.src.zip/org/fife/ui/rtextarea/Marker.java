/*    */ package org.fife.ui.rtextarea;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.fife.ui.rsyntaxtextarea.DocumentRange;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Marker
/*    */ {
/*    */   public static void markAll(RTextArea textArea, List<DocumentRange> ranges) {
/* 23 */     textArea.markAll(ranges);
/*    */   }
/*    */   
/*    */   public static void clearMarkAllHighlights(RTextArea textArea) {
/* 27 */     textArea.clearMarkAllHighlights();
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/Marker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */