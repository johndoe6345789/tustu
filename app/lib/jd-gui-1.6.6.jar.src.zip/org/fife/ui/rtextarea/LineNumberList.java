/*     */ package org.fife.ui.rtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.util.Map;
/*     */ import javax.swing.event.CaretEvent;
/*     */ import javax.swing.event.CaretListener;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.MouseInputListener;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.text.View;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxUtilities;
/*     */ import org.fife.ui.rsyntaxtextarea.folding.Fold;
/*     */ import org.fife.ui.rsyntaxtextarea.folding.FoldManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineNumberList
/*     */   extends AbstractGutterComponent
/*     */   implements MouseInputListener
/*     */ {
/*     */   private int currentLine;
/*  50 */   private int lastY = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   private int lastVisibleLine;
/*     */ 
/*     */ 
/*     */   
/*     */   private int cellHeight;
/*     */ 
/*     */ 
/*     */   
/*     */   private int cellWidth;
/*     */ 
/*     */ 
/*     */   
/*     */   private int ascent;
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<?, ?> aaHints;
/*     */ 
/*     */ 
/*     */   
/*     */   private int mouseDragStartOffset;
/*     */ 
/*     */ 
/*     */   
/*     */   private Listener l;
/*     */ 
/*     */ 
/*     */   
/*     */   private Insets textAreaInsets;
/*     */ 
/*     */ 
/*     */   
/*     */   private Rectangle visibleRect;
/*     */ 
/*     */   
/*     */   private int lineNumberingStartIndex;
/*     */ 
/*     */ 
/*     */   
/*     */   public LineNumberList(RTextArea textArea) {
/*  94 */     this(textArea, (Color)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineNumberList(RTextArea textArea, Color numberColor) {
/* 108 */     super(textArea);
/*     */     
/* 110 */     if (numberColor != null) {
/* 111 */       setForeground(numberColor);
/*     */     } else {
/*     */       
/* 114 */       setForeground(Color.GRAY);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addNotify() {
/* 127 */     super.addNotify();
/* 128 */     if (this.textArea != null) {
/* 129 */       this.l.install(this.textArea);
/*     */     }
/* 131 */     updateCellWidths();
/* 132 */     updateCellHeights();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int calculateLastVisibleLineNumber() {
/* 142 */     int lastLine = 0;
/* 143 */     if (this.textArea != null) {
/* 144 */       lastLine = this.textArea.getLineCount() + getLineNumberingStartIndex() - 1;
/*     */     }
/* 146 */     return lastLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNumberingStartIndex() {
/* 158 */     return this.lineNumberingStartIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 167 */     int h = (this.textArea != null) ? this.textArea.getHeight() : 100;
/* 168 */     return new Dimension(this.cellWidth, h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getRhsBorderWidth() {
/* 179 */     int w = 4;
/* 180 */     if (this.textArea instanceof RSyntaxTextArea && (
/* 181 */       (RSyntaxTextArea)this.textArea).isCodeFoldingEnabled()) {
/* 182 */       w = 0;
/*     */     }
/*     */     
/* 185 */     return w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void handleDocumentEvent(DocumentEvent e) {
/* 194 */     int newLastLine = calculateLastVisibleLineNumber();
/* 195 */     if (newLastLine != this.lastVisibleLine) {
/*     */ 
/*     */       
/* 198 */       if (newLastLine / 10 != this.lastVisibleLine / 10) {
/* 199 */         updateCellWidths();
/*     */       }
/* 201 */       this.lastVisibleLine = newLastLine;
/* 202 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init() {
/* 210 */     super.init();
/*     */ 
/*     */ 
/*     */     
/* 214 */     this.currentLine = 0;
/* 215 */     setLineNumberingStartIndex(1);
/*     */     
/* 217 */     this.visibleRect = new Rectangle();
/*     */     
/* 219 */     addMouseListener(this);
/* 220 */     addMouseMotionListener(this);
/*     */     
/* 222 */     this.aaHints = RSyntaxUtilities.getDesktopAntiAliasHints();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void lineHeightsChanged() {
/* 232 */     updateCellHeights();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseDragged(MouseEvent e) {
/* 243 */     if (this.mouseDragStartOffset > -1) {
/* 244 */       int pos = this.textArea.viewToModel(new Point(0, e.getY()));
/* 245 */       if (pos >= 0) {
/* 246 */         this.textArea.setCaretPosition(this.mouseDragStartOffset);
/* 247 */         this.textArea.moveCaretPosition(pos);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseExited(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent e) {
/* 270 */     if (this.textArea == null) {
/*     */       return;
/*     */     }
/* 273 */     if (e.getButton() == 1) {
/* 274 */       int pos = this.textArea.viewToModel(new Point(0, e.getY()));
/* 275 */       if (pos >= 0) {
/* 276 */         this.textArea.setCaretPosition(pos);
/*     */       }
/* 278 */       this.mouseDragStartOffset = pos;
/*     */     } else {
/*     */       
/* 281 */       this.mouseDragStartOffset = -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintComponent(Graphics g) {
/* 299 */     if (this.textArea == null) {
/*     */       return;
/*     */     }
/*     */     
/* 303 */     this.visibleRect = g.getClipBounds(this.visibleRect);
/* 304 */     if (this.visibleRect == null) {
/* 305 */       this.visibleRect = getVisibleRect();
/*     */     }
/*     */     
/* 308 */     if (this.visibleRect == null) {
/*     */       return;
/*     */     }
/*     */     
/* 312 */     Color bg = getBackground();
/* 313 */     if (getGutter() != null) {
/* 314 */       bg = getGutter().getBackground();
/*     */     }
/* 316 */     g.setColor(bg);
/* 317 */     g.fillRect(0, this.visibleRect.y, this.cellWidth, this.visibleRect.height);
/* 318 */     g.setFont(getFont());
/* 319 */     if (this.aaHints != null) {
/* 320 */       ((Graphics2D)g).addRenderingHints(this.aaHints);
/*     */     }
/*     */     
/* 323 */     if (this.textArea.getLineWrap()) {
/* 324 */       paintWrappedLineNumbers(g, this.visibleRect);
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 332 */     this.textAreaInsets = this.textArea.getInsets(this.textAreaInsets);
/* 333 */     if (this.visibleRect.y < this.textAreaInsets.top) {
/* 334 */       this.visibleRect.height -= this.textAreaInsets.top - this.visibleRect.y;
/* 335 */       this.visibleRect.y = this.textAreaInsets.top;
/*     */     } 
/* 337 */     int topLine = (this.visibleRect.y - this.textAreaInsets.top) / this.cellHeight;
/* 338 */     int actualTopY = topLine * this.cellHeight + this.textAreaInsets.top;
/* 339 */     int y = actualTopY + this.ascent;
/*     */ 
/*     */     
/* 342 */     FoldManager fm = null;
/* 343 */     if (this.textArea instanceof RSyntaxTextArea) {
/* 344 */       fm = ((RSyntaxTextArea)this.textArea).getFoldManager();
/* 345 */       topLine += fm.getHiddenLineCountAbove(topLine, true);
/*     */     } 
/* 347 */     int rhsBorderWidth = getRhsBorderWidth();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 360 */     g.setColor(getForeground());
/* 361 */     boolean ltr = getComponentOrientation().isLeftToRight();
/* 362 */     if (ltr) {
/* 363 */       FontMetrics metrics = g.getFontMetrics();
/* 364 */       int rhs = getWidth() - rhsBorderWidth;
/* 365 */       int line = topLine + 1;
/* 366 */       while (y < this.visibleRect.y + this.visibleRect.height + this.ascent && line <= this.textArea.getLineCount()) {
/* 367 */         String number = Integer.toString(line + getLineNumberingStartIndex() - 1);
/* 368 */         int width = metrics.stringWidth(number);
/* 369 */         g.drawString(number, rhs - width, y);
/* 370 */         y += this.cellHeight;
/* 371 */         if (fm != null) {
/* 372 */           Fold fold = fm.getFoldForLine(line - 1);
/*     */ 
/*     */           
/* 375 */           while (fold != null && fold.isCollapsed()) {
/* 376 */             int hiddenLineCount = fold.getLineCount();
/* 377 */             if (hiddenLineCount == 0) {
/*     */               break;
/*     */             }
/*     */ 
/*     */             
/* 382 */             line += hiddenLineCount;
/* 383 */             fold = fm.getFoldForLine(line - 1);
/*     */           } 
/*     */         } 
/* 386 */         line++;
/*     */       } 
/*     */     } else {
/*     */       
/* 390 */       int line = topLine + 1;
/* 391 */       while (y < this.visibleRect.y + this.visibleRect.height && line < this.textArea.getLineCount()) {
/* 392 */         String number = Integer.toString(line + getLineNumberingStartIndex() - 1);
/* 393 */         g.drawString(number, rhsBorderWidth, y);
/* 394 */         y += this.cellHeight;
/* 395 */         if (fm != null) {
/* 396 */           Fold fold = fm.getFoldForLine(line - 1);
/*     */ 
/*     */           
/* 399 */           while (fold != null && fold.isCollapsed()) {
/* 400 */             line += fold.getLineCount();
/* 401 */             fold = fm.getFoldForLine(line);
/*     */           } 
/*     */         } 
/* 404 */         line++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintWrappedLineNumbers(Graphics g, Rectangle visibleRect) {
/* 449 */     int rhs, width = getWidth();
/*     */     
/* 451 */     RTextAreaUI ui = (RTextAreaUI)this.textArea.getUI();
/* 452 */     View v = ui.getRootView(this.textArea).getView(0);
/*     */     
/* 454 */     Document doc = this.textArea.getDocument();
/* 455 */     Element root = doc.getDefaultRootElement();
/* 456 */     int lineCount = root.getElementCount();
/* 457 */     int topPosition = this.textArea.viewToModel(new Point(visibleRect.x, visibleRect.y));
/*     */     
/* 459 */     int topLine = root.getElementIndex(topPosition);
/* 460 */     FoldManager fm = null;
/* 461 */     if (this.textArea instanceof RSyntaxTextArea) {
/* 462 */       fm = ((RSyntaxTextArea)this.textArea).getFoldManager();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 469 */     Rectangle visibleEditorRect = ui.getVisibleEditorRect();
/* 470 */     Rectangle r = getChildViewBounds(v, topLine, visibleEditorRect);
/*     */     
/* 472 */     int y = r.y;
/* 473 */     int rhsBorderWidth = getRhsBorderWidth();
/*     */     
/* 475 */     boolean ltr = getComponentOrientation().isLeftToRight();
/* 476 */     if (ltr) {
/* 477 */       rhs = width - rhsBorderWidth;
/*     */     } else {
/*     */       
/* 480 */       rhs = rhsBorderWidth;
/*     */     } 
/* 482 */     int visibleBottom = visibleRect.y + visibleRect.height;
/* 483 */     FontMetrics metrics = g.getFontMetrics();
/*     */ 
/*     */ 
/*     */     
/* 487 */     g.setColor(getForeground());
/*     */     
/* 489 */     while (y < visibleBottom) {
/*     */       
/* 491 */       r = getChildViewBounds(v, topLine, visibleEditorRect);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 503 */       int index = topLine + 1 + getLineNumberingStartIndex() - 1;
/* 504 */       String number = Integer.toString(index);
/* 505 */       if (ltr) {
/* 506 */         int strWidth = metrics.stringWidth(number);
/* 507 */         g.drawString(number, rhs - strWidth, y + this.ascent);
/*     */       } else {
/*     */         
/* 510 */         int x = rhsBorderWidth;
/* 511 */         g.drawString(number, x, y + this.ascent);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 516 */       y += r.height;
/*     */ 
/*     */ 
/*     */       
/* 520 */       if (fm != null) {
/* 521 */         Fold fold = fm.getFoldForLine(topLine);
/* 522 */         if (fold != null && fold.isCollapsed()) {
/* 523 */           topLine += fold.getCollapsedLineCount();
/*     */         }
/*     */       } 
/* 526 */       topLine++;
/* 527 */       if (topLine >= lineCount) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeNotify() {
/* 541 */     super.removeNotify();
/* 542 */     if (this.textArea != null) {
/* 543 */       this.l.uninstall(this.textArea);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void repaintLine(int line) {
/* 554 */     int y = (this.textArea.getInsets()).top;
/* 555 */     y += line * this.cellHeight;
/* 556 */     repaint(0, y, this.cellWidth, this.cellHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 568 */     super.setFont(font);
/* 569 */     updateCellWidths();
/* 570 */     updateCellHeights();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineNumberingStartIndex(int index) {
/* 583 */     if (index != this.lineNumberingStartIndex) {
/* 584 */       this.lineNumberingStartIndex = index;
/* 585 */       updateCellWidths();
/* 586 */       repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTextArea(RTextArea textArea) {
/* 599 */     if (this.l == null) {
/* 600 */       this.l = new Listener();
/*     */     }
/*     */     
/* 603 */     if (this.textArea != null) {
/* 604 */       this.l.uninstall(textArea);
/*     */     }
/*     */     
/* 607 */     super.setTextArea(textArea);
/* 608 */     this.lastVisibleLine = calculateLastVisibleLineNumber();
/*     */     
/* 610 */     if (textArea != null) {
/* 611 */       this.l.install(textArea);
/* 612 */       updateCellHeights();
/* 613 */       updateCellWidths();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateCellHeights() {
/* 625 */     if (this.textArea != null) {
/* 626 */       this.cellHeight = this.textArea.getLineHeight();
/* 627 */       this.ascent = this.textArea.getMaxAscent();
/*     */     } else {
/*     */       
/* 630 */       this.cellHeight = 20;
/* 631 */       this.ascent = 5;
/*     */     } 
/* 633 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateCellWidths() {
/* 643 */     int oldCellWidth = this.cellWidth;
/* 644 */     this.cellWidth = getRhsBorderWidth();
/*     */ 
/*     */     
/* 647 */     if (this.textArea != null) {
/* 648 */       Font font = getFont();
/* 649 */       if (font != null) {
/* 650 */         FontMetrics fontMetrics = getFontMetrics(font);
/* 651 */         int count = 0;
/*     */         
/* 653 */         int lineCount = this.textArea.getLineCount() + getLineNumberingStartIndex() - 1;
/*     */         while (true) {
/* 655 */           lineCount /= 10;
/* 656 */           count++;
/* 657 */           if (lineCount < 10) {
/* 658 */             this.cellWidth += fontMetrics.charWidth('9') * (count + 1) + 3; break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 662 */     }  if (this.cellWidth != oldCellWidth) {
/* 663 */       revalidate();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class Listener
/*     */     implements CaretListener, PropertyChangeListener
/*     */   {
/*     */     private boolean installed;
/*     */ 
/*     */     
/*     */     private Listener() {}
/*     */ 
/*     */     
/*     */     public void caretUpdate(CaretEvent e) {
/* 679 */       int dot = LineNumberList.this.textArea.getCaretPosition();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 689 */       if (!LineNumberList.this.textArea.getLineWrap()) {
/*     */         
/* 691 */         int line = LineNumberList.this.textArea.getDocument().getDefaultRootElement().getElementIndex(dot);
/* 692 */         if (LineNumberList.this.currentLine != line) {
/* 693 */           LineNumberList.this.repaintLine(line);
/* 694 */           LineNumberList.this.repaintLine(LineNumberList.this.currentLine);
/* 695 */           LineNumberList.this.currentLine = line;
/*     */         } 
/*     */       } else {
/*     */         
/*     */         try {
/* 700 */           int y = LineNumberList.this.textArea.yForLineContaining(dot);
/* 701 */           if (y != LineNumberList.this.lastY) {
/* 702 */             LineNumberList.this.lastY = y;
/* 703 */             LineNumberList.this.currentLine = LineNumberList.this.textArea.getDocument()
/* 704 */               .getDefaultRootElement().getElementIndex(dot);
/* 705 */             LineNumberList.this.repaint();
/*     */           } 
/* 707 */         } catch (BadLocationException ble) {
/* 708 */           ble.printStackTrace();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void install(RTextArea textArea) {
/* 715 */       if (!this.installed) {
/*     */         
/* 717 */         textArea.addCaretListener(this);
/* 718 */         textArea.addPropertyChangeListener(this);
/* 719 */         caretUpdate(null);
/* 720 */         this.installed = true;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void propertyChange(PropertyChangeEvent e) {
/* 727 */       String name = e.getPropertyName();
/*     */ 
/*     */       
/* 730 */       if ("RTA.currentLineHighlight".equals(name) || "RTA.currentLineHighlightColor"
/* 731 */         .equals(name)) {
/* 732 */         LineNumberList.this.repaintLine(LineNumberList.this.currentLine);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void uninstall(RTextArea textArea) {
/* 738 */       if (this.installed) {
/*     */         
/* 740 */         textArea.removeCaretListener(this);
/* 741 */         textArea.removePropertyChangeListener(this);
/* 742 */         this.installed = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/LineNumberList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */