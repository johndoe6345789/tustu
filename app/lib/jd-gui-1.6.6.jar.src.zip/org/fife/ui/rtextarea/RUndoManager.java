/*     */ package org.fife.ui.rtextarea;
/*     */ 
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.event.UndoableEditEvent;
/*     */ import javax.swing.undo.CompoundEdit;
/*     */ import javax.swing.undo.UndoManager;
/*     */ import javax.swing.undo.UndoableEdit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RUndoManager
/*     */   extends UndoManager
/*     */ {
/*     */   private RCompoundEdit compoundEdit;
/*     */   private RTextArea textArea;
/*     */   private int lastOffset;
/*     */   private String cantUndoText;
/*     */   private String cantRedoText;
/*     */   private int internalAtomicEditDepth;
/*     */   private static final String MSG = "org.fife.ui.rtextarea.RTextArea";
/*     */   
/*     */   public RUndoManager(RTextArea textArea) {
/*  51 */     this.textArea = textArea;
/*  52 */     ResourceBundle msg = ResourceBundle.getBundle("org.fife.ui.rtextarea.RTextArea");
/*  53 */     this.cantUndoText = msg.getString("Action.CantUndo.Name");
/*  54 */     this.cantRedoText = msg.getString("Action.CantRedo.Name");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginInternalAtomicEdit() {
/*  68 */     if (++this.internalAtomicEditDepth == 1) {
/*  69 */       if (this.compoundEdit != null) {
/*  70 */         this.compoundEdit.end();
/*     */       }
/*  72 */       this.compoundEdit = new RCompoundEdit();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endInternalAtomicEdit() {
/*  83 */     if (this.internalAtomicEditDepth > 0 && --this.internalAtomicEditDepth == 0) {
/*  84 */       addEdit(this.compoundEdit);
/*  85 */       this.compoundEdit.end();
/*  86 */       this.compoundEdit = null;
/*  87 */       updateActions();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCantRedoText() {
/*  99 */     return this.cantRedoText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCantUndoText() {
/* 110 */     return this.cantUndoText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void redo() {
/* 119 */     super.redo();
/* 120 */     updateActions();
/*     */   }
/*     */ 
/*     */   
/*     */   private RCompoundEdit startCompoundEdit(UndoableEdit edit) {
/* 125 */     this.lastOffset = this.textArea.getCaretPosition();
/* 126 */     this.compoundEdit = new RCompoundEdit();
/* 127 */     this.compoundEdit.addEdit(edit);
/* 128 */     addEdit(this.compoundEdit);
/* 129 */     return this.compoundEdit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void undo() {
/* 138 */     super.undo();
/* 139 */     updateActions();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void undoableEditHappened(UndoableEditEvent e) {
/* 148 */     if (this.compoundEdit == null) {
/* 149 */       this.compoundEdit = startCompoundEdit(e.getEdit());
/* 150 */       updateActions();
/*     */       
/*     */       return;
/*     */     } 
/* 154 */     if (this.internalAtomicEditDepth > 0) {
/* 155 */       this.compoundEdit.addEdit(e.getEdit());
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 164 */     int diff = this.textArea.getCaretPosition() - this.lastOffset;
/*     */ 
/*     */     
/* 167 */     if (Math.abs(diff) <= 1) {
/* 168 */       this.compoundEdit.addEdit(e.getEdit());
/* 169 */       this.lastOffset += diff;
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 178 */     this.compoundEdit.end();
/* 179 */     this.compoundEdit = startCompoundEdit(e.getEdit());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateActions() {
/* 193 */     Action a = RTextArea.getAction(6);
/* 194 */     if (canUndo()) {
/* 195 */       a.setEnabled(true);
/* 196 */       String text = getUndoPresentationName();
/* 197 */       a.putValue("Name", text);
/* 198 */       a.putValue("ShortDescription", text);
/*     */     
/*     */     }
/* 201 */     else if (a.isEnabled()) {
/* 202 */       a.setEnabled(false);
/* 203 */       String text = this.cantUndoText;
/* 204 */       a.putValue("Name", text);
/* 205 */       a.putValue("ShortDescription", text);
/*     */     } 
/*     */ 
/*     */     
/* 209 */     a = RTextArea.getAction(4);
/* 210 */     if (canRedo()) {
/* 211 */       a.setEnabled(true);
/* 212 */       String text = getRedoPresentationName();
/* 213 */       a.putValue("Name", text);
/* 214 */       a.putValue("ShortDescription", text);
/*     */     
/*     */     }
/* 217 */     else if (a.isEnabled()) {
/* 218 */       a.setEnabled(false);
/* 219 */       String text = this.cantRedoText;
/* 220 */       a.putValue("Name", text);
/* 221 */       a.putValue("ShortDescription", text);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class RCompoundEdit
/*     */     extends CompoundEdit
/*     */   {
/*     */     public String getUndoPresentationName() {
/* 234 */       return UIManager.getString("AbstractUndoableEdit.undoText");
/*     */     }
/*     */ 
/*     */     
/*     */     public String getRedoPresentationName() {
/* 239 */       return UIManager.getString("AbstractUndoableEdit.redoText");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isInProgress() {
/* 244 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void undo() {
/* 249 */       if (RUndoManager.this.compoundEdit != null) {
/* 250 */         RUndoManager.this.compoundEdit.end();
/*     */       }
/* 252 */       super.undo();
/* 253 */       RUndoManager.this.compoundEdit = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/RUndoManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */