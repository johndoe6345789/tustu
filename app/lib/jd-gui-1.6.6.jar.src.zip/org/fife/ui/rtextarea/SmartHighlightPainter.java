/*     */ package org.fife.ui.rtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import javax.swing.text.Position;
/*     */ import javax.swing.text.View;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SmartHighlightPainter
/*     */   extends ChangeableHighlightPainter
/*     */ {
/*     */   private Color borderColor;
/*     */   private boolean paintBorder;
/*     */   
/*     */   public SmartHighlightPainter() {
/*  50 */     super(Color.BLUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SmartHighlightPainter(Paint paint) {
/*  60 */     super(paint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getPaintBorder() {
/*  72 */     return this.paintBorder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Shape paintLayer(Graphics g, int p0, int p1, Shape viewBounds, JTextComponent c, View view) {
/*  83 */     g.setColor((Color)getPaint());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     if (p0 == p1) {
/*     */       try {
/*  92 */         Shape s = view.modelToView(p0, viewBounds, Position.Bias.Forward);
/*     */         
/*  94 */         Rectangle r = s.getBounds();
/*  95 */         g.drawLine(r.x, r.y, r.x, r.y + r.height);
/*  96 */         return r;
/*  97 */       } catch (BadLocationException ble) {
/*  98 */         ble.printStackTrace();
/*  99 */         return null;
/*     */       } 
/*     */     }
/*     */     
/* 103 */     if (p0 == view.getStartOffset() && p1 == view.getEndOffset()) {
/*     */       Rectangle alloc;
/*     */       
/* 106 */       if (viewBounds instanceof Rectangle) {
/* 107 */         alloc = (Rectangle)viewBounds;
/*     */       } else {
/* 109 */         alloc = viewBounds.getBounds();
/*     */       } 
/* 111 */       g.fillRect(alloc.x, alloc.y, alloc.width, alloc.height);
/* 112 */       return alloc;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 118 */       Shape shape = view.modelToView(p0, Position.Bias.Forward, p1, Position.Bias.Backward, viewBounds);
/*     */ 
/*     */       
/* 121 */       Rectangle r = (shape instanceof Rectangle) ? (Rectangle)shape : shape.getBounds();
/* 122 */       g.fillRect(r.x, r.y, r.width, r.height);
/* 123 */       if (this.paintBorder) {
/* 124 */         g.setColor(this.borderColor);
/* 125 */         g.drawRect(r.x, r.y, r.width - 1, r.height - 1);
/*     */       } 
/* 127 */       return r;
/* 128 */     } catch (BadLocationException e) {
/* 129 */       e.printStackTrace();
/* 130 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPaint(Paint paint) {
/* 141 */     super.setPaint(paint);
/* 142 */     if (paint instanceof Color) {
/* 143 */       this.borderColor = ((Color)paint).darker();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPaintBorder(boolean paint) {
/* 156 */     this.paintBorder = paint;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/SmartHighlightPainter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */