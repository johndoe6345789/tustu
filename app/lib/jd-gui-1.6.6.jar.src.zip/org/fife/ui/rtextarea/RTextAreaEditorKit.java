/*      */ package org.fife.ui.rtextarea;
/*      */ 
/*      */ import java.awt.Container;
/*      */ import java.awt.Font;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.text.DateFormat;
/*      */ import java.util.Date;
/*      */ import javax.swing.Action;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.JViewport;
/*      */ import javax.swing.KeyStroke;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.text.BadLocationException;
/*      */ import javax.swing.text.Caret;
/*      */ import javax.swing.text.DefaultEditorKit;
/*      */ import javax.swing.text.Document;
/*      */ import javax.swing.text.Element;
/*      */ import javax.swing.text.JTextComponent;
/*      */ import javax.swing.text.NavigationFilter;
/*      */ import javax.swing.text.Position;
/*      */ import javax.swing.text.Segment;
/*      */ import javax.swing.text.Utilities;
/*      */ import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
/*      */ import org.fife.ui.rsyntaxtextarea.RSyntaxUtilities;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RTextAreaEditorKit
/*      */   extends DefaultEditorKit
/*      */ {
/*      */   public static final String rtaBeginRecordingMacroAction = "RTA.BeginRecordingMacroAction";
/*      */   public static final String rtaDecreaseFontSizeAction = "RTA.DecreaseFontSizeAction";
/*      */   public static final String rtaDeleteLineAction = "RTA.DeleteLineAction";
/*      */   public static final String rtaDeletePrevWordAction = "RTA.DeletePrevWordAction";
/*      */   public static final String rtaDeleteRestOfLineAction = "RTA.DeleteRestOfLineAction";
/*      */   public static final String rtaDumbCompleteWordAction = "RTA.DumbCompleteWordAction";
/*      */   public static final String rtaEndRecordingMacroAction = "RTA.EndRecordingMacroAction";
/*      */   public static final String rtaIncreaseFontSizeAction = "RTA.IncreaseFontSizeAction";
/*      */   public static final String rtaInvertSelectionCaseAction = "RTA.InvertCaseAction";
/*      */   public static final String rtaJoinLinesAction = "RTA.JoinLinesAction";
/*      */   public static final String rtaLineDownAction = "RTA.LineDownAction";
/*      */   public static final String rtaLineUpAction = "RTA.LineUpAction";
/*      */   public static final String rtaLowerSelectionCaseAction = "RTA.LowerCaseAction";
/*      */   public static final String rtaNextOccurrenceAction = "RTA.NextOccurrenceAction";
/*      */   public static final String rtaPrevOccurrenceAction = "RTA.PrevOccurrenceAction";
/*      */   public static final String rtaNextBookmarkAction = "RTA.NextBookmarkAction";
/*      */   public static final String clipboardHistoryAction = "RTA.PasteHistoryAction";
/*      */   public static final String rtaPrevBookmarkAction = "RTA.PrevBookmarkAction";
/*      */   public static final String rtaPlaybackLastMacroAction = "RTA.PlaybackLastMacroAction";
/*      */   public static final String rtaRedoAction = "RTA.RedoAction";
/*      */   public static final String rtaScrollDownAction = "RTA.ScrollDownAction";
/*      */   public static final String rtaScrollUpAction = "RTA.ScrollUpAction";
/*      */   public static final String rtaSelectionPageUpAction = "RTA.SelectionPageUpAction";
/*      */   public static final String rtaSelectionPageDownAction = "RTA.SelectionPageDownAction";
/*      */   public static final String rtaSelectionPageLeftAction = "RTA.SelectionPageLeftAction";
/*      */   public static final String rtaSelectionPageRightAction = "RTA.SelectionPageRightAction";
/*      */   public static final String rtaTimeDateAction = "RTA.TimeDateAction";
/*      */   public static final String rtaToggleBookmarkAction = "RTA.ToggleBookmarkAction";
/*      */   public static final String rtaToggleTextModeAction = "RTA.ToggleTextModeAction";
/*      */   public static final String rtaUndoAction = "RTA.UndoAction";
/*      */   public static final String rtaUnselectAction = "RTA.UnselectAction";
/*      */   public static final String rtaUpperSelectionCaseAction = "RTA.UpperCaseAction";
/*  230 */   private static final RecordableTextAction[] defaultActions = new RecordableTextAction[] { new BeginAction("caret-begin", false), new BeginAction("selection-begin", true), new BeginLineAction("caret-begin-line", false), new BeginLineAction("selection-begin-line", true), new BeginRecordingMacroAction(), new BeginWordAction("caret-begin-word", false), new BeginWordAction("selection-begin-word", true), new ClipboardHistoryAction(), new CopyAction(), new CutAction(), new DefaultKeyTypedAction(), new DeleteLineAction(), new DeleteNextCharAction(), new DeletePrevCharAction(), new DeletePrevWordAction(), new DeleteRestOfLineAction(), new DumbCompleteWordAction(), new EndAction("caret-end", false), new EndAction("selection-end", true), new EndLineAction("caret-end-line", false), new EndLineAction("selection-end-line", true), new EndRecordingMacroAction(), new EndWordAction("caret-end-word", false), new EndWordAction("caret-end-word", true), new InsertBreakAction(), new InsertContentAction(), new InsertTabAction(), new InvertSelectionCaseAction(), new JoinLinesAction(), new LowerSelectionCaseAction(), new LineMoveAction("RTA.LineUpAction", -1), new LineMoveAction("RTA.LineDownAction", 1), new NextBookmarkAction("RTA.NextBookmarkAction", true), new NextBookmarkAction("RTA.PrevBookmarkAction", false), new NextVisualPositionAction("caret-forward", false, 3), new NextVisualPositionAction("caret-backward", false, 7), new NextVisualPositionAction("selection-forward", true, 3), new NextVisualPositionAction("selection-backward", true, 7), new NextVisualPositionAction("caret-up", false, 1), new NextVisualPositionAction("caret-down", false, 5), new NextVisualPositionAction("selection-up", true, 1), new NextVisualPositionAction("selection-down", true, 5), new NextOccurrenceAction("RTA.NextOccurrenceAction"), new PreviousOccurrenceAction("RTA.PrevOccurrenceAction"), new NextWordAction("caret-next-word", false), new NextWordAction("selection-next-word", true), new PageAction("RTA.SelectionPageLeftAction", true, true), new PageAction("RTA.SelectionPageRightAction", false, true), new PasteAction(), new PlaybackLastMacroAction(), new PreviousWordAction("caret-previous-word", false), new PreviousWordAction("selection-previous-word", true), new RedoAction(), new ScrollAction("RTA.ScrollUpAction", -1), new ScrollAction("RTA.ScrollDownAction", 1), new SelectAllAction(), new SelectLineAction(), new SelectWordAction(), new SetReadOnlyAction(), new SetWritableAction(), new ToggleBookmarkAction(), new ToggleTextModeAction(), new UndoAction(), new UnselectAction(), new UpperSelectionCaseAction(), new VerticalPageAction("page-up", -1, false), new VerticalPageAction("page-down", 1, false), new VerticalPageAction("RTA.SelectionPageUpAction", -1, true), new VerticalPageAction("RTA.SelectionPageDownAction", 1, true) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int READBUFFER_SIZE = 32768;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IconRowHeader createIconRowHeader(RTextArea textArea) {
/*  323 */     return new IconRowHeader(textArea);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LineNumberList createLineNumberList(RTextArea textArea) {
/*  334 */     return new LineNumberList(textArea);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Action[] getActions() {
/*  347 */     return (Action[])defaultActions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void read(Reader in, Document doc, int pos) throws IOException, BadLocationException {
/*  368 */     char[] buff = new char[32768];
/*      */     
/*  370 */     boolean lastWasCR = false;
/*  371 */     boolean isCRLF = false;
/*  372 */     boolean isCR = false;
/*      */     
/*  374 */     boolean wasEmpty = (doc.getLength() == 0);
/*      */ 
/*      */ 
/*      */     
/*      */     int nch;
/*      */ 
/*      */     
/*  381 */     while ((nch = in.read(buff, 0, buff.length)) != -1) {
/*  382 */       int last = 0;
/*  383 */       for (int counter = 0; counter < nch; counter++) {
/*  384 */         switch (buff[counter]) {
/*      */           case '\r':
/*  386 */             if (lastWasCR) {
/*  387 */               isCR = true;
/*  388 */               if (counter == 0) {
/*  389 */                 doc.insertString(pos, "\n", null);
/*  390 */                 pos++;
/*      */                 break;
/*      */               } 
/*  393 */               buff[counter - 1] = '\n';
/*      */               
/*      */               break;
/*      */             } 
/*  397 */             lastWasCR = true;
/*      */             break;
/*      */           
/*      */           case '\n':
/*  401 */             if (lastWasCR) {
/*  402 */               if (counter > last + 1) {
/*  403 */                 doc.insertString(pos, new String(buff, last, counter - last - 1), null);
/*      */                 
/*  405 */                 pos += counter - last - 1;
/*      */               } 
/*      */ 
/*      */               
/*  409 */               lastWasCR = false;
/*  410 */               last = counter;
/*  411 */               isCRLF = true;
/*      */             } 
/*      */             break;
/*      */           default:
/*  415 */             if (lastWasCR) {
/*  416 */               isCR = true;
/*  417 */               if (counter == 0) {
/*  418 */                 doc.insertString(pos, "\n", null);
/*  419 */                 pos++;
/*      */               } else {
/*      */                 
/*  422 */                 buff[counter - 1] = '\n';
/*      */               } 
/*  424 */               lastWasCR = false;
/*      */             } 
/*      */             break;
/*      */         } 
/*      */       
/*      */       } 
/*  430 */       if (last < nch) {
/*  431 */         if (lastWasCR) {
/*  432 */           if (last < nch - 1) {
/*  433 */             doc.insertString(pos, new String(buff, last, nch - last - 1), null);
/*      */             
/*  435 */             pos += nch - last - 1;
/*      */           } 
/*      */           continue;
/*      */         } 
/*  439 */         doc.insertString(pos, new String(buff, last, nch - last), null);
/*      */         
/*  441 */         pos += nch - last;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  447 */     if (lastWasCR) {
/*  448 */       doc.insertString(pos, "\n", null);
/*  449 */       isCR = true;
/*      */     } 
/*      */     
/*  452 */     if (wasEmpty) {
/*  453 */       if (isCRLF) {
/*  454 */         doc.putProperty("__EndOfLine__", "\r\n");
/*      */       }
/*  456 */       else if (isCR) {
/*  457 */         doc.putProperty("__EndOfLine__", "\r");
/*      */       } else {
/*      */         
/*  460 */         doc.putProperty("__EndOfLine__", "\n");
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class BeepAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public BeepAction() {
/*  473 */       super("beep");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*  478 */       UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/*  483 */       return "beep";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class BeginAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private boolean select;
/*      */ 
/*      */ 
/*      */     
/*      */     public BeginAction(String name, boolean select) {
/*  497 */       super(name);
/*  498 */       this.select = select;
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*  503 */       if (this.select) {
/*  504 */         textArea.moveCaretPosition(0);
/*      */       } else {
/*      */         
/*  507 */         textArea.setCaretPosition(0);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/*  513 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class BeginLineAction
/*      */     extends RecordableTextAction
/*      */   {
/*  525 */     private Segment currentLine = new Segment();
/*      */     private boolean select;
/*      */     
/*      */     public BeginLineAction(String name, boolean select) {
/*  529 */       super(name);
/*  530 */       this.select = select;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*  536 */       int newPos = 0;
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  541 */         if (textArea.getLineWrap()) {
/*  542 */           int offs = textArea.getCaretPosition();
/*      */ 
/*      */ 
/*      */           
/*  546 */           int begOffs = Utilities.getRowStart(textArea, offs);
/*      */ 
/*      */ 
/*      */           
/*  550 */           newPos = begOffs;
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */           
/*  559 */           int caretPosition = textArea.getCaretPosition();
/*  560 */           Document document = textArea.getDocument();
/*  561 */           Element map = document.getDefaultRootElement();
/*  562 */           int currentLineNum = map.getElementIndex(caretPosition);
/*  563 */           Element currentLineElement = map.getElement(currentLineNum);
/*  564 */           int currentLineStart = currentLineElement.getStartOffset();
/*  565 */           int currentLineEnd = currentLineElement.getEndOffset();
/*  566 */           int count = currentLineEnd - currentLineStart;
/*  567 */           if (count > 0) {
/*  568 */             document.getText(currentLineStart, count, this.currentLine);
/*  569 */             int firstNonWhitespace = getFirstNonWhitespacePos();
/*  570 */             firstNonWhitespace = currentLineStart + firstNonWhitespace - this.currentLine.offset;
/*      */             
/*  572 */             if (caretPosition != firstNonWhitespace) {
/*  573 */               newPos = firstNonWhitespace;
/*      */             } else {
/*      */               
/*  576 */               newPos = currentLineStart;
/*      */             } 
/*      */           } else {
/*      */             
/*  580 */             newPos = currentLineStart;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  585 */         if (this.select) {
/*  586 */           textArea.moveCaretPosition(newPos);
/*      */         } else {
/*      */           
/*  589 */           textArea.setCaretPosition(newPos);
/*      */         }
/*      */       
/*      */       }
/*  593 */       catch (BadLocationException ble) {
/*      */         
/*  595 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*  596 */         ble.printStackTrace();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private int getFirstNonWhitespacePos() {
/*  602 */       int offset = this.currentLine.offset;
/*  603 */       int end = offset + this.currentLine.count - 1;
/*  604 */       int pos = offset;
/*  605 */       char[] array = this.currentLine.array;
/*  606 */       char currentChar = array[pos];
/*  607 */       while ((currentChar == '\t' || currentChar == ' ') && ++pos < end) {
/*  608 */         currentChar = array[pos];
/*      */       }
/*  610 */       return pos;
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/*  615 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class BeginRecordingMacroAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public BeginRecordingMacroAction() {
/*  627 */       super("RTA.BeginRecordingMacroAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public BeginRecordingMacroAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/*  632 */       super(name, icon, desc, mnemonic, accelerator);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*  637 */       RTextArea.beginRecordingMacro();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isRecordable() {
/*  642 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/*  647 */       return "RTA.BeginRecordingMacroAction";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class BeginWordAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private boolean select;
/*      */ 
/*      */ 
/*      */     
/*      */     protected BeginWordAction(String name, boolean select) {
/*  661 */       super(name);
/*  662 */       this.select = select;
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*      */       try {
/*  668 */         int offs = textArea.getCaretPosition();
/*  669 */         int begOffs = getWordStart(textArea, offs);
/*  670 */         if (this.select) {
/*  671 */           textArea.moveCaretPosition(begOffs);
/*      */         } else {
/*      */           
/*  674 */           textArea.setCaretPosition(begOffs);
/*      */         } 
/*  676 */       } catch (BadLocationException ble) {
/*  677 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/*  683 */       return getName();
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getWordStart(RTextArea textArea, int offs) throws BadLocationException {
/*  688 */       return Utilities.getWordStart(textArea, offs);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ClipboardHistoryAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private ClipboardHistory clipboardHistory;
/*      */ 
/*      */ 
/*      */     
/*      */     public ClipboardHistoryAction() {
/*  703 */       super("RTA.PasteHistoryAction");
/*  704 */       this.clipboardHistory = ClipboardHistory.get();
/*      */     }
/*      */ 
/*      */     
/*      */     public ClipboardHistoryAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/*  709 */       super(name, icon, desc, mnemonic, accelerator);
/*  710 */       this.clipboardHistory = ClipboardHistory.get();
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*  715 */       Window owner = SwingUtilities.getWindowAncestor(textArea);
/*  716 */       ClipboardHistoryPopup popup = new ClipboardHistoryPopup(owner, textArea);
/*  717 */       popup.setContents(this.clipboardHistory.getHistory());
/*  718 */       popup.setVisible(true);
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/*  723 */       return "RTA.PasteHistoryAction";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class CopyAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public CopyAction() {
/*  735 */       super("copy-to-clipboard");
/*      */     }
/*      */ 
/*      */     
/*      */     public CopyAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/*  740 */       super(name, icon, desc, mnemonic, accelerator);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*  745 */       textArea.copy();
/*  746 */       textArea.requestFocusInWindow();
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/*  751 */       return "copy-to-clipboard";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class CutAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public CutAction() {
/*  763 */       super("cut-to-clipboard");
/*      */     }
/*      */ 
/*      */     
/*      */     public CutAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/*  768 */       super(name, icon, desc, mnemonic, accelerator);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*  773 */       textArea.cut();
/*  774 */       textArea.requestFocusInWindow();
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/*  779 */       return "cut-to-clipboard";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DecreaseFontSizeAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     protected float decreaseAmount;
/*      */ 
/*      */     
/*      */     protected static final float MINIMUM_SIZE = 2.0F;
/*      */ 
/*      */     
/*      */     public DecreaseFontSizeAction() {
/*  795 */       super("RTA.DecreaseFontSizeAction");
/*  796 */       initialize();
/*      */     }
/*      */ 
/*      */     
/*      */     public DecreaseFontSizeAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/*  801 */       super(name, icon, desc, mnemonic, accelerator);
/*  802 */       initialize();
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*  807 */       Font font = textArea.getFont();
/*  808 */       float oldSize = font.getSize2D();
/*  809 */       float newSize = oldSize - this.decreaseAmount;
/*  810 */       if (newSize >= 2.0F) {
/*      */         
/*  812 */         font = font.deriveFont(newSize);
/*  813 */         textArea.setFont(font);
/*      */       }
/*  815 */       else if (oldSize > 2.0F) {
/*      */ 
/*      */         
/*  818 */         font = font.deriveFont(2.0F);
/*  819 */         textArea.setFont(font);
/*      */       }
/*      */       else {
/*      */         
/*  823 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */       } 
/*  825 */       textArea.requestFocusInWindow();
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/*  830 */       return "RTA.DecreaseFontSizeAction";
/*      */     }
/*      */     
/*      */     protected void initialize() {
/*  834 */       this.decreaseAmount = 1.0F;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DefaultKeyTypedAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private Action delegate;
/*      */ 
/*      */ 
/*      */     
/*      */     public DefaultKeyTypedAction() {
/*  849 */       super("default-typed", (Icon)null, (String)null, (Integer)null, (KeyStroke)null);
/*      */       
/*  851 */       this.delegate = new DefaultEditorKit.DefaultKeyTypedAction();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*  862 */       this.delegate.actionPerformed(e);
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/*  867 */       return "default-typed";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DeleteLineAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public DeleteLineAction() {
/*  879 */       super("RTA.DeleteLineAction", (Icon)null, (String)null, (Integer)null, (KeyStroke)null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*  886 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/*  887 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */         
/*      */         return;
/*      */       } 
/*  891 */       int selStart = textArea.getSelectionStart();
/*  892 */       int selEnd = textArea.getSelectionEnd();
/*      */ 
/*      */       
/*      */       try {
/*  896 */         int line1 = textArea.getLineOfOffset(selStart);
/*  897 */         int startOffs = textArea.getLineStartOffset(line1);
/*  898 */         int line2 = textArea.getLineOfOffset(selEnd);
/*  899 */         int endOffs = textArea.getLineEndOffset(line2);
/*      */ 
/*      */         
/*  902 */         if (line2 > line1 && 
/*  903 */           selEnd == textArea.getLineStartOffset(line2)) {
/*  904 */           endOffs = selEnd;
/*      */         }
/*      */ 
/*      */         
/*  908 */         textArea.replaceRange((String)null, startOffs, endOffs);
/*      */       }
/*  910 */       catch (BadLocationException ble) {
/*  911 */         ble.printStackTrace();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/*  918 */       return "RTA.DeleteLineAction";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DeleteNextCharAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public DeleteNextCharAction() {
/*  931 */       super("delete-next", (Icon)null, (String)null, (Integer)null, (KeyStroke)null);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public DeleteNextCharAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/*  937 */       super(name, icon, desc, mnemonic, accelerator);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*  943 */       boolean beep = true;
/*  944 */       if (textArea != null && textArea.isEditable()) {
/*      */         try {
/*  946 */           Document doc = textArea.getDocument();
/*  947 */           Caret caret = textArea.getCaret();
/*  948 */           int dot = caret.getDot();
/*  949 */           int mark = caret.getMark();
/*  950 */           if (dot != mark) {
/*  951 */             doc.remove(Math.min(dot, mark), Math.abs(dot - mark));
/*  952 */             beep = false;
/*      */           }
/*  954 */           else if (dot < doc.getLength()) {
/*  955 */             int delChars = 1;
/*  956 */             if (dot < doc.getLength() - 1) {
/*  957 */               String dotChars = doc.getText(dot, 2);
/*  958 */               char c0 = dotChars.charAt(0);
/*  959 */               char c1 = dotChars.charAt(1);
/*  960 */               if (c0 >= '?' && c0 <= '?' && c1 >= '?' && c1 <= '?')
/*      */               {
/*  962 */                 delChars = 2;
/*      */               }
/*      */             } 
/*  965 */             doc.remove(dot, delChars);
/*  966 */             beep = false;
/*      */           } 
/*  968 */         } catch (BadLocationException bl) {}
/*      */       }
/*      */ 
/*      */       
/*  972 */       if (beep) {
/*  973 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */       }
/*  975 */       if (textArea != null) {
/*  976 */         textArea.requestFocusInWindow();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/*  983 */       return "delete-next";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DeletePrevCharAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public DeletePrevCharAction() {
/*  996 */       super("delete-previous");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1002 */       boolean beep = true;
/* 1003 */       if (textArea != null && textArea.isEditable()) {
/*      */         try {
/* 1005 */           Document doc = textArea.getDocument();
/* 1006 */           Caret caret = textArea.getCaret();
/* 1007 */           int dot = caret.getDot();
/* 1008 */           int mark = caret.getMark();
/* 1009 */           if (dot != mark) {
/* 1010 */             doc.remove(Math.min(dot, mark), Math.abs(dot - mark));
/* 1011 */             beep = false;
/*      */           }
/* 1013 */           else if (dot > 0) {
/* 1014 */             int delChars = 1;
/* 1015 */             if (dot > 1) {
/* 1016 */               String dotChars = doc.getText(dot - 2, 2);
/* 1017 */               char c0 = dotChars.charAt(0);
/* 1018 */               char c1 = dotChars.charAt(1);
/* 1019 */               if (c0 >= '?' && c0 <= '?' && c1 >= '?' && c1 <= '?')
/*      */               {
/* 1021 */                 delChars = 2;
/*      */               }
/*      */             } 
/* 1024 */             doc.remove(dot - delChars, delChars);
/* 1025 */             beep = false;
/*      */           } 
/* 1027 */         } catch (BadLocationException bl) {}
/*      */       }
/*      */ 
/*      */       
/* 1031 */       if (beep) {
/* 1032 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1039 */       return "delete-previous";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DeletePrevWordAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public DeletePrevWordAction() {
/* 1051 */       super("RTA.DeletePrevWordAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1056 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/* 1057 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */         return;
/*      */       } 
/*      */       try {
/* 1061 */         int end = textArea.getSelectionStart();
/* 1062 */         int start = getPreviousWordStart(textArea, end);
/* 1063 */         if (end > start) {
/* 1064 */           textArea.getDocument().remove(start, end - start);
/*      */         }
/* 1066 */       } catch (BadLocationException ex) {
/* 1067 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public String getMacroID() {
/* 1073 */       return "RTA.DeletePrevWordAction";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected int getPreviousWordStart(RTextArea textArea, int end) throws BadLocationException {
/* 1082 */       return Utilities.getPreviousWord(textArea, end);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DeleteRestOfLineAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public DeleteRestOfLineAction() {
/* 1095 */       super("RTA.DeleteRestOfLineAction");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*      */       try {
/* 1105 */         Document document = textArea.getDocument();
/* 1106 */         int caretPosition = textArea.getCaretPosition();
/* 1107 */         Element map = document.getDefaultRootElement();
/* 1108 */         int currentLineNum = map.getElementIndex(caretPosition);
/* 1109 */         Element currentLineElement = map.getElement(currentLineNum);
/*      */         
/* 1111 */         int currentLineEnd = currentLineElement.getEndOffset() - 1;
/* 1112 */         if (caretPosition < currentLineEnd) {
/* 1113 */           document.remove(caretPosition, currentLineEnd - caretPosition);
/*      */         
/*      */         }
/*      */       }
/* 1117 */       catch (BadLocationException ble) {
/* 1118 */         ble.printStackTrace();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1125 */       return "RTA.DeleteRestOfLineAction";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DumbCompleteWordAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private int lastWordStart;
/*      */ 
/*      */     
/*      */     private int lastDot;
/*      */     
/*      */     private int searchOffs;
/*      */     
/*      */     private String lastPrefix;
/*      */ 
/*      */     
/*      */     public DumbCompleteWordAction() {
/* 1145 */       super("RTA.DumbCompleteWordAction");
/* 1146 */       this.lastWordStart = this.searchOffs = this.lastDot = -1;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1152 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/* 1158 */         int dot = textArea.getCaretPosition();
/* 1159 */         if (dot == 0) {
/*      */           return;
/*      */         }
/*      */         
/* 1163 */         int curWordStart = getWordStart(textArea, dot);
/*      */         
/* 1165 */         if (this.lastWordStart != curWordStart || dot != this.lastDot) {
/* 1166 */           this.lastPrefix = textArea.getText(curWordStart, dot - curWordStart);
/*      */ 
/*      */           
/* 1169 */           if (!isAcceptablePrefix(this.lastPrefix)) {
/* 1170 */             UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */             return;
/*      */           } 
/* 1173 */           this.lastWordStart = dot - this.lastPrefix.length();
/*      */ 
/*      */           
/* 1176 */           this.searchOffs = Math.max(this.lastWordStart - 1, 0);
/*      */         } 
/*      */         
/* 1179 */         while (this.searchOffs > 0) {
/* 1180 */           int wordStart = 0;
/*      */           try {
/* 1182 */             wordStart = getPreviousWord(textArea, this.searchOffs);
/* 1183 */           } catch (BadLocationException ble) {
/*      */ 
/*      */ 
/*      */             
/* 1187 */             wordStart = -1;
/*      */           } 
/* 1189 */           if (wordStart == -1) {
/* 1190 */             UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */             
/*      */             break;
/*      */           } 
/* 1194 */           int end = getWordEnd(textArea, wordStart);
/* 1195 */           String word = textArea.getText(wordStart, end - wordStart);
/* 1196 */           this.searchOffs = wordStart;
/* 1197 */           if (word.startsWith(this.lastPrefix)) {
/* 1198 */             textArea.replaceRange(word, this.lastWordStart, dot);
/* 1199 */             this.lastDot = textArea.getCaretPosition();
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/* 1204 */       } catch (BadLocationException ble) {
/* 1205 */         ble.printStackTrace();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1212 */       return getName();
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getPreviousWord(RTextArea textArea, int offs) throws BadLocationException {
/* 1217 */       return Utilities.getPreviousWord(textArea, offs);
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getWordEnd(RTextArea textArea, int offs) throws BadLocationException {
/* 1222 */       return Utilities.getWordEnd(textArea, offs);
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getWordStart(RTextArea textArea, int offs) throws BadLocationException {
/* 1227 */       return Utilities.getWordStart(textArea, offs);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected boolean isAcceptablePrefix(String prefix) {
/* 1241 */       return (prefix.length() > 0 && 
/* 1242 */         Character.isLetter(prefix.charAt(prefix.length() - 1)));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EndAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private boolean select;
/*      */ 
/*      */ 
/*      */     
/*      */     public EndAction(String name, boolean select) {
/* 1256 */       super(name);
/* 1257 */       this.select = select;
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1262 */       int dot = getVisibleEnd(textArea);
/* 1263 */       if (this.select) {
/* 1264 */         textArea.moveCaretPosition(dot);
/*      */       } else {
/*      */         
/* 1267 */         textArea.setCaretPosition(dot);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1273 */       return getName();
/*      */     }
/*      */     
/*      */     protected int getVisibleEnd(RTextArea textArea) {
/* 1277 */       return textArea.getDocument().getLength();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EndLineAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private boolean select;
/*      */ 
/*      */ 
/*      */     
/*      */     public EndLineAction(String name, boolean select) {
/* 1291 */       super(name);
/* 1292 */       this.select = select;
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1297 */       int offs = textArea.getCaretPosition();
/* 1298 */       int endOffs = 0;
/*      */       try {
/* 1300 */         if (textArea.getLineWrap()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1306 */           endOffs = Utilities.getRowEnd(textArea, offs);
/*      */         } else {
/*      */           
/* 1309 */           Element root = textArea.getDocument().getDefaultRootElement();
/* 1310 */           int line = root.getElementIndex(offs);
/* 1311 */           endOffs = root.getElement(line).getEndOffset() - 1;
/*      */         } 
/* 1313 */         if (this.select) {
/* 1314 */           textArea.moveCaretPosition(endOffs);
/*      */         } else {
/*      */           
/* 1317 */           textArea.setCaretPosition(endOffs);
/*      */         } 
/* 1319 */       } catch (Exception ex) {
/* 1320 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1326 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EndRecordingMacroAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public EndRecordingMacroAction() {
/* 1338 */       super("RTA.EndRecordingMacroAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public EndRecordingMacroAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/* 1343 */       super(name, icon, desc, mnemonic, accelerator);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1348 */       RTextArea.endRecordingMacro();
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1353 */       return "RTA.EndRecordingMacroAction";
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isRecordable() {
/* 1358 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class EndWordAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private boolean select;
/*      */ 
/*      */ 
/*      */     
/*      */     protected EndWordAction(String name, boolean select) {
/* 1372 */       super(name);
/* 1373 */       this.select = select;
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/*      */       try {
/* 1379 */         int offs = textArea.getCaretPosition();
/* 1380 */         int endOffs = getWordEnd(textArea, offs);
/* 1381 */         if (this.select) {
/* 1382 */           textArea.moveCaretPosition(endOffs);
/*      */         } else {
/*      */           
/* 1385 */           textArea.setCaretPosition(endOffs);
/*      */         } 
/* 1387 */       } catch (BadLocationException ble) {
/* 1388 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1394 */       return getName();
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getWordEnd(RTextArea textArea, int offs) throws BadLocationException {
/* 1399 */       return Utilities.getWordEnd(textArea, offs);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class IncreaseFontSizeAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     protected float increaseAmount;
/*      */ 
/*      */     
/*      */     protected static final float MAXIMUM_SIZE = 40.0F;
/*      */ 
/*      */     
/*      */     public IncreaseFontSizeAction() {
/* 1415 */       super("RTA.IncreaseFontSizeAction");
/* 1416 */       initialize();
/*      */     }
/*      */ 
/*      */     
/*      */     public IncreaseFontSizeAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/* 1421 */       super(name, icon, desc, mnemonic, accelerator);
/* 1422 */       initialize();
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1427 */       Font font = textArea.getFont();
/* 1428 */       float oldSize = font.getSize2D();
/* 1429 */       float newSize = oldSize + this.increaseAmount;
/* 1430 */       if (newSize <= 40.0F) {
/*      */         
/* 1432 */         font = font.deriveFont(newSize);
/* 1433 */         textArea.setFont(font);
/*      */       }
/* 1435 */       else if (oldSize < 40.0F) {
/*      */ 
/*      */         
/* 1438 */         font = font.deriveFont(40.0F);
/* 1439 */         textArea.setFont(font);
/*      */       }
/*      */       else {
/*      */         
/* 1443 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */       } 
/* 1445 */       textArea.requestFocusInWindow();
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1450 */       return "RTA.IncreaseFontSizeAction";
/*      */     }
/*      */     
/*      */     protected void initialize() {
/* 1454 */       this.increaseAmount = 1.0F;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class InsertBreakAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public InsertBreakAction() {
/* 1466 */       super("insert-break");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1471 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/* 1472 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */         return;
/*      */       } 
/* 1475 */       textArea.replaceSelection("\n");
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1480 */       return "insert-break";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isEnabled() {
/* 1490 */       JTextComponent tc = getTextComponent((ActionEvent)null);
/* 1491 */       return (tc == null || tc.isEditable()) ? super.isEnabled() : false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class InsertContentAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public InsertContentAction() {
/* 1503 */       super("insert-content", (Icon)null, (String)null, (Integer)null, (KeyStroke)null);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1509 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/* 1510 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */         return;
/*      */       } 
/* 1513 */       String content = e.getActionCommand();
/* 1514 */       if (content != null) {
/* 1515 */         textArea.replaceSelection(content);
/*      */       } else {
/*      */         
/* 1518 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1524 */       return "insert-content";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class InsertTabAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public InsertTabAction() {
/* 1537 */       super("insert-tab");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1542 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/* 1543 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */         return;
/*      */       } 
/* 1546 */       textArea.replaceSelection("\t");
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1551 */       return "insert-tab";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class InvertSelectionCaseAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public InvertSelectionCaseAction() {
/* 1563 */       super("RTA.InvertCaseAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1568 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/* 1569 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */         return;
/*      */       } 
/* 1572 */       String selection = textArea.getSelectedText();
/* 1573 */       if (selection != null) {
/* 1574 */         StringBuilder buffer = new StringBuilder(selection);
/* 1575 */         int length = buffer.length();
/* 1576 */         for (int i = 0; i < length; i++) {
/* 1577 */           char c = buffer.charAt(i);
/* 1578 */           if (Character.isUpperCase(c)) {
/* 1579 */             buffer.setCharAt(i, Character.toLowerCase(c));
/*      */           }
/* 1581 */           else if (Character.isLowerCase(c)) {
/* 1582 */             buffer.setCharAt(i, Character.toUpperCase(c));
/*      */           } 
/*      */         } 
/* 1585 */         textArea.replaceSelection(buffer.toString());
/*      */       } 
/* 1587 */       textArea.requestFocusInWindow();
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1592 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class JoinLinesAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public JoinLinesAction() {
/* 1604 */       super("RTA.JoinLinesAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1609 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/* 1610 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */         return;
/*      */       } 
/*      */       try {
/* 1614 */         Caret c = textArea.getCaret();
/* 1615 */         int caretPos = c.getDot();
/* 1616 */         Document doc = textArea.getDocument();
/* 1617 */         Element map = doc.getDefaultRootElement();
/* 1618 */         int lineCount = map.getElementCount();
/* 1619 */         int line = map.getElementIndex(caretPos);
/* 1620 */         if (line == lineCount - 1) {
/* 1621 */           UIManager.getLookAndFeel()
/* 1622 */             .provideErrorFeedback(textArea);
/*      */           return;
/*      */         } 
/* 1625 */         Element lineElem = map.getElement(line);
/* 1626 */         caretPos = lineElem.getEndOffset() - 1;
/* 1627 */         c.setDot(caretPos);
/* 1628 */         doc.remove(caretPos, 1);
/* 1629 */       } catch (BadLocationException ble) {
/*      */         
/* 1631 */         ble.printStackTrace();
/*      */       } 
/* 1633 */       textArea.requestFocusInWindow();
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1638 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LineMoveAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private int moveAmt;
/*      */ 
/*      */ 
/*      */     
/*      */     public LineMoveAction(String name, int moveAmt) {
/* 1652 */       super(name);
/* 1653 */       this.moveAmt = moveAmt;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1659 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/* 1660 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*      */       try {
/* 1666 */         int dot = textArea.getCaretPosition();
/* 1667 */         int mark = textArea.getCaret().getMark();
/* 1668 */         Document doc = textArea.getDocument();
/* 1669 */         Element root = doc.getDefaultRootElement();
/* 1670 */         int startLine = root.getElementIndex(Math.min(dot, mark));
/* 1671 */         int endLine = root.getElementIndex(Math.max(dot, mark));
/*      */ 
/*      */ 
/*      */         
/* 1675 */         int moveCount = endLine - startLine + 1;
/* 1676 */         if (moveCount > 1) {
/* 1677 */           Element elem = root.getElement(endLine);
/* 1678 */           if (dot == elem.getStartOffset() || mark == elem.getStartOffset()) {
/* 1679 */             moveCount--;
/*      */           }
/*      */         } 
/*      */         
/* 1683 */         if (this.moveAmt == -1 && startLine > 0) {
/* 1684 */           moveLineUp(textArea, startLine, moveCount);
/*      */         }
/* 1686 */         else if (this.moveAmt == 1 && endLine < root.getElementCount() - 1) {
/* 1687 */           moveLineDown(textArea, startLine, moveCount);
/*      */         } else {
/*      */           
/* 1690 */           UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */           return;
/*      */         } 
/* 1693 */       } catch (BadLocationException ble) {
/*      */         
/* 1695 */         ble.printStackTrace();
/* 1696 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */         return;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1703 */       return getName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void moveLineDown(RTextArea textArea, int line, int lineCount) throws BadLocationException {
/* 1717 */       Document doc = textArea.getDocument();
/* 1718 */       Element root = doc.getDefaultRootElement();
/* 1719 */       Element elem = root.getElement(line);
/* 1720 */       int start = elem.getStartOffset();
/*      */       
/* 1722 */       int endLine = line + lineCount - 1;
/* 1723 */       elem = root.getElement(endLine);
/* 1724 */       int end = elem.getEndOffset();
/*      */       
/* 1726 */       textArea.beginAtomicEdit();
/*      */       
/*      */       try {
/* 1729 */         String text = doc.getText(start, end - start);
/* 1730 */         doc.remove(start, end - start);
/*      */         
/* 1732 */         int insertLine = Math.min(line + 1, textArea.getLineCount());
/* 1733 */         boolean newlineInserted = false;
/* 1734 */         if (insertLine == textArea.getLineCount()) {
/* 1735 */           textArea.append("\n");
/* 1736 */           newlineInserted = true;
/*      */         } 
/*      */         
/* 1739 */         int insertOffs = textArea.getLineStartOffset(insertLine);
/* 1740 */         doc.insertString(insertOffs, text, null);
/* 1741 */         textArea.setSelectionStart(insertOffs);
/* 1742 */         textArea.setSelectionEnd(insertOffs + text.length() - 1);
/*      */         
/* 1744 */         if (newlineInserted) {
/* 1745 */           doc.remove(doc.getLength() - 1, 1);
/*      */         }
/*      */       } finally {
/*      */         
/* 1749 */         textArea.endAtomicEdit();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void moveLineUp(RTextArea textArea, int line, int moveCount) throws BadLocationException {
/* 1757 */       Document doc = textArea.getDocument();
/* 1758 */       Element root = doc.getDefaultRootElement();
/* 1759 */       Element elem = root.getElement(line);
/* 1760 */       int start = elem.getStartOffset();
/*      */       
/* 1762 */       int endLine = line + moveCount - 1;
/* 1763 */       elem = root.getElement(endLine);
/* 1764 */       int end = elem.getEndOffset();
/* 1765 */       int lineCount = textArea.getLineCount();
/* 1766 */       boolean movingLastLine = false;
/* 1767 */       if (endLine == lineCount - 1) {
/* 1768 */         movingLastLine = true;
/* 1769 */         end--;
/*      */       } 
/*      */       
/* 1772 */       int insertLine = Math.max(line - 1, 0);
/*      */       
/* 1774 */       textArea.beginAtomicEdit();
/*      */       
/*      */       try {
/* 1777 */         String text = doc.getText(start, end - start);
/* 1778 */         if (movingLastLine) {
/* 1779 */           text = text + '\n';
/*      */         }
/* 1781 */         doc.remove(start, end - start);
/*      */         
/* 1783 */         int insertOffs = textArea.getLineStartOffset(insertLine);
/* 1784 */         doc.insertString(insertOffs, text, null);
/* 1785 */         textArea.setSelectionStart(insertOffs);
/* 1786 */         int selEnd = insertOffs + text.length() - 1;
/* 1787 */         textArea.setSelectionEnd(selEnd);
/* 1788 */         if (movingLastLine) {
/* 1789 */           doc.remove(doc.getLength() - 1, 1);
/*      */         }
/*      */       } finally {
/*      */         
/* 1793 */         textArea.endAtomicEdit();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LowerSelectionCaseAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public LowerSelectionCaseAction() {
/* 1807 */       super("RTA.LowerCaseAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1812 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/* 1813 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */         return;
/*      */       } 
/* 1816 */       String selection = textArea.getSelectedText();
/* 1817 */       if (selection != null) {
/* 1818 */         textArea.replaceSelection(selection.toLowerCase());
/*      */       }
/* 1820 */       textArea.requestFocusInWindow();
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1825 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class NextBookmarkAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private boolean forward;
/*      */ 
/*      */ 
/*      */     
/*      */     public NextBookmarkAction(String name, boolean forward) {
/* 1839 */       super(name);
/* 1840 */       this.forward = forward;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1846 */       Gutter gutter = RSyntaxUtilities.getGutter(textArea);
/* 1847 */       if (gutter != null) {
/*      */         
/*      */         try {
/*      */           
/* 1851 */           GutterIconInfo[] bookmarks = gutter.getBookmarks();
/* 1852 */           if (bookmarks.length == 0) {
/* 1853 */             UIManager.getLookAndFeel()
/* 1854 */               .provideErrorFeedback(textArea);
/*      */             
/*      */             return;
/*      */           } 
/* 1858 */           GutterIconInfo moveTo = null;
/* 1859 */           int curLine = textArea.getCaretLineNumber();
/*      */           
/* 1861 */           if (this.forward) {
/* 1862 */             for (GutterIconInfo bookmark : bookmarks) {
/* 1863 */               int i = bookmark.getMarkedOffset();
/* 1864 */               int j = textArea.getLineOfOffset(i);
/* 1865 */               if (j > curLine) {
/* 1866 */                 moveTo = bookmark;
/*      */                 break;
/*      */               } 
/*      */             } 
/* 1870 */             if (moveTo == null) {
/* 1871 */               moveTo = bookmarks[0];
/*      */             }
/*      */           } else {
/*      */             
/* 1875 */             for (int i = bookmarks.length - 1; i >= 0; i--) {
/* 1876 */               GutterIconInfo bookmark = bookmarks[i];
/* 1877 */               int j = bookmark.getMarkedOffset();
/* 1878 */               int k = textArea.getLineOfOffset(j);
/* 1879 */               if (k < curLine) {
/* 1880 */                 moveTo = bookmark;
/*      */                 break;
/*      */               } 
/*      */             } 
/* 1884 */             if (moveTo == null) {
/* 1885 */               moveTo = bookmarks[bookmarks.length - 1];
/*      */             }
/*      */           } 
/*      */           
/* 1889 */           int offs = moveTo.getMarkedOffset();
/* 1890 */           if (textArea instanceof RSyntaxTextArea) {
/* 1891 */             RSyntaxTextArea rsta = (RSyntaxTextArea)textArea;
/* 1892 */             if (rsta.isCodeFoldingEnabled()) {
/* 1893 */               rsta.getFoldManager()
/* 1894 */                 .ensureOffsetNotInClosedFold(offs);
/*      */             }
/*      */           } 
/* 1897 */           int line = textArea.getLineOfOffset(offs);
/* 1898 */           offs = textArea.getLineStartOffset(line);
/* 1899 */           textArea.setCaretPosition(offs);
/*      */         }
/* 1901 */         catch (BadLocationException ble) {
/* 1902 */           UIManager.getLookAndFeel()
/* 1903 */             .provideErrorFeedback(textArea);
/* 1904 */           ble.printStackTrace();
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1912 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class NextOccurrenceAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public NextOccurrenceAction(String name) {
/* 1924 */       super(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1929 */       String selectedText = textArea.getSelectedText();
/* 1930 */       if (selectedText == null || selectedText.length() == 0) {
/* 1931 */         selectedText = RTextArea.getSelectedOccurrenceText();
/* 1932 */         if (selectedText == null || selectedText.length() == 0) {
/* 1933 */           UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */           return;
/*      */         } 
/*      */       } 
/* 1937 */       SearchContext context = new SearchContext(selectedText);
/* 1938 */       if (!textArea.getMarkAllOnOccurrenceSearches()) {
/* 1939 */         context.setMarkAll(false);
/*      */       }
/* 1941 */       if (!SearchEngine.find(textArea, context).wasFound()) {
/* 1942 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */       }
/* 1944 */       RTextArea.setSelectedOccurrenceText(selectedText);
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 1949 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class NextVisualPositionAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private boolean select;
/*      */ 
/*      */     
/*      */     private int direction;
/*      */ 
/*      */     
/*      */     public NextVisualPositionAction(String nm, boolean select, int dir) {
/* 1965 */       super(nm);
/* 1966 */       this.select = select;
/* 1967 */       this.direction = dir;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 1973 */       Caret caret = textArea.getCaret();
/* 1974 */       int dot = caret.getDot();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1982 */       if (!this.select) {
/* 1983 */         int mark; switch (this.direction) {
/*      */           case 3:
/* 1985 */             mark = caret.getMark();
/* 1986 */             if (dot != mark) {
/* 1987 */               caret.setDot(Math.max(dot, mark));
/*      */               return;
/*      */             } 
/*      */             break;
/*      */           case 7:
/* 1992 */             mark = caret.getMark();
/* 1993 */             if (dot != mark) {
/* 1994 */               caret.setDot(Math.min(dot, mark));
/*      */               return;
/*      */             } 
/*      */             break;
/*      */         } 
/*      */ 
/*      */       
/*      */       } 
/* 2002 */       Position.Bias[] bias = new Position.Bias[1];
/* 2003 */       Point magicPosition = caret.getMagicCaretPosition();
/*      */ 
/*      */       
/*      */       try {
/* 2007 */         if (magicPosition == null && (this.direction == 1 || this.direction == 5)) {
/*      */ 
/*      */           
/* 2010 */           Rectangle r = textArea.modelToView(dot);
/* 2011 */           magicPosition = new Point(r.x, r.y);
/*      */         } 
/*      */         
/* 2014 */         NavigationFilter filter = textArea.getNavigationFilter();
/*      */         
/* 2016 */         if (filter != null) {
/* 2017 */           dot = filter.getNextVisualPositionFrom(textArea, dot, Position.Bias.Forward, this.direction, bias);
/*      */         }
/*      */         else {
/*      */           
/* 2021 */           dot = textArea.getUI().getNextVisualPositionFrom(textArea, dot, Position.Bias.Forward, this.direction, bias);
/*      */         } 
/*      */ 
/*      */         
/* 2025 */         if (this.select) {
/* 2026 */           caret.moveDot(dot);
/*      */         } else {
/*      */           
/* 2029 */           caret.setDot(dot);
/*      */         } 
/*      */         
/* 2032 */         if (magicPosition != null && (this.direction == 1 || this.direction == 5))
/*      */         {
/*      */           
/* 2035 */           caret.setMagicCaretPosition(magicPosition);
/*      */         }
/*      */       }
/* 2038 */       catch (BadLocationException ble) {
/* 2039 */         ble.printStackTrace();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2046 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class NextWordAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private boolean select;
/*      */ 
/*      */ 
/*      */     
/*      */     public NextWordAction(String name, boolean select) {
/* 2060 */       super(name);
/* 2061 */       this.select = select;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2067 */       int offs = textArea.getCaretPosition();
/* 2068 */       int oldOffs = offs;
/* 2069 */       Element curPara = Utilities.getParagraphElement(textArea, offs);
/*      */       
/*      */       try {
/* 2072 */         offs = getNextWord(textArea, offs);
/* 2073 */         if (offs >= curPara.getEndOffset() && oldOffs != curPara
/* 2074 */           .getEndOffset() - 1)
/*      */         {
/*      */           
/* 2077 */           offs = curPara.getEndOffset() - 1;
/*      */         }
/* 2079 */       } catch (BadLocationException ble) {
/* 2080 */         int end = textArea.getDocument().getLength();
/* 2081 */         if (offs != end) {
/* 2082 */           if (oldOffs != curPara.getEndOffset() - 1) {
/* 2083 */             offs = curPara.getEndOffset() - 1;
/*      */           } else {
/*      */             
/* 2086 */             offs = end;
/*      */           } 
/*      */         }
/*      */       } 
/*      */       
/* 2091 */       if (this.select) {
/* 2092 */         textArea.moveCaretPosition(offs);
/*      */       } else {
/*      */         
/* 2095 */         textArea.setCaretPosition(offs);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2102 */       return getName();
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getNextWord(RTextArea textArea, int offs) throws BadLocationException {
/* 2107 */       return Utilities.getNextWord(textArea, offs);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class PageAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private boolean select;
/*      */     
/*      */     private boolean left;
/*      */ 
/*      */     
/*      */     PageAction(String name, boolean left, boolean select) {
/* 2122 */       super(name);
/* 2123 */       this.select = select;
/* 2124 */       this.left = left;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2131 */       Rectangle visible = new Rectangle();
/* 2132 */       textArea.computeVisibleRect(visible);
/* 2133 */       if (this.left) {
/* 2134 */         visible.x = Math.max(0, visible.x - visible.width);
/*      */       } else {
/*      */         
/* 2137 */         visible.x += visible.width;
/*      */       } 
/*      */       
/* 2140 */       int selectedIndex = textArea.getCaretPosition();
/* 2141 */       if (selectedIndex != -1) {
/* 2142 */         if (this.left) {
/* 2143 */           selectedIndex = textArea.viewToModel(new Point(visible.x, visible.y));
/*      */         }
/*      */         else {
/*      */           
/* 2147 */           selectedIndex = textArea.viewToModel(new Point(visible.x + visible.width - 1, visible.y + visible.height - 1));
/*      */         } 
/*      */ 
/*      */         
/* 2151 */         Document doc = textArea.getDocument();
/* 2152 */         if (selectedIndex != 0 && selectedIndex > doc
/* 2153 */           .getLength() - 1) {
/* 2154 */           selectedIndex = doc.getLength() - 1;
/*      */         }
/* 2156 */         else if (selectedIndex < 0) {
/* 2157 */           selectedIndex = 0;
/*      */         } 
/* 2159 */         if (this.select) {
/* 2160 */           textArea.moveCaretPosition(selectedIndex);
/*      */         } else {
/*      */           
/* 2163 */           textArea.setCaretPosition(selectedIndex);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2171 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class PasteAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public PasteAction() {
/* 2183 */       super("paste-from-clipboard");
/*      */     }
/*      */ 
/*      */     
/*      */     public PasteAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/* 2188 */       super(name, icon, desc, mnemonic, accelerator);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2193 */       textArea.paste();
/* 2194 */       textArea.requestFocusInWindow();
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2199 */       return "paste-from-clipboard";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class PlaybackLastMacroAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public PlaybackLastMacroAction() {
/* 2211 */       super("RTA.PlaybackLastMacroAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public PlaybackLastMacroAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/* 2216 */       super(name, icon, desc, mnemonic, accelerator);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2221 */       textArea.playbackLastMacro();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isRecordable() {
/* 2226 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2231 */       return "RTA.PlaybackLastMacroAction";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class PreviousOccurrenceAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public PreviousOccurrenceAction(String name) {
/* 2243 */       super(name);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2248 */       String selectedText = textArea.getSelectedText();
/* 2249 */       if (selectedText == null || selectedText.length() == 0) {
/* 2250 */         selectedText = RTextArea.getSelectedOccurrenceText();
/* 2251 */         if (selectedText == null || selectedText.length() == 0) {
/* 2252 */           UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */           return;
/*      */         } 
/*      */       } 
/* 2256 */       SearchContext context = new SearchContext(selectedText);
/* 2257 */       if (!textArea.getMarkAllOnOccurrenceSearches()) {
/* 2258 */         context.setMarkAll(false);
/*      */       }
/* 2260 */       context.setSearchForward(false);
/* 2261 */       if (!SearchEngine.find(textArea, context).wasFound()) {
/* 2262 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */       }
/* 2264 */       RTextArea.setSelectedOccurrenceText(selectedText);
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2269 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class PreviousWordAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private boolean select;
/*      */ 
/*      */ 
/*      */     
/*      */     public PreviousWordAction(String name, boolean select) {
/* 2283 */       super(name);
/* 2284 */       this.select = select;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2290 */       int offs = textArea.getCaretPosition();
/* 2291 */       boolean failed = false;
/*      */       
/*      */       try {
/* 2294 */         Element curPara = Utilities.getParagraphElement(textArea, offs);
/* 2295 */         offs = getPreviousWord(textArea, offs);
/* 2296 */         if (offs < curPara.getStartOffset())
/*      */         {
/* 2298 */           offs = Utilities.getParagraphElement(textArea, offs).getEndOffset() - 1;
/*      */         }
/*      */       }
/* 2301 */       catch (BadLocationException bl) {
/* 2302 */         if (offs != 0) {
/* 2303 */           offs = 0;
/*      */         } else {
/*      */           
/* 2306 */           failed = true;
/*      */         } 
/*      */       } 
/*      */       
/* 2310 */       if (!failed) {
/* 2311 */         if (this.select) {
/* 2312 */           textArea.moveCaretPosition(offs);
/*      */         } else {
/*      */           
/* 2315 */           textArea.setCaretPosition(offs);
/*      */         } 
/*      */       } else {
/*      */         
/* 2319 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2326 */       return getName();
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getPreviousWord(RTextArea textArea, int offs) throws BadLocationException {
/* 2331 */       return Utilities.getPreviousWord(textArea, offs);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class RedoAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public RedoAction() {
/* 2343 */       super("RTA.RedoAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public RedoAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/* 2348 */       super(name, icon, desc, mnemonic, accelerator);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2353 */       if (textArea.isEnabled() && textArea.isEditable()) {
/* 2354 */         textArea.redoLastAction();
/* 2355 */         textArea.requestFocusInWindow();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2361 */       return "RTA.RedoAction";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ScrollAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private int delta;
/*      */ 
/*      */ 
/*      */     
/*      */     public ScrollAction(String name, int delta) {
/* 2376 */       super(name);
/* 2377 */       this.delta = delta;
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2382 */       Container parent = textArea.getParent();
/* 2383 */       if (parent instanceof JViewport) {
/* 2384 */         JViewport viewport = (JViewport)parent;
/* 2385 */         Point p = viewport.getViewPosition();
/* 2386 */         p.y += this.delta * textArea.getLineHeight();
/* 2387 */         if (p.y < 0) {
/* 2388 */           p.y = 0;
/*      */         } else {
/*      */           
/* 2391 */           Rectangle viewRect = viewport.getViewRect();
/* 2392 */           int visibleEnd = p.y + viewRect.height;
/* 2393 */           if (visibleEnd >= textArea.getHeight()) {
/* 2394 */             p.y = textArea.getHeight() - viewRect.height;
/*      */           }
/*      */         } 
/* 2397 */         viewport.setViewPosition(p);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2403 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SelectAllAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public SelectAllAction() {
/* 2415 */       super("select-all");
/*      */     }
/*      */ 
/*      */     
/*      */     public SelectAllAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/* 2420 */       super(name, icon, desc, mnemonic, accelerator);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2425 */       Document doc = textArea.getDocument();
/* 2426 */       textArea.setCaretPosition(0);
/* 2427 */       textArea.moveCaretPosition(doc.getLength());
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2432 */       return "select-all";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SelectLineAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private Action start;
/*      */     
/*      */     private Action end;
/*      */ 
/*      */     
/*      */     public SelectLineAction() {
/* 2447 */       super("select-line");
/* 2448 */       this.start = new RTextAreaEditorKit.BeginLineAction("pigdog", false);
/* 2449 */       this.end = new RTextAreaEditorKit.EndLineAction("pigdog", true);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2454 */       this.start.actionPerformed(e);
/* 2455 */       this.end.actionPerformed(e);
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2460 */       return "select-line";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SelectWordAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     protected Action start;
/*      */     
/*      */     protected Action end;
/*      */ 
/*      */     
/*      */     public SelectWordAction() {
/* 2475 */       super("select-word");
/* 2476 */       createActions();
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2481 */       this.start.actionPerformed(e);
/* 2482 */       this.end.actionPerformed(e);
/*      */     }
/*      */     
/*      */     protected void createActions() {
/* 2486 */       this.start = new RTextAreaEditorKit.BeginWordAction("pigdog", false);
/* 2487 */       this.end = new RTextAreaEditorKit.EndWordAction("pigdog", true);
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2492 */       return "select-word";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SetReadOnlyAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public SetReadOnlyAction() {
/* 2505 */       super("set-read-only");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2510 */       textArea.setEditable(false);
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2515 */       return "set-read-only";
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isRecordable() {
/* 2520 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SetWritableAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public SetWritableAction() {
/* 2532 */       super("set-writable");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2537 */       textArea.setEditable(true);
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2542 */       return "set-writable";
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isRecordable() {
/* 2547 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class TimeDateAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public TimeDateAction() {
/* 2560 */       super("RTA.TimeDateAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public TimeDateAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/* 2565 */       super(name, icon, desc, mnemonic, accelerator);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2570 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/* 2571 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */         return;
/*      */       } 
/* 2574 */       Date today = new Date();
/* 2575 */       DateFormat timeDateStamp = DateFormat.getDateTimeInstance();
/* 2576 */       String dateString = timeDateStamp.format(today);
/* 2577 */       textArea.replaceSelection(dateString);
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2582 */       return "RTA.TimeDateAction";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ToggleBookmarkAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public ToggleBookmarkAction() {
/* 2594 */       super("RTA.ToggleBookmarkAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2599 */       Gutter gutter = RSyntaxUtilities.getGutter(textArea);
/* 2600 */       if (gutter != null) {
/* 2601 */         int line = textArea.getCaretLineNumber();
/*      */         try {
/* 2603 */           gutter.toggleBookmark(line);
/* 2604 */         } catch (BadLocationException ble) {
/* 2605 */           UIManager.getLookAndFeel()
/* 2606 */             .provideErrorFeedback(textArea);
/* 2607 */           ble.printStackTrace();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2614 */       return "RTA.ToggleBookmarkAction";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ToggleTextModeAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public ToggleTextModeAction() {
/* 2626 */       super("RTA.ToggleTextModeAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2631 */       int textMode = textArea.getTextMode();
/* 2632 */       if (textMode == 0) {
/* 2633 */         textArea.setTextMode(1);
/*      */       } else {
/*      */         
/* 2636 */         textArea.setTextMode(0);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2642 */       return "RTA.ToggleTextModeAction";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class UndoAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public UndoAction() {
/* 2654 */       super("RTA.UndoAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public UndoAction(String name, Icon icon, String desc, Integer mnemonic, KeyStroke accelerator) {
/* 2659 */       super(name, icon, desc, mnemonic, accelerator);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2664 */       if (textArea.isEnabled() && textArea.isEditable()) {
/* 2665 */         textArea.undoLastAction();
/* 2666 */         textArea.requestFocusInWindow();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2672 */       return "RTA.UndoAction";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class UnselectAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public UnselectAction() {
/* 2684 */       super("RTA.UnselectAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2689 */       textArea.setCaretPosition(textArea.getCaretPosition());
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2694 */       return "RTA.UnselectAction";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class UpperSelectionCaseAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     public UpperSelectionCaseAction() {
/* 2706 */       super("RTA.UpperCaseAction");
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2711 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/* 2712 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*      */         return;
/*      */       } 
/* 2715 */       String selection = textArea.getSelectedText();
/* 2716 */       if (selection != null) {
/* 2717 */         textArea.replaceSelection(selection.toUpperCase());
/*      */       }
/* 2719 */       textArea.requestFocusInWindow();
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2724 */       return getName();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class VerticalPageAction
/*      */     extends RecordableTextAction
/*      */   {
/*      */     private boolean select;
/*      */ 
/*      */     
/*      */     private int direction;
/*      */ 
/*      */     
/*      */     public VerticalPageAction(String name, int direction, boolean select) {
/* 2740 */       super(name);
/* 2741 */       this.select = select;
/* 2742 */       this.direction = direction;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 2748 */       Rectangle visible = textArea.getVisibleRect();
/* 2749 */       Rectangle newVis = new Rectangle(visible);
/* 2750 */       int selectedIndex = textArea.getCaretPosition();
/* 2751 */       int scrollAmount = textArea.getScrollableBlockIncrement(visible, 1, this.direction);
/*      */       
/* 2753 */       int initialY = visible.y;
/* 2754 */       Caret caret = textArea.getCaret();
/* 2755 */       Point magicPosition = caret.getMagicCaretPosition();
/*      */ 
/*      */       
/* 2758 */       if (selectedIndex != -1) {
/*      */ 
/*      */         
/*      */         try {
/* 2762 */           Rectangle dotBounds = textArea.modelToView(selectedIndex);
/* 2763 */           int x = (magicPosition != null) ? magicPosition.x : dotBounds.x;
/*      */           
/* 2765 */           int h = dotBounds.height;
/*      */           
/* 2767 */           int yOffset = this.direction * ((int)Math.ceil(scrollAmount / h) - 1) * h;
/* 2768 */           newVis.y = constrainY(textArea, initialY + yOffset, yOffset, visible.height);
/*      */ 
/*      */           
/* 2771 */           if (visible.contains(dotBounds.x, dotBounds.y)) {
/*      */ 
/*      */             
/* 2774 */             newIndex = textArea.viewToModel(new Point(x, 
/* 2775 */                   constrainY(textArea, dotBounds.y + yOffset, 0, 0)));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/* 2781 */           else if (this.direction == -1) {
/* 2782 */             newIndex = textArea.viewToModel(new Point(x, newVis.y));
/*      */           }
/*      */           else {
/*      */             
/* 2786 */             newIndex = textArea.viewToModel(new Point(x, newVis.y + visible.height));
/*      */           } 
/*      */ 
/*      */           
/* 2790 */           int newIndex = constrainOffset(textArea, newIndex);
/* 2791 */           if (newIndex != selectedIndex) {
/*      */ 
/*      */ 
/*      */             
/* 2795 */             adjustScrollIfNecessary(textArea, newVis, initialY, newIndex);
/*      */             
/* 2797 */             if (this.select) {
/* 2798 */               textArea.moveCaretPosition(newIndex);
/*      */             } else {
/*      */               
/* 2801 */               textArea.setCaretPosition(newIndex);
/*      */             }
/*      */           
/*      */           } 
/* 2805 */         } catch (BadLocationException ble) {}
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 2810 */         int yOffset = this.direction * scrollAmount;
/* 2811 */         newVis.y = constrainY(textArea, initialY + yOffset, yOffset, visible.height);
/*      */       } 
/*      */       
/* 2814 */       if (magicPosition != null) {
/* 2815 */         caret.setMagicCaretPosition(magicPosition);
/*      */       }
/*      */       
/* 2818 */       textArea.scrollRectToVisible(newVis);
/*      */     }
/*      */     
/*      */     private int constrainY(JTextComponent textArea, int y, int vis, int screenHeight) {
/* 2822 */       if (y < 0) {
/* 2823 */         y = 0;
/*      */       }
/* 2825 */       else if (y + vis > textArea.getHeight()) {
/*      */         
/* 2827 */         y = Math.max(0, textArea.getHeight() - screenHeight);
/*      */       } 
/* 2829 */       return y;
/*      */     }
/*      */     
/*      */     private int constrainOffset(JTextComponent text, int offset) {
/* 2833 */       Document doc = text.getDocument();
/* 2834 */       if (offset != 0 && offset > doc.getLength()) {
/* 2835 */         offset = doc.getLength();
/*      */       }
/* 2837 */       if (offset < 0) {
/* 2838 */         offset = 0;
/*      */       }
/* 2840 */       return offset;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void adjustScrollIfNecessary(JTextComponent text, Rectangle visible, int initialY, int index) {
/*      */       try {
/* 2847 */         Rectangle dotBounds = text.modelToView(index);
/* 2848 */         if (dotBounds.y < visible.y || dotBounds.y > visible.y + visible.height || dotBounds.y + dotBounds.height > visible.y + visible.height) {
/*      */           int y;
/*      */ 
/*      */ 
/*      */           
/* 2853 */           if (dotBounds.y < visible.y) {
/* 2854 */             y = dotBounds.y;
/*      */           } else {
/*      */             
/* 2857 */             y = dotBounds.y + dotBounds.height - visible.height;
/*      */           } 
/* 2859 */           if ((this.direction == -1 && y < initialY) || (this.direction == 1 && y > initialY))
/*      */           {
/*      */             
/* 2862 */             visible.y = y;
/*      */           }
/*      */         } 
/* 2865 */       } catch (BadLocationException ble) {}
/*      */     }
/*      */ 
/*      */     
/*      */     public final String getMacroID() {
/* 2870 */       return getName();
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/RTextAreaEditorKit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */