/*      */ package org.fife.ui.rtextarea;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.ComponentOrientation;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.FocusEvent;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.print.PageFormat;
/*      */ import java.awt.print.Printable;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Reader;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.ResourceBundle;
/*      */ import javax.swing.Action;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.InputMap;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.KeyStroke;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.event.CaretEvent;
/*      */ import javax.swing.plaf.TextUI;
/*      */ import javax.swing.text.AbstractDocument;
/*      */ import javax.swing.text.BadLocationException;
/*      */ import javax.swing.text.Caret;
/*      */ import javax.swing.text.Document;
/*      */ import javax.swing.text.Element;
/*      */ import javax.swing.text.Segment;
/*      */ import javax.swing.undo.CannotRedoException;
/*      */ import javax.swing.undo.CannotUndoException;
/*      */ import org.fife.print.RPrintUtilities;
/*      */ import org.fife.ui.rsyntaxtextarea.DocumentRange;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RTextArea
/*      */   extends RTextAreaBase
/*      */   implements Printable
/*      */ {
/*      */   public static final int INSERT_MODE = 0;
/*      */   public static final int OVERWRITE_MODE = 1;
/*      */   public static final String MARK_ALL_COLOR_PROPERTY = "RTA.markAllColor";
/*      */   public static final String MARK_ALL_ON_OCCURRENCE_SEARCHES_PROPERTY = "RTA.markAllOnOccurrenceSearches";
/*      */   public static final String MARK_ALL_OCCURRENCES_CHANGED_PROPERTY = "RTA.markAllOccurrencesChanged";
/*      */   private static final int MIN_ACTION_CONSTANT = 0;
/*      */   public static final int COPY_ACTION = 0;
/*      */   public static final int CUT_ACTION = 1;
/*      */   public static final int DELETE_ACTION = 2;
/*      */   public static final int PASTE_ACTION = 3;
/*      */   public static final int REDO_ACTION = 4;
/*      */   public static final int SELECT_ALL_ACTION = 5;
/*      */   public static final int UNDO_ACTION = 6;
/*      */   private static final int MAX_ACTION_CONSTANT = 6;
/*  125 */   private static final Color DEFAULT_MARK_ALL_COLOR = new Color(16762880);
/*      */ 
/*      */   
/*      */   private int textMode;
/*      */ 
/*      */   
/*      */   private static boolean recordingMacro;
/*      */ 
/*      */   
/*      */   private static Macro currentMacro;
/*      */ 
/*      */   
/*      */   private JPopupMenu popupMenu;
/*      */ 
/*      */   
/*      */   private JMenuItem undoMenuItem;
/*      */ 
/*      */   
/*      */   private JMenuItem redoMenuItem;
/*      */ 
/*      */   
/*      */   private JMenuItem cutMenuItem;
/*      */ 
/*      */   
/*      */   private JMenuItem pasteMenuItem;
/*      */ 
/*      */   
/*      */   private JMenuItem deleteMenuItem;
/*      */ 
/*      */   
/*      */   private boolean popupMenuCreated;
/*      */ 
/*      */   
/*      */   private static String selectedOccurrenceText;
/*      */ 
/*      */   
/*      */   private ToolTipSupplier toolTipSupplier;
/*      */ 
/*      */   
/*      */   private static RecordableTextAction cutAction;
/*      */ 
/*      */   
/*      */   private static RecordableTextAction copyAction;
/*      */ 
/*      */   
/*      */   private static RecordableTextAction pasteAction;
/*      */   
/*      */   private static RecordableTextAction deleteAction;
/*      */   
/*      */   private static RecordableTextAction undoAction;
/*      */   
/*      */   private static RecordableTextAction redoAction;
/*      */   
/*      */   private static RecordableTextAction selectAllAction;
/*      */   
/*      */   private static IconGroup iconGroup;
/*      */   
/*      */   private transient RUndoManager undoManager;
/*      */   
/*      */   private transient LineHighlightManager lineHighlightManager;
/*      */   
/*      */   private SmartHighlightPainter markAllHighlightPainter;
/*      */   
/*      */   private boolean markAllOnOccurrenceSearches;
/*      */   
/*      */   private CaretStyle[] carets;
/*      */   
/*      */   private static final String MSG = "org.fife.ui.rtextarea.RTextArea";
/*      */   
/*      */   private static StringBuilder repTabsSB;
/*      */ 
/*      */   
/*      */   public RTextArea() {}
/*      */ 
/*      */   
/*      */   public RTextArea(AbstractDocument doc) {
/*  201 */     super(doc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RTextArea(String text) {
/*  211 */     super(text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RTextArea(int rows, int cols) {
/*  224 */     super(rows, cols);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RTextArea(String text, int rows, int cols) {
/*  238 */     super(text, rows, cols);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RTextArea(AbstractDocument doc, String text, int rows, int cols) {
/*  253 */     super(doc, text, rows, cols);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RTextArea(int textMode) {
/*  264 */     setTextMode(textMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static synchronized void addToCurrentMacro(String id, String actionCommand) {
/*  277 */     currentMacro.addMacroRecord(new Macro.MacroRecord(id, actionCommand));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object addLineHighlight(int line, Color color) throws BadLocationException {
/*  293 */     if (this.lineHighlightManager == null) {
/*  294 */       this.lineHighlightManager = new LineHighlightManager(this);
/*      */     }
/*  296 */     return this.lineHighlightManager.addLineHighlight(line, color);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beginAtomicEdit() {
/*  320 */     this.undoManager.beginInternalAtomicEdit();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void beginRecordingMacro() {
/*  334 */     if (isRecordingMacro()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  339 */     if (currentMacro != null) {
/*  340 */       currentMacro = null;
/*      */     }
/*  342 */     currentMacro = new Macro();
/*  343 */     recordingMacro = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canUndo() {
/*  354 */     return this.undoManager.canUndo();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canRedo() {
/*  365 */     return this.undoManager.canRedo();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void clearMarkAllHighlights() {
/*  377 */     ((RTextAreaHighlighter)getHighlighter()).clearMarkAllHighlights();
/*      */     
/*  379 */     repaint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configurePopupMenu(JPopupMenu popupMenu) {
/*  401 */     boolean canType = (isEditable() && isEnabled());
/*      */ 
/*      */ 
/*      */     
/*  405 */     if (this.undoMenuItem != null) {
/*  406 */       this.undoMenuItem.setEnabled((undoAction.isEnabled() && canType));
/*  407 */       this.redoMenuItem.setEnabled((redoAction.isEnabled() && canType));
/*  408 */       this.cutMenuItem.setEnabled((cutAction.isEnabled() && canType));
/*  409 */       this.pasteMenuItem.setEnabled((pasteAction.isEnabled() && canType));
/*  410 */       this.deleteMenuItem.setEnabled((deleteAction.isEnabled() && canType));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Document createDefaultModel() {
/*  425 */     return new RDocument();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RTextAreaBase.RTAMouseListener createMouseListener() {
/*  435 */     return new RTextAreaMutableCaretEvent(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JPopupMenu createPopupMenu() {
/*  449 */     JPopupMenu menu = new JPopupMenu();
/*  450 */     menu.add(this.undoMenuItem = createPopupMenuItem(undoAction));
/*  451 */     menu.add(this.redoMenuItem = createPopupMenuItem(redoAction));
/*  452 */     menu.addSeparator();
/*  453 */     menu.add(this.cutMenuItem = createPopupMenuItem(cutAction));
/*  454 */     menu.add(createPopupMenuItem(copyAction));
/*  455 */     menu.add(this.pasteMenuItem = createPopupMenuItem(pasteAction));
/*  456 */     menu.add(this.deleteMenuItem = createPopupMenuItem(deleteAction));
/*  457 */     menu.addSeparator();
/*  458 */     menu.add(createPopupMenuItem(selectAllAction));
/*  459 */     return menu;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void createPopupMenuActions() {
/*  473 */     int mod = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
/*  474 */     ResourceBundle msg = ResourceBundle.getBundle("org.fife.ui.rtextarea.RTextArea");
/*      */     
/*  476 */     cutAction = new RTextAreaEditorKit.CutAction();
/*  477 */     cutAction.setProperties(msg, "Action.Cut");
/*  478 */     cutAction.setAccelerator(KeyStroke.getKeyStroke(88, mod));
/*  479 */     copyAction = new RTextAreaEditorKit.CopyAction();
/*  480 */     copyAction.setProperties(msg, "Action.Copy");
/*  481 */     copyAction.setAccelerator(KeyStroke.getKeyStroke(67, mod));
/*  482 */     pasteAction = new RTextAreaEditorKit.PasteAction();
/*  483 */     pasteAction.setProperties(msg, "Action.Paste");
/*  484 */     pasteAction.setAccelerator(KeyStroke.getKeyStroke(86, mod));
/*  485 */     deleteAction = new RTextAreaEditorKit.DeleteNextCharAction();
/*  486 */     deleteAction.setProperties(msg, "Action.Delete");
/*  487 */     deleteAction.setAccelerator(KeyStroke.getKeyStroke(127, 0));
/*  488 */     undoAction = new RTextAreaEditorKit.UndoAction();
/*  489 */     undoAction.setProperties(msg, "Action.Undo");
/*  490 */     undoAction.setAccelerator(KeyStroke.getKeyStroke(90, mod));
/*  491 */     redoAction = new RTextAreaEditorKit.RedoAction();
/*  492 */     redoAction.setProperties(msg, "Action.Redo");
/*  493 */     redoAction.setAccelerator(KeyStroke.getKeyStroke(89, mod));
/*  494 */     selectAllAction = new RTextAreaEditorKit.SelectAllAction();
/*  495 */     selectAllAction.setProperties(msg, "Action.SelectAll");
/*  496 */     selectAllAction.setAccelerator(KeyStroke.getKeyStroke(65, mod));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JMenuItem createPopupMenuItem(Action a) {
/*  509 */     JMenuItem item = new JMenuItem(a)
/*      */       {
/*      */         public void setToolTipText(String text) {}
/*      */       };
/*      */ 
/*      */ 
/*      */     
/*  516 */     item.setAccelerator(null);
/*  517 */     return item;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RTextAreaUI createRTextAreaUI() {
/*  528 */     return new RTextAreaUI(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String createSpacer(int size) {
/*  539 */     StringBuilder sb = new StringBuilder();
/*  540 */     for (int i = 0; i < size; i++) {
/*  541 */       sb.append(' ');
/*      */     }
/*  543 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RUndoManager createUndoManager() {
/*  553 */     return new RUndoManager(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void discardAllEdits() {
/*  568 */     this.undoManager.discardAllEdits();
/*  569 */     getDocument().removeUndoableEditListener(this.undoManager);
/*  570 */     this.undoManager = createUndoManager();
/*  571 */     getDocument().addUndoableEditListener(this.undoManager);
/*  572 */     this.undoManager.updateActions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void endAtomicEdit() {
/*  582 */     this.undoManager.endInternalAtomicEdit();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void endRecordingMacro() {
/*  597 */     if (!isRecordingMacro()) {
/*      */       return;
/*      */     }
/*      */     
/*  601 */     recordingMacro = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fireCaretUpdate(CaretEvent e) {
/*  614 */     possiblyUpdateCurrentLineHighlightLocation();
/*      */ 
/*      */ 
/*      */     
/*  618 */     if (e != null && e.getDot() != e.getMark()) {
/*  619 */       cutAction.setEnabled(true);
/*  620 */       copyAction.setEnabled(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  627 */     else if (cutAction.isEnabled()) {
/*  628 */       cutAction.setEnabled(false);
/*  629 */       copyAction.setEnabled(false);
/*      */     } 
/*      */     
/*  632 */     super.fireCaretUpdate(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fixCtrlH() {
/*  642 */     InputMap inputMap = getInputMap();
/*  643 */     KeyStroke char010 = KeyStroke.getKeyStroke("typed \b");
/*  644 */     InputMap parent = inputMap;
/*  645 */     while (parent != null) {
/*  646 */       parent.remove(char010);
/*  647 */       parent = parent.getParent();
/*      */     } 
/*  649 */     if (inputMap != null) {
/*  650 */       KeyStroke backspace = KeyStroke.getKeyStroke("BACK_SPACE");
/*  651 */       inputMap.put(backspace, "delete-previous");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static RecordableTextAction getAction(int action) {
/*  673 */     if (action < 0 || action > 6) {
/*  674 */       return null;
/*      */     }
/*  676 */     switch (action) {
/*      */       case 0:
/*  678 */         return copyAction;
/*      */       case 1:
/*  680 */         return cutAction;
/*      */       case 2:
/*  682 */         return deleteAction;
/*      */       case 3:
/*  684 */         return pasteAction;
/*      */       case 4:
/*  686 */         return redoAction;
/*      */       case 5:
/*  688 */         return selectAllAction;
/*      */       case 6:
/*  690 */         return undoAction;
/*      */     } 
/*  692 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized Macro getCurrentMacro() {
/*  706 */     return currentMacro;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Color getDefaultMarkAllHighlightColor() {
/*  718 */     return DEFAULT_MARK_ALL_COLOR;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IconGroup getIconGroup() {
/*  729 */     return iconGroup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMarkAllOnOccurrenceSearches() {
/*  742 */     return this.markAllOnOccurrenceSearches;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   LineHighlightManager getLineHighlightManager() {
/*  752 */     return this.lineHighlightManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getMarkAllHighlightColor() {
/*  763 */     return (Color)this.markAllHighlightPainter.getPaint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxAscent() {
/*  778 */     return getFontMetrics(getFont()).getAscent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JPopupMenu getPopupMenu() {
/*  791 */     if (!this.popupMenuCreated) {
/*  792 */       this.popupMenu = createPopupMenu();
/*  793 */       if (this.popupMenu != null) {
/*      */         
/*  795 */         ComponentOrientation orientation = ComponentOrientation.getOrientation(Locale.getDefault());
/*  796 */         this.popupMenu.applyComponentOrientation(orientation);
/*      */       } 
/*  798 */       this.popupMenuCreated = true;
/*      */     } 
/*  800 */     return this.popupMenu;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getSelectedOccurrenceText() {
/*  811 */     return selectedOccurrenceText;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTextMode() {
/*  822 */     return this.textMode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ToolTipSupplier getToolTipSupplier() {
/*  834 */     return this.toolTipSupplier;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getToolTipText(MouseEvent e) {
/*  852 */     String tip = null;
/*  853 */     if (getToolTipSupplier() != null) {
/*  854 */       tip = getToolTipSupplier().getToolTipText(this, e);
/*      */     }
/*  856 */     return (tip != null) ? tip : getToolTipText();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleReplaceSelection(String content) {
/*  869 */     super.replaceSelection(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void init() {
/*  876 */     super.init();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  884 */     if (cutAction == null) {
/*  885 */       createPopupMenuActions();
/*      */     }
/*      */ 
/*      */     
/*  889 */     this.undoManager = createUndoManager();
/*  890 */     getDocument().addUndoableEditListener(this.undoManager);
/*      */ 
/*      */     
/*  893 */     Color markAllHighlightColor = getDefaultMarkAllHighlightColor();
/*  894 */     this.markAllHighlightPainter = new SmartHighlightPainter(markAllHighlightColor);
/*      */     
/*  896 */     setMarkAllHighlightColor(markAllHighlightColor);
/*  897 */     this.carets = new CaretStyle[2];
/*  898 */     setCaretStyle(0, CaretStyle.THICK_VERTICAL_LINE_STYLE);
/*  899 */     setCaretStyle(1, CaretStyle.BLOCK_STYLE);
/*  900 */     setDragEnabled(true);
/*      */     
/*  902 */     setTextMode(0);
/*  903 */     setMarkAllOnOccurrenceSearches(true);
/*      */ 
/*      */     
/*  906 */     fixCtrlH();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized boolean isRecordingMacro() {
/*  919 */     return recordingMacro;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void loadMacro(Macro macro) {
/*  931 */     currentMacro = macro;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void markAll(List<DocumentRange> ranges) {
/*  952 */     RTextAreaHighlighter h = (RTextAreaHighlighter)getHighlighter();
/*  953 */     if (h != null) {
/*      */ 
/*      */       
/*  956 */       if (ranges != null) {
/*  957 */         for (DocumentRange range : ranges) {
/*      */           try {
/*  959 */             h.addMarkAllHighlight(range
/*  960 */                 .getStartOffset(), range.getEndOffset(), this.markAllHighlightPainter);
/*      */           }
/*  962 */           catch (BadLocationException ble) {
/*  963 */             ble.printStackTrace();
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/*  968 */       repaint();
/*  969 */       firePropertyChange("RTA.markAllOccurrencesChanged", (Object)null, ranges);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void paste() {
/*  981 */     beginAtomicEdit();
/*      */     try {
/*  983 */       super.paste();
/*      */     } finally {
/*  985 */       endAtomicEdit();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void playbackLastMacro() {
/*  994 */     if (currentMacro != null) {
/*  995 */       List<Macro.MacroRecord> macroRecords = currentMacro.getMacroRecords();
/*  996 */       if (!macroRecords.isEmpty()) {
/*  997 */         Action[] actions = getActions();
/*  998 */         this.undoManager.beginInternalAtomicEdit();
/*      */         try {
/* 1000 */           for (Macro.MacroRecord record : macroRecords) {
/* 1001 */             for (Action action : actions) {
/* 1002 */               if (action instanceof RecordableTextAction && record.id
/* 1003 */                 .equals(((RecordableTextAction)action)
/* 1004 */                   .getMacroID())) {
/* 1005 */                 action.actionPerformed(new ActionEvent(this, 1001, record.actionCommand));
/*      */ 
/*      */ 
/*      */                 
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } finally {
/* 1014 */           this.undoManager.endInternalAtomicEdit();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int print(Graphics g, PageFormat pageFormat, int pageIndex) {
/* 1031 */     return RPrintUtilities.printDocumentWordWrap(g, this, getFont(), pageIndex, pageFormat, getTabSize());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void read(Reader in, Object desc) throws IOException {
/* 1043 */     RTextAreaEditorKit kit = (RTextAreaEditorKit)getUI().getEditorKit(this);
/* 1044 */     setText((String)null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1051 */     Document doc = getDocument();
/* 1052 */     setDocument(createDefaultModel());
/*      */     
/* 1054 */     if (desc != null) {
/* 1055 */       doc.putProperty("stream", desc);
/*      */     }
/*      */     
/*      */     try {
/* 1059 */       kit.read(in, doc, 0);
/* 1060 */     } catch (BadLocationException e) {
/* 1061 */       throw new IOException(e.getMessage());
/*      */     } 
/*      */     
/* 1064 */     setDocument(doc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream s) throws ClassNotFoundException, IOException {
/* 1078 */     s.defaultReadObject();
/*      */ 
/*      */ 
/*      */     
/* 1082 */     this.undoManager = createUndoManager();
/* 1083 */     getDocument().addUndoableEditListener(this.undoManager);
/*      */     
/* 1085 */     this.lineHighlightManager = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void redoLastAction() {
/*      */     try {
/* 1098 */       if (this.undoManager.canRedo()) {
/* 1099 */         this.undoManager.redo();
/*      */       }
/* 1101 */     } catch (CannotRedoException cre) {
/* 1102 */       cre.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAllLineHighlights() {
/* 1113 */     if (this.lineHighlightManager != null) {
/* 1114 */       this.lineHighlightManager.removeAllLineHighlights();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeLineHighlight(Object tag) {
/* 1127 */     if (this.lineHighlightManager != null) {
/* 1128 */       this.lineHighlightManager.removeLineHighlight(tag);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void replaceRange(String str, int start, int end) {
/* 1154 */     if (end < start) {
/* 1155 */       throw new IllegalArgumentException("end before start");
/*      */     }
/* 1157 */     Document doc = getDocument();
/* 1158 */     if (doc != null) {
/*      */       
/*      */       try {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1167 */         this.undoManager.beginInternalAtomicEdit();
/* 1168 */         ((AbstractDocument)doc).replace(start, end - start, str, null);
/*      */       }
/* 1170 */       catch (BadLocationException e) {
/* 1171 */         throw new IllegalArgumentException(e.getMessage());
/*      */       } finally {
/* 1173 */         this.undoManager.endInternalAtomicEdit();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void replaceSelection(String text) {
/* 1190 */     if (text == null) {
/* 1191 */       handleReplaceSelection(text);
/*      */       
/*      */       return;
/*      */     } 
/* 1195 */     if (getTabsEmulated()) {
/* 1196 */       int firstTab = text.indexOf('\t');
/* 1197 */       if (firstTab > -1) {
/* 1198 */         int docOffs = getSelectionStart();
/*      */         try {
/* 1200 */           text = replaceTabsWithSpaces(text, docOffs, firstTab);
/* 1201 */         } catch (BadLocationException ble) {
/* 1202 */           ble.printStackTrace();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1208 */     if (this.textMode == 1 && !"\n".equals(text)) {
/*      */       
/* 1210 */       Caret caret = getCaret();
/* 1211 */       int caretPos = caret.getDot();
/* 1212 */       Document doc = getDocument();
/* 1213 */       Element map = doc.getDefaultRootElement();
/* 1214 */       int curLine = map.getElementIndex(caretPos);
/* 1215 */       int lastLine = map.getElementCount() - 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1222 */         int curLineEnd = getLineEndOffset(curLine);
/* 1223 */         if (caretPos == caret.getMark() && caretPos != curLineEnd) {
/* 1224 */           if (curLine == lastLine) {
/* 1225 */             caretPos = Math.min(caretPos + text.length(), curLineEnd);
/*      */           } else {
/*      */             
/* 1228 */             caretPos = Math.min(caretPos + text.length(), curLineEnd - 1);
/*      */           } 
/* 1230 */           caret.moveDot(caretPos);
/*      */         }
/*      */       
/* 1233 */       } catch (BadLocationException ble) {
/* 1234 */         UIManager.getLookAndFeel().provideErrorFeedback(this);
/* 1235 */         ble.printStackTrace();
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1243 */     handleReplaceSelection(text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1249 */   private static Segment repTabsSeg = new Segment();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String replaceTabsWithSpaces(String text, int docOffs, int firstTab) throws BadLocationException {
/* 1270 */     int tabSize = getTabSize();
/*      */ 
/*      */     
/* 1273 */     Document doc = getDocument();
/* 1274 */     Element root = doc.getDefaultRootElement();
/* 1275 */     int lineIndex = root.getElementIndex(docOffs);
/* 1276 */     Element line = root.getElement(lineIndex);
/* 1277 */     int lineStart = line.getStartOffset();
/* 1278 */     int charCount = docOffs - lineStart;
/*      */ 
/*      */     
/* 1281 */     if (charCount > 0) {
/* 1282 */       doc.getText(lineStart, charCount, repTabsSeg);
/* 1283 */       charCount = 0;
/* 1284 */       for (int i = 0; i < repTabsSeg.count; i++) {
/* 1285 */         char ch = repTabsSeg.array[repTabsSeg.offset + i];
/* 1286 */         if (ch == '\t') {
/* 1287 */           charCount = 0;
/*      */         } else {
/*      */           
/* 1290 */           charCount = (charCount + 1) % tabSize;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1296 */     if (text.length() == 1) {
/* 1297 */       return createSpacer(tabSize - charCount);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1302 */     if (repTabsSB == null) {
/* 1303 */       repTabsSB = new StringBuilder();
/*      */     }
/* 1305 */     repTabsSB.setLength(0);
/* 1306 */     char[] array = text.toCharArray();
/* 1307 */     int lastPos = 0;
/* 1308 */     int offsInLine = charCount;
/* 1309 */     for (int pos = firstTab; pos < array.length; pos++) {
/* 1310 */       int thisTabSize; char ch = array[pos];
/* 1311 */       switch (ch) {
/*      */         case '\t':
/* 1313 */           if (pos > lastPos) {
/* 1314 */             repTabsSB.append(array, lastPos, pos - lastPos);
/*      */           }
/* 1316 */           thisTabSize = tabSize - offsInLine % tabSize;
/* 1317 */           repTabsSB.append(createSpacer(thisTabSize));
/* 1318 */           lastPos = pos + 1;
/* 1319 */           offsInLine = 0;
/*      */           break;
/*      */         case '\n':
/* 1322 */           offsInLine = 0;
/*      */           break;
/*      */         default:
/* 1325 */           offsInLine++;
/*      */           break;
/*      */       } 
/*      */     } 
/* 1329 */     if (lastPos < array.length) {
/* 1330 */       repTabsSB.append(array, lastPos, array.length - lastPos);
/*      */     }
/*      */     
/* 1333 */     return repTabsSB.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setActionProperties(int action, String name, char mnemonic, KeyStroke accelerator) {
/* 1349 */     setActionProperties(action, name, Integer.valueOf(mnemonic), accelerator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setActionProperties(int action, String name, Integer mnemonic, KeyStroke accelerator) {
/* 1364 */     Action tempAction = null;
/*      */     
/* 1366 */     switch (action) {
/*      */       case 1:
/* 1368 */         tempAction = cutAction;
/*      */         break;
/*      */       case 0:
/* 1371 */         tempAction = copyAction;
/*      */         break;
/*      */       case 3:
/* 1374 */         tempAction = pasteAction;
/*      */         break;
/*      */       case 2:
/* 1377 */         tempAction = deleteAction;
/*      */         break;
/*      */       case 5:
/* 1380 */         tempAction = selectAllAction;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*      */         return;
/*      */     } 
/*      */     
/* 1388 */     tempAction.putValue("Name", name);
/* 1389 */     tempAction.putValue("ShortDescription", name);
/* 1390 */     tempAction.putValue("AcceleratorKey", accelerator);
/* 1391 */     tempAction.putValue("MnemonicKey", mnemonic);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCaret(Caret caret) {
/* 1407 */     super.setCaret(caret);
/* 1408 */     if (this.carets != null && caret instanceof ConfigurableCaret)
/*      */     {
/* 1410 */       ((ConfigurableCaret)caret).setStyle(this.carets[getTextMode()]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCaretStyle(int mode, CaretStyle style) {
/* 1423 */     if (style == null) {
/* 1424 */       style = CaretStyle.THICK_VERTICAL_LINE_STYLE;
/*      */     }
/* 1426 */     this.carets[mode] = style;
/* 1427 */     if (mode == getTextMode() && getCaret() instanceof ConfigurableCaret)
/*      */     {
/* 1429 */       ((ConfigurableCaret)getCaret()).setStyle(style);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDocument(Document document) {
/* 1443 */     if (!(document instanceof RDocument)) {
/* 1444 */       throw new IllegalArgumentException("RTextArea requires instances of RDocument for its document");
/*      */     }
/*      */     
/* 1447 */     if (this.undoManager != null) {
/* 1448 */       Document old = getDocument();
/* 1449 */       if (old != null) {
/* 1450 */         old.removeUndoableEditListener(this.undoManager);
/*      */       }
/*      */     } 
/* 1453 */     super.setDocument(document);
/* 1454 */     if (this.undoManager != null) {
/* 1455 */       document.addUndoableEditListener(this.undoManager);
/* 1456 */       discardAllEdits();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void setIconGroup(IconGroup group) {
/* 1481 */     Icon icon = group.getIcon("cut");
/* 1482 */     cutAction.putValue("SmallIcon", icon);
/* 1483 */     icon = group.getIcon("copy");
/* 1484 */     copyAction.putValue("SmallIcon", icon);
/* 1485 */     icon = group.getIcon("paste");
/* 1486 */     pasteAction.putValue("SmallIcon", icon);
/* 1487 */     icon = group.getIcon("delete");
/* 1488 */     deleteAction.putValue("SmallIcon", icon);
/* 1489 */     icon = group.getIcon("undo");
/* 1490 */     undoAction.putValue("SmallIcon", icon);
/* 1491 */     icon = group.getIcon("redo");
/* 1492 */     redoAction.putValue("SmallIcon", icon);
/* 1493 */     icon = group.getIcon("selectall");
/* 1494 */     selectAllAction.putValue("SmallIcon", icon);
/* 1495 */     iconGroup = group;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMarkAllHighlightColor(Color color) {
/* 1507 */     Color old = (Color)this.markAllHighlightPainter.getPaint();
/* 1508 */     if (old != null && !old.equals(color)) {
/* 1509 */       this.markAllHighlightPainter.setPaint(color);
/* 1510 */       RTextAreaHighlighter h = (RTextAreaHighlighter)getHighlighter();
/* 1511 */       if (h.getMarkAllHighlightCount() > 0) {
/* 1512 */         repaint();
/*      */       }
/* 1514 */       firePropertyChange("RTA.markAllColor", old, color);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMarkAllOnOccurrenceSearches(boolean markAll) {
/* 1530 */     if (markAll != this.markAllOnOccurrenceSearches) {
/* 1531 */       this.markAllOnOccurrenceSearches = markAll;
/* 1532 */       firePropertyChange("RTA.markAllOnOccurrenceSearches", !markAll, markAll);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPopupMenu(JPopupMenu popupMenu) {
/* 1551 */     this.popupMenu = popupMenu;
/* 1552 */     this.popupMenuCreated = true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRoundedSelectionEdges(boolean rounded) {
/* 1558 */     if (getRoundedSelectionEdges() != rounded) {
/* 1559 */       this.markAllHighlightPainter.setRoundedEdges(rounded);
/* 1560 */       super.setRoundedSelectionEdges(rounded);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setSelectedOccurrenceText(String text) {
/* 1579 */     selectedOccurrenceText = text;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTextMode(int mode) {
/* 1594 */     if (mode != 0 && mode != 1) {
/* 1595 */       mode = 0;
/*      */     }
/*      */     
/* 1598 */     if (this.textMode != mode) {
/* 1599 */       Caret caret = getCaret();
/* 1600 */       if (caret instanceof ConfigurableCaret) {
/* 1601 */         ((ConfigurableCaret)caret).setStyle(this.carets[mode]);
/*      */       }
/* 1603 */       this.textMode = mode;
/*      */ 
/*      */       
/* 1606 */       caret.setVisible(false);
/* 1607 */       caret.setVisible(true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToolTipSupplier(ToolTipSupplier supplier) {
/* 1621 */     this.toolTipSupplier = supplier;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setUI(TextUI ui) {
/* 1639 */     if (this.popupMenu != null) {
/* 1640 */       SwingUtilities.updateComponentTreeUI(this.popupMenu);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1645 */     RTextAreaUI rtaui = (RTextAreaUI)getUI();
/* 1646 */     if (rtaui != null) {
/* 1647 */       rtaui.installDefaults();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void undoLastAction() {
/*      */     try {
/* 1661 */       if (this.undoManager.canUndo()) {
/* 1662 */         this.undoManager.undo();
/*      */       }
/*      */     }
/* 1665 */     catch (CannotUndoException cre) {
/* 1666 */       cre.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeObject(ObjectOutputStream s) throws IOException {
/* 1680 */     getDocument().removeUndoableEditListener(this.undoManager);
/* 1681 */     s.defaultWriteObject();
/* 1682 */     getDocument().addUndoableEditListener(this.undoManager);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected class RTextAreaMutableCaretEvent
/*      */     extends RTextAreaBase.RTAMouseListener
/*      */   {
/*      */     protected RTextAreaMutableCaretEvent(RTextArea textArea) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focusGained(FocusEvent e) {
/* 1701 */       Caret c = RTextArea.this.getCaret();
/* 1702 */       boolean enabled = (c.getDot() != c.getMark());
/* 1703 */       RTextArea.cutAction.setEnabled(enabled);
/* 1704 */       RTextArea.copyAction.setEnabled(enabled);
/* 1705 */       RTextArea.this.undoManager.updateActions();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focusLost(FocusEvent e) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mouseDragged(MouseEvent e) {
/* 1717 */       if ((e.getModifiers() & 0x10) != 0) {
/* 1718 */         Caret caret = RTextArea.this.getCaret();
/* 1719 */         this.dot = caret.getDot();
/* 1720 */         this.mark = caret.getMark();
/* 1721 */         RTextArea.this.fireCaretUpdate(this);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void mousePressed(MouseEvent e) {
/* 1727 */       if (e.isPopupTrigger()) {
/* 1728 */         showPopup(e);
/*      */       }
/* 1730 */       else if ((e.getModifiers() & 0x10) != 0) {
/* 1731 */         Caret caret = RTextArea.this.getCaret();
/* 1732 */         this.dot = caret.getDot();
/* 1733 */         this.mark = caret.getMark();
/* 1734 */         RTextArea.this.fireCaretUpdate(this);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void mouseReleased(MouseEvent e) {
/* 1740 */       if (e.isPopupTrigger()) {
/* 1741 */         showPopup(e);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void showPopup(MouseEvent e) {
/* 1752 */       JPopupMenu popupMenu = RTextArea.this.getPopupMenu();
/* 1753 */       if (popupMenu != null) {
/* 1754 */         RTextArea.this.configurePopupMenu(popupMenu);
/* 1755 */         popupMenu.show(e.getComponent(), e.getX(), e.getY());
/* 1756 */         e.consume();
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/RTextArea.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */