package org.fife.ui.rtextarea;

import java.awt.event.MouseEvent;

public interface ToolTipSupplier {
  String getToolTipText(RTextArea paramRTextArea, MouseEvent paramMouseEvent);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rtextarea/ToolTipSupplier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */