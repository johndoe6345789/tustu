/*     */ package org.fife.ui.rsyntaxtextarea.focusabletip;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.GraphicsDevice;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.SystemColor;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.basic.BasicEditorPaneUI;
/*     */ import javax.swing.text.html.HTMLDocument;
/*     */ import org.fife.ui.rsyntaxtextarea.HtmlUtil;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TipUtil
/*     */ {
/*     */   public static Rectangle getScreenBoundsForPoint(int x, int y) {
/*  54 */     GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*  55 */     GraphicsDevice[] devices = env.getScreenDevices();
/*  56 */     for (GraphicsDevice device : devices) {
/*  57 */       GraphicsConfiguration[] configs = device.getConfigurations();
/*  58 */       for (GraphicsConfiguration config : configs) {
/*  59 */         Rectangle gcBounds = config.getBounds();
/*  60 */         if (gcBounds.contains(x, y)) {
/*  61 */           return gcBounds;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  66 */     return env.getMaximumWindowBounds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color getToolTipBackground() {
/*  77 */     Color c = UIManager.getColor("ToolTip.background");
/*     */ 
/*     */     
/*  80 */     boolean isNimbus = isNimbusLookAndFeel();
/*  81 */     if (c == null || isNimbus) {
/*  82 */       c = UIManager.getColor("info");
/*  83 */       if (c == null || (isNimbus && isDerivedColor(c))) {
/*  84 */         c = SystemColor.info;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  90 */     if (c instanceof javax.swing.plaf.ColorUIResource) {
/*  91 */       c = new Color(c.getRGB());
/*     */     }
/*     */     
/*  94 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Border getToolTipBorder() {
/* 106 */     Border border = UIManager.getBorder("ToolTip.border");
/*     */     
/* 108 */     if (border == null || isNimbusLookAndFeel()) {
/* 109 */       border = UIManager.getBorder("nimbusBorder");
/* 110 */       if (border == null) {
/* 111 */         border = BorderFactory.createLineBorder(SystemColor.controlDkShadow);
/*     */       }
/*     */     } 
/*     */     
/* 115 */     return border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isDerivedColor(Color c) {
/* 129 */     return (c != null && c.getClass().getName().endsWith(".DerivedColor"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isNimbusLookAndFeel() {
/* 139 */     return UIManager.getLookAndFeel().getName().equals("Nimbus");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void tweakTipEditorPane(JEditorPane textArea) {
/* 153 */     boolean isNimbus = isNimbusLookAndFeel();
/* 154 */     if (isNimbus) {
/* 155 */       Color selBG = textArea.getSelectionColor();
/* 156 */       Color selFG = textArea.getSelectedTextColor();
/* 157 */       textArea.setUI(new BasicEditorPaneUI());
/* 158 */       textArea.setSelectedTextColor(selFG);
/* 159 */       textArea.setSelectionColor(selBG);
/*     */     } 
/*     */     
/* 162 */     textArea.setEditable(false);
/* 163 */     textArea.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
/*     */ 
/*     */     
/* 166 */     textArea.getCaret().setSelectionVisible(true);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     Color fg = UIManager.getColor("Label.foreground");
/* 172 */     if (fg == null || (isNimbus && isDerivedColor(fg))) {
/* 173 */       fg = SystemColor.textText;
/*     */     }
/* 175 */     textArea.setForeground(fg);
/*     */ 
/*     */     
/* 178 */     textArea.setBackground(getToolTipBackground());
/*     */ 
/*     */ 
/*     */     
/* 182 */     Font font = UIManager.getFont("Label.font");
/* 183 */     if (font == null) {
/* 184 */       font = new Font("SansSerif", 0, 12);
/*     */     }
/* 186 */     HTMLDocument doc = (HTMLDocument)textArea.getDocument();
/* 187 */     setFont(doc, font, fg);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     Color linkFG = RSyntaxUtilities.getHyperlinkForeground();
/* 193 */     doc.getStyleSheet().addRule("a { color: " + 
/* 194 */         HtmlUtil.getHexString(linkFG) + "; }");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setFont(HTMLDocument doc, Font font, Color fg) {
/* 209 */     doc.getStyleSheet().addRule("body { font-family: " + font
/* 210 */         .getFamily() + "; font-size: " + font
/* 211 */         .getSize() + "pt" + "; color: " + 
/* 212 */         HtmlUtil.getHexString(fg) + "; }");
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/focusabletip/TipUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */