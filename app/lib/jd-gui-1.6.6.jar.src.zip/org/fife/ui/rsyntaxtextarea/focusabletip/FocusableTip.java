/*     */ package org.fife.ui.rsyntaxtextarea.focusabletip;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.ComponentOrientation;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.net.URL;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.ToolTipManager;
/*     */ import javax.swing.event.CaretEvent;
/*     */ import javax.swing.event.CaretListener;
/*     */ import javax.swing.event.HyperlinkListener;
/*     */ import javax.swing.event.MouseInputAdapter;
/*     */ import org.fife.ui.rsyntaxtextarea.PopupWindowDecorator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FocusableTip
/*     */ {
/*     */   private JTextArea textArea;
/*     */   private TipWindow tipWindow;
/*     */   private URL imageBase;
/*     */   private TextAreaListener textAreaListener;
/*     */   private HyperlinkListener hyperlinkListener;
/*     */   private String lastText;
/*     */   private Dimension maxSize;
/*     */   private Rectangle tipVisibleBounds;
/*     */   private static final int X_MARGIN = 18;
/*     */   private static final int Y_MARGIN = 12;
/*  72 */   private static final ResourceBundle MSG = ResourceBundle.getBundle("org.fife.ui.rsyntaxtextarea.focusabletip.FocusableTip");
/*     */ 
/*     */ 
/*     */   
/*     */   public FocusableTip(JTextArea textArea, HyperlinkListener listener) {
/*  77 */     setTextArea(textArea);
/*  78 */     this.hyperlinkListener = listener;
/*  79 */     this.textAreaListener = new TextAreaListener();
/*  80 */     this.tipVisibleBounds = new Rectangle();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeTipVisibleBounds() {
/*  92 */     Rectangle r = this.tipWindow.getBounds();
/*  93 */     Point p = r.getLocation();
/*  94 */     SwingUtilities.convertPointFromScreen(p, this.textArea);
/*  95 */     r.setLocation(p);
/*  96 */     this.tipVisibleBounds.setBounds(r.x, r.y - 15, r.width, r.height + 30);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void createAndShowTipWindow(MouseEvent e, String text) {
/* 102 */     Window owner = SwingUtilities.getWindowAncestor(this.textArea);
/* 103 */     this.tipWindow = new TipWindow(owner, this, text);
/* 104 */     this.tipWindow.setHyperlinkListener(this.hyperlinkListener);
/*     */ 
/*     */     
/* 107 */     PopupWindowDecorator decorator = PopupWindowDecorator.get();
/* 108 */     if (decorator != null) {
/* 109 */       decorator.decorate(this.tipWindow);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     SwingUtilities.invokeLater(() -> {
/*     */           if (this.tipWindow == null) {
/*     */             return;
/*     */           }
/*     */           this.tipWindow.fixSize();
/*     */           ComponentOrientation o = this.textArea.getComponentOrientation();
/*     */           Point p = paramMouseEvent.getPoint();
/*     */           SwingUtilities.convertPointToScreen(p, this.textArea);
/*     */           Rectangle sb = TipUtil.getScreenBoundsForPoint(p.x, p.y);
/*     */           int y = p.y + 12;
/*     */           if (y + this.tipWindow.getHeight() >= sb.y + sb.height) {
/*     */             y = p.y - 12 - this.tipWindow.getHeight();
/*     */           }
/*     */           int x = p.x - 18;
/*     */           if (!o.isLeftToRight()) {
/*     */             x = p.x - this.tipWindow.getWidth() + 18;
/*     */           }
/*     */           if (x < sb.x) {
/*     */             x = sb.x;
/*     */           } else if (x + this.tipWindow.getWidth() > sb.x + sb.width) {
/*     */             x = sb.x + sb.width - this.tipWindow.getWidth();
/*     */           } 
/*     */           this.tipWindow.setLocation(x, y);
/*     */           this.tipWindow.setVisible(true);
/*     */           computeTipVisibleBounds();
/*     */           this.textAreaListener.install(this.textArea);
/*     */           this.lastText = paramString;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getImageBase() {
/* 180 */     return this.imageBase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getMaxSize() {
/* 192 */     return this.maxSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getString(String key) {
/* 203 */     return MSG.getString(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void possiblyDisposeOfTipWindow() {
/* 211 */     if (this.tipWindow != null) {
/* 212 */       this.tipWindow.dispose();
/* 213 */       this.tipWindow = null;
/* 214 */       this.textAreaListener.uninstall();
/* 215 */       this.tipVisibleBounds.setBounds(-1, -1, 0, 0);
/* 216 */       this.lastText = null;
/* 217 */       this.textArea.requestFocus();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void removeListeners() {
/* 224 */     this.textAreaListener.uninstall();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImageBase(URL url) {
/* 235 */     this.imageBase = url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxSize(Dimension maxSize) {
/* 247 */     this.maxSize = maxSize;
/*     */   }
/*     */ 
/*     */   
/*     */   private void setTextArea(JTextArea textArea) {
/* 252 */     this.textArea = textArea;
/*     */     
/* 254 */     ToolTipManager.sharedInstance().registerComponent(textArea);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void toolTipRequested(MouseEvent e, String text) {
/* 260 */     if (text == null || text.length() == 0) {
/* 261 */       possiblyDisposeOfTipWindow();
/* 262 */       this.lastText = text;
/*     */       
/*     */       return;
/*     */     } 
/* 266 */     if (this.lastText == null || text.length() != this.lastText.length() || 
/* 267 */       !text.equals(this.lastText)) {
/* 268 */       possiblyDisposeOfTipWindow();
/* 269 */       createAndShowTipWindow(e, text);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class TextAreaListener
/*     */     extends MouseInputAdapter
/*     */     implements CaretListener, ComponentListener, FocusListener, KeyListener
/*     */   {
/*     */     private TextAreaListener() {}
/*     */ 
/*     */     
/*     */     public void caretUpdate(CaretEvent e) {
/* 283 */       Object source = e.getSource();
/* 284 */       if (source == FocusableTip.this.textArea) {
/* 285 */         FocusableTip.this.possiblyDisposeOfTipWindow();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void componentHidden(ComponentEvent e) {
/* 291 */       handleComponentEvent(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public void componentMoved(ComponentEvent e) {
/* 296 */       handleComponentEvent(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public void componentResized(ComponentEvent e) {
/* 301 */       handleComponentEvent(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public void componentShown(ComponentEvent e) {
/* 306 */       handleComponentEvent(e);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void focusGained(FocusEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void focusLost(FocusEvent e) {
/* 319 */       Component c = e.getOppositeComponent();
/*     */ 
/*     */       
/* 322 */       boolean tipClicked = (c instanceof TipWindow || (c != null && SwingUtilities.getWindowAncestor(c) instanceof TipWindow));
/* 323 */       if (!tipClicked) {
/* 324 */         FocusableTip.this.possiblyDisposeOfTipWindow();
/*     */       }
/*     */     }
/*     */     
/*     */     private void handleComponentEvent(ComponentEvent e) {
/* 329 */       FocusableTip.this.possiblyDisposeOfTipWindow();
/*     */     }
/*     */     
/*     */     public void install(JTextArea textArea) {
/* 333 */       textArea.addCaretListener(this);
/* 334 */       textArea.addComponentListener(this);
/* 335 */       textArea.addFocusListener(this);
/* 336 */       textArea.addKeyListener(this);
/* 337 */       textArea.addMouseListener(this);
/* 338 */       textArea.addMouseMotionListener(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void keyPressed(KeyEvent e) {
/* 343 */       if (e.getKeyCode() == 27) {
/* 344 */         FocusableTip.this.possiblyDisposeOfTipWindow();
/*     */       }
/* 346 */       else if (e.getKeyCode() == 113 && 
/* 347 */         FocusableTip.this.tipWindow != null && !FocusableTip.this.tipWindow.getFocusableWindowState()) {
/* 348 */         FocusableTip.this.tipWindow.actionPerformed((ActionEvent)null);
/* 349 */         e.consume();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void keyReleased(KeyEvent e) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void keyTyped(KeyEvent e) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseExited(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseMoved(MouseEvent e) {
/* 369 */       if (FocusableTip.this.tipVisibleBounds == null || 
/* 370 */         !FocusableTip.this.tipVisibleBounds.contains(e.getPoint())) {
/* 371 */         FocusableTip.this.possiblyDisposeOfTipWindow();
/*     */       }
/*     */     }
/*     */     
/*     */     public void uninstall() {
/* 376 */       FocusableTip.this.textArea.removeCaretListener(this);
/* 377 */       FocusableTip.this.textArea.removeComponentListener(this);
/* 378 */       FocusableTip.this.textArea.removeFocusListener(this);
/* 379 */       FocusableTip.this.textArea.removeKeyListener(this);
/* 380 */       FocusableTip.this.textArea.removeMouseListener(this);
/* 381 */       FocusableTip.this.textArea.removeMouseMotionListener(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/focusabletip/FocusableTip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */