/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.text.Document;
/*     */ import org.fife.io.UnicodeReader;
/*     */ import org.fife.io.UnicodeWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextEditorPane
/*     */   extends RSyntaxTextArea
/*     */   implements DocumentListener
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final String FULL_PATH_PROPERTY = "TextEditorPane.fileFullPath";
/*     */   public static final String DIRTY_PROPERTY = "TextEditorPane.dirty";
/*     */   public static final String READ_ONLY_PROPERTY = "TextEditorPane.readOnly";
/*     */   public static final String ENCODING_PROPERTY = "TextEditorPane.encoding";
/*     */   private FileLocation loc;
/*     */   private String charSet;
/*     */   private boolean readOnly;
/*     */   private boolean dirty;
/*     */   private long lastSaveOrLoadTime;
/*     */   public static final long LAST_MODIFIED_UNKNOWN = 0L;
/*     */   private static final String DEFAULT_FILE_NAME = "Untitled.txt";
/*     */   
/*     */   public TextEditorPane() {
/* 136 */     this(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextEditorPane(int textMode) {
/* 147 */     this(textMode, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextEditorPane(int textMode, boolean wordWrapEnabled) {
/* 160 */     super(textMode);
/* 161 */     setLineWrap(wordWrapEnabled);
/*     */     try {
/* 163 */       init((FileLocation)null, (String)null);
/* 164 */     } catch (IOException ioe) {
/* 165 */       ioe.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextEditorPane(int textMode, boolean wordWrapEnabled, FileLocation loc) throws IOException {
/* 185 */     this(textMode, wordWrapEnabled, loc, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextEditorPane(int textMode, boolean wordWrapEnabled, FileLocation loc, String defaultEnc) throws IOException {
/* 208 */     super(textMode);
/* 209 */     setLineWrap(wordWrapEnabled);
/* 210 */     init(loc, defaultEnc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void changedUpdate(DocumentEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getDefaultEncoding() {
/* 234 */     return Charset.defaultCharset().name();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncoding() {
/* 245 */     return this.charSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileFullPath() {
/* 255 */     return (this.loc == null) ? null : this.loc.getFileFullPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileName() {
/* 265 */     return (this.loc == null) ? null : this.loc.getFileName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLastSaveOrLoadTime() {
/* 284 */     return this.lastSaveOrLoadTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getLineSeparator() {
/* 305 */     return getDocument().getProperty("__EndOfLine__");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(FileLocation loc, String defaultEnc) throws IOException {
/* 323 */     if (loc == null) {
/*     */ 
/*     */ 
/*     */       
/* 327 */       this.loc = FileLocation.create("Untitled.txt");
/* 328 */       this.charSet = (defaultEnc == null) ? getDefaultEncoding() : defaultEnc;
/*     */ 
/*     */ 
/*     */       
/* 332 */       setLineSeparator(System.getProperty("line.separator"));
/*     */     } else {
/*     */       
/* 335 */       load(loc, defaultEnc);
/*     */     } 
/*     */     
/* 338 */     if (this.loc.isLocalAndExists()) {
/* 339 */       File file = new File(this.loc.getFileFullPath());
/* 340 */       this.lastSaveOrLoadTime = file.lastModified();
/* 341 */       setReadOnly(!file.canWrite());
/*     */     } else {
/*     */       
/* 344 */       this.lastSaveOrLoadTime = 0L;
/* 345 */       setReadOnly(false);
/*     */     } 
/*     */     
/* 348 */     setDirty(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertUpdate(DocumentEvent e) {
/* 360 */     if (!this.dirty) {
/* 361 */       setDirty(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDirty() {
/* 373 */     return this.dirty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocal() {
/* 383 */     return this.loc.isLocal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocalAndExists() {
/* 393 */     return this.loc.isLocalAndExists();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isModifiedOutsideEditor() {
/* 411 */     return (this.loc.getActualLastModified() > getLastSaveOrLoadTime());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 422 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void load(FileLocation loc, String defaultEnc) throws IOException {
/* 443 */     if (loc.isLocal() && !loc.isLocalAndExists()) {
/* 444 */       this.charSet = (defaultEnc != null) ? defaultEnc : getDefaultEncoding();
/* 445 */       this.loc = loc;
/* 446 */       setText((String)null);
/* 447 */       discardAllEdits();
/* 448 */       setDirty(false);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 455 */     UnicodeReader ur = new UnicodeReader(loc.getInputStream(), defaultEnc);
/*     */ 
/*     */     
/* 458 */     Document doc = getDocument();
/* 459 */     doc.removeDocumentListener(this);
/* 460 */     try (BufferedReader r = new BufferedReader(ur)) {
/* 461 */       read(r, (Object)null);
/*     */     } finally {
/* 463 */       doc.addDocumentListener(this);
/*     */     } 
/*     */ 
/*     */     
/* 467 */     this.charSet = ur.getEncoding();
/* 468 */     String old = getFileFullPath();
/* 469 */     this.loc = loc;
/* 470 */     setDirty(false);
/* 471 */     setCaretPosition(0);
/* 472 */     discardAllEdits();
/* 473 */     firePropertyChange("TextEditorPane.fileFullPath", old, getFileFullPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reload() throws IOException {
/* 496 */     String oldEncoding = getEncoding();
/* 497 */     UnicodeReader ur = new UnicodeReader(this.loc.getInputStream(), oldEncoding);
/* 498 */     String encoding = ur.getEncoding();
/* 499 */     try (BufferedReader r = new BufferedReader(ur)) {
/* 500 */       read(r, (Object)null);
/*     */     } 
/* 502 */     setEncoding(encoding);
/* 503 */     setDirty(false);
/* 504 */     syncLastSaveOrLoadTimeToActualFile();
/* 505 */     discardAllEdits();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeUpdate(DocumentEvent e) {
/* 516 */     if (!this.dirty) {
/* 517 */       setDirty(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save() throws IOException {
/* 533 */     saveImpl(this.loc);
/* 534 */     setDirty(false);
/* 535 */     syncLastSaveOrLoadTimeToActualFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveAs(FileLocation loc) throws IOException {
/* 549 */     saveImpl(loc);
/*     */     
/* 551 */     String old = getFileFullPath();
/* 552 */     this.loc = loc;
/* 553 */     setDirty(false);
/* 554 */     this.lastSaveOrLoadTime = loc.getActualLastModified();
/* 555 */     firePropertyChange("TextEditorPane.fileFullPath", old, getFileFullPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void saveImpl(FileLocation loc) throws IOException {
/* 566 */     OutputStream out = loc.getOutputStream();
/* 567 */     try (BufferedWriter w = new BufferedWriter(new UnicodeWriter(out, 
/* 568 */             getEncoding()))) {
/* 569 */       write(w);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDirty(boolean dirty) {
/* 591 */     if (this.dirty != dirty) {
/* 592 */       this.dirty = dirty;
/* 593 */       firePropertyChange("TextEditorPane.dirty", !dirty, dirty);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDocument(Document doc) {
/* 605 */     Document old = getDocument();
/* 606 */     if (old != null) {
/* 607 */       old.removeDocumentListener(this);
/*     */     }
/* 609 */     super.setDocument(doc);
/* 610 */     doc.addDocumentListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncoding(String encoding) {
/* 626 */     if (encoding == null) {
/* 627 */       throw new NullPointerException("encoding cannot be null");
/*     */     }
/* 629 */     if (!Charset.isSupported(encoding)) {
/* 630 */       throw new UnsupportedCharsetException(encoding);
/*     */     }
/* 632 */     if (this.charSet == null || !this.charSet.equals(encoding)) {
/* 633 */       String oldEncoding = this.charSet;
/* 634 */       this.charSet = encoding;
/* 635 */       firePropertyChange("TextEditorPane.encoding", oldEncoding, this.charSet);
/* 636 */       setDirty(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineSeparator(String separator) {
/* 657 */     setLineSeparator(separator, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineSeparator(String separator, boolean setDirty) {
/* 679 */     if (separator == null) {
/* 680 */       throw new NullPointerException("terminator cannot be null");
/*     */     }
/* 682 */     if (!"\r\n".equals(separator) && !"\n".equals(separator) && 
/* 683 */       !"\r".equals(separator)) {
/* 684 */       throw new IllegalArgumentException("Invalid line terminator");
/*     */     }
/* 686 */     Document doc = getDocument();
/* 687 */     Object old = doc.getProperty("__EndOfLine__");
/*     */     
/* 689 */     if (!separator.equals(old)) {
/* 690 */       doc.putProperty("__EndOfLine__", separator);
/*     */       
/* 692 */       if (setDirty) {
/* 693 */         setDirty(true);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadOnly(boolean readOnly) {
/* 707 */     if (this.readOnly != readOnly) {
/* 708 */       this.readOnly = readOnly;
/* 709 */       firePropertyChange("TextEditorPane.readOnly", !readOnly, readOnly);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void syncLastSaveOrLoadTimeToActualFile() {
/* 727 */     if (this.loc.isLocalAndExists()) {
/* 728 */       this.lastSaveOrLoadTime = this.loc.getActualLastModified();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/*     */     try {
/* 735 */       TextEditorPane textArea = new TextEditorPane();
/* 736 */       textArea.load(FileLocation.create("d:/temp/test.txt"), "UTF-8");
/* 737 */       JPanel cp = new JPanel();
/* 738 */       cp.setPreferredSize(new Dimension(300, 300));
/* 739 */       cp.setLayout(new BorderLayout());
/* 740 */       cp.add(new JScrollPane(textArea));
/* 741 */       JFrame frame = new JFrame();
/* 742 */       frame.setContentPane(cp);
/* 743 */       frame.pack();
/* 744 */       frame.setDefaultCloseOperation(3);
/* 745 */       frame.setLocationByPlatform(true);
/* 746 */       frame.setVisible(true);
/* 747 */     } catch (Exception e) {
/* 748 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/TextEditorPane.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */