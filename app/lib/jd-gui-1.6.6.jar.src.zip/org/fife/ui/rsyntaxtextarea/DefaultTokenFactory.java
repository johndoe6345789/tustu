/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import javax.swing.text.Segment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultTokenFactory
/*     */   implements TokenFactory
/*     */ {
/*     */   private int size;
/*     */   private int increment;
/*     */   private TokenImpl[] tokenList;
/*     */   private int currentFreeToken;
/*     */   protected static final int DEFAULT_START_SIZE = 30;
/*     */   protected static final int DEFAULT_INCREMENT = 10;
/*     */   
/*     */   DefaultTokenFactory() {
/*  46 */     this(30, 10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultTokenFactory(int size, int increment) {
/*  59 */     this.size = size;
/*  60 */     this.increment = increment;
/*  61 */     this.currentFreeToken = 0;
/*     */ 
/*     */     
/*  64 */     this.tokenList = new TokenImpl[size];
/*  65 */     for (int i = 0; i < size; i++) {
/*  66 */       this.tokenList[i] = new TokenImpl();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void augmentTokenList() {
/*  77 */     TokenImpl[] temp = new TokenImpl[this.size + this.increment];
/*  78 */     System.arraycopy(this.tokenList, 0, temp, 0, this.size);
/*  79 */     this.size += this.increment;
/*  80 */     this.tokenList = temp;
/*  81 */     for (int i = 0; i < this.increment; i++) {
/*  82 */       this.tokenList[this.size - i - 1] = new TokenImpl();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenImpl createToken() {
/*  93 */     TokenImpl token = this.tokenList[this.currentFreeToken];
/*  94 */     token.text = null;
/*  95 */     token.setType(0);
/*  96 */     token.setOffset(-1);
/*  97 */     token.setNextToken(null);
/*  98 */     this.currentFreeToken++;
/*  99 */     if (this.currentFreeToken == this.size) {
/* 100 */       augmentTokenList();
/*     */     }
/* 102 */     return token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenImpl createToken(Segment line, int beg, int end, int startOffset, int type) {
/* 112 */     return createToken(line.array, beg, end, startOffset, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenImpl createToken(char[] line, int beg, int end, int startOffset, int type) {
/* 122 */     TokenImpl token = this.tokenList[this.currentFreeToken];
/* 123 */     token.set(line, beg, end, startOffset, type);
/* 124 */     this.currentFreeToken++;
/* 125 */     if (this.currentFreeToken == this.size) {
/* 126 */       augmentTokenList();
/*     */     }
/* 128 */     return token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetAllTokens() {
/* 139 */     this.currentFreeToken = 0;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/DefaultTokenFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */