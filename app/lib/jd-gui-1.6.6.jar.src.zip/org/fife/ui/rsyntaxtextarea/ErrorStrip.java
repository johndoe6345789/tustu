/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.ToolTipManager;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.event.CaretEvent;
/*     */ import javax.swing.event.CaretListener;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import org.fife.ui.rsyntaxtextarea.parser.Parser;
/*     */ import org.fife.ui.rsyntaxtextarea.parser.ParserNotice;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorStrip
/*     */   extends JPanel
/*     */ {
/*     */   private RSyntaxTextArea textArea;
/*     */   private transient Listener listener;
/*     */   private boolean showMarkedOccurrences;
/*     */   private boolean showMarkAll;
/*     */   private Map<Color, Color> brighterColors;
/*     */   private ParserNotice.Level levelThreshold;
/*     */   private boolean followCaret;
/*     */   private Color caretMarkerColor;
/*     */   private int caretLineY;
/*     */   private int lastLineY;
/*     */   private transient ErrorStripMarkerToolTipProvider markerToolTipProvider;
/*     */   private static final int PREFERRED_WIDTH = 14;
/* 145 */   private static final ResourceBundle MSG = ResourceBundle.getBundle("org.fife.ui.rsyntaxtextarea.ErrorStrip");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ErrorStrip(RSyntaxTextArea textArea) {
/* 154 */     this.textArea = textArea;
/* 155 */     this.listener = new Listener();
/* 156 */     ToolTipManager.sharedInstance().registerComponent(this);
/* 157 */     setLayout((LayoutManager)null);
/* 158 */     addMouseListener(this.listener);
/* 159 */     setShowMarkedOccurrences(true);
/* 160 */     setShowMarkAll(true);
/* 161 */     setLevelThreshold(ParserNotice.Level.WARNING);
/* 162 */     setFollowCaret(true);
/* 163 */     setCaretMarkerColor(getDefaultCaretMarkerColor());
/* 164 */     setMarkerToolTipProvider((ErrorStripMarkerToolTipProvider)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addNotify() {
/* 174 */     super.addNotify();
/* 175 */     this.textArea.addCaretListener(this.listener);
/* 176 */     this.textArea.addPropertyChangeListener("RSTA.parserNotices", this.listener);
/*     */     
/* 178 */     this.textArea.addPropertyChangeListener("RSTA.markOccurrences", this.listener);
/*     */     
/* 180 */     this.textArea.addPropertyChangeListener("RSTA.markedOccurrencesChanged", this.listener);
/*     */     
/* 182 */     this.textArea.addPropertyChangeListener("RTA.markAllOccurrencesChanged", this.listener);
/*     */     
/* 184 */     refreshMarkers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doLayout() {
/* 193 */     for (int i = 0; i < getComponentCount(); i++) {
/* 194 */       Marker m = (Marker)getComponent(i);
/* 195 */       m.updateLocation();
/*     */     } 
/* 197 */     this.listener.caretUpdate(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Color getBrighterColor(Color c) {
/* 208 */     if (this.brighterColors == null) {
/* 209 */       this.brighterColors = new HashMap<>(5);
/*     */     }
/* 211 */     Color brighter = this.brighterColors.get(c);
/* 212 */     if (brighter == null) {
/*     */ 
/*     */       
/* 215 */       int r = possiblyBrighter(c.getRed());
/* 216 */       int g = possiblyBrighter(c.getGreen());
/* 217 */       int b = possiblyBrighter(c.getBlue());
/* 218 */       brighter = new Color(r, g, b);
/* 219 */       this.brighterColors.put(c, brighter);
/*     */     } 
/* 221 */     return brighter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getCaretMarkerColor() {
/* 232 */     return this.caretMarkerColor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ColorUIResource getDefaultCaretMarkerColor() {
/* 245 */     if (RSyntaxUtilities.isLightForeground(getForeground())) {
/* 246 */       return new ColorUIResource(this.textArea.getCaretColor());
/*     */     }
/*     */     
/* 249 */     return new ColorUIResource(Color.black);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getFollowCaret() {
/* 259 */     return this.followCaret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 265 */     int height = (this.textArea.getPreferredScrollableViewportSize()).height;
/* 266 */     return new Dimension(14, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParserNotice.Level getLevelThreshold() {
/* 279 */     return this.levelThreshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getShowMarkAll() {
/* 290 */     return this.showMarkAll;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getShowMarkedOccurrences() {
/* 301 */     return this.showMarkedOccurrences;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToolTipText(MouseEvent e) {
/* 307 */     String text = null;
/* 308 */     int line = yToLine(e.getY());
/* 309 */     if (line > -1) {
/* 310 */       text = MSG.getString("Line");
/* 311 */       text = MessageFormat.format(text, new Object[] { Integer.valueOf(line + 1) });
/*     */     } 
/* 313 */     return text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int lineToY(int line) {
/* 326 */     int h = (this.textArea.getVisibleRect()).height;
/* 327 */     float lineCount = this.textArea.getLineCount();
/* 328 */     return (int)((line - 1) / (lineCount - 1.0F) * (h - 2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintComponent(Graphics g) {
/* 339 */     super.paintComponent(g);
/* 340 */     if (this.caretLineY > -1) {
/* 341 */       g.setColor(getCaretMarkerColor());
/* 342 */       g.fillRect(0, this.caretLineY, getWidth(), 2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int possiblyBrighter(int i) {
/* 354 */     if (i < 255) {
/* 355 */       i += (int)((255 - i) * 0.8F);
/*     */     }
/* 357 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void refreshMarkers() {
/* 366 */     removeAll();
/* 367 */     Map<Integer, Marker> markerMap = new HashMap<>();
/*     */     
/* 369 */     List<ParserNotice> notices = this.textArea.getParserNotices();
/* 370 */     for (ParserNotice notice : notices) {
/* 371 */       if (notice.getLevel().isEqualToOrWorseThan(this.levelThreshold) || notice instanceof org.fife.ui.rsyntaxtextarea.parser.TaskTagParser.TaskNotice) {
/*     */         
/* 373 */         Integer key = Integer.valueOf(notice.getLine());
/* 374 */         Marker m = markerMap.get(key);
/* 375 */         if (m == null) {
/* 376 */           m = new Marker(notice);
/* 377 */           m.addMouseListener(this.listener);
/* 378 */           markerMap.put(key, m);
/* 379 */           add(m);
/*     */           continue;
/*     */         } 
/* 382 */         m.addNotice(notice);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 387 */     if (getShowMarkedOccurrences() && this.textArea.getMarkOccurrences()) {
/* 388 */       List<DocumentRange> occurrences = this.textArea.getMarkedOccurrences();
/* 389 */       addMarkersForRanges(occurrences, markerMap, this.textArea.getMarkOccurrencesColor());
/*     */     } 
/*     */     
/* 392 */     if (getShowMarkAll()) {
/* 393 */       Color markAllColor = this.textArea.getMarkAllHighlightColor();
/* 394 */       List<DocumentRange> ranges = this.textArea.getMarkAllHighlightRanges();
/* 395 */       addMarkersForRanges(ranges, markerMap, markAllColor);
/*     */     } 
/*     */     
/* 398 */     revalidate();
/* 399 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addMarkersForRanges(List<DocumentRange> ranges, Map<Integer, Marker> markerMap, Color color) {
/* 413 */     for (DocumentRange range : ranges) {
/* 414 */       int line = 0;
/*     */       try {
/* 416 */         line = this.textArea.getLineOfOffset(range.getStartOffset());
/* 417 */       } catch (BadLocationException ble) {
/*     */         continue;
/*     */       } 
/* 420 */       ParserNotice notice = new MarkedOccurrenceNotice(range, color);
/* 421 */       Integer key = Integer.valueOf(line);
/* 422 */       Marker m = markerMap.get(key);
/* 423 */       if (m == null) {
/* 424 */         m = new Marker(notice);
/* 425 */         m.addMouseListener(this.listener);
/* 426 */         markerMap.put(key, m);
/* 427 */         add(m);
/*     */         continue;
/*     */       } 
/* 430 */       if (!m.containsMarkedOccurence()) {
/* 431 */         m.addNotice(notice);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeNotify() {
/* 443 */     super.removeNotify();
/* 444 */     this.textArea.removeCaretListener(this.listener);
/* 445 */     this.textArea.removePropertyChangeListener("RSTA.parserNotices", this.listener);
/*     */     
/* 447 */     this.textArea.removePropertyChangeListener("RSTA.markOccurrences", this.listener);
/*     */     
/* 449 */     this.textArea.removePropertyChangeListener("RSTA.markedOccurrencesChanged", this.listener);
/*     */     
/* 451 */     this.textArea.removePropertyChangeListener("RTA.markAllOccurrencesChanged", this.listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCaretMarkerColor(Color color) {
/* 463 */     if (color != null) {
/* 464 */       this.caretMarkerColor = color;
/* 465 */       this.listener.caretUpdate(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFollowCaret(boolean follow) {
/* 477 */     if (this.followCaret != follow) {
/* 478 */       if (this.followCaret) {
/* 479 */         repaint(0, this.caretLineY, getWidth(), 2);
/*     */       }
/* 481 */       this.caretLineY = -1;
/* 482 */       this.lastLineY = -1;
/* 483 */       this.followCaret = follow;
/* 484 */       this.listener.caretUpdate(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLevelThreshold(ParserNotice.Level level) {
/* 500 */     this.levelThreshold = level;
/* 501 */     if (isDisplayable()) {
/* 502 */       refreshMarkers();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarkerToolTipProvider(ErrorStripMarkerToolTipProvider provider) {
/* 516 */     this.markerToolTipProvider = (provider != null) ? provider : new DefaultErrorStripMarkerToolTipProvider();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShowMarkAll(boolean show) {
/* 528 */     if (show != this.showMarkAll) {
/* 529 */       this.showMarkAll = show;
/* 530 */       if (isDisplayable()) {
/* 531 */         refreshMarkers();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShowMarkedOccurrences(boolean show) {
/* 544 */     if (show != this.showMarkedOccurrences) {
/* 545 */       this.showMarkedOccurrences = show;
/* 546 */       if (isDisplayable()) {
/* 547 */         refreshMarkers();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateUI() {
/* 555 */     super.updateUI();
/*     */     
/* 557 */     if (this.caretMarkerColor instanceof ColorUIResource) {
/* 558 */       setCaretMarkerColor(getDefaultCaretMarkerColor());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int yToLine(int y) {
/* 571 */     int line = -1;
/* 572 */     int h = (this.textArea.getVisibleRect()).height;
/* 573 */     if (y < h) {
/* 574 */       float at = y / h;
/* 575 */       line = Math.round((this.textArea.getLineCount() - 1) * at);
/*     */     } 
/* 577 */     return line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DefaultErrorStripMarkerToolTipProvider
/*     */     implements ErrorStripMarkerToolTipProvider
/*     */   {
/*     */     private DefaultErrorStripMarkerToolTipProvider() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getToolTipText(List<ParserNotice> notices) {
/* 593 */       String text = null;
/*     */       
/* 595 */       if (notices.size() == 1) {
/* 596 */         text = ((ParserNotice)notices.get(0)).getMessage();
/*     */       } else {
/*     */         
/* 599 */         StringBuilder sb = new StringBuilder("<html>");
/* 600 */         sb.append(ErrorStrip.MSG.getString("MultipleMarkers"));
/* 601 */         sb.append("<br>");
/* 602 */         for (ParserNotice pn : notices) {
/* 603 */           sb.append("&nbsp;&nbsp;&nbsp;- ");
/* 604 */           sb.append(pn.getMessage());
/* 605 */           sb.append("<br>");
/*     */         } 
/* 607 */         text = sb.toString();
/*     */       } 
/*     */       
/* 610 */       return text;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface ErrorStripMarkerToolTipProvider
/*     */   {
/*     */     String getToolTipText(List<ParserNotice> param1List);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class Listener
/*     */     extends MouseAdapter
/*     */     implements PropertyChangeListener, CaretListener
/*     */   {
/* 644 */     private Rectangle visibleRect = new Rectangle();
/*     */ 
/*     */     
/*     */     public void caretUpdate(CaretEvent e) {
/* 648 */       if (ErrorStrip.this.getFollowCaret()) {
/* 649 */         int line = ErrorStrip.this.textArea.getCaretLineNumber();
/* 650 */         float percent = line / (ErrorStrip.this.textArea.getLineCount() - 1);
/* 651 */         ErrorStrip.this.textArea.computeVisibleRect(this.visibleRect);
/* 652 */         ErrorStrip.this.caretLineY = (int)(this.visibleRect.height * percent);
/* 653 */         if (ErrorStrip.this.caretLineY != ErrorStrip.this.lastLineY) {
/* 654 */           ErrorStrip.this.repaint(0, ErrorStrip.this.lastLineY, ErrorStrip.this.getWidth(), 2);
/* 655 */           ErrorStrip.this.repaint(0, ErrorStrip.this.caretLineY, ErrorStrip.this.getWidth(), 2);
/* 656 */           ErrorStrip.this.lastLineY = ErrorStrip.this.caretLineY;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseClicked(MouseEvent e) {
/* 664 */       Component source = (Component)e.getSource();
/* 665 */       if (source instanceof ErrorStrip.Marker) {
/* 666 */         ((ErrorStrip.Marker)source).mouseClicked(e);
/*     */         
/*     */         return;
/*     */       } 
/* 670 */       int line = ErrorStrip.this.yToLine(e.getY());
/* 671 */       if (line > -1) {
/*     */         try {
/* 673 */           int offs = ErrorStrip.this.textArea.getLineStartOffset(line);
/* 674 */           ErrorStrip.this.textArea.setCaretPosition(offs);
/* 675 */         } catch (BadLocationException ble) {
/* 676 */           UIManager.getLookAndFeel().provideErrorFeedback(ErrorStrip.this.textArea);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void propertyChange(PropertyChangeEvent e) {
/* 685 */       String propName = e.getPropertyName();
/*     */ 
/*     */       
/* 688 */       if ("RSTA.markOccurrences".equals(propName)) {
/* 689 */         if (ErrorStrip.this.getShowMarkedOccurrences()) {
/* 690 */           ErrorStrip.this.refreshMarkers();
/*     */ 
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 696 */       else if ("RSTA.parserNotices".equals(propName)) {
/* 697 */         ErrorStrip.this.refreshMarkers();
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 702 */       else if ("RSTA.markedOccurrencesChanged"
/* 703 */         .equals(propName)) {
/* 704 */         if (ErrorStrip.this.getShowMarkedOccurrences()) {
/* 705 */           ErrorStrip.this.refreshMarkers();
/*     */ 
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 711 */       else if ("RTA.markAllOccurrencesChanged"
/* 712 */         .equals(propName) && 
/* 713 */         ErrorStrip.this.getShowMarkAll()) {
/* 714 */         ErrorStrip.this.refreshMarkers();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private Listener() {}
/*     */   }
/*     */ 
/*     */   
/*     */   private class MarkedOccurrenceNotice
/*     */     implements ParserNotice
/*     */   {
/*     */     private DocumentRange range;
/*     */     
/*     */     private Color color;
/*     */ 
/*     */     
/*     */     MarkedOccurrenceNotice(DocumentRange range, Color color) {
/* 732 */       this.range = range;
/* 733 */       this.color = color;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(ParserNotice other) {
/* 738 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsPosition(int pos) {
/* 743 */       return (pos >= this.range.getStartOffset() && pos < this.range.getEndOffset());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 749 */       if (!(o instanceof ParserNotice)) {
/* 750 */         return false;
/*     */       }
/* 752 */       return (compareTo((ParserNotice)o) == 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public Color getColor() {
/* 757 */       return this.color;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean getKnowsOffsetAndLength() {
/* 765 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getLength() {
/* 770 */       return this.range.getEndOffset() - this.range.getStartOffset();
/*     */     }
/*     */ 
/*     */     
/*     */     public ParserNotice.Level getLevel() {
/* 775 */       return ParserNotice.Level.INFO;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getLine() {
/*     */       try {
/* 781 */         return ErrorStrip.this.textArea.getLineOfOffset(this.range.getStartOffset()) + 1;
/* 782 */       } catch (BadLocationException ble) {
/* 783 */         return 0;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String getMessage() {
/* 789 */       String text = null;
/*     */       try {
/* 791 */         String word = ErrorStrip.this.textArea.getText(this.range.getStartOffset(), 
/* 792 */             getLength());
/* 793 */         text = ErrorStrip.MSG.getString("OccurrenceOf");
/* 794 */         text = MessageFormat.format(text, new Object[] { word });
/* 795 */       } catch (BadLocationException ble) {
/* 796 */         UIManager.getLookAndFeel().provideErrorFeedback(ErrorStrip.this.textArea);
/*     */       } 
/* 798 */       return text;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOffset() {
/* 803 */       return this.range.getStartOffset();
/*     */     }
/*     */ 
/*     */     
/*     */     public Parser getParser() {
/* 808 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean getShowInEditor() {
/* 813 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getToolTipText() {
/* 818 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 823 */       return 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class Marker
/*     */     extends JComponent
/*     */   {
/*     */     private List<ParserNotice> notices;
/*     */ 
/*     */ 
/*     */     
/*     */     Marker(ParserNotice notice) {
/* 837 */       this.notices = new ArrayList<>(1);
/* 838 */       addNotice(notice);
/* 839 */       setCursor(Cursor.getPredefinedCursor(12));
/* 840 */       setSize(getPreferredSize());
/* 841 */       ToolTipManager.sharedInstance().registerComponent(this);
/*     */     }
/*     */     
/*     */     public void addNotice(ParserNotice notice) {
/* 845 */       this.notices.add(notice);
/*     */     }
/*     */     
/*     */     public boolean containsMarkedOccurence() {
/* 849 */       boolean result = false;
/* 850 */       for (ParserNotice notice : this.notices) {
/* 851 */         if (notice instanceof ErrorStrip.MarkedOccurrenceNotice) {
/* 852 */           result = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 856 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public Color getColor() {
/* 861 */       Color c = null;
/* 862 */       int lowestLevel = Integer.MAX_VALUE;
/* 863 */       for (ParserNotice notice : this.notices) {
/* 864 */         if (notice.getLevel().getNumericValue() < lowestLevel) {
/* 865 */           lowestLevel = notice.getLevel().getNumericValue();
/* 866 */           c = notice.getColor();
/*     */         } 
/*     */       } 
/* 869 */       return c;
/*     */     }
/*     */ 
/*     */     
/*     */     public Dimension getPreferredSize() {
/* 874 */       int w = 10;
/* 875 */       return new Dimension(w, 5);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getToolTipText() {
/* 880 */       return ErrorStrip.this.markerToolTipProvider.getToolTipText(
/* 881 */           Collections.unmodifiableList(this.notices));
/*     */     }
/*     */     
/*     */     protected void mouseClicked(MouseEvent e) {
/* 885 */       ParserNotice pn = this.notices.get(0);
/* 886 */       int offs = pn.getOffset();
/* 887 */       int len = pn.getLength();
/* 888 */       if (offs > -1 && len > -1) {
/* 889 */         DocumentRange range = new DocumentRange(offs, offs + len);
/* 890 */         RSyntaxUtilities.selectAndPossiblyCenter(ErrorStrip.this.textArea, range, true);
/*     */       } else {
/*     */         
/* 893 */         int line = pn.getLine();
/*     */         try {
/* 895 */           offs = ErrorStrip.this.textArea.getLineStartOffset(line);
/* 896 */           ErrorStrip.this.textArea.getFoldManager().ensureOffsetNotInClosedFold(offs);
/* 897 */           ErrorStrip.this.textArea.setCaretPosition(offs);
/* 898 */         } catch (BadLocationException ble) {
/* 899 */           UIManager.getLookAndFeel().provideErrorFeedback(ErrorStrip.this.textArea);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void paintComponent(Graphics g) {
/* 910 */       Color borderColor = getColor();
/* 911 */       if (borderColor == null) {
/* 912 */         borderColor = Color.DARK_GRAY;
/*     */       }
/* 914 */       Color fillColor = ErrorStrip.this.getBrighterColor(borderColor);
/*     */       
/* 916 */       int w = getWidth();
/* 917 */       int h = getHeight();
/*     */       
/* 919 */       g.setColor(fillColor);
/* 920 */       g.fillRect(0, 0, w, h);
/*     */       
/* 922 */       g.setColor(borderColor);
/* 923 */       g.drawRect(0, 0, w - 1, h - 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeNotify() {
/* 929 */       super.removeNotify();
/* 930 */       ToolTipManager.sharedInstance().unregisterComponent(this);
/* 931 */       removeMouseListener(ErrorStrip.this.listener);
/*     */     }
/*     */     
/*     */     public void updateLocation() {
/* 935 */       int line = ((ParserNotice)this.notices.get(0)).getLine();
/* 936 */       int y = ErrorStrip.this.lineToY(line);
/* 937 */       setLocation(2, y);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/ErrorStrip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */