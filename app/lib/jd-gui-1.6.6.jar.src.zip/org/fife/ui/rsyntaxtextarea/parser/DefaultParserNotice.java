/*     */ package org.fife.ui.rsyntaxtextarea.parser;
/*     */ 
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultParserNotice
/*     */   implements ParserNotice
/*     */ {
/*     */   private Parser parser;
/*     */   private ParserNotice.Level level;
/*     */   private int line;
/*     */   private int offset;
/*     */   private int length;
/*     */   private boolean showInEditor;
/*     */   private Color color;
/*     */   private String message;
/*     */   private String toolTipText;
/*  35 */   private static final Color[] DEFAULT_COLORS = new Color[] { new Color(255, 0, 128), new Color(244, 200, 45), Color.gray };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultParserNotice(Parser parser, String msg, int line) {
/*  50 */     this(parser, msg, line, -1, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultParserNotice(Parser parser, String message, int line, int offset, int length) {
/*  67 */     this.parser = parser;
/*  68 */     this.message = message;
/*  69 */     this.line = line;
/*  70 */     this.offset = offset;
/*  71 */     this.length = length;
/*  72 */     setLevel(ParserNotice.Level.ERROR);
/*  73 */     setShowInEditor(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ParserNotice other) {
/*  86 */     int diff = -1;
/*  87 */     if (other != null) {
/*  88 */       diff = this.level.getNumericValue() - other.getLevel().getNumericValue();
/*  89 */       if (diff == 0) {
/*  90 */         diff = this.line - other.getLine();
/*  91 */         if (diff == 0) {
/*  92 */           diff = this.message.compareTo(other.getMessage());
/*     */         }
/*     */       } 
/*     */     } 
/*  96 */     return diff;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsPosition(int pos) {
/* 105 */     return (this.offset <= pos && pos < this.offset + this.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 117 */     if (!(obj instanceof ParserNotice)) {
/* 118 */       return false;
/*     */     }
/* 120 */     return (compareTo((ParserNotice)obj) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getColor() {
/* 129 */     Color c = this.color;
/* 130 */     if (c == null) {
/* 131 */       c = DEFAULT_COLORS[getLevel().getNumericValue()];
/*     */     }
/* 133 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getKnowsOffsetAndLength() {
/* 142 */     return (this.offset >= 0 && this.length >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 151 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParserNotice.Level getLevel() {
/* 160 */     return this.level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLine() {
/* 169 */     return this.line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 178 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 187 */     return this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Parser getParser() {
/* 196 */     return this.parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getShowInEditor() {
/* 205 */     return this.showInEditor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToolTipText() {
/* 214 */     return (this.toolTipText != null) ? this.toolTipText : getMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 225 */     return this.line << 16 | this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColor(Color color) {
/* 236 */     this.color = color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLevel(ParserNotice.Level level) {
/* 247 */     if (level == null) {
/* 248 */       level = ParserNotice.Level.ERROR;
/*     */     }
/* 250 */     this.level = level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShowInEditor(boolean show) {
/* 262 */     this.showInEditor = show;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setToolTipText(String text) {
/* 275 */     this.toolTipText = text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 286 */     return "Line " + getLine() + ": " + getMessage();
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/parser/DefaultParserNotice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */