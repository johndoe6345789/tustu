/*     */ package org.fife.ui.rsyntaxtextarea.parser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultParseResult
/*     */   implements ParseResult
/*     */ {
/*     */   private Parser parser;
/*     */   private int firstLineParsed;
/*     */   private int lastLineParsed;
/*     */   private List<ParserNotice> notices;
/*     */   private long parseTime;
/*     */   private Exception error;
/*     */   
/*     */   public DefaultParseResult(Parser parser) {
/*  34 */     this.parser = parser;
/*  35 */     this.notices = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addNotice(ParserNotice notice) {
/*  46 */     this.notices.add(notice);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearNotices() {
/*  56 */     this.notices.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Exception getError() {
/*  65 */     return this.error;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstLineParsed() {
/*  74 */     return this.firstLineParsed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLastLineParsed() {
/*  83 */     return this.lastLineParsed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ParserNotice> getNotices() {
/*  92 */     return this.notices;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Parser getParser() {
/* 101 */     return this.parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getParseTime() {
/* 110 */     return this.parseTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setError(Exception e) {
/* 122 */     this.error = e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParsedLines(int first, int last) {
/* 135 */     this.firstLineParsed = first;
/* 136 */     this.lastLineParsed = last;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParseTime(long time) {
/* 147 */     this.parseTime = time;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/parser/DefaultParseResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */