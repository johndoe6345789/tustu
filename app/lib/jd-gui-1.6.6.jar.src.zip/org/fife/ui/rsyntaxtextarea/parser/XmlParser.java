/*     */ package org.fife.ui.rsyntaxtextarea.parser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import javax.xml.parsers.FactoryConfigurationError;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.fife.io.DocumentReader;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxDocument;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlParser
/*     */   extends AbstractParser
/*     */ {
/*     */   private SAXParserFactory spf;
/*     */   private DefaultParseResult result;
/*     */   private EntityResolver entityResolver;
/*     */   
/*     */   public XmlParser() {
/*  68 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlParser(EntityResolver resolver) {
/*  79 */     this.entityResolver = resolver;
/*  80 */     this.result = new DefaultParseResult(this);
/*     */     try {
/*  82 */       this.spf = SAXParserFactory.newInstance();
/*  83 */     } catch (FactoryConfigurationError fce) {
/*  84 */       fce.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidating() {
/*  96 */     return this.spf.isValidating();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseResult parse(RSyntaxDocument doc, String style) {
/* 106 */     this.result.clearNotices();
/* 107 */     Element root = doc.getDefaultRootElement();
/* 108 */     this.result.setParsedLines(0, root.getElementCount() - 1);
/*     */     
/* 110 */     if (this.spf == null || doc.getLength() == 0) {
/* 111 */       return this.result;
/*     */     }
/*     */     
/*     */     try {
/* 115 */       SAXParser sp = this.spf.newSAXParser();
/* 116 */       Handler handler = new Handler(doc);
/* 117 */       DocumentReader r = new DocumentReader(doc);
/* 118 */       InputSource input = new InputSource(r);
/* 119 */       sp.parse(input, handler);
/* 120 */       r.close();
/* 121 */     } catch (SAXParseException spe) {
/*     */     
/* 123 */     } catch (Exception e) {
/*     */       
/* 125 */       this.result.addNotice(new DefaultParserNotice(this, "Error parsing XML: " + e
/* 126 */             .getMessage(), 0, -1, -1));
/*     */     } 
/*     */     
/* 129 */     return this.result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValidating(boolean validating) {
/* 143 */     this.spf.setValidating(validating);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class Handler
/*     */     extends DefaultHandler
/*     */   {
/*     */     private Document doc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Handler(Document doc) {
/* 184 */       this.doc = doc;
/*     */     }
/*     */     
/*     */     private void doError(SAXParseException e, ParserNotice.Level level) {
/* 188 */       int line = e.getLineNumber() - 1;
/* 189 */       Element root = this.doc.getDefaultRootElement();
/* 190 */       Element elem = root.getElement(line);
/* 191 */       int offs = elem.getStartOffset();
/* 192 */       int len = elem.getEndOffset() - offs;
/* 193 */       if (line == root.getElementCount() - 1) {
/* 194 */         len++;
/*     */       }
/*     */       
/* 197 */       DefaultParserNotice pn = new DefaultParserNotice(XmlParser.this, e.getMessage(), line, offs, len);
/* 198 */       pn.setLevel(level);
/* 199 */       XmlParser.this.result.addNotice(pn);
/*     */     }
/*     */ 
/*     */     
/*     */     public void error(SAXParseException e) {
/* 204 */       doError(e, ParserNotice.Level.ERROR);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatalError(SAXParseException e) {
/* 209 */       doError(e, ParserNotice.Level.ERROR);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public InputSource resolveEntity(String publicId, String systemId) throws IOException, SAXException {
/* 215 */       if (XmlParser.this.entityResolver != null) {
/* 216 */         return XmlParser.this.entityResolver.resolveEntity(publicId, systemId);
/*     */       }
/* 218 */       return super.resolveEntity(publicId, systemId);
/*     */     }
/*     */ 
/*     */     
/*     */     public void warning(SAXParseException e) {
/* 223 */       doError(e, ParserNotice.Level.WARNING);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/parser/XmlParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */