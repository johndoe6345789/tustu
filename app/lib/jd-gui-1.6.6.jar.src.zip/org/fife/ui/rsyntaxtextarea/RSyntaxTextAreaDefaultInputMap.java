/*    */ package org.fife.ui.rsyntaxtextarea;
/*    */ 
/*    */ import javax.swing.KeyStroke;
/*    */ import org.fife.ui.rtextarea.RTADefaultInputMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RSyntaxTextAreaDefaultInputMap
/*    */   extends RTADefaultInputMap
/*    */ {
/*    */   public RSyntaxTextAreaDefaultInputMap() {
/* 39 */     int defaultMod = getDefaultModifier();
/* 40 */     int shift = 64;
/* 41 */     int defaultShift = defaultMod | shift;
/*    */     
/* 43 */     put(KeyStroke.getKeyStroke(9, shift), "RSTA.DecreaseIndentAction");
/* 44 */     put(KeyStroke.getKeyStroke('}'), "RSTA.CloseCurlyBraceAction");
/*    */     
/* 46 */     put(KeyStroke.getKeyStroke('/'), "RSTA.CloseMarkupTagAction");
/* 47 */     int os = RSyntaxUtilities.getOS();
/* 48 */     if (os == 1 || os == 2)
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 59 */       put(KeyStroke.getKeyStroke(47, defaultMod), "RSTA.ToggleCommentAction");
/*    */     }
/*    */     
/* 62 */     put(KeyStroke.getKeyStroke(91, defaultMod), "RSTA.GoToMatchingBracketAction");
/* 63 */     put(KeyStroke.getKeyStroke(109, defaultMod), "RSTA.CollapseFoldAction");
/* 64 */     put(KeyStroke.getKeyStroke(107, defaultMod), "RSTA.ExpandFoldAction");
/* 65 */     put(KeyStroke.getKeyStroke(111, defaultMod), "RSTA.CollapseAllFoldsAction");
/* 66 */     put(KeyStroke.getKeyStroke(106, defaultMod), "RSTA.ExpandAllFoldsAction");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 72 */     put(KeyStroke.getKeyStroke(32, defaultShift), "RSTA.TemplateAction");
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/RSyntaxTextAreaDefaultInputMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */