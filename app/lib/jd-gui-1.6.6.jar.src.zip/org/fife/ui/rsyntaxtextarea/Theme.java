/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.SystemColor;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.Field;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ import javax.swing.text.StyleContext;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.fife.io.UnicodeWriter;
/*     */ import org.fife.ui.rtextarea.Gutter;
/*     */ import org.fife.ui.rtextarea.RTextArea;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Theme
/*     */ {
/*     */   public Font baseFont;
/*     */   public Color bgColor;
/*     */   public Color caretColor;
/*     */   public boolean useSelctionFG;
/*     */   public Color selectionFG;
/*     */   public Color selectionBG;
/*     */   public boolean selectionRoundedEdges;
/*     */   public Color currentLineHighlight;
/*     */   public boolean fadeCurrentLineHighlight;
/*     */   public Color marginLineColor;
/*     */   public Color markAllHighlightColor;
/*     */   public Color markOccurrencesColor;
/*     */   public boolean markOccurrencesBorder;
/*     */   public Color matchedBracketFG;
/*     */   public Color matchedBracketBG;
/*     */   public boolean matchedBracketHighlightBoth;
/*     */   public boolean matchedBracketAnimate;
/*     */   public Color hyperlinkFG;
/*     */   public Color[] secondaryLanguages;
/*     */   public SyntaxScheme scheme;
/*     */   public Color gutterBackgroundColor;
/*     */   public Color gutterBorderColor;
/*     */   public Color activeLineRangeColor;
/*     */   public boolean iconRowHeaderInheritsGutterBG;
/*     */   public Color lineNumberColor;
/*     */   public String lineNumberFont;
/*     */   public int lineNumberFontSize;
/*     */   public Color foldIndicatorFG;
/*     */   public Color foldBG;
/*     */   public Color armedFoldBG;
/*     */   
/*     */   private Theme(Font baseFont) {
/* 119 */     this.baseFont = (baseFont != null) ? baseFont : RTextArea.getDefaultFont();
/* 120 */     this.secondaryLanguages = new Color[3];
/* 121 */     this.activeLineRangeColor = Gutter.DEFAULT_ACTIVE_LINE_RANGE_COLOR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Theme(RSyntaxTextArea textArea) {
/* 133 */     this.baseFont = textArea.getFont();
/* 134 */     this.bgColor = textArea.getBackground();
/* 135 */     this.caretColor = textArea.getCaretColor();
/* 136 */     this.useSelctionFG = textArea.getUseSelectedTextColor();
/* 137 */     this.selectionFG = textArea.getSelectedTextColor();
/* 138 */     this.selectionBG = textArea.getSelectionColor();
/* 139 */     this.selectionRoundedEdges = textArea.getRoundedSelectionEdges();
/* 140 */     this.currentLineHighlight = textArea.getCurrentLineHighlightColor();
/* 141 */     this.fadeCurrentLineHighlight = textArea.getFadeCurrentLineHighlight();
/* 142 */     this.marginLineColor = textArea.getMarginLineColor();
/* 143 */     this.markAllHighlightColor = textArea.getMarkAllHighlightColor();
/* 144 */     this.markOccurrencesColor = textArea.getMarkOccurrencesColor();
/* 145 */     this.markOccurrencesBorder = textArea.getPaintMarkOccurrencesBorder();
/* 146 */     this.matchedBracketBG = textArea.getMatchedBracketBGColor();
/* 147 */     this.matchedBracketFG = textArea.getMatchedBracketBorderColor();
/* 148 */     this.matchedBracketHighlightBoth = textArea.getPaintMatchedBracketPair();
/* 149 */     this.matchedBracketAnimate = textArea.getAnimateBracketMatching();
/* 150 */     this.hyperlinkFG = textArea.getHyperlinkForeground();
/*     */     
/* 152 */     int count = textArea.getSecondaryLanguageCount();
/* 153 */     this.secondaryLanguages = new Color[count];
/* 154 */     for (int i = 0; i < count; i++) {
/* 155 */       this.secondaryLanguages[i] = textArea.getSecondaryLanguageBackground(i + 1);
/*     */     }
/*     */     
/* 158 */     this.scheme = textArea.getSyntaxScheme();
/*     */     
/* 160 */     Gutter gutter = RSyntaxUtilities.getGutter(textArea);
/* 161 */     if (gutter != null) {
/* 162 */       this.gutterBackgroundColor = gutter.getBackground();
/* 163 */       this.gutterBorderColor = gutter.getBorderColor();
/* 164 */       this.activeLineRangeColor = gutter.getActiveLineRangeColor();
/* 165 */       this.iconRowHeaderInheritsGutterBG = gutter.getIconRowHeaderInheritsGutterBackground();
/* 166 */       this.lineNumberColor = gutter.getLineNumberColor();
/* 167 */       this.lineNumberFont = gutter.getLineNumberFont().getFamily();
/* 168 */       this.lineNumberFontSize = gutter.getLineNumberFont().getSize();
/* 169 */       this.foldIndicatorFG = gutter.getFoldIndicatorForeground();
/* 170 */       this.foldBG = gutter.getFoldBackground();
/* 171 */       this.armedFoldBG = gutter.getArmedFoldBackground();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply(RSyntaxTextArea textArea) {
/* 184 */     textArea.setFont(this.baseFont);
/* 185 */     textArea.setBackground(this.bgColor);
/* 186 */     textArea.setCaretColor(this.caretColor);
/* 187 */     textArea.setUseSelectedTextColor(this.useSelctionFG);
/* 188 */     textArea.setSelectedTextColor(this.selectionFG);
/* 189 */     textArea.setSelectionColor(this.selectionBG);
/* 190 */     textArea.setRoundedSelectionEdges(this.selectionRoundedEdges);
/* 191 */     textArea.setCurrentLineHighlightColor(this.currentLineHighlight);
/* 192 */     textArea.setFadeCurrentLineHighlight(this.fadeCurrentLineHighlight);
/* 193 */     textArea.setMarginLineColor(this.marginLineColor);
/* 194 */     textArea.setMarkAllHighlightColor(this.markAllHighlightColor);
/* 195 */     textArea.setMarkOccurrencesColor(this.markOccurrencesColor);
/* 196 */     textArea.setPaintMarkOccurrencesBorder(this.markOccurrencesBorder);
/* 197 */     textArea.setMatchedBracketBGColor(this.matchedBracketBG);
/* 198 */     textArea.setMatchedBracketBorderColor(this.matchedBracketFG);
/* 199 */     textArea.setPaintMatchedBracketPair(this.matchedBracketHighlightBoth);
/* 200 */     textArea.setAnimateBracketMatching(this.matchedBracketAnimate);
/* 201 */     textArea.setHyperlinkForeground(this.hyperlinkFG);
/*     */     
/* 203 */     int count = this.secondaryLanguages.length;
/* 204 */     for (int i = 0; i < count; i++) {
/* 205 */       textArea.setSecondaryLanguageBackground(i + 1, this.secondaryLanguages[i]);
/*     */     }
/*     */     
/* 208 */     textArea.setSyntaxScheme(this.scheme);
/*     */     
/* 210 */     Gutter gutter = RSyntaxUtilities.getGutter(textArea);
/* 211 */     if (gutter != null) {
/* 212 */       gutter.setBackground(this.gutterBackgroundColor);
/* 213 */       gutter.setBorderColor(this.gutterBorderColor);
/* 214 */       gutter.setActiveLineRangeColor(this.activeLineRangeColor);
/* 215 */       gutter.setIconRowHeaderInheritsGutterBackground(this.iconRowHeaderInheritsGutterBG);
/* 216 */       gutter.setLineNumberColor(this.lineNumberColor);
/*     */       
/* 218 */       String fontName = (this.lineNumberFont != null) ? this.lineNumberFont : this.baseFont.getFamily();
/*     */       
/* 220 */       int fontSize = (this.lineNumberFontSize > 0) ? this.lineNumberFontSize : this.baseFont.getSize();
/* 221 */       Font font = getFont(fontName, 0, fontSize);
/* 222 */       gutter.setLineNumberFont(font);
/* 223 */       gutter.setFoldIndicatorForeground(this.foldIndicatorFG);
/* 224 */       gutter.setFoldBackground(this.foldBG);
/* 225 */       gutter.setArmedFoldBackground(this.armedFoldBG);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String colorToString(Color c) {
/* 232 */     int color = c.getRGB() & 0xFFFFFF;
/* 233 */     StringBuilder stringBuilder = new StringBuilder(Integer.toHexString(color));
/* 234 */     while (stringBuilder.length() < 6) {
/* 235 */       stringBuilder.insert(0, "0");
/*     */     }
/* 237 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Color getDefaultBG() {
/* 249 */     Color c = UIManager.getColor("nimbusLightBackground");
/* 250 */     if (c == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 255 */       c = UIManager.getColor("TextArea.background");
/* 256 */       if (c == null) {
/* 257 */         c = new ColorUIResource(SystemColor.text);
/*     */       }
/*     */     } 
/* 260 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Color getDefaultSelectionBG() {
/* 272 */     Color c = UIManager.getColor("TextArea.selectionBackground");
/* 273 */     if (c == null) {
/* 274 */       c = UIManager.getColor("textHighlight");
/* 275 */       if (c == null) {
/* 276 */         c = UIManager.getColor("nimbusSelectionBackground");
/* 277 */         if (c == null) {
/* 278 */           c = new ColorUIResource(SystemColor.textHighlight);
/*     */         }
/*     */       } 
/*     */     } 
/* 282 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Color getDefaultSelectionFG() {
/* 294 */     Color c = UIManager.getColor("TextArea.selectionForeground");
/* 295 */     if (c == null) {
/* 296 */       c = UIManager.getColor("textHighlightText");
/* 297 */       if (c == null) {
/* 298 */         c = UIManager.getColor("nimbusSelectedText");
/* 299 */         if (c == null) {
/* 300 */           c = new ColorUIResource(SystemColor.textHighlightText);
/*     */         }
/*     */       } 
/*     */     } 
/* 304 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Font getFont(String family, int style, int size) {
/* 318 */     StyleContext sc = StyleContext.getDefaultStyleContext();
/* 319 */     return sc.getFont(family, style, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Theme load(InputStream in) throws IOException {
/* 333 */     return load(in, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Theme load(InputStream in, Font baseFont) throws IOException {
/* 351 */     Theme theme = new Theme(baseFont);
/*     */     
/* 353 */     try (BufferedInputStream bin = new BufferedInputStream(in)) {
/* 354 */       XmlHandler.load(theme, bin);
/*     */     } 
/*     */     
/* 357 */     return theme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(OutputStream out) throws IOException {
/* 370 */     try (BufferedOutputStream bout = new BufferedOutputStream(out)) {
/*     */ 
/*     */       
/* 373 */       DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/* 374 */       DOMImplementation impl = db.getDOMImplementation();
/*     */       
/* 376 */       Document doc = impl.createDocument(null, "RSyntaxTheme", null);
/* 377 */       Element root = doc.getDocumentElement();
/* 378 */       root.setAttribute("version", "1.0");
/*     */       
/* 380 */       Element elem = doc.createElement("baseFont");
/* 381 */       if (!this.baseFont.getFamily().equals(
/* 382 */           RSyntaxTextArea.getDefaultFont().getFamily())) {
/* 383 */         elem.setAttribute("family", this.baseFont.getFamily());
/*     */       }
/* 385 */       elem.setAttribute("size", Integer.toString(this.baseFont.getSize()));
/* 386 */       root.appendChild(elem);
/*     */       
/* 388 */       elem = doc.createElement("background");
/* 389 */       elem.setAttribute("color", colorToString(this.bgColor));
/* 390 */       root.appendChild(elem);
/*     */       
/* 392 */       elem = doc.createElement("caret");
/* 393 */       elem.setAttribute("color", colorToString(this.caretColor));
/* 394 */       root.appendChild(elem);
/*     */       
/* 396 */       elem = doc.createElement("selection");
/* 397 */       elem.setAttribute("useFG", Boolean.toString(this.useSelctionFG));
/* 398 */       elem.setAttribute("fg", colorToString(this.selectionFG));
/* 399 */       elem.setAttribute("bg", colorToString(this.selectionBG));
/* 400 */       elem.setAttribute("roundedEdges", Boolean.toString(this.selectionRoundedEdges));
/* 401 */       root.appendChild(elem);
/*     */       
/* 403 */       elem = doc.createElement("currentLineHighlight");
/* 404 */       elem.setAttribute("color", colorToString(this.currentLineHighlight));
/* 405 */       elem.setAttribute("fade", Boolean.toString(this.fadeCurrentLineHighlight));
/* 406 */       root.appendChild(elem);
/*     */       
/* 408 */       elem = doc.createElement("marginLine");
/* 409 */       elem.setAttribute("fg", colorToString(this.marginLineColor));
/* 410 */       root.appendChild(elem);
/*     */       
/* 412 */       elem = doc.createElement("markAllHighlight");
/* 413 */       elem.setAttribute("color", colorToString(this.markAllHighlightColor));
/* 414 */       root.appendChild(elem);
/*     */       
/* 416 */       elem = doc.createElement("markOccurrencesHighlight");
/* 417 */       elem.setAttribute("color", colorToString(this.markOccurrencesColor));
/* 418 */       elem.setAttribute("border", Boolean.toString(this.markOccurrencesBorder));
/* 419 */       root.appendChild(elem);
/*     */       
/* 421 */       elem = doc.createElement("matchedBracket");
/* 422 */       elem.setAttribute("fg", colorToString(this.matchedBracketFG));
/* 423 */       elem.setAttribute("bg", colorToString(this.matchedBracketBG));
/* 424 */       elem.setAttribute("highlightBoth", Boolean.toString(this.matchedBracketHighlightBoth));
/* 425 */       elem.setAttribute("animate", Boolean.toString(this.matchedBracketAnimate));
/* 426 */       root.appendChild(elem);
/*     */       
/* 428 */       elem = doc.createElement("hyperlinks");
/* 429 */       elem.setAttribute("fg", colorToString(this.hyperlinkFG));
/* 430 */       root.appendChild(elem);
/*     */       
/* 432 */       elem = doc.createElement("secondaryLanguages");
/* 433 */       for (int i = 0; i < this.secondaryLanguages.length; i++) {
/* 434 */         Color color = this.secondaryLanguages[i];
/* 435 */         Element elem2 = doc.createElement("language");
/* 436 */         elem2.setAttribute("index", Integer.toString(i + 1));
/* 437 */         elem2.setAttribute("bg", (color == null) ? "" : colorToString(color));
/* 438 */         elem.appendChild(elem2);
/*     */       } 
/* 440 */       root.appendChild(elem);
/*     */       
/* 442 */       elem = doc.createElement("gutterBackground");
/* 443 */       elem.setAttribute("color", colorToString(this.gutterBackgroundColor));
/* 444 */       root.appendChild(elem);
/*     */       
/* 446 */       elem = doc.createElement("gutterBorder");
/* 447 */       elem.setAttribute("color", colorToString(this.gutterBorderColor));
/* 448 */       root.appendChild(elem);
/*     */       
/* 450 */       elem = doc.createElement("lineNumbers");
/* 451 */       elem.setAttribute("fg", colorToString(this.lineNumberColor));
/* 452 */       if (this.lineNumberFont != null) {
/* 453 */         elem.setAttribute("fontFamily", this.lineNumberFont);
/*     */       }
/* 455 */       if (this.lineNumberFontSize > 0) {
/* 456 */         elem.setAttribute("fontSize", 
/* 457 */             Integer.toString(this.lineNumberFontSize));
/*     */       }
/* 459 */       root.appendChild(elem);
/*     */       
/* 461 */       elem = doc.createElement("foldIndicator");
/* 462 */       elem.setAttribute("fg", colorToString(this.foldIndicatorFG));
/* 463 */       elem.setAttribute("iconBg", colorToString(this.foldBG));
/* 464 */       elem.setAttribute("iconArmedBg", colorToString(this.armedFoldBG));
/* 465 */       root.appendChild(elem);
/*     */       
/* 467 */       elem = doc.createElement("iconRowHeader");
/* 468 */       elem.setAttribute("activeLineRange", colorToString(this.activeLineRangeColor));
/* 469 */       elem.setAttribute("inheritsGutterBG", Boolean.toString(this.iconRowHeaderInheritsGutterBG));
/* 470 */       root.appendChild(elem);
/*     */       
/* 472 */       elem = doc.createElement("tokenStyles");
/* 473 */       Field[] fields = TokenTypes.class.getFields();
/* 474 */       for (Field field : fields) {
/* 475 */         int value = field.getInt(null);
/* 476 */         if (value != 39) {
/* 477 */           Style style = this.scheme.getStyle(value);
/* 478 */           if (style != null) {
/* 479 */             Element elem2 = doc.createElement("style");
/* 480 */             elem2.setAttribute("token", field.getName());
/* 481 */             Color fg = style.foreground;
/* 482 */             if (fg != null) {
/* 483 */               elem2.setAttribute("fg", colorToString(fg));
/*     */             }
/* 485 */             Color bg = style.background;
/* 486 */             if (bg != null) {
/* 487 */               elem2.setAttribute("bg", colorToString(bg));
/*     */             }
/* 489 */             Font font = style.font;
/* 490 */             if (font != null) {
/* 491 */               if (!font.getFamily().equals(this.baseFont
/* 492 */                   .getFamily())) {
/* 493 */                 elem2.setAttribute("fontFamily", font.getFamily());
/*     */               }
/* 495 */               if (font.getSize() != this.baseFont.getSize()) {
/* 496 */                 elem2.setAttribute("fontSize", Integer.toString(font.getSize()));
/*     */               }
/* 498 */               if (font.isBold()) {
/* 499 */                 elem2.setAttribute("bold", "true");
/*     */               }
/* 501 */               if (font.isItalic()) {
/* 502 */                 elem2.setAttribute("italic", "true");
/*     */               }
/*     */             } 
/* 505 */             if (style.underline) {
/* 506 */               elem2.setAttribute("underline", "true");
/*     */             }
/* 508 */             elem.appendChild(elem2);
/*     */           } 
/*     */         } 
/*     */       } 
/* 512 */       root.appendChild(elem);
/*     */       
/* 514 */       DOMSource source = new DOMSource(doc);
/*     */ 
/*     */       
/* 517 */       StreamResult result = new StreamResult(new PrintWriter(new UnicodeWriter(bout, "UTF-8")));
/*     */       
/* 519 */       TransformerFactory transFac = TransformerFactory.newInstance();
/* 520 */       Transformer transformer = transFac.newTransformer();
/* 521 */       transformer.setOutputProperty("indent", "yes");
/* 522 */       transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
/* 523 */       transformer.setOutputProperty("encoding", "UTF-8");
/* 524 */       transformer.setOutputProperty("doctype-system", "theme.dtd");
/* 525 */       transformer.transform(source, result);
/*     */     }
/* 527 */     catch (RuntimeException re) {
/* 528 */       throw re;
/* 529 */     } catch (Exception e) {
/* 530 */       throw new IOException("Error generating XML: " + e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Color stringToColor(String s) {
/* 550 */     return stringToColor(s, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Color stringToColor(String s, Color defaultVal) {
/* 570 */     if (s == null || "default".equalsIgnoreCase(s)) {
/* 571 */       return defaultVal;
/*     */     }
/* 573 */     if (s.length() == 6 || s.length() == 7) {
/* 574 */       if (s.charAt(0) == '$') {
/* 575 */         s = s.substring(1);
/*     */       }
/* 577 */       return new Color(Integer.parseInt(s, 16));
/*     */     } 
/* 579 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class XmlHandler
/*     */     extends DefaultHandler
/*     */   {
/*     */     private Theme theme;
/*     */ 
/*     */ 
/*     */     
/*     */     public void error(SAXParseException e) throws SAXException {
/* 592 */       throw e;
/*     */     }
/*     */ 
/*     */     
/*     */     public void fatalError(SAXParseException e) throws SAXException {
/* 597 */       throw e;
/*     */     }
/*     */     
/*     */     public static void load(Theme theme, InputStream in) throws IOException {
/* 601 */       SAXParserFactory spf = SAXParserFactory.newInstance();
/* 602 */       spf.setValidating(true);
/*     */       try {
/* 604 */         SAXParser parser = spf.newSAXParser();
/* 605 */         XMLReader reader = parser.getXMLReader();
/* 606 */         XmlHandler handler = new XmlHandler();
/* 607 */         handler.theme = theme;
/* 608 */         reader.setEntityResolver(handler);
/* 609 */         reader.setContentHandler(handler);
/* 610 */         reader.setDTDHandler(handler);
/* 611 */         reader.setErrorHandler(handler);
/* 612 */         InputSource is = new InputSource(in);
/* 613 */         is.setEncoding("UTF-8");
/* 614 */         reader.parse(is);
/* 615 */       } catch (Exception se) {
/* 616 */         throw new IOException(se.toString());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private static int parseInt(Attributes attrs, String attr, int def) {
/* 622 */       int value = def;
/* 623 */       String temp = attrs.getValue(attr);
/* 624 */       if (temp != null) {
/*     */         try {
/* 626 */           value = Integer.parseInt(temp);
/* 627 */         } catch (NumberFormatException nfe) {
/* 628 */           nfe.printStackTrace();
/*     */         } 
/*     */       }
/* 631 */       return value;
/*     */     }
/*     */ 
/*     */     
/*     */     public InputSource resolveEntity(String publicID, String systemID) {
/* 636 */       return new InputSource(getClass()
/* 637 */           .getResourceAsStream("themes/theme.dtd"));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void startElement(String uri, String localName, String qName, Attributes attrs) {
/* 644 */       if ("background".equals(qName)) {
/*     */         
/* 646 */         String color = attrs.getValue("color");
/* 647 */         if (color != null) {
/* 648 */           this.theme.bgColor = Theme.stringToColor(color, Theme.getDefaultBG());
/* 649 */           this.theme.gutterBackgroundColor = this.theme.bgColor;
/*     */         } else {
/*     */           
/* 652 */           String img = attrs.getValue("image");
/* 653 */           if (img != null) {
/* 654 */             throw new IllegalArgumentException("Not yet implemented");
/*     */           
/*     */           }
/*     */         }
/*     */       
/*     */       }
/* 660 */       else if ("baseFont".equals(qName)) {
/* 661 */         int size = this.theme.baseFont.getSize();
/* 662 */         String sizeStr = attrs.getValue("size");
/* 663 */         if (sizeStr != null) {
/* 664 */           size = Integer.parseInt(sizeStr);
/*     */         }
/* 666 */         String family = attrs.getValue("family");
/* 667 */         if (family != null) {
/* 668 */           this.theme.baseFont = Theme.getFont(family, 0, size);
/*     */         }
/* 670 */         else if (sizeStr != null) {
/*     */           
/* 672 */           this.theme.baseFont = this.theme.baseFont.deriveFont(size * 1.0F);
/*     */         }
/*     */       
/*     */       }
/* 676 */       else if ("caret".equals(qName)) {
/* 677 */         String color = attrs.getValue("color");
/* 678 */         this.theme.caretColor = Theme.stringToColor(color);
/*     */       
/*     */       }
/* 681 */       else if ("currentLineHighlight".equals(qName)) {
/* 682 */         String color = attrs.getValue("color");
/* 683 */         this.theme.currentLineHighlight = Theme.stringToColor(color);
/* 684 */         String fadeStr = attrs.getValue("fade");
/* 685 */         boolean fade = Boolean.parseBoolean(fadeStr);
/* 686 */         this.theme.fadeCurrentLineHighlight = fade;
/*     */       
/*     */       }
/* 689 */       else if ("foldIndicator".equals(qName)) {
/* 690 */         String color = attrs.getValue("fg");
/* 691 */         this.theme.foldIndicatorFG = Theme.stringToColor(color);
/* 692 */         color = attrs.getValue("iconBg");
/* 693 */         this.theme.foldBG = Theme.stringToColor(color);
/* 694 */         color = attrs.getValue("iconArmedBg");
/* 695 */         this.theme.armedFoldBG = Theme.stringToColor(color);
/*     */       
/*     */       }
/* 698 */       else if ("gutterBackground".equals(qName)) {
/* 699 */         String color = attrs.getValue("color");
/* 700 */         if (color != null) {
/* 701 */           this.theme.gutterBackgroundColor = Theme.stringToColor(color);
/*     */         
/*     */         }
/*     */       }
/* 705 */       else if ("gutterBorder".equals(qName)) {
/* 706 */         String color = attrs.getValue("color");
/* 707 */         this.theme.gutterBorderColor = Theme.stringToColor(color);
/*     */       
/*     */       }
/* 710 */       else if ("iconRowHeader".equals(qName)) {
/* 711 */         String color = attrs.getValue("activeLineRange");
/* 712 */         this.theme.activeLineRangeColor = Theme.stringToColor(color);
/* 713 */         String inheritBGStr = attrs.getValue("inheritsGutterBG");
/* 714 */         this.theme
/* 715 */           .iconRowHeaderInheritsGutterBG = Boolean.parseBoolean(inheritBGStr);
/*     */       
/*     */       }
/* 718 */       else if ("lineNumbers".equals(qName)) {
/* 719 */         String color = attrs.getValue("fg");
/* 720 */         this.theme.lineNumberColor = Theme.stringToColor(color);
/* 721 */         this.theme.lineNumberFont = attrs.getValue("fontFamily");
/* 722 */         this.theme.lineNumberFontSize = parseInt(attrs, "fontSize", -1);
/*     */       
/*     */       }
/* 725 */       else if ("marginLine".equals(qName)) {
/* 726 */         String color = attrs.getValue("fg");
/* 727 */         this.theme.marginLineColor = Theme.stringToColor(color);
/*     */       
/*     */       }
/* 730 */       else if ("markAllHighlight".equals(qName)) {
/* 731 */         String color = attrs.getValue("color");
/* 732 */         this.theme.markAllHighlightColor = Theme.stringToColor(color);
/*     */       
/*     */       }
/* 735 */       else if ("markOccurrencesHighlight".equals(qName)) {
/* 736 */         String color = attrs.getValue("color");
/* 737 */         this.theme.markOccurrencesColor = Theme.stringToColor(color);
/* 738 */         String border = attrs.getValue("border");
/* 739 */         this.theme.markOccurrencesBorder = Boolean.parseBoolean(border);
/*     */       
/*     */       }
/* 742 */       else if ("matchedBracket".equals(qName)) {
/* 743 */         String fg = attrs.getValue("fg");
/* 744 */         this.theme.matchedBracketFG = Theme.stringToColor(fg);
/* 745 */         String bg = attrs.getValue("bg");
/* 746 */         this.theme.matchedBracketBG = Theme.stringToColor(bg);
/* 747 */         String highlightBoth = attrs.getValue("highlightBoth");
/* 748 */         this.theme.matchedBracketHighlightBoth = Boolean.parseBoolean(highlightBoth);
/* 749 */         String animate = attrs.getValue("animate");
/* 750 */         this.theme.matchedBracketAnimate = Boolean.parseBoolean(animate);
/*     */       
/*     */       }
/* 753 */       else if ("hyperlinks".equals(qName)) {
/* 754 */         String fg = attrs.getValue("fg");
/* 755 */         this.theme.hyperlinkFG = Theme.stringToColor(fg);
/*     */       
/*     */       }
/* 758 */       else if ("language".equals(qName)) {
/* 759 */         String indexStr = attrs.getValue("index");
/* 760 */         int index = Integer.parseInt(indexStr) - 1;
/* 761 */         if (this.theme.secondaryLanguages.length > index) {
/* 762 */           Color bg = Theme.stringToColor(attrs.getValue("bg"));
/* 763 */           this.theme.secondaryLanguages[index] = bg;
/*     */         }
/*     */       
/*     */       }
/* 767 */       else if ("selection".equals(qName)) {
/* 768 */         String useStr = attrs.getValue("useFG");
/* 769 */         this.theme.useSelctionFG = Boolean.parseBoolean(useStr);
/* 770 */         String color = attrs.getValue("fg");
/* 771 */         this.theme.selectionFG = Theme.stringToColor(color, Theme
/* 772 */             .getDefaultSelectionFG());
/*     */         
/* 774 */         color = attrs.getValue("bg");
/* 775 */         this.theme.selectionBG = Theme.stringToColor(color, Theme
/* 776 */             .getDefaultSelectionBG());
/* 777 */         String roundedStr = attrs.getValue("roundedEdges");
/* 778 */         this.theme.selectionRoundedEdges = Boolean.parseBoolean(roundedStr);
/*     */ 
/*     */       
/*     */       }
/* 782 */       else if ("tokenStyles".equals(qName)) {
/* 783 */         this.theme.scheme = new SyntaxScheme(this.theme.baseFont, false);
/*     */ 
/*     */       
/*     */       }
/* 787 */       else if ("style".equals(qName)) {
/*     */         
/* 789 */         String type = attrs.getValue("token");
/* 790 */         Field field = null;
/*     */         try {
/* 792 */           field = Token.class.getField(type);
/* 793 */         } catch (RuntimeException re) {
/* 794 */           throw re;
/* 795 */         } catch (Exception e) {
/* 796 */           System.err.println("Invalid token type: " + type);
/*     */           
/*     */           return;
/*     */         } 
/* 800 */         if (field.getType() == int.class) {
/*     */           
/* 802 */           int index = 0;
/*     */           try {
/* 804 */             index = field.getInt(this.theme.scheme);
/* 805 */           } catch (IllegalArgumentException|IllegalAccessException e) {
/* 806 */             e.printStackTrace();
/*     */             
/*     */             return;
/*     */           } 
/* 810 */           String fgStr = attrs.getValue("fg");
/* 811 */           Color fg = Theme.stringToColor(fgStr);
/* 812 */           (this.theme.scheme.getStyle(index)).foreground = fg;
/*     */           
/* 814 */           String bgStr = attrs.getValue("bg");
/* 815 */           Color bg = Theme.stringToColor(bgStr);
/* 816 */           (this.theme.scheme.getStyle(index)).background = bg;
/*     */           
/* 818 */           Font font = this.theme.baseFont;
/* 819 */           String familyName = attrs.getValue("fontFamily");
/* 820 */           if (familyName != null) {
/* 821 */             font = Theme.getFont(familyName, font.getStyle(), font
/* 822 */                 .getSize());
/*     */           }
/* 824 */           String sizeStr = attrs.getValue("fontSize");
/* 825 */           if (sizeStr != null) {
/*     */             try {
/* 827 */               float size = Float.parseFloat(sizeStr);
/* 828 */               size = Math.max(size, 1.0F);
/* 829 */               font = font.deriveFont(size);
/* 830 */             } catch (NumberFormatException nfe) {
/* 831 */               nfe.printStackTrace();
/*     */             } 
/*     */           }
/* 834 */           (this.theme.scheme.getStyle(index)).font = font;
/*     */           
/* 836 */           boolean styleSpecified = false;
/* 837 */           boolean bold = false;
/* 838 */           boolean italic = false;
/* 839 */           String boldStr = attrs.getValue("bold");
/* 840 */           if (boldStr != null) {
/* 841 */             bold = Boolean.parseBoolean(boldStr);
/* 842 */             styleSpecified = true;
/*     */           } 
/* 844 */           String italicStr = attrs.getValue("italic");
/* 845 */           if (italicStr != null) {
/* 846 */             italic = Boolean.parseBoolean(italicStr);
/* 847 */             styleSpecified = true;
/*     */           } 
/* 849 */           if (styleSpecified) {
/* 850 */             int style = 0;
/* 851 */             if (bold) {
/* 852 */               style |= 0x1;
/*     */             }
/* 854 */             if (italic) {
/* 855 */               style |= 0x2;
/*     */             }
/* 857 */             Font orig = (this.theme.scheme.getStyle(index)).font;
/* 858 */             (this.theme.scheme.getStyle(index))
/* 859 */               .font = orig.deriveFont(style);
/*     */           } 
/*     */           
/* 862 */           String ulineStr = attrs.getValue("underline");
/* 863 */           if (ulineStr != null) {
/* 864 */             boolean uline = Boolean.parseBoolean(ulineStr);
/* 865 */             (this.theme.scheme.getStyle(index)).underline = uline;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void warning(SAXParseException e) throws SAXException {
/* 876 */       throw e;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/Theme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */