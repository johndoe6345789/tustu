/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Element;
/*     */ import org.fife.ui.rtextarea.SmartHighlightPainter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlOccurrenceMarker
/*     */   implements OccurrenceMarker
/*     */ {
/*  28 */   private static final char[] CLOSE_TAG_START = new char[] { '<', '/' };
/*  29 */   private static final char[] TAG_SELF_CLOSE = new char[] { '/', '>' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token getTokenToMark(RSyntaxTextArea textArea) {
/*  37 */     return HtmlOccurrenceMarker.getTagNameTokenForCaretOffset(textArea, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidType(RSyntaxTextArea textArea, Token t) {
/*  47 */     return textArea.getMarkOccurrencesOfTokenType(t.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markOccurrences(RSyntaxDocument doc, Token t, RSyntaxTextAreaHighlighter h, SmartHighlightPainter p) {
/*  58 */     char[] lexeme = t.getLexeme().toCharArray();
/*  59 */     int tokenOffs = t.getOffset();
/*  60 */     Element root = doc.getDefaultRootElement();
/*  61 */     int lineCount = root.getElementCount();
/*  62 */     int curLine = root.getElementIndex(t.getOffset());
/*  63 */     int depth = 0;
/*     */ 
/*     */ 
/*     */     
/*  67 */     boolean found = false;
/*  68 */     boolean forward = true;
/*  69 */     t = doc.getTokenListForLine(curLine);
/*  70 */     while (t != null && t.isPaintable()) {
/*  71 */       if (t.getType() == 25) {
/*  72 */         if (t.isSingleChar('<') && t.getOffset() + 1 == tokenOffs) {
/*  73 */           found = true;
/*     */           break;
/*     */         } 
/*  76 */         if (t.is(CLOSE_TAG_START) && t.getOffset() + 2 == tokenOffs) {
/*  77 */           found = true;
/*  78 */           forward = false;
/*     */           break;
/*     */         } 
/*     */       } 
/*  82 */       t = t.getNextToken();
/*     */     } 
/*     */     
/*  85 */     if (!found) {
/*     */       return;
/*     */     }
/*     */     
/*  89 */     if (forward) {
/*     */       
/*  91 */       t = t.getNextToken().getNextToken();
/*     */ 
/*     */       
/*     */       while (true) {
/*  95 */         if (t != null && t.isPaintable()) {
/*  96 */           if (t.getType() == 25) {
/*  97 */             if (t.is(CLOSE_TAG_START)) {
/*  98 */               Token match = t.getNextToken();
/*  99 */               if (match != null && match.is(lexeme)) {
/* 100 */                 if (depth > 0) {
/* 101 */                   depth--;
/*     */                 } else {
/*     */                   
/*     */                   try {
/* 105 */                     int end = match.getOffset() + match.length();
/* 106 */                     h.addMarkedOccurrenceHighlight(match.getOffset(), end, p);
/* 107 */                     end = tokenOffs + match.length();
/* 108 */                     h.addMarkedOccurrenceHighlight(tokenOffs, end, p);
/* 109 */                   } catch (BadLocationException ble) {
/* 110 */                     ble.printStackTrace();
/*     */                   } 
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */               }
/* 116 */             } else if (t.isSingleChar('<')) {
/* 117 */               t = t.getNextToken();
/* 118 */               if (t != null && t.is(lexeme)) {
/* 119 */                 depth++;
/*     */               }
/*     */             } 
/*     */           }
/* 123 */           t = (t == null) ? null : t.getNextToken();
/*     */           continue;
/*     */         } 
/* 126 */         if (++curLine < lineCount) {
/* 127 */           t = doc.getTokenListForLine(curLine);
/*     */         }
/*     */         
/* 130 */         if (curLine >= lineCount)
/*     */         {
/*     */           break;
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 142 */       List<Entry> openCloses = new ArrayList<>();
/* 143 */       boolean inPossibleMatch = false;
/* 144 */       t = doc.getTokenListForLine(curLine);
/* 145 */       int endBefore = tokenOffs - 2;
/*     */ 
/*     */       
/*     */       while (true) {
/* 149 */         if (t != null && t.getOffset() < endBefore && t.isPaintable()) {
/* 150 */           if (t.getType() == 25) {
/* 151 */             if (t.isSingleChar('<')) {
/* 152 */               Token next = t.getNextToken();
/* 153 */               if (next != null) {
/* 154 */                 if (next.is(lexeme)) {
/* 155 */                   openCloses.add(new Entry(true, next));
/* 156 */                   inPossibleMatch = true;
/*     */                 } else {
/*     */                   
/* 159 */                   inPossibleMatch = false;
/*     */                 } 
/* 161 */                 t = next;
/*     */               }
/*     */             
/* 164 */             } else if (t.isSingleChar('>')) {
/* 165 */               inPossibleMatch = false;
/*     */             }
/* 167 */             else if (inPossibleMatch && t.is(TAG_SELF_CLOSE)) {
/* 168 */               openCloses.remove(openCloses.size() - 1);
/* 169 */               inPossibleMatch = false;
/*     */             }
/* 171 */             else if (t.is(CLOSE_TAG_START)) {
/* 172 */               Token next = t.getNextToken();
/* 173 */               if (next != null) {
/*     */                 
/* 175 */                 if (next.is(lexeme)) {
/* 176 */                   openCloses.add(new Entry(false, next));
/*     */                 }
/* 178 */                 t = next;
/*     */               } 
/*     */             } 
/*     */           }
/* 182 */           t = t.getNextToken();
/*     */           continue;
/*     */         } 
/* 185 */         for (int i = openCloses.size() - 1; i >= 0; i--) {
/* 186 */           Entry entry = openCloses.get(i);
/* 187 */           depth += entry.open ? -1 : 1;
/* 188 */           if (depth == -1) {
/*     */             try {
/* 190 */               Token match = entry.t;
/* 191 */               int end = match.getOffset() + match.length();
/* 192 */               h.addMarkedOccurrenceHighlight(match.getOffset(), end, p);
/* 193 */               end = tokenOffs + match.length();
/* 194 */               h.addMarkedOccurrenceHighlight(tokenOffs, end, p);
/* 195 */             } catch (BadLocationException ble) {
/* 196 */               ble.printStackTrace();
/*     */             } 
/* 198 */             openCloses.clear();
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 203 */         openCloses.clear();
/* 204 */         if (--curLine >= 0) {
/* 205 */           t = doc.getTokenListForLine(curLine);
/*     */         }
/*     */         
/* 208 */         if (curLine < 0) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Entry
/*     */   {
/*     */     private boolean open;
/*     */     
/*     */     private Token t;
/*     */ 
/*     */     
/*     */     Entry(boolean open, Token t) {
/* 225 */       this.open = open;
/* 226 */       this.t = t;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/XmlOccurrenceMarker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */