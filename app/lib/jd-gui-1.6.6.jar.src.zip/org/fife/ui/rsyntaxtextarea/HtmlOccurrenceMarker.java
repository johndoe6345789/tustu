/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Element;
/*     */ import org.fife.ui.rtextarea.SmartHighlightPainter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HtmlOccurrenceMarker
/*     */   implements OccurrenceMarker
/*     */ {
/*  34 */   private static final char[] CLOSE_TAG_START = new char[] { '<', '/' };
/*  35 */   private static final char[] TAG_SELF_CLOSE = new char[] { '/', '>' };
/*     */ 
/*     */   
/*  38 */   private static final Set<String> TAGS_REQUIRING_CLOSING = getRequiredClosingTags();
/*     */   
/*     */   public static final Set<String> getRequiredClosingTags() {
/*  41 */     String[] tags = { "html", "head", "title", "style", "script", "noscript", "body", "section", "nav", "article", "aside", "h1", "h2", "h3", "h4", "h5", "h6", "header", "footer", "address", "pre", "dialog", "blockquote", "ol", "ul", "dl", "a", "q", "cite", "em", "strong", "small", "mark", "dfn", "abbr", "time", "progress", "meter", "code", "var", "samp", "kbd", "sub", "sup", "span", "i", "b", "bdo", "ruby", "rt", "rp", "ins", "del", "figure", "iframe", "object", "video", "audio", "canvas", "map", "table", "caption", "form", "fieldset", "label", "button", "select", "datalist", "textarea", "output", "details", "bb", "menu", "legend", "div", "acronym", "applet", "big", "blink", "center", "dir", "font", "frame", "frameset", "isindex", "listing", "marquee", "nobr", "noembed", "noframes", "plaintext", "s", "spacer", "strike", "tt", "u", "xmp" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     return new HashSet<>(Arrays.asList(tags));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Token getTagNameTokenForCaretOffset(RSyntaxTextArea textArea, OccurrenceMarker occurrenceMarker) {
/* 165 */     int dot = textArea.getCaretPosition();
/* 166 */     Token t = textArea.getTokenListForLine(textArea.getCaretLineNumber());
/* 167 */     Token toMark = null;
/*     */     
/* 169 */     while (t != null && t.isPaintable()) {
/* 170 */       if (t.getType() == 26) {
/* 171 */         toMark = t;
/*     */       }
/*     */ 
/*     */       
/* 175 */       if (t.getEndOffset() == dot || t.containsPosition(dot)) {
/*     */ 
/*     */         
/* 178 */         if (occurrenceMarker.isValidType(textArea, t) && t
/* 179 */           .getType() != 26) {
/* 180 */           return t;
/*     */         }
/* 182 */         if (t.containsPosition(dot)) {
/*     */           break;
/*     */         }
/*     */       } 
/* 186 */       if (t.getType() == 25 && (
/* 187 */         t.isSingleChar('>') || t.is(TAG_SELF_CLOSE))) {
/* 188 */         toMark = null;
/*     */       }
/*     */       
/* 191 */       t = t.getNextToken();
/*     */     } 
/*     */     
/* 194 */     return toMark;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token getTokenToMark(RSyntaxTextArea textArea) {
/* 204 */     return getTagNameTokenForCaretOffset(textArea, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidType(RSyntaxTextArea textArea, Token t) {
/* 213 */     return textArea.getMarkOccurrencesOfTokenType(t.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markOccurrences(RSyntaxDocument doc, Token t, RSyntaxTextAreaHighlighter h, SmartHighlightPainter p) {
/* 224 */     if (t.getType() != 26) {
/* 225 */       DefaultOccurrenceMarker.markOccurrencesOfToken(doc, t, h, p);
/*     */       
/*     */       return;
/*     */     } 
/* 229 */     String lexemeStr = t.getLexeme();
/* 230 */     char[] lexeme = lexemeStr.toCharArray();
/* 231 */     lexemeStr = lexemeStr.toLowerCase();
/* 232 */     int tokenOffs = t.getOffset();
/* 233 */     Element root = doc.getDefaultRootElement();
/* 234 */     int lineCount = root.getElementCount();
/* 235 */     int curLine = root.getElementIndex(t.getOffset());
/* 236 */     int depth = 0;
/*     */ 
/*     */ 
/*     */     
/* 240 */     boolean found = false;
/* 241 */     boolean forward = true;
/* 242 */     t = doc.getTokenListForLine(curLine);
/* 243 */     while (t != null && t.isPaintable()) {
/* 244 */       if (t.getType() == 25) {
/* 245 */         if (t.isSingleChar('<') && t.getOffset() + 1 == tokenOffs) {
/*     */ 
/*     */           
/* 248 */           if (TAGS_REQUIRING_CLOSING.contains(lexemeStr)) {
/* 249 */             found = true;
/*     */           }
/*     */           break;
/*     */         } 
/* 253 */         if (t.is(CLOSE_TAG_START) && t.getOffset() + 2 == tokenOffs) {
/*     */ 
/*     */           
/* 256 */           found = true;
/* 257 */           forward = false;
/*     */           break;
/*     */         } 
/*     */       } 
/* 261 */       t = t.getNextToken();
/*     */     } 
/*     */     
/* 264 */     if (!found) {
/*     */       return;
/*     */     }
/*     */     
/* 268 */     if (forward) {
/*     */       
/* 270 */       t = t.getNextToken().getNextToken();
/*     */ 
/*     */       
/*     */       while (true) {
/* 274 */         if (t != null && t.isPaintable()) {
/* 275 */           if (t.getType() == 25) {
/* 276 */             if (t.is(CLOSE_TAG_START)) {
/* 277 */               Token match = t.getNextToken();
/* 278 */               if (match != null && match.is(lexeme)) {
/* 279 */                 if (depth > 0) {
/* 280 */                   depth--;
/*     */                 } else {
/*     */                   
/*     */                   try {
/* 284 */                     int end = match.getOffset() + match.length();
/* 285 */                     h.addMarkedOccurrenceHighlight(match.getOffset(), end, p);
/* 286 */                     end = tokenOffs + match.length();
/* 287 */                     h.addMarkedOccurrenceHighlight(tokenOffs, end, p);
/* 288 */                   } catch (BadLocationException ble) {
/* 289 */                     ble.printStackTrace();
/*     */                   } 
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */               }
/* 295 */             } else if (t.isSingleChar('<')) {
/* 296 */               t = t.getNextToken();
/* 297 */               if (t != null && t.is(lexeme)) {
/* 298 */                 depth++;
/*     */               }
/*     */             } 
/*     */           }
/* 302 */           t = (t == null) ? null : t.getNextToken();
/*     */           continue;
/*     */         } 
/* 305 */         if (++curLine < lineCount) {
/* 306 */           t = doc.getTokenListForLine(curLine);
/*     */         }
/*     */         
/* 309 */         if (curLine >= lineCount)
/*     */         {
/*     */           break;
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 321 */       List<Entry> openCloses = new ArrayList<>();
/* 322 */       boolean inPossibleMatch = false;
/* 323 */       t = doc.getTokenListForLine(curLine);
/* 324 */       int endBefore = tokenOffs - 2;
/*     */ 
/*     */       
/*     */       while (true) {
/* 328 */         if (t != null && t.getOffset() < endBefore && t.isPaintable()) {
/* 329 */           if (t.getType() == 25) {
/* 330 */             if (t.isSingleChar('<')) {
/* 331 */               Token next = t.getNextToken();
/* 332 */               if (next != null) {
/* 333 */                 if (next.is(lexeme)) {
/* 334 */                   openCloses.add(new Entry(true, next));
/* 335 */                   inPossibleMatch = true;
/*     */                 } else {
/*     */                   
/* 338 */                   inPossibleMatch = false;
/*     */                 } 
/* 340 */                 t = next;
/*     */               }
/*     */             
/* 343 */             } else if (t.isSingleChar('>')) {
/* 344 */               inPossibleMatch = false;
/*     */             }
/* 346 */             else if (inPossibleMatch && t.is(TAG_SELF_CLOSE)) {
/* 347 */               openCloses.remove(openCloses.size() - 1);
/* 348 */               inPossibleMatch = false;
/*     */             }
/* 350 */             else if (t.is(CLOSE_TAG_START)) {
/* 351 */               Token next = t.getNextToken();
/* 352 */               if (next != null) {
/*     */                 
/* 354 */                 if (next.is(lexeme)) {
/* 355 */                   openCloses.add(new Entry(false, next));
/*     */                 }
/* 357 */                 t = next;
/*     */               } 
/*     */             } 
/*     */           }
/* 361 */           t = t.getNextToken();
/*     */           continue;
/*     */         } 
/* 364 */         for (int i = openCloses.size() - 1; i >= 0; i--) {
/* 365 */           Entry entry = openCloses.get(i);
/* 366 */           depth += entry.open ? -1 : 1;
/* 367 */           if (depth == -1) {
/*     */             try {
/* 369 */               Token match = entry.t;
/* 370 */               int end = match.getOffset() + match.length();
/* 371 */               h.addMarkedOccurrenceHighlight(match.getOffset(), end, p);
/* 372 */               end = tokenOffs + match.length();
/* 373 */               h.addMarkedOccurrenceHighlight(tokenOffs, end, p);
/* 374 */             } catch (BadLocationException ble) {
/* 375 */               ble.printStackTrace();
/*     */             } 
/* 377 */             openCloses.clear();
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/* 382 */         openCloses.clear();
/* 383 */         if (--curLine >= 0) {
/* 384 */           t = doc.getTokenListForLine(curLine);
/*     */         }
/*     */         
/* 387 */         if (curLine < 0) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Entry
/*     */   {
/*     */     private boolean open;
/*     */     
/*     */     private Token t;
/*     */ 
/*     */     
/*     */     Entry(boolean open, Token t) {
/* 404 */       this.open = open;
/* 405 */       this.t = t;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/HtmlOccurrenceMarker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */