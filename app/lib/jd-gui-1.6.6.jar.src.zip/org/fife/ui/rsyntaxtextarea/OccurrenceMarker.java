package org.fife.ui.rsyntaxtextarea;

import org.fife.ui.rtextarea.SmartHighlightPainter;

public interface OccurrenceMarker {
  Token getTokenToMark(RSyntaxTextArea paramRSyntaxTextArea);
  
  boolean isValidType(RSyntaxTextArea paramRSyntaxTextArea, Token paramToken);
  
  void markOccurrences(RSyntaxDocument paramRSyntaxDocument, Token paramToken, RSyntaxTextAreaHighlighter paramRSyntaxTextAreaHighlighter, SmartHighlightPainter paramSmartHighlightPainter);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/OccurrenceMarker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */