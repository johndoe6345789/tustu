/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import org.fife.ui.rsyntaxtextarea.folding.FoldManager;
/*     */ import org.fife.ui.rtextarea.GutterIconInfo;
/*     */ import org.fife.ui.rtextarea.IconRowHeader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FoldingAwareIconRowHeader
/*     */   extends IconRowHeader
/*     */ {
/*     */   public FoldingAwareIconRowHeader(RSyntaxTextArea textArea) {
/*  41 */     super(textArea);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintComponent(Graphics g) {
/*  52 */     if (this.textArea == null) {
/*     */       return;
/*     */     }
/*  55 */     RSyntaxTextArea rsta = (RSyntaxTextArea)this.textArea;
/*  56 */     FoldManager fm = rsta.getFoldManager();
/*  57 */     if (!fm.isCodeFoldingSupportedAndEnabled()) {
/*  58 */       super.paintComponent(g);
/*     */       
/*     */       return;
/*     */     } 
/*  62 */     this.visibleRect = g.getClipBounds(this.visibleRect);
/*  63 */     if (this.visibleRect == null) {
/*  64 */       this.visibleRect = getVisibleRect();
/*     */     }
/*     */     
/*  67 */     if (this.visibleRect == null) {
/*     */       return;
/*     */     }
/*  70 */     paintBackgroundImpl(g, this.visibleRect);
/*     */     
/*  72 */     if (this.textArea.getLineWrap()) {
/*  73 */       paintComponentWrapped(g);
/*     */       
/*     */       return;
/*     */     } 
/*  77 */     Document doc = this.textArea.getDocument();
/*  78 */     Element root = doc.getDefaultRootElement();
/*  79 */     this.textAreaInsets = this.textArea.getInsets(this.textAreaInsets);
/*  80 */     if (this.visibleRect.y < this.textAreaInsets.top) {
/*  81 */       this.visibleRect.height -= this.textAreaInsets.top - this.visibleRect.y;
/*  82 */       this.visibleRect.y = this.textAreaInsets.top;
/*     */     } 
/*     */ 
/*     */     
/*  86 */     int cellHeight = this.textArea.getLineHeight();
/*  87 */     int topLine = (this.visibleRect.y - this.textAreaInsets.top) / cellHeight;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     int y = topLine * cellHeight + this.textAreaInsets.top;
/*     */ 
/*     */     
/*  95 */     topLine += fm.getHiddenLineCountAbove(topLine, true);
/*     */ 
/*     */     
/*  98 */     if (this.activeLineRangeStart > -1 && this.activeLineRangeEnd > -1) {
/*  99 */       Color activeLineRangeColor = getActiveLineRangeColor();
/* 100 */       g.setColor(activeLineRangeColor);
/*     */       
/*     */       try {
/* 103 */         int realY1 = rsta.yForLine(this.activeLineRangeStart);
/* 104 */         if (realY1 > -1)
/*     */         {
/* 106 */           int y1 = realY1;
/*     */           
/* 108 */           int y2 = rsta.yForLine(this.activeLineRangeEnd);
/* 109 */           if (y2 == -1) {
/* 110 */             y2 = y1;
/*     */           }
/* 112 */           y2 += cellHeight - 1;
/*     */           
/* 114 */           if (y2 < this.visibleRect.y || y1 > this.visibleRect.y + this.visibleRect.height) {
/*     */             return;
/*     */           }
/*     */           
/* 118 */           y1 = Math.max(y, realY1);
/* 119 */           y2 = Math.min(y2, this.visibleRect.y + this.visibleRect.height);
/*     */ 
/*     */           
/* 122 */           int j = y1;
/* 123 */           while (j <= y2) {
/* 124 */             int yEnd = Math.min(y2, j + getWidth());
/* 125 */             int xEnd = yEnd - j;
/* 126 */             g.drawLine(0, j, xEnd, yEnd);
/* 127 */             j += 2;
/*     */           } 
/*     */           
/* 130 */           int i = 2;
/* 131 */           while (i < getWidth()) {
/* 132 */             int yEnd = y1 + getWidth() - i;
/* 133 */             g.drawLine(i, y1, getWidth(), yEnd);
/* 134 */             i += 2;
/*     */           } 
/*     */           
/* 137 */           if (realY1 >= y && realY1 < this.visibleRect.y + this.visibleRect.height) {
/* 138 */             g.drawLine(0, realY1, getWidth(), realY1);
/*     */           }
/* 140 */           if (y2 >= y && y2 < this.visibleRect.y + this.visibleRect.height) {
/* 141 */             g.drawLine(0, y2, getWidth(), y2);
/*     */           }
/*     */         }
/*     */       
/*     */       }
/* 146 */       catch (BadLocationException ble) {
/* 147 */         ble.printStackTrace();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 152 */     if (this.trackingIcons != null) {
/* 153 */       int lastLine = this.textArea.getLineCount() - 1;
/* 154 */       for (int i = this.trackingIcons.size() - 1; i >= 0; i--) {
/* 155 */         GutterIconInfo ti = getTrackingIcon(i);
/* 156 */         int offs = ti.getMarkedOffset();
/* 157 */         if (offs >= 0 && offs <= doc.getLength()) {
/* 158 */           int line = root.getElementIndex(offs);
/* 159 */           if (line <= lastLine && line >= topLine) {
/*     */             try {
/* 161 */               Icon icon = ti.getIcon();
/* 162 */               if (icon != null) {
/* 163 */                 int lineY = rsta.yForLine(line);
/* 164 */                 if (lineY >= y && lineY <= this.visibleRect.y + this.visibleRect.height) {
/* 165 */                   int y2 = lineY + (cellHeight - icon.getIconHeight()) / 2;
/* 166 */                   icon.paintIcon(this, g, 0, y2);
/* 167 */                   lastLine = line - 1;
/*     */                 } 
/*     */               } 
/* 170 */             } catch (BadLocationException ble) {
/* 171 */               ble.printStackTrace();
/*     */             }
/*     */           
/* 174 */           } else if (line < topLine) {
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintComponentWrapped(Graphics g) {
/* 205 */     RSyntaxTextArea rsta = (RSyntaxTextArea)this.textArea;
/*     */     
/* 207 */     Document doc = this.textArea.getDocument();
/* 208 */     Element root = doc.getDefaultRootElement();
/* 209 */     int topPosition = this.textArea.viewToModel(new Point(this.visibleRect.x, this.visibleRect.y));
/*     */     
/* 211 */     int topLine = root.getElementIndex(topPosition);
/*     */     
/* 213 */     int topY = this.visibleRect.y;
/* 214 */     int bottomY = this.visibleRect.y + this.visibleRect.height;
/* 215 */     int cellHeight = this.textArea.getLineHeight();
/*     */ 
/*     */     
/* 218 */     if (this.trackingIcons != null) {
/* 219 */       int lastLine = this.textArea.getLineCount() - 1;
/* 220 */       for (int i = this.trackingIcons.size() - 1; i >= 0; i--) {
/* 221 */         GutterIconInfo ti = getTrackingIcon(i);
/* 222 */         Icon icon = ti.getIcon();
/* 223 */         if (icon != null) {
/* 224 */           int iconH = icon.getIconHeight();
/* 225 */           int offs = ti.getMarkedOffset();
/* 226 */           if (offs >= 0 && offs <= doc.getLength()) {
/* 227 */             int line = root.getElementIndex(offs);
/* 228 */             if (line <= lastLine && line >= topLine) {
/*     */               try {
/* 230 */                 int lineY = rsta.yForLine(line);
/* 231 */                 if (lineY <= bottomY && lineY + iconH >= topY) {
/* 232 */                   int y2 = lineY + (cellHeight - iconH) / 2;
/* 233 */                   ti.getIcon().paintIcon(this, g, 0, y2);
/* 234 */                   lastLine = line - 1;
/*     */                 } 
/* 236 */               } catch (BadLocationException ble) {
/* 237 */                 ble.printStackTrace();
/*     */               }
/*     */             
/* 240 */             } else if (line < topLine) {
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/FoldingAwareIconRowHeader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */