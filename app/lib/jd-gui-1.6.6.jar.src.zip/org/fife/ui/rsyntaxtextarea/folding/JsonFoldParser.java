/*     */ package org.fife.ui.rsyntaxtextarea.folding;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
/*     */ import org.fife.ui.rsyntaxtextarea.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonFoldParser
/*     */   implements FoldParser
/*     */ {
/*  32 */   private static final Object OBJECT_BLOCK = new Object();
/*  33 */   private static final Object ARRAY_BLOCK = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Fold> getFolds(RSyntaxTextArea textArea) {
/*  42 */     Stack<Object> blocks = new Stack();
/*  43 */     List<Fold> folds = new ArrayList<>();
/*     */     
/*  45 */     Fold currentFold = null;
/*  46 */     int lineCount = textArea.getLineCount();
/*     */ 
/*     */     
/*     */     try {
/*  50 */       for (int line = 0; line < lineCount; line++)
/*     */       {
/*  52 */         Token t = textArea.getTokenListForLine(line);
/*  53 */         while (t != null && t.isPaintable())
/*     */         {
/*  55 */           if (t.isLeftCurly()) {
/*  56 */             if (currentFold == null) {
/*  57 */               currentFold = new Fold(0, textArea, t.getOffset());
/*  58 */               folds.add(currentFold);
/*     */             } else {
/*     */               
/*  61 */               currentFold = currentFold.createChild(0, t.getOffset());
/*     */             } 
/*  63 */             blocks.push(OBJECT_BLOCK);
/*     */           
/*     */           }
/*  66 */           else if (t.isRightCurly() && popOffTop(blocks, OBJECT_BLOCK)) {
/*  67 */             if (currentFold != null) {
/*  68 */               currentFold.setEndOffset(t.getOffset());
/*  69 */               Fold parentFold = currentFold.getParent();
/*     */ 
/*     */               
/*  72 */               if (currentFold.isOnSingleLine() && 
/*  73 */                 !currentFold.removeFromParent()) {
/*  74 */                 folds.remove(folds.size() - 1);
/*     */               }
/*     */               
/*  77 */               currentFold = parentFold;
/*     */             }
/*     */           
/*     */           }
/*  81 */           else if (isLeftBracket(t)) {
/*  82 */             if (currentFold == null) {
/*  83 */               currentFold = new Fold(0, textArea, t.getOffset());
/*  84 */               folds.add(currentFold);
/*     */             } else {
/*     */               
/*  87 */               currentFold = currentFold.createChild(0, t.getOffset());
/*     */             } 
/*  89 */             blocks.push(ARRAY_BLOCK);
/*     */           
/*     */           }
/*  92 */           else if (isRightBracket(t) && popOffTop(blocks, ARRAY_BLOCK) && 
/*  93 */             currentFold != null) {
/*  94 */             currentFold.setEndOffset(t.getOffset());
/*  95 */             Fold parentFold = currentFold.getParent();
/*     */ 
/*     */             
/*  98 */             if (currentFold.isOnSingleLine() && 
/*  99 */               !currentFold.removeFromParent()) {
/* 100 */               folds.remove(folds.size() - 1);
/*     */             }
/*     */             
/* 103 */             currentFold = parentFold;
/*     */           } 
/*     */ 
/*     */           
/* 107 */           t = t.getNextToken();
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 113 */     catch (BadLocationException ble) {
/* 114 */       ble.printStackTrace();
/*     */     } 
/*     */     
/* 117 */     return folds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isLeftBracket(Token t) {
/* 130 */     return (t.getType() == 22 && t.isSingleChar('['));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isRightBracket(Token t) {
/* 142 */     return (t.getType() == 22 && t.isSingleChar(']'));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean popOffTop(Stack<Object> stack, Object value) {
/* 155 */     if (stack.size() > 0 && stack.peek() == value) {
/* 156 */       stack.pop();
/* 157 */       return true;
/*     */     } 
/* 159 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/folding/JsonFoldParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */