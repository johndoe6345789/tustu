/*     */ package org.fife.ui.rsyntaxtextarea.folding;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
/*     */ import org.fife.ui.rsyntaxtextarea.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CurlyFoldParser
/*     */   implements FoldParser
/*     */ {
/*     */   private boolean foldableMultiLineComments;
/*     */   private final boolean java;
/*  60 */   private static final char[] KEYWORD_IMPORT = "import".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   protected static final char[] C_MLC_END = "*/".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CurlyFoldParser() {
/*  73 */     this(true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CurlyFoldParser(boolean cStyleMultiLineComments, boolean java) {
/*  87 */     this.foldableMultiLineComments = cStyleMultiLineComments;
/*  88 */     this.java = java;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getFoldableMultiLineComments() {
/*  99 */     return this.foldableMultiLineComments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Fold> getFolds(RSyntaxTextArea textArea) {
/* 109 */     List<Fold> folds = new ArrayList<>();
/*     */     
/* 111 */     Fold currentFold = null;
/* 112 */     int lineCount = textArea.getLineCount();
/* 113 */     boolean inMLC = false;
/* 114 */     int mlcStart = 0;
/* 115 */     int importStartLine = -1;
/* 116 */     int lastSeenImportLine = -1;
/* 117 */     int importGroupStartOffs = -1;
/* 118 */     int importGroupEndOffs = -1;
/* 119 */     int lastRightCurlyLine = -1;
/* 120 */     Fold prevFold = null;
/*     */ 
/*     */     
/*     */     try {
/* 124 */       for (int line = 0; line < lineCount; line++)
/*     */       {
/* 126 */         Token t = textArea.getTokenListForLine(line);
/* 127 */         while (t != null && t.isPaintable())
/*     */         {
/* 129 */           if (getFoldableMultiLineComments() && t.isComment()) {
/*     */ 
/*     */             
/* 132 */             if (this.java)
/*     */             {
/* 134 */               if (importStartLine > -1) {
/* 135 */                 if (lastSeenImportLine > importStartLine) {
/* 136 */                   Fold fold = null;
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 141 */                   if (currentFold == null) {
/* 142 */                     fold = new Fold(2, textArea, importGroupStartOffs);
/*     */                     
/* 144 */                     folds.add(fold);
/*     */                   } else {
/*     */                     
/* 147 */                     fold = currentFold.createChild(2, importGroupStartOffs);
/*     */                   } 
/*     */                   
/* 150 */                   fold.setEndOffset(importGroupEndOffs);
/*     */                 } 
/* 152 */                 importStartLine = lastSeenImportLine = importGroupStartOffs = importGroupEndOffs = -1;
/*     */               } 
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 158 */             if (inMLC)
/*     */             {
/*     */               
/* 161 */               if (t.endsWith(C_MLC_END)) {
/* 162 */                 int mlcEnd = t.getEndOffset() - 1;
/* 163 */                 if (currentFold == null) {
/* 164 */                   currentFold = new Fold(1, textArea, mlcStart);
/* 165 */                   currentFold.setEndOffset(mlcEnd);
/* 166 */                   folds.add(currentFold);
/* 167 */                   currentFold = null;
/*     */                 } else {
/*     */                   
/* 170 */                   currentFold = currentFold.createChild(1, mlcStart);
/* 171 */                   currentFold.setEndOffset(mlcEnd);
/* 172 */                   currentFold = currentFold.getParent();
/*     */                 } 
/*     */                 
/* 175 */                 inMLC = false;
/* 176 */                 mlcStart = 0;
/*     */ 
/*     */               
/*     */               }
/*     */ 
/*     */             
/*     */             }
/* 183 */             else if (t.getType() != 1 && !t.endsWith(C_MLC_END))
/*     */             {
/* 185 */               inMLC = true;
/* 186 */               mlcStart = t.getOffset();
/*     */             
/*     */             }
/*     */ 
/*     */           
/*     */           }
/* 192 */           else if (isLeftCurly(t)) {
/*     */ 
/*     */             
/* 195 */             if (this.java)
/*     */             {
/* 197 */               if (importStartLine > -1) {
/* 198 */                 if (lastSeenImportLine > importStartLine) {
/* 199 */                   Fold fold = null;
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 204 */                   if (currentFold == null) {
/* 205 */                     fold = new Fold(2, textArea, importGroupStartOffs);
/*     */                     
/* 207 */                     folds.add(fold);
/*     */                   } else {
/*     */                     
/* 210 */                     fold = currentFold.createChild(2, importGroupStartOffs);
/*     */                   } 
/*     */                   
/* 213 */                   fold.setEndOffset(importGroupEndOffs);
/*     */                 } 
/* 215 */                 importStartLine = lastSeenImportLine = importGroupStartOffs = importGroupEndOffs = -1;
/*     */               } 
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 224 */             if (prevFold != null && line == lastRightCurlyLine) {
/* 225 */               currentFold = prevFold;
/*     */ 
/*     */ 
/*     */               
/* 229 */               prevFold = null;
/* 230 */               lastRightCurlyLine = -1;
/*     */             }
/* 232 */             else if (currentFold == null) {
/* 233 */               currentFold = new Fold(0, textArea, t.getOffset());
/* 234 */               folds.add(currentFold);
/*     */             } else {
/*     */               
/* 237 */               currentFold = currentFold.createChild(0, t.getOffset());
/*     */             
/*     */             }
/*     */           
/*     */           }
/* 242 */           else if (isRightCurly(t)) {
/*     */             
/* 244 */             if (currentFold != null) {
/* 245 */               currentFold.setEndOffset(t.getOffset());
/* 246 */               Fold parentFold = currentFold.getParent();
/*     */ 
/*     */               
/* 249 */               if (currentFold.isOnSingleLine()) {
/* 250 */                 if (!currentFold.removeFromParent()) {
/* 251 */                   folds.remove(folds.size() - 1);
/*     */                 
/*     */                 }
/*     */               
/*     */               }
/*     */               else {
/*     */                 
/* 258 */                 lastRightCurlyLine = line;
/* 259 */                 prevFold = currentFold;
/*     */               } 
/* 261 */               currentFold = parentFold;
/*     */             
/*     */             }
/*     */ 
/*     */           
/*     */           }
/* 267 */           else if (this.java) {
/*     */             
/* 269 */             if (t.is(6, KEYWORD_IMPORT)) {
/* 270 */               if (importStartLine == -1) {
/* 271 */                 importStartLine = line;
/* 272 */                 importGroupStartOffs = t.getOffset();
/* 273 */                 importGroupEndOffs = t.getOffset();
/*     */               } 
/* 275 */               lastSeenImportLine = line;
/*     */             
/*     */             }
/* 278 */             else if (importStartLine > -1 && t
/* 279 */               .isIdentifier() && t
/* 280 */               .isSingleChar(';')) {
/* 281 */               importGroupEndOffs = t.getOffset();
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 286 */           t = t.getNextToken();
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 292 */     catch (BadLocationException ble) {
/* 293 */       ble.printStackTrace();
/*     */     } 
/*     */     
/* 296 */     return folds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLeftCurly(Token t) {
/* 310 */     return t.isLeftCurly();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRightCurly(Token t) {
/* 323 */     return t.isRightCurly();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFoldableMultiLineComments(boolean foldable) {
/* 334 */     this.foldableMultiLineComments = foldable;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/folding/CurlyFoldParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */