package org.fife.ui.rsyntaxtextarea.folding;

public interface FoldType {
  public static final int CODE = 0;
  
  public static final int COMMENT = 1;
  
  public static final int IMPORTS = 2;
  
  public static final int FOLD_TYPE_USER_DEFINED_MIN = 1000;
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/folding/FoldType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */