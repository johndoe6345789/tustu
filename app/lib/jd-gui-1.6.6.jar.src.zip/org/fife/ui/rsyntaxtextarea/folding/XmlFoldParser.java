/*     */ package org.fife.ui.rsyntaxtextarea.folding;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
/*     */ import org.fife.ui.rsyntaxtextarea.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlFoldParser
/*     */   implements FoldParser
/*     */ {
/*  30 */   private static final char[] MARKUP_CLOSING_TAG_START = new char[] { '<', '/' };
/*  31 */   private static final char[] MARKUP_SHORT_TAG_END = new char[] { '/', '>' };
/*  32 */   private static final char[] MLC_END = new char[] { '-', '-', '>' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Fold> getFolds(RSyntaxTextArea textArea) {
/*  41 */     List<Fold> folds = new ArrayList<>();
/*     */     
/*  43 */     Fold currentFold = null;
/*  44 */     int lineCount = textArea.getLineCount();
/*  45 */     boolean inMLC = false;
/*  46 */     int mlcStart = 0;
/*     */ 
/*     */     
/*     */     try {
/*  50 */       for (int line = 0; line < lineCount; line++)
/*     */       {
/*  52 */         Token t = textArea.getTokenListForLine(line);
/*  53 */         while (t != null && t.isPaintable())
/*     */         {
/*  55 */           if (t.isComment()) {
/*     */ 
/*     */             
/*  58 */             if (inMLC) {
/*     */               
/*  60 */               if (t.endsWith(MLC_END)) {
/*  61 */                 int mlcEnd = t.getEndOffset() - 1;
/*  62 */                 if (currentFold == null) {
/*  63 */                   currentFold = new Fold(1, textArea, mlcStart);
/*  64 */                   currentFold.setEndOffset(mlcEnd);
/*  65 */                   folds.add(currentFold);
/*  66 */                   currentFold = null;
/*     */                 } else {
/*     */                   
/*  69 */                   currentFold = currentFold.createChild(1, mlcStart);
/*  70 */                   currentFold.setEndOffset(mlcEnd);
/*  71 */                   currentFold = currentFold.getParent();
/*     */                 } 
/*  73 */                 inMLC = false;
/*  74 */                 mlcStart = 0;
/*     */ 
/*     */               
/*     */               }
/*     */ 
/*     */ 
/*     */             
/*     */             }
/*  82 */             else if (t.getType() == 2 && !t.endsWith(MLC_END)) {
/*  83 */               inMLC = true;
/*  84 */               mlcStart = t.getOffset();
/*     */             
/*     */             }
/*     */ 
/*     */           
/*     */           }
/*  90 */           else if (t.isSingleChar(25, '<')) {
/*  91 */             if (currentFold == null) {
/*  92 */               currentFold = new Fold(0, textArea, t.getOffset());
/*  93 */               folds.add(currentFold);
/*     */             } else {
/*     */               
/*  96 */               currentFold = currentFold.createChild(0, t.getOffset());
/*     */             }
/*     */           
/*     */           }
/* 100 */           else if (t.is(25, MARKUP_SHORT_TAG_END)) {
/* 101 */             if (currentFold != null) {
/* 102 */               Fold parentFold = currentFold.getParent();
/* 103 */               removeFold(currentFold, folds);
/* 104 */               currentFold = parentFold;
/*     */             }
/*     */           
/*     */           }
/* 108 */           else if (t.is(25, MARKUP_CLOSING_TAG_START) && 
/* 109 */             currentFold != null) {
/* 110 */             currentFold.setEndOffset(t.getOffset());
/* 111 */             Fold parentFold = currentFold.getParent();
/*     */             
/* 113 */             if (currentFold.isOnSingleLine()) {
/* 114 */               removeFold(currentFold, folds);
/*     */             }
/* 116 */             currentFold = parentFold;
/*     */           } 
/*     */ 
/*     */           
/* 120 */           t = t.getNextToken();
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 126 */     catch (BadLocationException ble) {
/* 127 */       ble.printStackTrace();
/*     */     } 
/*     */     
/* 130 */     return folds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void removeFold(Fold fold, List<Fold> folds) {
/* 144 */     if (!fold.removeFromParent())
/* 145 */       folds.remove(folds.size() - 1); 
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/folding/XmlFoldParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */