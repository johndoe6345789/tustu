package org.fife.ui.rsyntaxtextarea.folding;

import java.util.List;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;

public interface FoldParser {
  List<Fold> getFolds(RSyntaxTextArea paramRSyntaxTextArea);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/folding/FoldParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */