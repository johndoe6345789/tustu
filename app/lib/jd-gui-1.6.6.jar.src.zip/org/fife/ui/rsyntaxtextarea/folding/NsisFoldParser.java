/*     */ package org.fife.ui.rsyntaxtextarea.folding;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
/*     */ import org.fife.ui.rsyntaxtextarea.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NsisFoldParser
/*     */   implements FoldParser
/*     */ {
/*  33 */   private static final char[] KEYWORD_FUNCTION = "Function".toCharArray();
/*  34 */   private static final char[] KEYWORD_FUNCTION_END = "FunctionEnd".toCharArray();
/*  35 */   private static final char[] KEYWORD_SECTION = "Section".toCharArray();
/*  36 */   private static final char[] KEYWORD_SECTION_END = "SectionEnd".toCharArray();
/*     */   
/*  38 */   protected static final char[] C_MLC_END = "*/".toCharArray();
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean foundEndKeyword(char[] keyword, Token t, Stack<char[]> endWordStack) {
/*  43 */     return (t.is(6, keyword) && !endWordStack.isEmpty() && keyword == endWordStack
/*  44 */       .peek());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Fold> getFolds(RSyntaxTextArea textArea) {
/*  54 */     List<Fold> folds = new ArrayList<>();
/*     */     
/*  56 */     Fold currentFold = null;
/*  57 */     int lineCount = textArea.getLineCount();
/*  58 */     boolean inMLC = false;
/*  59 */     int mlcStart = 0;
/*  60 */     Stack<char[]> endWordStack = (Stack)new Stack<>();
/*     */ 
/*     */     
/*     */     try {
/*  64 */       for (int line = 0; line < lineCount; line++)
/*     */       {
/*  66 */         Token t = textArea.getTokenListForLine(line);
/*  67 */         while (t != null && t.isPaintable())
/*     */         {
/*  69 */           if (t.isComment()) {
/*     */             
/*  71 */             if (inMLC)
/*     */             {
/*     */               
/*  74 */               if (t.endsWith(C_MLC_END)) {
/*  75 */                 int mlcEnd = t.getEndOffset() - 1;
/*  76 */                 if (currentFold == null) {
/*  77 */                   currentFold = new Fold(1, textArea, mlcStart);
/*  78 */                   currentFold.setEndOffset(mlcEnd);
/*  79 */                   folds.add(currentFold);
/*  80 */                   currentFold = null;
/*     */                 } else {
/*     */                   
/*  83 */                   currentFold = currentFold.createChild(1, mlcStart);
/*  84 */                   currentFold.setEndOffset(mlcEnd);
/*  85 */                   currentFold = currentFold.getParent();
/*     */                 } 
/*     */                 
/*  88 */                 inMLC = false;
/*  89 */                 mlcStart = 0;
/*     */ 
/*     */               
/*     */               }
/*     */ 
/*     */             
/*     */             }
/*  96 */             else if (t.getType() != 1 && !t.endsWith(C_MLC_END))
/*     */             {
/*  98 */               inMLC = true;
/*  99 */               mlcStart = t.getOffset();
/*     */             
/*     */             }
/*     */ 
/*     */           
/*     */           }
/* 105 */           else if (t.is(6, KEYWORD_SECTION)) {
/* 106 */             if (currentFold == null) {
/* 107 */               currentFold = new Fold(0, textArea, t.getOffset());
/* 108 */               folds.add(currentFold);
/*     */             } else {
/*     */               
/* 111 */               currentFold = currentFold.createChild(0, t.getOffset());
/*     */             } 
/* 113 */             endWordStack.push(KEYWORD_SECTION_END);
/*     */           
/*     */           }
/* 116 */           else if (t.is(6, KEYWORD_FUNCTION)) {
/* 117 */             if (currentFold == null) {
/* 118 */               currentFold = new Fold(0, textArea, t.getOffset());
/* 119 */               folds.add(currentFold);
/*     */             } else {
/*     */               
/* 122 */               currentFold = currentFold.createChild(0, t.getOffset());
/*     */             } 
/* 124 */             endWordStack.push(KEYWORD_FUNCTION_END);
/*     */           
/*     */           }
/* 127 */           else if ((foundEndKeyword(KEYWORD_SECTION_END, t, endWordStack) || 
/* 128 */             foundEndKeyword(KEYWORD_FUNCTION_END, t, endWordStack)) && 
/* 129 */             currentFold != null) {
/* 130 */             currentFold.setEndOffset(t.getOffset());
/* 131 */             Fold parentFold = currentFold.getParent();
/* 132 */             endWordStack.pop();
/*     */             
/* 134 */             if (currentFold.isOnSingleLine() && 
/* 135 */               !currentFold.removeFromParent()) {
/* 136 */               folds.remove(folds.size() - 1);
/*     */             }
/*     */             
/* 139 */             currentFold = parentFold;
/*     */           } 
/*     */ 
/*     */           
/* 143 */           t = t.getNextToken();
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 149 */     catch (BadLocationException ble) {
/* 150 */       ble.printStackTrace();
/*     */     } 
/*     */     
/* 153 */     return folds;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/folding/NsisFoldParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */