/*     */ package org.fife.ui.rsyntaxtextarea.folding;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
/*     */ import org.fife.ui.rsyntaxtextarea.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YamlFoldParser
/*     */   implements FoldParser
/*     */ {
/*     */   private static boolean isSpaces(Token t) {
/*  37 */     String lexeme = t.getLexeme();
/*  38 */     return lexeme.trim().isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Fold> getFolds(RSyntaxTextArea textArea) {
/*  47 */     List<Fold> folds = new ArrayList<>();
/*  48 */     Stack<Integer> indentStack = new Stack<>();
/*     */     
/*  50 */     Fold currentFold = null;
/*  51 */     int lineCount = textArea.getLineCount();
/*     */ 
/*     */     
/*  54 */     int lastOffset = 0;
/*     */ 
/*     */     
/*     */     try {
/*  58 */       for (int line = 0; line < lineCount; line++)
/*     */       {
/*  60 */         Token t = textArea.getTokenListForLine(line);
/*  61 */         Token startLine = t;
/*  62 */         int offset = t.getOffset();
/*     */ 
/*     */         
/*  65 */         int indent = 0;
/*  66 */         while (t != null && t.isPaintable() && isSpaces(t)) {
/*  67 */           indent += t.length();
/*  68 */           t = t.getNextToken();
/*     */         } 
/*  70 */         if (t != null && t.isPaintable() && t.isSingleChar('-')) {
/*  71 */           indent++;
/*  72 */           t = t.getNextToken();
/*     */         } 
/*     */         
/*  75 */         while (!indentStack.empty()) {
/*  76 */           int outer = ((Integer)indentStack.peek()).intValue();
/*  77 */           if (outer >= indent && currentFold != null) {
/*  78 */             currentFold.setEndOffset(lastOffset);
/*  79 */             Fold parentFold = currentFold.getParent();
/*     */             
/*  81 */             if (currentFold.isOnSingleLine()) {
/*  82 */               removeFold(currentFold, folds);
/*     */             }
/*  84 */             currentFold = parentFold;
/*  85 */             indentStack.pop();
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  92 */         while (t != null && t.isPaintable()) {
/*  93 */           offset = t.getOffset();
/*  94 */           t = t.getNextToken();
/*     */         } 
/*  96 */         lastOffset = offset;
/*     */         
/*  98 */         if (currentFold == null) {
/*  99 */           currentFold = new Fold(0, textArea, startLine.getOffset());
/* 100 */           folds.add(currentFold);
/*     */         } else {
/* 102 */           currentFold = currentFold.createChild(0, startLine.getOffset());
/*     */         } 
/* 104 */         indentStack.push(Integer.valueOf(indent));
/*     */       }
/*     */     
/*     */     }
/* 108 */     catch (BadLocationException ble) {
/* 109 */       ble.printStackTrace();
/*     */     } 
/*     */     
/* 112 */     return folds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void removeFold(Fold fold, List<Fold> folds) {
/* 127 */     if (!fold.removeFromParent())
/* 128 */       folds.remove(folds.size() - 1); 
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/folding/YamlFoldParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */