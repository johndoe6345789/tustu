/*     */ package org.fife.ui.rsyntaxtextarea.folding;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
/*     */ import org.fife.ui.rsyntaxtextarea.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HtmlFoldParser
/*     */   implements FoldParser
/*     */ {
/*     */   public static final int LANGUAGE_HTML = -1;
/*     */   public static final int LANGUAGE_PHP = 0;
/*     */   public static final int LANGUAGE_JSP = 1;
/*     */   private final int language;
/*     */   private static final Set<String> FOLDABLE_TAGS;
/*  61 */   private static final char[] MARKUP_CLOSING_TAG_START = "</".toCharArray();
/*     */   
/*  63 */   private static final char[] MLC_START = "<!--".toCharArray();
/*  64 */   private static final char[] MLC_END = "-->".toCharArray();
/*     */   
/*  66 */   private static final char[] PHP_START = "<?".toCharArray();
/*  67 */   private static final char[] PHP_END = "?>".toCharArray();
/*     */ 
/*     */   
/*  70 */   private static final char[] JSP_START = "<%".toCharArray();
/*  71 */   private static final char[] JSP_END = "%>".toCharArray();
/*     */   
/*  73 */   private static final char[][] LANG_START = new char[][] { PHP_START, JSP_START };
/*  74 */   private static final char[][] LANG_END = new char[][] { PHP_END, JSP_END };
/*     */   
/*  76 */   private static final char[] JSP_COMMENT_START = "<%--".toCharArray();
/*  77 */   private static final char[] JSP_COMMENT_END = "--%>".toCharArray();
/*     */   
/*     */   static {
/*  80 */     FOLDABLE_TAGS = new HashSet<>();
/*  81 */     FOLDABLE_TAGS.add("body");
/*  82 */     FOLDABLE_TAGS.add("canvas");
/*  83 */     FOLDABLE_TAGS.add("div");
/*  84 */     FOLDABLE_TAGS.add("form");
/*  85 */     FOLDABLE_TAGS.add("head");
/*  86 */     FOLDABLE_TAGS.add("html");
/*  87 */     FOLDABLE_TAGS.add("ol");
/*  88 */     FOLDABLE_TAGS.add("pre");
/*  89 */     FOLDABLE_TAGS.add("script");
/*  90 */     FOLDABLE_TAGS.add("span");
/*  91 */     FOLDABLE_TAGS.add("style");
/*  92 */     FOLDABLE_TAGS.add("table");
/*  93 */     FOLDABLE_TAGS.add("tfoot");
/*  94 */     FOLDABLE_TAGS.add("thead");
/*  95 */     FOLDABLE_TAGS.add("tr");
/*  96 */     FOLDABLE_TAGS.add("td");
/*  97 */     FOLDABLE_TAGS.add("ul");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HtmlFoldParser(int language) {
/* 107 */     if (language < -1 && language > 1) {
/* 108 */       throw new IllegalArgumentException("Invalid language: " + language);
/*     */     }
/* 110 */     this.language = language;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Fold> getFolds(RSyntaxTextArea textArea) {
/* 120 */     List<Fold> folds = new ArrayList<>();
/* 121 */     Stack<String> tagNameStack = new Stack<>();
/* 122 */     boolean inSublanguage = false;
/*     */     
/* 124 */     Fold currentFold = null;
/* 125 */     int lineCount = textArea.getLineCount();
/* 126 */     boolean inMLC = false;
/* 127 */     boolean inJSMLC = false;
/* 128 */     TagCloseInfo tci = new TagCloseInfo();
/*     */ 
/*     */     
/*     */     try {
/* 132 */       for (int line = 0; line < lineCount; line++)
/*     */       {
/* 134 */         Token t = textArea.getTokenListForLine(line);
/* 135 */         while (t != null && t.isPaintable())
/*     */         {
/*     */ 
/*     */           
/* 139 */           if (this.language >= 0 && t.getType() == 22)
/*     */           {
/*     */             
/* 142 */             if (t.startsWith(LANG_START[this.language])) {
/* 143 */               if (currentFold == null) {
/* 144 */                 currentFold = new Fold(0, textArea, t.getOffset());
/* 145 */                 folds.add(currentFold);
/*     */               } else {
/*     */                 
/* 148 */                 currentFold = currentFold.createChild(0, t.getOffset());
/*     */               } 
/* 150 */               inSublanguage = true;
/*     */ 
/*     */             
/*     */             }
/* 154 */             else if (t.startsWith(LANG_END[this.language]) && currentFold != null) {
/* 155 */               int phpEnd = t.getEndOffset() - 1;
/* 156 */               currentFold.setEndOffset(phpEnd);
/* 157 */               Fold parentFold = currentFold.getParent();
/*     */               
/* 159 */               if (currentFold.isOnSingleLine()) {
/* 160 */                 removeFold(currentFold, folds);
/*     */               }
/* 162 */               currentFold = parentFold;
/* 163 */               inSublanguage = false;
/* 164 */               t = t.getNextToken();
/*     */               
/*     */               continue;
/*     */             } 
/*     */           }
/*     */           
/* 170 */           if (!inSublanguage)
/*     */           {
/* 172 */             if (t.getType() == 2) {
/*     */ 
/*     */               
/* 175 */               if (inMLC) {
/*     */                 
/* 177 */                 if (t.endsWith(MLC_END)) {
/* 178 */                   int mlcEnd = t.getEndOffset() - 1;
/* 179 */                   currentFold.setEndOffset(mlcEnd);
/* 180 */                   Fold parentFold = currentFold.getParent();
/*     */                   
/* 182 */                   if (currentFold.isOnSingleLine()) {
/* 183 */                     removeFold(currentFold, folds);
/*     */                   }
/* 185 */                   currentFold = parentFold;
/* 186 */                   inMLC = false;
/*     */ 
/*     */                 
/*     */                 }
/*     */ 
/*     */               
/*     */               }
/* 193 */               else if (inJSMLC) {
/*     */                 
/* 195 */                 if (t.endsWith(JSP_COMMENT_END)) {
/* 196 */                   int mlcEnd = t.getEndOffset() - 1;
/* 197 */                   currentFold.setEndOffset(mlcEnd);
/* 198 */                   Fold parentFold = currentFold.getParent();
/*     */                   
/* 200 */                   if (currentFold.isOnSingleLine()) {
/* 201 */                     removeFold(currentFold, folds);
/*     */                   }
/* 203 */                   currentFold = parentFold;
/* 204 */                   inJSMLC = false;
/*     */ 
/*     */                 
/*     */                 }
/*     */ 
/*     */               
/*     */               }
/* 211 */               else if (t.startsWith(MLC_START) && !t.endsWith(MLC_END)) {
/* 212 */                 if (currentFold == null) {
/* 213 */                   currentFold = new Fold(1, textArea, t.getOffset());
/* 214 */                   folds.add(currentFold);
/*     */                 } else {
/*     */                   
/* 217 */                   currentFold = currentFold.createChild(1, t.getOffset());
/*     */                 } 
/* 219 */                 inMLC = true;
/*     */ 
/*     */               
/*     */               }
/* 223 */               else if (this.language == 1 && t
/* 224 */                 .startsWith(JSP_COMMENT_START) && 
/* 225 */                 !t.endsWith(JSP_COMMENT_END)) {
/* 226 */                 if (currentFold == null) {
/* 227 */                   currentFold = new Fold(1, textArea, t.getOffset());
/* 228 */                   folds.add(currentFold);
/*     */                 } else {
/*     */                   
/* 231 */                   currentFold = currentFold.createChild(1, t.getOffset());
/*     */                 } 
/* 233 */                 inJSMLC = true;
/*     */               
/*     */               }
/*     */ 
/*     */             
/*     */             }
/* 239 */             else if (t.isSingleChar(25, '<')) {
/* 240 */               Token tagStartToken = t;
/* 241 */               Token tagNameToken = t.getNextToken();
/* 242 */               if (isFoldableTag(tagNameToken)) {
/* 243 */                 int newLine = getTagCloseInfo(tagNameToken, textArea, line, tci);
/* 244 */                 if (tci.line == -1) {
/* 245 */                   return folds;
/*     */                 }
/*     */ 
/*     */                 
/* 249 */                 Token tagCloseToken = tci.closeToken;
/* 250 */                 if (tagCloseToken.isSingleChar(25, '>')) {
/* 251 */                   if (currentFold == null) {
/*     */                     
/* 253 */                     currentFold = new Fold(0, textArea, tagStartToken.getOffset());
/* 254 */                     folds.add(currentFold);
/*     */                   } else {
/*     */                     
/* 257 */                     currentFold = currentFold.createChild(0, tagStartToken
/* 258 */                         .getOffset());
/*     */                   } 
/* 260 */                   tagNameStack.push(tagNameToken.getLexeme());
/*     */                 } 
/* 262 */                 t = tagCloseToken;
/* 263 */                 line = newLine;
/*     */               
/*     */               }
/*     */             
/*     */             }
/* 268 */             else if (t.is(25, MARKUP_CLOSING_TAG_START) && 
/* 269 */               currentFold != null) {
/* 270 */               Token tagNameToken = t.getNextToken();
/* 271 */               if (isFoldableTag(tagNameToken) && 
/* 272 */                 isEndOfLastFold(tagNameStack, tagNameToken)) {
/* 273 */                 tagNameStack.pop();
/* 274 */                 currentFold.setEndOffset(t.getOffset());
/* 275 */                 Fold parentFold = currentFold.getParent();
/*     */                 
/* 277 */                 if (currentFold.isOnSingleLine()) {
/* 278 */                   removeFold(currentFold, folds);
/*     */                 }
/* 280 */                 currentFold = parentFold;
/* 281 */                 t = tagNameToken;
/*     */               } 
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 288 */           t = t.getNextToken();
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 294 */     catch (BadLocationException ble) {
/* 295 */       ble.printStackTrace();
/*     */     } 
/*     */     
/* 298 */     return folds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getTagCloseInfo(Token tagNameToken, RSyntaxTextArea textArea, int line, TagCloseInfo info) {
/* 319 */     info.reset();
/* 320 */     Token t = tagNameToken.getNextToken();
/*     */ 
/*     */     
/*     */     while (true) {
/* 324 */       if (t != null && t.getType() != 25) {
/* 325 */         t = t.getNextToken();
/*     */         continue;
/*     */       } 
/* 328 */       if (t != null) {
/* 329 */         info.closeToken = t;
/* 330 */         info.line = line;
/*     */         
/*     */         break;
/*     */       } 
/* 334 */       if (++line >= textArea.getLineCount() || (
/* 335 */         t = textArea.getTokenListForLine(line)) == null)
/*     */         break; 
/* 337 */     }  return line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isEndOfLastFold(Stack<String> tagNameStack, Token tagNameToken) {
/* 353 */     if (tagNameToken != null && !tagNameStack.isEmpty()) {
/* 354 */       return tagNameToken.getLexeme().equalsIgnoreCase(tagNameStack.peek());
/*     */     }
/* 356 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isFoldableTag(Token tagNameToken) {
/* 367 */     return (tagNameToken != null && FOLDABLE_TAGS
/* 368 */       .contains(tagNameToken.getLexeme().toLowerCase()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void removeFold(Fold fold, List<Fold> folds) {
/* 381 */     if (!fold.removeFromParent()) {
/* 382 */       folds.remove(folds.size() - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class TagCloseInfo
/*     */   {
/*     */     private Token closeToken;
/*     */     
/*     */     private int line;
/*     */ 
/*     */     
/*     */     private TagCloseInfo() {}
/*     */     
/*     */     public void reset() {
/* 397 */       this.closeToken = null;
/* 398 */       this.line = -1;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 403 */       return "[TagCloseInfo: closeToken=" + this.closeToken + ", line=" + this.line + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/folding/HtmlFoldParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */