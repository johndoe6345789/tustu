/*     */ package org.fife.ui.rsyntaxtextarea.folding;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FoldParserManager
/*     */   implements SyntaxConstants
/*     */ {
/*  35 */   private static final FoldParserManager INSTANCE = new FoldParserManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   private Map<String, FoldParser> foldParserMap = createFoldParserMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFoldParserMapping(String syntaxStyle, FoldParser parser) {
/*  59 */     this.foldParserMap.put(syntaxStyle, parser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, FoldParser> createFoldParserMap() {
/*  70 */     Map<String, FoldParser> map = new HashMap<>();
/*     */     
/*  72 */     map.put("text/c", new CurlyFoldParser());
/*  73 */     map.put("text/cpp", new CurlyFoldParser());
/*  74 */     map.put("text/cs", new CurlyFoldParser());
/*  75 */     map.put("text/clojure", new LispFoldParser());
/*  76 */     map.put("text/css", new CurlyFoldParser());
/*  77 */     map.put("text/d", new CurlyFoldParser());
/*  78 */     map.put("text/dart", new CurlyFoldParser());
/*  79 */     map.put("text/golang", new CurlyFoldParser());
/*  80 */     map.put("text/groovy", new CurlyFoldParser());
/*  81 */     map.put("text/htaccess", new XmlFoldParser());
/*  82 */     map.put("text/html", new HtmlFoldParser(-1));
/*  83 */     map.put("text/java", new CurlyFoldParser(true, true));
/*  84 */     map.put("text/javascript", new CurlyFoldParser());
/*  85 */     map.put("text/json", new JsonFoldParser());
/*  86 */     map.put("text/jshintrc", new JsonFoldParser());
/*  87 */     map.put("text/jsp", new HtmlFoldParser(1));
/*  88 */     map.put("text/latex", new LatexFoldParser());
/*  89 */     map.put("text/less", new CurlyFoldParser());
/*  90 */     map.put("text/lisp", new LispFoldParser());
/*  91 */     map.put("text/mxml", new XmlFoldParser());
/*  92 */     map.put("text/nsis", new NsisFoldParser());
/*  93 */     map.put("text/perl", new CurlyFoldParser());
/*  94 */     map.put("text/php", new HtmlFoldParser(0));
/*  95 */     map.put("text/scala", new CurlyFoldParser());
/*  96 */     map.put("text/typescript", new CurlyFoldParser());
/*  97 */     map.put("text/xml", new XmlFoldParser());
/*  98 */     map.put("text/yaml", new YamlFoldParser());
/*     */     
/* 100 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FoldParserManager get() {
/* 111 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FoldParser getFoldParser(String syntaxStyle) {
/* 125 */     return this.foldParserMap.get(syntaxStyle);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/folding/FoldParserManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */