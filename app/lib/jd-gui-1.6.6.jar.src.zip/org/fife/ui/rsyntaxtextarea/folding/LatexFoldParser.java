/*     */ package org.fife.ui.rsyntaxtextarea.folding;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
/*     */ import org.fife.ui.rsyntaxtextarea.Token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LatexFoldParser
/*     */   implements FoldParser
/*     */ {
/*  29 */   private static final char[] BEGIN = "\\begin".toCharArray();
/*  30 */   private static final char[] END = "\\end".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Fold> getFolds(RSyntaxTextArea textArea) {
/*  39 */     List<Fold> folds = new ArrayList<>();
/*  40 */     Stack<String> expectedStack = new Stack<>();
/*     */     
/*  42 */     Fold currentFold = null;
/*  43 */     int lineCount = textArea.getLineCount();
/*     */ 
/*     */     
/*     */     try {
/*  47 */       for (int line = 0; line < lineCount; line++)
/*     */       {
/*  49 */         Token t = textArea.getTokenListForLine(line);
/*  50 */         while (t != null && t.isPaintable())
/*     */         {
/*  52 */           if (t.is(6, BEGIN)) {
/*  53 */             Token temp = t.getNextToken();
/*  54 */             if (temp != null && temp.isLeftCurly()) {
/*  55 */               temp = temp.getNextToken();
/*  56 */               if (temp != null && temp.getType() == 6) {
/*  57 */                 if (currentFold == null) {
/*  58 */                   currentFold = new Fold(0, textArea, t.getOffset());
/*  59 */                   folds.add(currentFold);
/*     */                 } else {
/*     */                   
/*  62 */                   currentFold = currentFold.createChild(0, t.getOffset());
/*     */                 } 
/*  64 */                 expectedStack.push(temp.getLexeme());
/*  65 */                 t = temp;
/*     */               }
/*     */             
/*     */             }
/*     */           
/*  70 */           } else if (t.is(6, END) && currentFold != null && 
/*  71 */             !expectedStack.isEmpty()) {
/*  72 */             Token temp = t.getNextToken();
/*  73 */             if (temp != null && temp.isLeftCurly()) {
/*  74 */               temp = temp.getNextToken();
/*  75 */               if (temp != null && temp.getType() == 6) {
/*  76 */                 String value = temp.getLexeme();
/*  77 */                 if (((String)expectedStack.peek()).equals(value)) {
/*  78 */                   expectedStack.pop();
/*  79 */                   currentFold.setEndOffset(t.getOffset());
/*  80 */                   Fold parentFold = currentFold.getParent();
/*     */                   
/*  82 */                   if (currentFold.isOnSingleLine() && 
/*  83 */                     !currentFold.removeFromParent()) {
/*  84 */                     folds.remove(folds.size() - 1);
/*     */                   }
/*     */                   
/*  87 */                   t = temp;
/*  88 */                   currentFold = parentFold;
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/*  94 */           t = t.getNextToken();
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 100 */     catch (BadLocationException ble) {
/* 101 */       ble.printStackTrace();
/*     */     } 
/*     */     
/* 104 */     return folds;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/folding/LatexFoldParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */