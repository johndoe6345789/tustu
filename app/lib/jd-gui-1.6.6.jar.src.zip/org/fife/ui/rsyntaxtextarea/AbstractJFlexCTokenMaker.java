/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import org.fife.ui.rtextarea.RTextArea;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJFlexCTokenMaker
/*     */   extends AbstractJFlexTokenMaker
/*     */ {
/*  39 */   private static final Pattern MLC_PATTERN = Pattern.compile("([ \\t]*)(/?[\\*]+)([ \\t]*)");
/*     */ 
/*     */ 
/*     */   
/*  43 */   private final Action INSERT_BREAK_ACTION = createInsertBreakAction();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Action createInsertBreakAction() {
/*  56 */     return new CStyleInsertBreakAction();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getCurlyBracesDenoteCodeBlocks(int languageIndex) {
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Action getInsertBreakAction() {
/*  81 */     return this.INSERT_BREAK_ACTION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getMarkOccurrencesOfTokenType(int type) {
/*  90 */     return (type == 20 || type == 8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getShouldIndentNextLineAfter(Token t) {
/*  99 */     if (t != null && t.length() == 1) {
/* 100 */       char ch = t.charAt(0);
/* 101 */       return (ch == '{' || ch == '(');
/*     */     } 
/* 103 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isInternalEolTokenForMLCs(Token t) {
/* 120 */     int type = t.getType();
/* 121 */     if (type < 0) {
/* 122 */       type = getClosestStandardTokenTypeForInternalType(type);
/* 123 */       return (type == 2 || type == 3);
/*     */     } 
/*     */     
/* 126 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class CStyleInsertBreakAction
/*     */     extends RSyntaxTextAreaEditorKit.InsertBreakAction
/*     */   {
/*     */     public void actionPerformedImpl(ActionEvent e, RTextArea textArea) {
/* 140 */       if (!textArea.isEditable() || !textArea.isEnabled()) {
/* 141 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/*     */         
/*     */         return;
/*     */       } 
/* 145 */       RSyntaxTextArea rsta = (RSyntaxTextArea)getTextComponent(e);
/* 146 */       RSyntaxDocument doc = (RSyntaxDocument)rsta.getDocument();
/*     */       
/* 148 */       int line = textArea.getCaretLineNumber();
/* 149 */       int type = doc.getLastTokenTypeOnLine(line);
/* 150 */       if (type < 0) {
/* 151 */         type = doc.getClosestStandardTokenTypeForInternalType(type);
/*     */       }
/*     */ 
/*     */       
/* 155 */       if (type == 3 || type == 2) {
/*     */         
/* 157 */         insertBreakInMLC(e, rsta, line);
/*     */       } else {
/*     */         
/* 160 */         handleInsertBreak(rsta, true);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean appearsNested(RSyntaxTextArea textArea, int line, int offs) {
/* 181 */       int firstLine = line;
/*     */       
/* 183 */       while (line < textArea.getLineCount()) {
/* 184 */         Token t = textArea.getTokenListForLine(line);
/* 185 */         int i = 0;
/*     */         
/* 187 */         if (line++ == firstLine) {
/* 188 */           t = RSyntaxUtilities.getTokenAtOffset(t, offs);
/* 189 */           if (t == null) {
/*     */             continue;
/*     */           }
/* 192 */           i = t.documentToToken(offs);
/*     */         } else {
/*     */           
/* 195 */           i = t.getTextOffset();
/*     */         } 
/* 197 */         int textOffset = t.getTextOffset();
/* 198 */         while (i < textOffset + t.length() - 1) {
/* 199 */           if (t.charAt(i - textOffset) == '/' && t.charAt(i - textOffset + 1) == '*') {
/* 200 */             return true;
/*     */           }
/* 202 */           i++;
/*     */         } 
/*     */         
/* 205 */         if ((t = t.getNextToken()) != null && !AbstractJFlexCTokenMaker.this.isInternalEolTokenForMLCs(t)) {
/* 206 */           return false;
/*     */         }
/*     */       } 
/*     */       
/* 210 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void insertBreakInMLC(ActionEvent e, RSyntaxTextArea textArea, int line) {
/* 217 */       Matcher m = null;
/* 218 */       int start = -1;
/* 219 */       int end = -1;
/* 220 */       String text = null;
/*     */       try {
/* 222 */         start = textArea.getLineStartOffset(line);
/* 223 */         end = textArea.getLineEndOffset(line);
/* 224 */         text = textArea.getText(start, end - start);
/* 225 */         m = AbstractJFlexCTokenMaker.MLC_PATTERN.matcher(text);
/* 226 */       } catch (BadLocationException ble) {
/* 227 */         UIManager.getLookAndFeel().provideErrorFeedback(textArea);
/* 228 */         ble.printStackTrace();
/*     */         
/*     */         return;
/*     */       } 
/* 232 */       if (m.lookingAt()) {
/*     */         
/* 234 */         String leadingWS = m.group(1);
/* 235 */         String mlcMarker = m.group(2);
/*     */ 
/*     */ 
/*     */         
/* 239 */         int dot = textArea.getCaretPosition();
/* 240 */         if (dot >= start && dot < start + leadingWS
/* 241 */           .length() + mlcMarker.length()) {
/*     */ 
/*     */           
/* 244 */           if (mlcMarker.charAt(0) == '/') {
/* 245 */             handleInsertBreak(textArea, true);
/*     */             return;
/*     */           } 
/* 248 */           textArea.setCaretPosition(end - 1);
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 254 */           boolean moved = false;
/* 255 */           while (dot < end - 1 && 
/* 256 */             Character.isWhitespace(text.charAt(dot - start))) {
/* 257 */             moved = true;
/* 258 */             dot++;
/*     */           } 
/* 260 */           if (moved) {
/* 261 */             textArea.setCaretPosition(dot);
/*     */           }
/*     */         } 
/*     */         
/* 265 */         boolean firstMlcLine = (mlcMarker.charAt(0) == '/');
/* 266 */         boolean nested = appearsNested(textArea, line, start + leadingWS
/* 267 */             .length() + 2);
/*     */ 
/*     */         
/* 270 */         String header = leadingWS + (firstMlcLine ? " * " : "*") + m.group(3);
/* 271 */         textArea.replaceSelection("\n" + header);
/* 272 */         if (nested) {
/* 273 */           dot = textArea.getCaretPosition();
/* 274 */           textArea.insert("\n" + leadingWS + " */", dot);
/* 275 */           textArea.setCaretPosition(dot);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 280 */         handleInsertBreak(textArea, true);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/AbstractJFlexCTokenMaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */