package org.fife.ui.rsyntaxtextarea;

public interface TokenOrientedView {
  Token getTokenListForPhysicalLineAbove(int paramInt);
  
  Token getTokenListForPhysicalLineBelow(int paramInt);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/TokenOrientedView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */