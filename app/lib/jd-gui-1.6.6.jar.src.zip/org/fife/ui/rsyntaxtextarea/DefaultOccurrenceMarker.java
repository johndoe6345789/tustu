/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Caret;
/*     */ import org.fife.ui.rtextarea.SmartHighlightPainter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultOccurrenceMarker
/*     */   implements OccurrenceMarker
/*     */ {
/*     */   public Token getTokenToMark(RSyntaxTextArea textArea) {
/*  35 */     int line = textArea.getCaretLineNumber();
/*  36 */     Token tokenList = textArea.getTokenListForLine(line);
/*  37 */     Caret c = textArea.getCaret();
/*  38 */     int dot = c.getDot();
/*     */     
/*  40 */     Token t = RSyntaxUtilities.getTokenAtOffset(tokenList, dot);
/*  41 */     if (t == null || !isValidType(textArea, t) || 
/*  42 */       RSyntaxUtilities.isNonWordChar(t)) {
/*     */       
/*  44 */       dot--;
/*     */       try {
/*  46 */         if (dot >= textArea.getLineStartOffset(line)) {
/*  47 */           t = RSyntaxUtilities.getTokenAtOffset(tokenList, dot);
/*     */         }
/*  49 */       } catch (BadLocationException ble) {
/*  50 */         ble.printStackTrace();
/*     */       } 
/*     */     } 
/*     */     
/*  54 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidType(RSyntaxTextArea textArea, Token t) {
/*  64 */     return textArea.getMarkOccurrencesOfTokenType(t.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markOccurrences(RSyntaxDocument doc, Token t, RSyntaxTextAreaHighlighter h, SmartHighlightPainter p) {
/*  74 */     markOccurrencesOfToken(doc, t, h, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void markOccurrencesOfToken(RSyntaxDocument doc, Token t, RSyntaxTextAreaHighlighter h, SmartHighlightPainter p) {
/*  90 */     char[] lexeme = t.getLexeme().toCharArray();
/*  91 */     int type = t.getType();
/*  92 */     int lineCount = doc.getDefaultRootElement().getElementCount();
/*     */     
/*  94 */     for (int i = 0; i < lineCount; i++) {
/*  95 */       Token temp = doc.getTokenListForLine(i);
/*  96 */       while (temp != null && temp.isPaintable()) {
/*  97 */         if (temp.is(type, lexeme)) {
/*     */           try {
/*  99 */             int end = temp.getEndOffset();
/* 100 */             h.addMarkedOccurrenceHighlight(temp.getOffset(), end, p);
/* 101 */           } catch (BadLocationException ble) {
/* 102 */             ble.printStackTrace();
/*     */           } 
/*     */         }
/* 105 */         temp = temp.getNextToken();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/DefaultOccurrenceMarker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */