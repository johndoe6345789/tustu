/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import javax.swing.text.TabExpander;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class VisibleWhitespaceTokenPainter
/*     */   extends DefaultTokenPainter
/*     */ {
/*     */   protected float paintImpl(Token token, Graphics2D g, float x, float y, RSyntaxTextArea host, TabExpander e, float clipStart, boolean selected, boolean useSTC) {
/*  59 */     int origX = (int)x;
/*  60 */     int textOffs = token.getTextOffset();
/*  61 */     char[] text = token.getTextArray();
/*  62 */     int end = textOffs + token.length();
/*  63 */     float nextX = x;
/*  64 */     int flushLen = 0;
/*  65 */     int flushIndex = textOffs;
/*     */     
/*  67 */     Color fg = useSTC ? host.getSelectedTextColor() : host.getForegroundForToken(token);
/*  68 */     Color bg = selected ? null : host.getBackgroundForToken(token);
/*  69 */     g.setFont(host.getFontForTokenType(token.getType()));
/*  70 */     FontMetrics fm = host.getFontMetricsForTokenType(token.getType());
/*     */     
/*  72 */     int ascent = fm.getAscent();
/*  73 */     int height = fm.getHeight();
/*     */     
/*  75 */     for (int i = textOffs; i < end; i++) {
/*     */       float nextNextX; int halfHeight; int quarterHeight; int ymid; int width; int dotX; int dotY;
/*  77 */       switch (text[i]) {
/*     */ 
/*     */ 
/*     */         
/*     */         case '\t':
/*  82 */           nextX = x + fm.charsWidth(text, flushIndex, flushLen);
/*  83 */           nextNextX = e.nextTabStop(nextX, 0);
/*  84 */           if (bg != null) {
/*  85 */             paintBackground(x, y, nextNextX - x, height, g, ascent, host, bg);
/*     */           }
/*     */           
/*  88 */           g.setColor(fg);
/*     */ 
/*     */           
/*  91 */           if (flushLen > 0) {
/*  92 */             g.drawChars(text, flushIndex, flushLen, (int)x, (int)y);
/*  93 */             flushLen = 0;
/*     */           } 
/*  95 */           flushIndex = i + 1;
/*     */ 
/*     */           
/*  98 */           halfHeight = height / 2;
/*  99 */           quarterHeight = halfHeight / 2;
/* 100 */           ymid = (int)y - ascent + halfHeight;
/* 101 */           g.drawLine((int)nextX, ymid, (int)nextNextX, ymid);
/* 102 */           g.drawLine((int)nextNextX, ymid, (int)nextNextX - 4, ymid - quarterHeight);
/* 103 */           g.drawLine((int)nextNextX, ymid, (int)nextNextX - 4, ymid + quarterHeight);
/*     */           
/* 105 */           x = nextNextX;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case ' ':
/* 120 */           nextX = x + fm.charsWidth(text, flushIndex, flushLen + 1);
/* 121 */           width = fm.charWidth(' ');
/*     */ 
/*     */           
/* 124 */           if (bg != null) {
/* 125 */             paintBackground(x, y, nextX - x, height, g, ascent, host, bg);
/*     */           }
/*     */           
/* 128 */           g.setColor(fg);
/*     */ 
/*     */           
/* 131 */           if (flushLen > 0) {
/* 132 */             g.drawChars(text, flushIndex, flushLen, (int)x, (int)y);
/* 133 */             flushLen = 0;
/*     */           } 
/*     */ 
/*     */           
/* 137 */           dotX = (int)(nextX - width / 2.0F);
/* 138 */           dotY = (int)(y - ascent + height / 2.0F);
/* 139 */           g.drawLine(dotX, dotY, dotX, dotY);
/* 140 */           flushIndex = i + 1;
/* 141 */           x = nextX;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 150 */           flushLen++;
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 156 */     nextX = x + fm.charsWidth(text, flushIndex, flushLen);
/*     */     
/* 158 */     if (flushLen > 0 && nextX >= clipStart) {
/* 159 */       if (bg != null) {
/* 160 */         paintBackground(x, y, nextX - x, height, g, ascent, host, bg);
/*     */       }
/*     */       
/* 163 */       g.setColor(fg);
/* 164 */       g.drawChars(text, flushIndex, flushLen, (int)x, (int)y);
/*     */     } 
/*     */     
/* 167 */     if (host.getUnderlineForToken(token)) {
/* 168 */       g.setColor(fg);
/* 169 */       int y2 = (int)(y + 1.0F);
/* 170 */       g.drawLine(origX, y2, (int)nextX, y2);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     if (host.getPaintTabLines() && origX == (host.getMargin()).left) {
/* 177 */       paintTabLines(token, origX, (int)y, (int)nextX, g, e, host);
/*     */     }
/*     */     
/* 180 */     return nextX;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/VisibleWhitespaceTokenPainter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */