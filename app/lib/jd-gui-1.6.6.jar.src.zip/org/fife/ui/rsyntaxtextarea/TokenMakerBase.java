/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import javax.swing.Action;
/*     */ import javax.swing.text.Segment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TokenMakerBase
/*     */   implements TokenMaker
/*     */ {
/*  64 */   protected TokenImpl firstToken = this.currentToken = this.previousToken = null;
/*  65 */   private TokenFactory tokenFactory = new DefaultTokenFactory();
/*     */   
/*     */   protected TokenImpl currentToken;
/*     */   
/*     */   protected TokenImpl previousToken;
/*     */   private OccurrenceMarker occurrenceMarker;
/*     */   private int languageIndex;
/*     */   
/*     */   public void addNullToken() {
/*  74 */     if (this.firstToken == null) {
/*  75 */       this.firstToken = this.tokenFactory.createToken();
/*  76 */       this.currentToken = this.firstToken;
/*     */     } else {
/*     */       
/*  79 */       TokenImpl next = this.tokenFactory.createToken();
/*  80 */       this.currentToken.setNextToken(next);
/*  81 */       this.previousToken = this.currentToken;
/*  82 */       this.currentToken = next;
/*     */     } 
/*  84 */     this.currentToken.setLanguageIndex(this.languageIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addToken(Segment segment, int start, int end, int tokenType, int startOffset) {
/* 100 */     addToken(segment.array, start, end, tokenType, startOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addToken(char[] array, int start, int end, int tokenType, int startOffset) {
/* 110 */     addToken(array, start, end, tokenType, startOffset, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addToken(char[] array, int start, int end, int tokenType, int startOffset, boolean hyperlink) {
/* 128 */     if (this.firstToken == null) {
/* 129 */       this.firstToken = this.tokenFactory.createToken(array, start, end, startOffset, tokenType);
/*     */       
/* 131 */       this.currentToken = this.firstToken;
/*     */     } else {
/*     */       
/* 134 */       TokenImpl next = this.tokenFactory.createToken(array, start, end, startOffset, tokenType);
/*     */       
/* 136 */       this.currentToken.setNextToken(next);
/* 137 */       this.previousToken = this.currentToken;
/* 138 */       this.currentToken = next;
/*     */     } 
/*     */     
/* 141 */     this.currentToken.setLanguageIndex(this.languageIndex);
/* 142 */     this.currentToken.setHyperlink(hyperlink);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OccurrenceMarker createOccurrenceMarker() {
/* 154 */     return new DefaultOccurrenceMarker();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getClosestStandardTokenTypeForInternalType(int type) {
/* 171 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getCurlyBracesDenoteCodeBlocks(int languageIndex) {
/* 190 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Action getInsertBreakAction() {
/* 203 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getLanguageIndex() {
/* 214 */     return this.languageIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLastTokenTypeOnLine(Segment text, int initialTokenType) {
/* 225 */     Token t = getTokenList(text, initialTokenType, 0);
/*     */     
/* 227 */     while (t.getNextToken() != null) {
/* 228 */       t = t.getNextToken();
/*     */     }
/*     */     
/* 231 */     return t.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getLineCommentStartAndEnd(int languageIndex) {
/* 241 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getMarkOccurrencesOfTokenType(int type) {
/* 258 */     return (type == 20);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OccurrenceMarker getOccurrenceMarker() {
/* 267 */     if (this.occurrenceMarker == null) {
/* 268 */       this.occurrenceMarker = createOccurrenceMarker();
/*     */     }
/* 270 */     return this.occurrenceMarker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getShouldIndentNextLineAfter(Token token) {
/* 283 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIdentifierChar(int languageIndex, char ch) {
/* 294 */     return (Character.isLetterOrDigit(ch) || ch == '_' || ch == '$');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMarkupLanguage() {
/* 307 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resetTokenList() {
/* 319 */     this.firstToken = this.currentToken = this.previousToken = null;
/* 320 */     this.tokenFactory.resetAllTokens();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLanguageIndex(int languageIndex) {
/* 336 */     this.languageIndex = Math.max(0, languageIndex);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/TokenMakerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */