/*      */ package org.fife.ui.rsyntaxtextarea;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.Container;
/*      */ import java.awt.Cursor;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.Window;
/*      */ import java.awt.datatransfer.Clipboard;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.font.FontRenderContext;
/*      */ import java.io.File;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.ResourceBundle;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JMenu;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.Timer;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.event.CaretEvent;
/*      */ import javax.swing.event.CaretListener;
/*      */ import javax.swing.event.HyperlinkEvent;
/*      */ import javax.swing.event.HyperlinkListener;
/*      */ import javax.swing.text.BadLocationException;
/*      */ import javax.swing.text.Document;
/*      */ import javax.swing.text.Element;
/*      */ import javax.swing.text.Highlighter;
/*      */ import org.fife.ui.rsyntaxtextarea.focusabletip.FocusableTip;
/*      */ import org.fife.ui.rsyntaxtextarea.folding.DefaultFoldManager;
/*      */ import org.fife.ui.rsyntaxtextarea.folding.Fold;
/*      */ import org.fife.ui.rsyntaxtextarea.folding.FoldManager;
/*      */ import org.fife.ui.rsyntaxtextarea.parser.Parser;
/*      */ import org.fife.ui.rsyntaxtextarea.parser.ParserNotice;
/*      */ import org.fife.ui.rsyntaxtextarea.parser.ToolTipInfo;
/*      */ import org.fife.ui.rtextarea.RTextArea;
/*      */ import org.fife.ui.rtextarea.RTextAreaBase;
/*      */ import org.fife.ui.rtextarea.RTextAreaUI;
/*      */ import org.fife.ui.rtextarea.RecordableTextAction;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RSyntaxTextArea
/*      */   extends RTextArea
/*      */   implements SyntaxConstants
/*      */ {
/*      */   public static final String ANIMATE_BRACKET_MATCHING_PROPERTY = "RSTA.animateBracketMatching";
/*      */   public static final String ANTIALIAS_PROPERTY = "RSTA.antiAlias";
/*      */   public static final String AUTO_INDENT_PROPERTY = "RSTA.autoIndent";
/*      */   public static final String BRACKET_MATCHING_PROPERTY = "RSTA.bracketMatching";
/*      */   public static final String CLEAR_WHITESPACE_LINES_PROPERTY = "RSTA.clearWhitespaceLines";
/*      */   public static final String CLOSE_CURLY_BRACES_PROPERTY = "RSTA.closeCurlyBraces";
/*      */   public static final String CLOSE_MARKUP_TAGS_PROPERTY = "RSTA.closeMarkupTags";
/*      */   public static final String CODE_FOLDING_PROPERTY = "RSTA.codeFolding";
/*      */   public static final String EOL_VISIBLE_PROPERTY = "RSTA.eolMarkersVisible";
/*      */   public static final String FOCUSABLE_TIPS_PROPERTY = "RSTA.focusableTips";
/*      */   public static final String FRACTIONAL_FONTMETRICS_PROPERTY = "RSTA.fractionalFontMetrics";
/*      */   public static final String HIGHLIGHT_SECONDARY_LANGUAGES_PROPERTY = "RSTA.highlightSecondaryLanguages";
/*      */   public static final String HYPERLINKS_ENABLED_PROPERTY = "RSTA.hyperlinksEnabled";
/*      */   public static final String MARK_OCCURRENCES_PROPERTY = "RSTA.markOccurrences";
/*      */   public static final String MARKED_OCCURRENCES_CHANGED_PROPERTY = "RSTA.markedOccurrencesChanged";
/*      */   public static final String PAINT_MATCHED_BRACKET_PAIR_PROPERTY = "RSTA.paintMatchedBracketPair";
/*      */   public static final String PARSER_NOTICES_PROPERTY = "RSTA.parserNotices";
/*      */   public static final String SYNTAX_SCHEME_PROPERTY = "RSTA.syntaxScheme";
/*      */   public static final String SYNTAX_STYLE_PROPERTY = "RSTA.syntaxStyle";
/*      */   public static final String TAB_LINE_COLOR_PROPERTY = "RSTA.tabLineColor";
/*      */   public static final String TAB_LINES_PROPERTY = "RSTA.tabLines";
/*      */   public static final String USE_SELECTED_TEXT_COLOR_PROPERTY = "RSTA.useSelectedTextColor";
/*      */   public static final String VISIBLE_WHITESPACE_PROPERTY = "RSTA.visibleWhitespace";
/*  171 */   private static final Color DEFAULT_BRACKET_MATCH_BG_COLOR = new Color(234, 234, 255);
/*  172 */   private static final Color DEFAULT_BRACKET_MATCH_BORDER_COLOR = new Color(0, 0, 128);
/*  173 */   private static final Color DEFAULT_SELECTION_COLOR = new Color(200, 200, 255);
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String MSG = "org.fife.ui.rsyntaxtextarea.RSyntaxTextArea";
/*      */ 
/*      */ 
/*      */   
/*      */   private JMenu foldingMenu;
/*      */ 
/*      */ 
/*      */   
/*      */   private static RecordableTextAction toggleCurrentFoldAction;
/*      */ 
/*      */ 
/*      */   
/*      */   private static RecordableTextAction collapseAllCommentFoldsAction;
/*      */ 
/*      */ 
/*      */   
/*      */   private static RecordableTextAction collapseAllFoldsAction;
/*      */ 
/*      */ 
/*      */   
/*      */   private static RecordableTextAction expandAllFoldsAction;
/*      */ 
/*      */ 
/*      */   
/*      */   private String syntaxStyleKey;
/*      */ 
/*      */ 
/*      */   
/*      */   private SyntaxScheme syntaxScheme;
/*      */ 
/*      */ 
/*      */   
/*      */   private static CodeTemplateManager codeTemplateManager;
/*      */ 
/*      */   
/*      */   private static boolean templatesEnabled;
/*      */ 
/*      */   
/*      */   private Rectangle match;
/*      */ 
/*      */   
/*      */   private Rectangle dotRect;
/*      */ 
/*      */   
/*      */   private Point bracketInfo;
/*      */ 
/*      */   
/*      */   private Color matchedBracketBGColor;
/*      */ 
/*      */   
/*      */   private Color matchedBracketBorderColor;
/*      */ 
/*      */   
/*      */   private int lastBracketMatchPos;
/*      */ 
/*      */   
/*      */   private boolean bracketMatchingEnabled;
/*      */ 
/*      */   
/*      */   private boolean animateBracketMatching;
/*      */ 
/*      */   
/*      */   private boolean paintMatchedBracketPair;
/*      */ 
/*      */   
/*      */   private BracketMatchingTimer bracketRepaintTimer;
/*      */ 
/*      */   
/*      */   private MatchedBracketPopupTimer matchedBracketPopupTimer;
/*      */ 
/*      */   
/*      */   private boolean metricsNeverRefreshed;
/*      */ 
/*      */   
/*      */   private boolean autoIndentEnabled;
/*      */ 
/*      */   
/*      */   private boolean closeCurlyBraces;
/*      */ 
/*      */   
/*      */   private boolean closeMarkupTags;
/*      */ 
/*      */   
/*      */   private boolean clearWhitespaceLines;
/*      */ 
/*      */   
/*      */   private boolean whitespaceVisible;
/*      */ 
/*      */   
/*      */   private boolean eolMarkersVisible;
/*      */ 
/*      */   
/*      */   private boolean paintTabLines;
/*      */ 
/*      */   
/*      */   private Color tabLineColor;
/*      */ 
/*      */   
/*      */   private boolean hyperlinksEnabled;
/*      */ 
/*      */   
/*      */   private Color hyperlinkFG;
/*      */ 
/*      */   
/*      */   private int linkScanningMask;
/*      */ 
/*      */   
/*      */   private boolean highlightSecondaryLanguages;
/*      */ 
/*      */   
/*      */   private boolean useSelectedTextColor;
/*      */ 
/*      */   
/*      */   private MarkOccurrencesSupport markOccurrencesSupport;
/*      */ 
/*      */   
/*      */   private Color markOccurrencesColor;
/*      */ 
/*      */   
/*      */   private int markOccurrencesDelay;
/*      */ 
/*      */   
/*      */   private boolean paintMarkOccurrencesBorder;
/*      */ 
/*      */   
/*      */   private FontMetrics defaultFontMetrics;
/*      */ 
/*      */   
/*      */   private ParserManager parserManager;
/*      */ 
/*      */   
/*      */   private String cachedTip;
/*      */ 
/*      */   
/*      */   private Point cachedTipLoc;
/*      */ 
/*      */   
/*      */   private boolean isScanningForLinks;
/*      */ 
/*      */   
/*      */   private int hoveredOverLinkOffset;
/*      */ 
/*      */   
/*      */   private LinkGenerator linkGenerator;
/*      */ 
/*      */   
/*      */   private LinkGeneratorResult linkGeneratorResult;
/*      */ 
/*      */   
/*      */   private int rhsCorrection;
/*      */ 
/*      */   
/*      */   private FoldManager foldManager;
/*      */ 
/*      */   
/*      */   private boolean useFocusableTips;
/*      */ 
/*      */   
/*      */   private FocusableTip focusableTip;
/*      */ 
/*      */   
/*      */   private Map<?, ?> aaHints;
/*      */ 
/*      */   
/*      */   private TokenPainter tokenPainter;
/*      */ 
/*      */   
/*      */   private boolean showMatchedBracketPopup;
/*      */ 
/*      */   
/*      */   private int lineHeight;
/*      */ 
/*      */   
/*      */   private int maxAscent;
/*      */ 
/*      */   
/*      */   private boolean fractionalFontMetricsEnabled;
/*      */ 
/*      */   
/*      */   private Color[] secondaryLanguageBackgrounds;
/*      */ 
/*      */ 
/*      */   
/*      */   public RSyntaxTextArea() {}
/*      */ 
/*      */ 
/*      */   
/*      */   public RSyntaxTextArea(RSyntaxDocument doc) {
/*  365 */     super(doc);
/*  366 */     setSyntaxEditingStyle(doc.getSyntaxStyle());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RSyntaxTextArea(String text) {
/*  375 */     super(text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RSyntaxTextArea(int rows, int cols) {
/*  388 */     super(rows, cols);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RSyntaxTextArea(String text, int rows, int cols) {
/*  402 */     super(text, rows, cols);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RSyntaxTextArea(RSyntaxDocument doc, String text, int rows, int cols) {
/*  417 */     super(doc, text, rows, cols);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RSyntaxTextArea(int textMode) {
/*  428 */     super(textMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addActiveLineRangeListener(ActiveLineRangeListener l) {
/*  439 */     this.listenerList.add(ActiveLineRangeListener.class, l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addHyperlinkListener(HyperlinkListener l) {
/*  450 */     this.listenerList.add(HyperlinkListener.class, l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNotify() {
/*  460 */     super.addNotify();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  466 */     if (this.metricsNeverRefreshed) {
/*  467 */       Window parent = SwingUtilities.getWindowAncestor(this);
/*  468 */       if (parent != null && parent.getWidth() > 0 && parent.getHeight() > 0) {
/*  469 */         refreshFontMetrics(getGraphics2D(getGraphics()));
/*  470 */         this.metricsNeverRefreshed = false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  476 */     if (this.parserManager != null) {
/*  477 */       this.parserManager.restartParsing();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addParser(Parser parser) {
/*  495 */     if (this.parserManager == null) {
/*  496 */       this.parserManager = new ParserManager(this);
/*      */     }
/*  498 */     this.parserManager.addParser(parser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void appendFoldingMenu(JPopupMenu popup) {
/*  510 */     popup.addSeparator();
/*  511 */     ResourceBundle bundle = ResourceBundle.getBundle("org.fife.ui.rsyntaxtextarea.RSyntaxTextArea");
/*  512 */     this.foldingMenu = new JMenu(bundle.getString("ContextMenu.Folding"));
/*  513 */     this.foldingMenu.add(createPopupMenuItem(toggleCurrentFoldAction));
/*  514 */     this.foldingMenu.add(createPopupMenuItem(collapseAllCommentFoldsAction));
/*  515 */     this.foldingMenu.add(createPopupMenuItem(collapseAllFoldsAction));
/*  516 */     this.foldingMenu.add(createPopupMenuItem(expandAllFoldsAction));
/*  517 */     popup.add(this.foldingMenu);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void calculateLineHeight() {
/*  528 */     this.lineHeight = this.maxAscent = 0;
/*      */ 
/*      */     
/*  531 */     for (int i = 0; i < this.syntaxScheme.getStyleCount(); i++) {
/*  532 */       Style ss = this.syntaxScheme.getStyle(i);
/*  533 */       if (ss != null && ss.font != null) {
/*  534 */         FontMetrics fontMetrics = getFontMetrics(ss.font);
/*  535 */         int j = fontMetrics.getHeight();
/*  536 */         if (j > this.lineHeight) {
/*  537 */           this.lineHeight = j;
/*      */         }
/*  539 */         int k = fontMetrics.getMaxAscent();
/*  540 */         if (k > this.maxAscent) {
/*  541 */           this.maxAscent = k;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  547 */     Font temp = getFont();
/*  548 */     FontMetrics fm = getFontMetrics(temp);
/*  549 */     int height = fm.getHeight();
/*  550 */     if (height > this.lineHeight) {
/*  551 */       this.lineHeight = height;
/*      */     }
/*  553 */     int ascent = fm.getMaxAscent();
/*  554 */     if (ascent > this.maxAscent) {
/*  555 */       this.maxAscent = ascent;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearParsers() {
/*  567 */     if (this.parserManager != null) {
/*  568 */       this.parserManager.clearParsers();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TokenImpl cloneTokenList(Token t) {
/*  583 */     if (t == null) {
/*  584 */       return null;
/*      */     }
/*      */     
/*  587 */     TokenImpl clone = new TokenImpl(t);
/*  588 */     TokenImpl cloneEnd = clone;
/*      */     
/*  590 */     while ((t = t.getNextToken()) != null) {
/*  591 */       TokenImpl temp = new TokenImpl(t);
/*  592 */       cloneEnd.setNextToken(temp);
/*  593 */       cloneEnd = temp;
/*      */     } 
/*      */     
/*  596 */     return clone;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void configurePopupMenu(JPopupMenu popupMenu) {
/*  616 */     super.configurePopupMenu(popupMenu);
/*      */ 
/*      */     
/*  619 */     if (popupMenu != null && popupMenu.getComponentCount() > 0 && this.foldingMenu != null)
/*      */     {
/*  621 */       this.foldingMenu.setEnabled(this.foldManager
/*  622 */           .isCodeFoldingSupportedAndEnabled());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyAsStyledText(Theme theme) {
/*  640 */     if (theme == null) {
/*  641 */       copyAsStyledText();
/*      */       
/*      */       return;
/*      */     } 
/*  645 */     Theme origTheme = new Theme(this);
/*      */     
/*  647 */     theme.apply(this);
/*      */     try {
/*  649 */       copyAsStyledText();
/*      */     } finally {
/*  651 */       origTheme.apply(this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyAsStyledText() {
/*  664 */     int selStart = getSelectionStart();
/*  665 */     int selEnd = getSelectionEnd();
/*  666 */     if (selStart == selEnd) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  671 */     String html = HtmlUtil.getTextAsHtml(this, selStart, selEnd);
/*      */ 
/*      */     
/*  674 */     byte[] rtfBytes = getTextAsRtf(selStart, selEnd);
/*      */ 
/*      */     
/*  677 */     StyledTextTransferable contents = new StyledTextTransferable(html, rtfBytes);
/*      */     
/*  679 */     Clipboard cb = getToolkit().getSystemClipboard();
/*      */     try {
/*  681 */       cb.setContents(contents, null);
/*  682 */     } catch (IllegalStateException ise) {
/*  683 */       UIManager.getLookAndFeel().provideErrorFeedback(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Document createDefaultModel() {
/*  695 */     return new RSyntaxDocument("text/plain");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RTextAreaBase.RTAMouseListener createMouseListener() {
/*  706 */     return new RSyntaxTextAreaMutableCaretEvent(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JPopupMenu createPopupMenu() {
/*  718 */     JPopupMenu popup = super.createPopupMenu();
/*  719 */     appendFoldingMenu(popup);
/*  720 */     return popup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void createRstaPopupMenuActions() {
/*  732 */     ResourceBundle msg = ResourceBundle.getBundle("org.fife.ui.rsyntaxtextarea.RSyntaxTextArea");
/*      */     
/*  734 */     toggleCurrentFoldAction = new RSyntaxTextAreaEditorKit.ToggleCurrentFoldAction();
/*      */     
/*  736 */     toggleCurrentFoldAction.setProperties(msg, "Action.ToggleCurrentFold");
/*      */     
/*  738 */     collapseAllCommentFoldsAction = new RSyntaxTextAreaEditorKit.CollapseAllCommentFoldsAction();
/*      */     
/*  740 */     collapseAllCommentFoldsAction.setProperties(msg, "Action.CollapseCommentFolds");
/*      */     
/*  742 */     collapseAllFoldsAction = new RSyntaxTextAreaEditorKit.CollapseAllFoldsAction(true);
/*  743 */     expandAllFoldsAction = new RSyntaxTextAreaEditorKit.ExpandAllFoldsAction(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RTextAreaUI createRTextAreaUI() {
/*  755 */     return new RSyntaxTextAreaUI(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void doBracketMatching() {
/*  767 */     if (this.match != null) {
/*  768 */       repaint(this.match);
/*  769 */       if (this.dotRect != null) {
/*  770 */         repaint(this.dotRect);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  775 */     int lastCaretBracketPos = (this.bracketInfo == null) ? -1 : this.bracketInfo.x;
/*  776 */     this.bracketInfo = RSyntaxUtilities.getMatchingBracketPosition(this, this.bracketInfo);
/*      */     
/*  778 */     if (this.bracketInfo.y > -1 && (this.bracketInfo.y != this.lastBracketMatchPos || this.bracketInfo.x != lastCaretBracketPos)) {
/*      */ 
/*      */       
/*      */       try {
/*  782 */         this.match = modelToView(this.bracketInfo.y);
/*  783 */         if (this.match != null) {
/*  784 */           if (getPaintMatchedBracketPair()) {
/*  785 */             this.dotRect = modelToView(this.bracketInfo.x);
/*      */           } else {
/*      */             
/*  788 */             this.dotRect = null;
/*      */           } 
/*  790 */           if (getAnimateBracketMatching()) {
/*  791 */             this.bracketRepaintTimer.restart();
/*      */           }
/*  793 */           repaint(this.match);
/*  794 */           if (this.dotRect != null) {
/*  795 */             repaint(this.dotRect);
/*      */           }
/*      */           
/*  798 */           if (getShowMatchedBracketPopup()) {
/*  799 */             Container parent = getParent();
/*  800 */             if (parent instanceof javax.swing.JViewport) {
/*  801 */               Rectangle visibleRect = getVisibleRect();
/*  802 */               if ((this.match.y + this.match.height) < visibleRect.getY()) {
/*  803 */                 if (this.matchedBracketPopupTimer == null) {
/*  804 */                   this.matchedBracketPopupTimer = new MatchedBracketPopupTimer();
/*      */                 }
/*      */                 
/*  807 */                 this.matchedBracketPopupTimer.restart(this.bracketInfo.y);
/*      */               }
/*      */             
/*      */             } 
/*      */           } 
/*      */         } 
/*  813 */       } catch (BadLocationException ble) {
/*  814 */         ble.printStackTrace();
/*      */       }
/*      */     
/*  817 */     } else if (this.bracketInfo.y == -1) {
/*      */       
/*  819 */       this.match = null;
/*  820 */       this.dotRect = null;
/*  821 */       this.bracketRepaintTimer.stop();
/*      */     } 
/*  823 */     this.lastBracketMatchPos = this.bracketInfo.y;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fireCaretUpdate(CaretEvent e) {
/*  835 */     super.fireCaretUpdate(e);
/*  836 */     if (isBracketMatchingEnabled()) {
/*  837 */       doBracketMatching();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fireActiveLineRangeEvent(int min, int max) {
/*  849 */     ActiveLineRangeEvent e = null;
/*      */     
/*  851 */     Object[] listeners = this.listenerList.getListenerList();
/*      */ 
/*      */     
/*  854 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/*  855 */       if (listeners[i] == ActiveLineRangeListener.class) {
/*  856 */         if (e == null) {
/*  857 */           e = new ActiveLineRangeEvent(this, min, max);
/*      */         }
/*  859 */         ((ActiveLineRangeListener)listeners[i + 1]).activeLineRangeChanged(e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fireHyperlinkUpdate(HyperlinkEvent e) {
/*  873 */     Object[] listeners = this.listenerList.getListenerList();
/*      */ 
/*      */     
/*  876 */     for (int i = listeners.length - 2; i >= 0; i -= 2) {
/*  877 */       if (listeners[i] == HyperlinkListener.class) {
/*  878 */         ((HyperlinkListener)listeners[i + 1]).hyperlinkUpdate(e);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fireMarkedOccurrencesChanged() {
/*  889 */     firePropertyChange("RSTA.markedOccurrencesChanged", (Object)null, (Object)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fireParserNoticesChange() {
/*  899 */     firePropertyChange("RSTA.parserNotices", (Object)null, (Object)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void foldToggled(Fold fold) {
/*  911 */     this.match = null;
/*  912 */     this.dotRect = null;
/*  913 */     if (getLineWrap()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  919 */       SwingUtilities.invokeLater(this::possiblyUpdateCurrentLineHighlightLocation);
/*      */     } else {
/*      */       
/*  922 */       possiblyUpdateCurrentLineHighlightLocation();
/*      */     } 
/*  924 */     revalidate();
/*  925 */     repaint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void forceReparsing(int parser) {
/*  943 */     this.parserManager.forceReparsing(parser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean forceReparsing(Parser parser) {
/*  957 */     for (int i = 0; i < getParserCount(); i++) {
/*  958 */       if (getParser(i) == parser) {
/*  959 */         forceReparsing(i);
/*  960 */         return true;
/*      */       } 
/*      */     } 
/*  963 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAnimateBracketMatching() {
/*  974 */     return this.animateBracketMatching;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAntiAliasingEnabled() {
/*  986 */     return (this.aaHints != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getBackgroundForToken(Token token) {
/* 1000 */     Color c = null;
/* 1001 */     if (getHighlightSecondaryLanguages()) {
/*      */       
/* 1003 */       int languageIndex = token.getLanguageIndex() - 1;
/* 1004 */       if (languageIndex >= 0 && languageIndex < this.secondaryLanguageBackgrounds.length)
/*      */       {
/* 1006 */         c = this.secondaryLanguageBackgrounds[languageIndex];
/*      */       }
/*      */     } 
/* 1009 */     if (c == null) {
/* 1010 */       c = (this.syntaxScheme.getStyle(token.getType())).background;
/*      */     }
/*      */ 
/*      */     
/* 1014 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getCloseCurlyBraces() {
/* 1028 */     return this.closeCurlyBraces;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getCloseMarkupTags() {
/* 1041 */     return this.closeMarkupTags;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized CodeTemplateManager getCodeTemplateManager() {
/* 1053 */     if (codeTemplateManager == null) {
/* 1054 */       codeTemplateManager = new CodeTemplateManager();
/*      */     }
/* 1056 */     return codeTemplateManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Color getDefaultBracketMatchBGColor() {
/* 1067 */     return DEFAULT_BRACKET_MATCH_BG_COLOR;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Color getDefaultBracketMatchBorderColor() {
/* 1078 */     return DEFAULT_BRACKET_MATCH_BORDER_COLOR;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Color getDefaultSelectionColor() {
/* 1091 */     return DEFAULT_SELECTION_COLOR;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SyntaxScheme getDefaultSyntaxScheme() {
/* 1105 */     return new SyntaxScheme(getFont());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getEOLMarkersVisible() {
/* 1117 */     return this.eolMarkersVisible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FoldManager getFoldManager() {
/* 1127 */     return this.foldManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getFontForTokenType(int type) {
/* 1139 */     Font f = (this.syntaxScheme.getStyle(type)).font;
/* 1140 */     return (f != null) ? f : getFont();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FontMetrics getFontMetricsForTokenType(int type) {
/* 1152 */     FontMetrics fm = (this.syntaxScheme.getStyle(type)).fontMetrics;
/* 1153 */     return (fm != null) ? fm : this.defaultFontMetrics;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getForegroundForToken(Token t) {
/* 1166 */     if (getHyperlinksEnabled() && this.hoveredOverLinkOffset == t.getOffset() && (t
/* 1167 */       .isHyperlink() || this.linkGeneratorResult != null)) {
/* 1168 */       return this.hyperlinkFG;
/*      */     }
/* 1170 */     return getForegroundForTokenType(t.getType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getForegroundForTokenType(int type) {
/* 1184 */     Color fg = (this.syntaxScheme.getStyle(type)).foreground;
/* 1185 */     return (fg != null) ? fg : getForeground();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getFractionalFontMetricsEnabled() {
/* 1197 */     return this.fractionalFontMetricsEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Graphics2D getGraphics2D(Graphics g) {
/* 1210 */     Graphics2D g2d = (Graphics2D)g;
/* 1211 */     if (this.aaHints != null) {
/* 1212 */       g2d.addRenderingHints(this.aaHints);
/*      */     }
/* 1214 */     if (this.fractionalFontMetricsEnabled) {
/* 1215 */       g2d.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
/*      */     }
/*      */     
/* 1218 */     return g2d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getHighlightSecondaryLanguages() {
/* 1235 */     return this.highlightSecondaryLanguages;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getHyperlinkForeground() {
/* 1247 */     return this.hyperlinkFG;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getHyperlinksEnabled() {
/* 1258 */     return this.hyperlinksEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLastVisibleOffset() {
/* 1269 */     if (isCodeFoldingEnabled()) {
/* 1270 */       int lastVisibleLine = this.foldManager.getLastVisibleLine();
/* 1271 */       if (lastVisibleLine < getLineCount() - 1) {
/*      */         try {
/* 1273 */           return getLineEndOffset(lastVisibleLine) - 1;
/* 1274 */         } catch (BadLocationException ble) {
/* 1275 */           ble.printStackTrace();
/*      */         } 
/*      */       }
/*      */     } 
/* 1279 */     return getDocument().getLength();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLineHeight() {
/* 1291 */     return this.lineHeight;
/*      */   }
/*      */ 
/*      */   
/*      */   public LinkGenerator getLinkGenerator() {
/* 1296 */     return this.linkGenerator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<DocumentRange> getMarkAllHighlightRanges() {
/* 1308 */     return ((RSyntaxTextAreaHighlighter)getHighlighter()).getMarkAllHighlightRanges();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<DocumentRange> getMarkedOccurrences() {
/* 1320 */     return ((RSyntaxTextAreaHighlighter)getHighlighter()).getMarkedOccurrences();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMarkOccurrences() {
/* 1331 */     return (this.markOccurrencesSupport != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getMarkOccurrencesColor() {
/* 1342 */     return this.markOccurrencesColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMarkOccurrencesDelay() {
/* 1354 */     return this.markOccurrencesDelay;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean getMarkOccurrencesOfTokenType(int type) {
/* 1367 */     RSyntaxDocument doc = (RSyntaxDocument)getDocument();
/* 1368 */     return doc.getMarkOccurrencesOfTokenType(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getMatchedBracketBGColor() {
/* 1381 */     return this.matchedBracketBGColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getMatchedBracketBorderColor() {
/* 1393 */     return this.matchedBracketBorderColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Rectangle getDotRectangle() {
/* 1407 */     return this.dotRect;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Rectangle getMatchRectangle() {
/* 1420 */     return this.match;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxAscent() {
/* 1431 */     return this.maxAscent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getPaintMatchedBracketPair() {
/* 1448 */     return this.paintMatchedBracketPair;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getPaintTabLines() {
/* 1460 */     return this.paintTabLines;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean getPaintTokenBackgrounds(int line, float y) {
/* 1476 */     int iy = (int)y;
/* 1477 */     int curCaretY = getCurrentCaretY();
/* 1478 */     return (iy < curCaretY || iy >= curCaretY + getLineHeight() || 
/* 1479 */       !getHighlightCurrentLine());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parser getParser(int index) {
/* 1492 */     return this.parserManager.getParser(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getParserCount() {
/* 1503 */     return (this.parserManager == null) ? 0 : this.parserManager.getParserCount();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getParserDelay() {
/* 1515 */     return this.parserManager.getDelay();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<ParserNotice> getParserNotices() {
/* 1528 */     if (this.parserManager == null) {
/* 1529 */       return Collections.emptyList();
/*      */     }
/* 1531 */     return this.parserManager.getParserNotices();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRightHandSideCorrection() {
/* 1543 */     return this.rhsCorrection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getShouldIndentNextLine(int line) {
/* 1566 */     if (isAutoIndentEnabled()) {
/* 1567 */       RSyntaxDocument doc = (RSyntaxDocument)getDocument();
/* 1568 */       return doc.getShouldIndentNextLine(line);
/*      */     } 
/* 1570 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getShowMatchedBracketPopup() {
/* 1583 */     return this.showMatchedBracketPopup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSyntaxEditingStyle() {
/* 1596 */     return this.syntaxStyleKey;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SyntaxScheme getSyntaxScheme() {
/* 1609 */     return this.syntaxScheme;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getTabLineColor() {
/* 1622 */     return this.tabLineColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getPaintMarkOccurrencesBorder() {
/* 1635 */     return this.paintMarkOccurrencesBorder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getSecondaryLanguageBackground(int index) {
/* 1651 */     return this.secondaryLanguageBackgrounds[index - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSecondaryLanguageCount() {
/* 1664 */     return this.secondaryLanguageBackgrounds.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized boolean getTemplatesEnabled() {
/* 1684 */     return templatesEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] getTextAsRtf(int start, int end) {
/* 1690 */     RtfGenerator gen = new RtfGenerator(getBackground());
/* 1691 */     Token tokenList = getTokenListFor(start, end);
/* 1692 */     for (Token t = tokenList; t != null; t = t.getNextToken()) {
/* 1693 */       if (t.isPaintable()) {
/* 1694 */         if (t.length() == 1 && t.charAt(0) == '\n') {
/* 1695 */           gen.appendNewline();
/*      */         } else {
/* 1697 */           Font font = getFontForTokenType(t.getType());
/* 1698 */           Color bg = getBackgroundForToken(t);
/* 1699 */           boolean underline = getUnderlineForToken(t);
/*      */ 
/*      */           
/* 1702 */           if (t.isWhitespace()) {
/* 1703 */             gen.appendToDocNoFG(t.getLexeme(), font, bg, underline);
/*      */           } else {
/* 1705 */             Color fg = getForegroundForToken(t);
/* 1706 */             gen.appendToDoc(t.getLexeme(), font, fg, bg, underline);
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1713 */     return gen.getRtf().getBytes(StandardCharsets.UTF_8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Token getTokenListFor(int startOffs, int endOffs) {
/* 1726 */     TokenImpl tokenList = null;
/* 1727 */     TokenImpl lastToken = null;
/*      */     
/* 1729 */     Element map = getDocument().getDefaultRootElement();
/* 1730 */     int startLine = map.getElementIndex(startOffs);
/* 1731 */     int endLine = map.getElementIndex(endOffs);
/*      */     
/* 1733 */     for (int line = startLine; line <= endLine; line++) {
/* 1734 */       TokenImpl t = (TokenImpl)getTokenListForLine(line);
/* 1735 */       t = cloneTokenList(t);
/* 1736 */       if (tokenList == null) {
/* 1737 */         tokenList = t;
/* 1738 */         lastToken = tokenList;
/*      */       } else {
/*      */         
/* 1741 */         lastToken.setNextToken(t);
/*      */       } 
/* 1743 */       while (lastToken.getNextToken() != null && lastToken
/* 1744 */         .getNextToken().isPaintable()) {
/* 1745 */         lastToken = (TokenImpl)lastToken.getNextToken();
/*      */       }
/* 1747 */       if (line < endLine) {
/*      */ 
/*      */         
/* 1750 */         int docOffs = map.getElement(line).getEndOffset() - 1;
/* 1751 */         t = new TokenImpl(new char[] { '\n' }, 0, 0, docOffs, 21, 0);
/*      */         
/* 1753 */         lastToken.setNextToken(t);
/* 1754 */         lastToken = t;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1767 */     if (startOffs >= tokenList.getOffset()) {
/* 1768 */       while (!tokenList.containsPosition(startOffs)) {
/* 1769 */         tokenList = (TokenImpl)tokenList.getNextToken();
/*      */       }
/* 1771 */       tokenList.makeStartAt(startOffs);
/*      */     } 
/*      */     
/* 1774 */     TokenImpl temp = tokenList;
/*      */ 
/*      */     
/* 1777 */     while (temp != null && !temp.containsPosition(endOffs)) {
/* 1778 */       temp = (TokenImpl)temp.getNextToken();
/*      */     }
/* 1780 */     if (temp != null) {
/* 1781 */       temp.textCount = endOffs - temp.getOffset();
/* 1782 */       temp.setNextToken(null);
/*      */     } 
/*      */     
/* 1785 */     return tokenList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Token getTokenListForLine(int line) {
/* 1797 */     return ((RSyntaxDocument)getDocument()).getTokenListForLine(line);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TokenPainter getTokenPainter() {
/* 1807 */     return this.tokenPainter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getToolTipText(MouseEvent e) {
/* 1826 */     if (RSyntaxUtilities.getOS() == 2) {
/* 1827 */       Point newLoc = e.getPoint();
/* 1828 */       if (newLoc != null && newLoc.equals(this.cachedTipLoc)) {
/* 1829 */         return this.cachedTip;
/*      */       }
/* 1831 */       this.cachedTipLoc = newLoc;
/*      */     } 
/*      */     
/* 1834 */     return this.cachedTip = getToolTipTextImpl(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getToolTipTextImpl(MouseEvent e) {
/* 1848 */     String text = null;
/* 1849 */     URL imageBase = null;
/* 1850 */     if (this.parserManager != null) {
/* 1851 */       ToolTipInfo info = this.parserManager.getToolTipText(e);
/* 1852 */       if (info != null) {
/* 1853 */         text = info.getToolTipText();
/* 1854 */         imageBase = info.getImageBase();
/*      */       } 
/*      */     } 
/* 1857 */     if (text == null) {
/* 1858 */       text = super.getToolTipText(e);
/*      */     }
/*      */ 
/*      */     
/* 1862 */     if (getUseFocusableTips()) {
/* 1863 */       if (text != null) {
/* 1864 */         if (this.focusableTip == null) {
/* 1865 */           this.focusableTip = new FocusableTip(this, this.parserManager);
/*      */         }
/* 1867 */         this.focusableTip.setImageBase(imageBase);
/* 1868 */         this.focusableTip.toolTipRequested(e, text);
/*      */ 
/*      */       
/*      */       }
/* 1872 */       else if (this.focusableTip != null) {
/* 1873 */         this.focusableTip.possiblyDisposeOfTipWindow();
/*      */       } 
/* 1875 */       return null;
/*      */     } 
/*      */     
/* 1878 */     return text;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUnderlineForToken(Token t) {
/* 1892 */     return ((getHyperlinksEnabled() && (t
/* 1893 */       .isHyperlink() || (this.linkGeneratorResult != null && this.linkGeneratorResult
/*      */       
/* 1895 */       .getSourceOffset() == t.getOffset()))) || 
/* 1896 */       (this.syntaxScheme.getStyle(t.getType())).underline);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUseFocusableTips() {
/* 1910 */     return this.useFocusableTips;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUseSelectedTextColor() {
/* 1926 */     return this.useSelectedTextColor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void init() {
/* 1937 */     super.init();
/* 1938 */     this.metricsNeverRefreshed = true;
/*      */     
/* 1940 */     this.tokenPainter = new DefaultTokenPainter();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1948 */     if (toggleCurrentFoldAction == null) {
/* 1949 */       createRstaPopupMenuActions();
/*      */     }
/*      */ 
/*      */     
/* 1953 */     this.syntaxStyleKey = "text/plain";
/* 1954 */     setMatchedBracketBGColor(getDefaultBracketMatchBGColor());
/* 1955 */     setMatchedBracketBorderColor(getDefaultBracketMatchBorderColor());
/* 1956 */     setBracketMatchingEnabled(true);
/* 1957 */     setAnimateBracketMatching(true);
/* 1958 */     this.lastBracketMatchPos = -1;
/* 1959 */     setSelectionColor(getDefaultSelectionColor());
/* 1960 */     setTabLineColor((Color)null);
/* 1961 */     setMarkOccurrencesColor(MarkOccurrencesSupport.DEFAULT_COLOR);
/* 1962 */     setMarkOccurrencesDelay(1000);
/*      */     
/* 1964 */     this.foldManager = new DefaultFoldManager(this);
/*      */ 
/*      */     
/* 1967 */     setAutoIndentEnabled(true);
/* 1968 */     setCloseCurlyBraces(true);
/* 1969 */     setCloseMarkupTags(true);
/* 1970 */     setClearWhitespaceLinesEnabled(true);
/*      */     
/* 1972 */     setHyperlinksEnabled(true);
/* 1973 */     setLinkScanningMask(128);
/* 1974 */     setHyperlinkForeground(Color.BLUE);
/* 1975 */     this.isScanningForLinks = false;
/* 1976 */     setUseFocusableTips(true);
/*      */ 
/*      */     
/* 1979 */     setDefaultAntiAliasingState();
/* 1980 */     restoreDefaultSyntaxScheme();
/*      */     
/* 1982 */     setHighlightSecondaryLanguages(true);
/* 1983 */     this.secondaryLanguageBackgrounds = new Color[3];
/* 1984 */     this.secondaryLanguageBackgrounds[0] = new Color(16773324);
/* 1985 */     this.secondaryLanguageBackgrounds[1] = new Color(14352090);
/* 1986 */     this.secondaryLanguageBackgrounds[2] = new Color(16769264);
/*      */     
/* 1988 */     setRightHandSideCorrection(0);
/* 1989 */     setShowMatchedBracketPopup(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAutoIndentEnabled() {
/* 2001 */     return this.autoIndentEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isBracketMatchingEnabled() {
/* 2012 */     return this.bracketMatchingEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isClearWhitespaceLinesEnabled() {
/* 2025 */     return this.clearWhitespaceLines;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCodeFoldingEnabled() {
/* 2038 */     return this.foldManager.isCodeFoldingEnabled();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isWhitespaceVisible() {
/* 2050 */     return this.whitespaceVisible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Token modelToToken(int offs) {
/* 2063 */     if (offs >= 0) {
/*      */       try {
/* 2065 */         int line = getLineOfOffset(offs);
/* 2066 */         Token t = getTokenListForLine(line);
/* 2067 */         return RSyntaxUtilities.getTokenAtOffset(t, offs);
/* 2068 */       } catch (BadLocationException ble) {
/* 2069 */         ble.printStackTrace();
/*      */       } 
/*      */     }
/* 2072 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void paintComponent(Graphics g) {
/* 2089 */     if (this.metricsNeverRefreshed) {
/* 2090 */       refreshFontMetrics(getGraphics2D(getGraphics()));
/* 2091 */       this.metricsNeverRefreshed = false;
/*      */     } 
/*      */     
/* 2094 */     super.paintComponent(getGraphics2D(g));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void refreshFontMetrics(Graphics2D g2d) {
/* 2100 */     this.defaultFontMetrics = g2d.getFontMetrics(getFont());
/* 2101 */     this.syntaxScheme.refreshFontMetrics(g2d);
/* 2102 */     if (!getLineWrap()) {
/*      */ 
/*      */       
/* 2105 */       SyntaxView sv = (SyntaxView)getUI().getRootView(this).getView(0);
/* 2106 */       sv.calculateLongestLine();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void redoLastAction() {
/* 2116 */     super.redoLastAction();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2124 */     ((RSyntaxTextAreaHighlighter)getHighlighter())
/* 2125 */       .clearMarkOccurrencesHighlights();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeActiveLineRangeListener(ActiveLineRangeListener l) {
/* 2136 */     this.listenerList.remove(ActiveLineRangeListener.class, l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeHyperlinkListener(HyperlinkListener l) {
/* 2147 */     this.listenerList.remove(HyperlinkListener.class, l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeNotify() {
/* 2156 */     if (this.parserManager != null) {
/* 2157 */       this.parserManager.stopParsing();
/*      */     }
/* 2159 */     super.removeNotify();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean removeParser(Parser parser) {
/* 2173 */     boolean removed = false;
/* 2174 */     if (this.parserManager != null) {
/* 2175 */       removed = this.parserManager.removeParser(parser);
/*      */     }
/* 2177 */     return removed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void restoreDefaultSyntaxScheme() {
/* 2189 */     setSyntaxScheme(getDefaultSyntaxScheme());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized boolean saveTemplates() {
/* 2209 */     if (!getTemplatesEnabled()) {
/* 2210 */       return false;
/*      */     }
/* 2212 */     return getCodeTemplateManager().saveTemplates();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setActiveLineRange(int min, int max) {
/* 2236 */     if (min == -1) {
/* 2237 */       max = -1;
/*      */     }
/* 2239 */     fireActiveLineRangeEvent(min, max);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAnimateBracketMatching(boolean animate) {
/* 2251 */     if (animate != this.animateBracketMatching) {
/* 2252 */       this.animateBracketMatching = animate;
/* 2253 */       if (animate && this.bracketRepaintTimer == null) {
/* 2254 */         this.bracketRepaintTimer = new BracketMatchingTimer();
/*      */       }
/* 2256 */       firePropertyChange("RSTA.animateBracketMatching", !animate, animate);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAntiAliasingEnabled(boolean enabled) {
/* 2271 */     boolean currentlyEnabled = (this.aaHints != null);
/*      */     
/* 2273 */     if (enabled != currentlyEnabled) {
/*      */       
/* 2275 */       if (enabled) {
/* 2276 */         this.aaHints = RSyntaxUtilities.getDesktopAntiAliasHints();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2281 */         if (this.aaHints == null) {
/* 2282 */           Map<RenderingHints.Key, Object> temp = new HashMap<>();
/*      */           
/* 2284 */           temp.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*      */           
/* 2286 */           this.aaHints = temp;
/*      */         } 
/*      */       } else {
/*      */         
/* 2290 */         this.aaHints = null;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2295 */       if (isDisplayable()) {
/* 2296 */         refreshFontMetrics(getGraphics2D(getGraphics()));
/*      */       }
/* 2298 */       firePropertyChange("RSTA.antiAlias", !enabled, enabled);
/* 2299 */       repaint();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoIndentEnabled(boolean enabled) {
/* 2314 */     if (this.autoIndentEnabled != enabled) {
/* 2315 */       this.autoIndentEnabled = enabled;
/* 2316 */       firePropertyChange("RSTA.autoIndent", !enabled, enabled);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBracketMatchingEnabled(boolean enabled) {
/* 2329 */     if (enabled != this.bracketMatchingEnabled) {
/* 2330 */       this.bracketMatchingEnabled = enabled;
/* 2331 */       repaint();
/* 2332 */       firePropertyChange("RSTA.bracketMatching", !enabled, enabled);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClearWhitespaceLinesEnabled(boolean enabled) {
/* 2347 */     if (enabled != this.clearWhitespaceLines) {
/* 2348 */       this.clearWhitespaceLines = enabled;
/* 2349 */       firePropertyChange("RSTA.clearWhitespaceLines", !enabled, enabled);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCloseCurlyBraces(boolean close) {
/* 2368 */     if (close != this.closeCurlyBraces) {
/* 2369 */       this.closeCurlyBraces = close;
/* 2370 */       firePropertyChange("RSTA.closeCurlyBraces", !close, close);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCloseMarkupTags(boolean close) {
/* 2388 */     if (close != this.closeMarkupTags) {
/* 2389 */       this.closeMarkupTags = close;
/* 2390 */       firePropertyChange("RSTA.closeMarkupTags", !close, close);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCodeFoldingEnabled(boolean enabled) {
/* 2406 */     if (enabled != this.foldManager.isCodeFoldingEnabled()) {
/* 2407 */       this.foldManager.setCodeFoldingEnabled(enabled);
/* 2408 */       firePropertyChange("RSTA.codeFolding", !enabled, enabled);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setDefaultAntiAliasingState() {
/* 2421 */     this.aaHints = RSyntaxUtilities.getDesktopAntiAliasHints();
/* 2422 */     if (this.aaHints == null) {
/*      */       
/* 2424 */       Map<RenderingHints.Key, Object> temp = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2429 */       JLabel label = new JLabel();
/* 2430 */       FontMetrics fm = label.getFontMetrics(label.getFont());
/* 2431 */       Object hint = null;
/*      */ 
/*      */       
/*      */       try {
/* 2435 */         Method m = FontMetrics.class.getMethod("getFontRenderContext", new Class[0]);
/* 2436 */         FontRenderContext frc = (FontRenderContext)m.invoke(fm, new Object[0]);
/* 2437 */         m = FontRenderContext.class.getMethod("getAntiAliasingHint", new Class[0]);
/* 2438 */         hint = m.invoke(frc, new Object[0]);
/* 2439 */       } catch (RuntimeException re) {
/* 2440 */         throw re;
/* 2441 */       } catch (Exception e) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2450 */       if (hint == null) {
/* 2451 */         String os = System.getProperty("os.name").toLowerCase();
/* 2452 */         if (os.contains("windows")) {
/* 2453 */           hint = RenderingHints.VALUE_TEXT_ANTIALIAS_ON;
/*      */         } else {
/*      */           
/* 2456 */           hint = RenderingHints.VALUE_TEXT_ANTIALIAS_DEFAULT;
/*      */         } 
/*      */       } 
/* 2459 */       temp.put(RenderingHints.KEY_TEXT_ANTIALIASING, hint);
/*      */       
/* 2461 */       this.aaHints = temp;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2467 */     if (isDisplayable()) {
/* 2468 */       refreshFontMetrics(getGraphics2D(getGraphics()));
/*      */     }
/* 2470 */     repaint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDocument(Document document) {
/* 2486 */     if (!(document instanceof RSyntaxDocument)) {
/* 2487 */       throw new IllegalArgumentException("Documents for RSyntaxTextArea must be instances of RSyntaxDocument!");
/*      */     }
/*      */ 
/*      */     
/* 2491 */     if (this.markOccurrencesSupport != null) {
/* 2492 */       this.markOccurrencesSupport.clear();
/*      */     }
/* 2494 */     super.setDocument(document);
/* 2495 */     setSyntaxEditingStyle(((RSyntaxDocument)document).getSyntaxStyle());
/* 2496 */     if (this.markOccurrencesSupport != null) {
/* 2497 */       this.markOccurrencesSupport.doMarkOccurrences();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEOLMarkersVisible(boolean visible) {
/* 2511 */     if (visible != this.eolMarkersVisible) {
/* 2512 */       this.eolMarkersVisible = visible;
/* 2513 */       repaint();
/* 2514 */       firePropertyChange("RSTA.eolMarkersVisible", !visible, visible);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFont(Font font) {
/* 2531 */     Font old = getFont();
/* 2532 */     super.setFont(font);
/*      */ 
/*      */ 
/*      */     
/* 2536 */     SyntaxScheme scheme = getSyntaxScheme();
/* 2537 */     if (scheme != null && old != null) {
/* 2538 */       scheme.changeBaseFont(old, font);
/* 2539 */       calculateLineHeight();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2544 */     if (isDisplayable()) {
/* 2545 */       refreshFontMetrics(getGraphics2D(getGraphics()));
/*      */       
/* 2547 */       updateMarginLineX();
/*      */ 
/*      */       
/* 2550 */       forceCurrentLineHighlightRepaint();
/*      */ 
/*      */       
/* 2553 */       firePropertyChange("font", old, font);
/*      */       
/* 2555 */       revalidate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFractionalFontMetricsEnabled(boolean enabled) {
/* 2569 */     if (this.fractionalFontMetricsEnabled != enabled) {
/* 2570 */       this.fractionalFontMetricsEnabled = enabled;
/*      */ 
/*      */       
/* 2573 */       if (isDisplayable()) {
/* 2574 */         refreshFontMetrics(getGraphics2D(getGraphics()));
/*      */       }
/* 2576 */       firePropertyChange("RSTA.fractionalFontMetrics", !enabled, enabled);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHighlighter(Highlighter h) {
/* 2595 */     if (h == null) {
/* 2596 */       h = new RSyntaxTextAreaHighlighter();
/*      */     }
/*      */     
/* 2599 */     if (!(h instanceof RSyntaxTextAreaHighlighter)) {
/* 2600 */       throw new IllegalArgumentException("RSyntaxTextArea requires an RSyntaxTextAreaHighlighter for its Highlighter");
/*      */     }
/*      */     
/* 2603 */     super.setHighlighter(h);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHighlightSecondaryLanguages(boolean highlight) {
/* 2618 */     if (this.highlightSecondaryLanguages != highlight) {
/* 2619 */       this.highlightSecondaryLanguages = highlight;
/* 2620 */       repaint();
/* 2621 */       firePropertyChange("RSTA.highlightSecondaryLanguages", !highlight, highlight);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHyperlinkForeground(Color fg) {
/* 2636 */     if (fg == null) {
/* 2637 */       throw new NullPointerException("fg cannot be null");
/*      */     }
/* 2639 */     this.hyperlinkFG = fg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHyperlinksEnabled(boolean enabled) {
/* 2653 */     if (this.hyperlinksEnabled != enabled) {
/* 2654 */       this.hyperlinksEnabled = enabled;
/* 2655 */       repaint();
/* 2656 */       firePropertyChange("RSTA.hyperlinksEnabled", !enabled, enabled);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLinkGenerator(LinkGenerator generator) {
/* 2662 */     this.linkGenerator = generator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLinkScanningMask(int mask) {
/* 2685 */     mask &= 0x3C0;
/*      */     
/* 2687 */     if (mask == 0) {
/* 2688 */       throw new IllegalArgumentException("mask argument should be some combination of InputEvent.*_DOWN_MASK fields");
/*      */     }
/*      */     
/* 2691 */     this.linkScanningMask = mask;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMarkOccurrences(boolean markOccurrences) {
/* 2704 */     if (markOccurrences) {
/* 2705 */       if (this.markOccurrencesSupport == null) {
/* 2706 */         this.markOccurrencesSupport = new MarkOccurrencesSupport();
/* 2707 */         this.markOccurrencesSupport.install(this);
/* 2708 */         firePropertyChange("RSTA.markOccurrences", false, true);
/*      */       }
/*      */     
/*      */     }
/* 2712 */     else if (this.markOccurrencesSupport != null) {
/* 2713 */       this.markOccurrencesSupport.uninstall();
/* 2714 */       this.markOccurrencesSupport = null;
/* 2715 */       firePropertyChange("RSTA.markOccurrences", true, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMarkOccurrencesColor(Color color) {
/* 2729 */     this.markOccurrencesColor = color;
/* 2730 */     if (this.markOccurrencesSupport != null) {
/* 2731 */       this.markOccurrencesSupport.setColor(color);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMarkOccurrencesDelay(int delay) {
/* 2745 */     if (delay <= 0) {
/* 2746 */       throw new IllegalArgumentException("Delay must be > 0");
/*      */     }
/* 2748 */     if (delay != this.markOccurrencesDelay) {
/* 2749 */       this.markOccurrencesDelay = delay;
/* 2750 */       if (this.markOccurrencesSupport != null) {
/* 2751 */         this.markOccurrencesSupport.setDelay(delay);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMatchedBracketBGColor(Color color) {
/* 2767 */     this.matchedBracketBGColor = color;
/* 2768 */     if (this.match != null) {
/* 2769 */       repaint();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMatchedBracketBorderColor(Color color) {
/* 2782 */     this.matchedBracketBorderColor = color;
/* 2783 */     if (this.match != null) {
/* 2784 */       repaint();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPaintMarkOccurrencesBorder(boolean paintBorder) {
/* 2798 */     this.paintMarkOccurrencesBorder = paintBorder;
/* 2799 */     if (this.markOccurrencesSupport != null) {
/* 2800 */       this.markOccurrencesSupport.setPaintBorder(paintBorder);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPaintMatchedBracketPair(boolean paintPair) {
/* 2820 */     if (paintPair != this.paintMatchedBracketPair) {
/* 2821 */       this.paintMatchedBracketPair = paintPair;
/* 2822 */       doBracketMatching();
/* 2823 */       repaint();
/* 2824 */       firePropertyChange("RSTA.paintMatchedBracketPair", !this.paintMatchedBracketPair, this.paintMatchedBracketPair);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPaintTabLines(boolean paint) {
/* 2839 */     if (paint != this.paintTabLines) {
/* 2840 */       this.paintTabLines = paint;
/* 2841 */       repaint();
/* 2842 */       firePropertyChange("RSTA.tabLines", !paint, paint);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParserDelay(int millis) {
/* 2856 */     if (this.parserManager == null) {
/* 2857 */       this.parserManager = new ParserManager(this);
/*      */     }
/* 2859 */     this.parserManager.setDelay(millis);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRightHandSideCorrection(int rhsCorrection) {
/* 2874 */     if (rhsCorrection < 0) {
/* 2875 */       throw new IllegalArgumentException("correction should be > 0");
/*      */     }
/* 2877 */     if (rhsCorrection != this.rhsCorrection) {
/* 2878 */       this.rhsCorrection = rhsCorrection;
/* 2879 */       revalidate();
/* 2880 */       repaint();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSecondaryLanguageBackground(int index, Color color) {
/* 2896 */     index--;
/* 2897 */     Color old = this.secondaryLanguageBackgrounds[index];
/* 2898 */     if ((color == null && old != null) || (color != null && !color.equals(old))) {
/* 2899 */       this.secondaryLanguageBackgrounds[index] = color;
/* 2900 */       if (getHighlightSecondaryLanguages()) {
/* 2901 */         repaint();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShowMatchedBracketPopup(boolean show) {
/* 2916 */     this.showMatchedBracketPopup = show;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSyntaxEditingStyle(String styleKey) {
/* 2931 */     if (styleKey == null) {
/* 2932 */       styleKey = "text/plain";
/*      */     }
/* 2934 */     if (!styleKey.equals(this.syntaxStyleKey)) {
/* 2935 */       String oldStyle = this.syntaxStyleKey;
/* 2936 */       this.syntaxStyleKey = styleKey;
/* 2937 */       ((RSyntaxDocument)getDocument()).setSyntaxStyle(styleKey);
/* 2938 */       firePropertyChange("RSTA.syntaxStyle", oldStyle, styleKey);
/* 2939 */       setActiveLineRange(-1, -1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSyntaxScheme(SyntaxScheme scheme) {
/* 2964 */     SyntaxScheme old = this.syntaxScheme;
/* 2965 */     this.syntaxScheme = scheme;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2970 */     calculateLineHeight();
/*      */     
/* 2972 */     if (isDisplayable()) {
/* 2973 */       refreshFontMetrics(getGraphics2D(getGraphics()));
/*      */     }
/*      */ 
/*      */     
/* 2977 */     updateMarginLineX();
/* 2978 */     this.lastBracketMatchPos = -1;
/* 2979 */     doBracketMatching();
/*      */ 
/*      */ 
/*      */     
/* 2983 */     forceCurrentLineHighlightRepaint();
/*      */ 
/*      */     
/* 2986 */     revalidate();
/*      */     
/* 2988 */     firePropertyChange("RSTA.syntaxScheme", old, this.syntaxScheme);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized boolean setTemplateDirectory(String dir) {
/* 3009 */     if (getTemplatesEnabled() && dir != null) {
/* 3010 */       File directory = new File(dir);
/* 3011 */       if (directory.isDirectory()) {
/* 3012 */         return 
/* 3013 */           (getCodeTemplateManager().setTemplateDirectory(directory) > -1);
/*      */       }
/* 3015 */       boolean created = directory.mkdir();
/* 3016 */       if (created) {
/* 3017 */         return 
/* 3018 */           (getCodeTemplateManager().setTemplateDirectory(directory) > -1);
/*      */       }
/*      */     } 
/* 3021 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void setTemplatesEnabled(boolean enabled) {
/* 3055 */     templatesEnabled = enabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTabLineColor(Color c) {
/* 3071 */     if (c == null) {
/* 3072 */       c = Color.gray;
/*      */     }
/*      */     
/* 3075 */     if (!c.equals(this.tabLineColor)) {
/* 3076 */       Color old = this.tabLineColor;
/* 3077 */       this.tabLineColor = c;
/* 3078 */       if (getPaintTabLines()) {
/* 3079 */         repaint();
/*      */       }
/* 3081 */       firePropertyChange("RSTA.tabLineColor", old, this.tabLineColor);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseFocusableTips(boolean use) {
/* 3098 */     if (use != this.useFocusableTips) {
/* 3099 */       this.useFocusableTips = use;
/* 3100 */       firePropertyChange("RSTA.focusableTips", !use, use);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseSelectedTextColor(boolean use) {
/* 3118 */     if (use != this.useSelectedTextColor) {
/* 3119 */       this.useSelectedTextColor = use;
/* 3120 */       firePropertyChange("RSTA.useSelectedTextColor", !use, use);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWhitespaceVisible(boolean visible) {
/* 3133 */     if (this.whitespaceVisible != visible) {
/* 3134 */       this.whitespaceVisible = visible;
/* 3135 */       this.tokenPainter = visible ? new VisibleWhitespaceTokenPainter() : new DefaultTokenPainter();
/*      */       
/* 3137 */       repaint();
/* 3138 */       firePropertyChange("RSTA.visibleWhitespace", !visible, visible);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void stopScanningForLinks() {
/* 3148 */     if (this.isScanningForLinks) {
/* 3149 */       Cursor c = getCursor();
/* 3150 */       this.isScanningForLinks = false;
/* 3151 */       this.linkGeneratorResult = null;
/* 3152 */       this.hoveredOverLinkOffset = -1;
/* 3153 */       if (c != null && c.getType() == 12) {
/* 3154 */         setCursor(Cursor.getPredefinedCursor(2));
/* 3155 */         repaint();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void undoLastAction() {
/* 3166 */     super.undoLastAction();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3174 */     ((RSyntaxTextAreaHighlighter)getHighlighter())
/* 3175 */       .clearMarkOccurrencesHighlights();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Token viewToToken(Point p) {
/* 3194 */     return modelToToken(viewToModel(p));
/*      */   }
/*      */ 
/*      */   
/*      */   private final class MatchedBracketPopupTimer
/*      */     extends Timer
/*      */     implements ActionListener, CaretListener
/*      */   {
/*      */     private MatchedBracketPopup popup;
/*      */     
/*      */     private int origDot;
/*      */     
/*      */     private int matchedBracketOffs;
/*      */     
/*      */     private MatchedBracketPopupTimer() {
/* 3209 */       super(350, null);
/* 3210 */       addActionListener(this);
/* 3211 */       setRepeats(false);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void actionPerformed(ActionEvent e) {
/* 3217 */       if (this.popup != null) {
/* 3218 */         this.popup.dispose();
/*      */       }
/*      */       
/* 3221 */       Window window = SwingUtilities.getWindowAncestor(RSyntaxTextArea.this);
/* 3222 */       this.popup = new MatchedBracketPopup(window, RSyntaxTextArea.this, this.matchedBracketOffs);
/* 3223 */       this.popup.pack();
/* 3224 */       this.popup.setVisible(true);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void caretUpdate(CaretEvent e) {
/* 3230 */       int dot = e.getDot();
/* 3231 */       if (dot != this.origDot) {
/* 3232 */         stop();
/* 3233 */         RSyntaxTextArea.this.removeCaretListener(this);
/* 3234 */         if (this.popup != null) {
/* 3235 */           this.popup.dispose();
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void restart(int matchedBracketOffs) {
/* 3246 */       this.origDot = RSyntaxTextArea.this.getCaretPosition();
/* 3247 */       this.matchedBracketOffs = matchedBracketOffs;
/* 3248 */       restart();
/*      */     }
/*      */ 
/*      */     
/*      */     public void start() {
/* 3253 */       super.start();
/* 3254 */       RSyntaxTextArea.this.addCaretListener(this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class BracketMatchingTimer
/*      */     extends Timer
/*      */     implements ActionListener
/*      */   {
/*      */     private int pulseCount;
/*      */ 
/*      */     
/*      */     BracketMatchingTimer() {
/* 3268 */       super(20, null);
/* 3269 */       addActionListener(this);
/* 3270 */       setCoalesce(false);
/*      */     }
/*      */ 
/*      */     
/*      */     public void actionPerformed(ActionEvent e) {
/* 3275 */       if (RSyntaxTextArea.this.isBracketMatchingEnabled()) {
/* 3276 */         if (RSyntaxTextArea.this.match != null) {
/* 3277 */           updateAndInvalidate(RSyntaxTextArea.this.match);
/*      */         }
/* 3279 */         if (RSyntaxTextArea.this.dotRect != null && RSyntaxTextArea.this.getPaintMatchedBracketPair()) {
/* 3280 */           updateAndInvalidate(RSyntaxTextArea.this.dotRect);
/*      */         }
/* 3282 */         if (++this.pulseCount == 8) {
/* 3283 */           this.pulseCount = 0;
/* 3284 */           stop();
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private void init(Rectangle r) {
/* 3290 */       r.x += 3;
/* 3291 */       r.y += 3;
/* 3292 */       r.width -= 6;
/* 3293 */       r.height -= 6;
/*      */     }
/*      */ 
/*      */     
/*      */     public void start() {
/* 3298 */       init(RSyntaxTextArea.this.match);
/* 3299 */       if (RSyntaxTextArea.this.dotRect != null && RSyntaxTextArea.this.getPaintMatchedBracketPair()) {
/* 3300 */         init(RSyntaxTextArea.this.dotRect);
/*      */       }
/* 3302 */       this.pulseCount = 0;
/* 3303 */       super.start();
/*      */     }
/*      */     
/*      */     private void updateAndInvalidate(Rectangle r) {
/* 3307 */       if (this.pulseCount < 5) {
/* 3308 */         r.x--;
/* 3309 */         r.y--;
/* 3310 */         r.width += 2;
/* 3311 */         r.height += 2;
/* 3312 */         RSyntaxTextArea.this.repaint(r.x, r.y, r.width, r.height);
/*      */       }
/* 3314 */       else if (this.pulseCount < 7) {
/* 3315 */         r.x++;
/* 3316 */         r.y++;
/* 3317 */         r.width -= 2;
/* 3318 */         r.height -= 2;
/* 3319 */         RSyntaxTextArea.this.repaint(r.x - 2, r.y - 2, r.width + 5, r.height + 5);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class RSyntaxTextAreaMutableCaretEvent
/*      */     extends RTextArea.RTextAreaMutableCaretEvent
/*      */   {
/*      */     private Insets insets;
/*      */ 
/*      */ 
/*      */     
/*      */     protected RSyntaxTextAreaMutableCaretEvent(RTextArea textArea) {
/* 3335 */       super(textArea);
/* 3336 */       this.insets = new Insets(0, 0, 0, 0);
/*      */     }
/*      */     
/*      */     private HyperlinkEvent createHyperlinkEvent() {
/* 3340 */       HyperlinkEvent he = null;
/* 3341 */       if (RSyntaxTextArea.this.linkGeneratorResult != null) {
/* 3342 */         he = RSyntaxTextArea.this.linkGeneratorResult.execute();
/* 3343 */         RSyntaxTextArea.this.linkGeneratorResult = null;
/*      */       } else {
/*      */         
/* 3346 */         Token t = RSyntaxTextArea.this.modelToToken(RSyntaxTextArea.this.hoveredOverLinkOffset);
/* 3347 */         URL url = null;
/* 3348 */         String desc = null;
/*      */         try {
/* 3350 */           String temp = t.getLexeme();
/*      */           
/* 3352 */           if (temp.startsWith("www.")) {
/* 3353 */             temp = "http://" + temp;
/*      */           }
/* 3355 */           url = new URL(temp);
/* 3356 */         } catch (MalformedURLException mue) {
/* 3357 */           desc = mue.getMessage();
/*      */         } 
/* 3359 */         he = new HyperlinkEvent(RSyntaxTextArea.this, HyperlinkEvent.EventType.ACTIVATED, url, desc);
/*      */       } 
/*      */ 
/*      */       
/* 3363 */       return he;
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean equal(LinkGeneratorResult e1, LinkGeneratorResult e2) {
/* 3368 */       return (e1.getSourceOffset() == e2.getSourceOffset());
/*      */     }
/*      */ 
/*      */     
/*      */     public void mouseClicked(MouseEvent e) {
/* 3373 */       if (RSyntaxTextArea.this.getHyperlinksEnabled() && RSyntaxTextArea.this.isScanningForLinks && RSyntaxTextArea.this
/* 3374 */         .hoveredOverLinkOffset > -1) {
/* 3375 */         HyperlinkEvent he = createHyperlinkEvent();
/* 3376 */         if (he != null) {
/* 3377 */           RSyntaxTextArea.this.fireHyperlinkUpdate(he);
/*      */         }
/* 3379 */         RSyntaxTextArea.this.stopScanningForLinks();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void mouseMoved(MouseEvent e) {
/* 3386 */       super.mouseMoved(e);
/*      */       
/* 3388 */       if (!RSyntaxTextArea.this.getHyperlinksEnabled()) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 3393 */       if ((e.getModifiersEx() & RSyntaxTextArea.this.linkScanningMask) == RSyntaxTextArea.this.linkScanningMask) {
/*      */ 
/*      */ 
/*      */         
/* 3397 */         this.insets = RSyntaxTextArea.this.getInsets(this.insets);
/* 3398 */         if (this.insets != null) {
/* 3399 */           int x = e.getX();
/* 3400 */           int y = e.getY();
/* 3401 */           if (x <= this.insets.left || y < this.insets.top) {
/* 3402 */             if (RSyntaxTextArea.this.isScanningForLinks) {
/* 3403 */               RSyntaxTextArea.this.stopScanningForLinks();
/*      */             }
/*      */             
/*      */             return;
/*      */           } 
/*      */         } 
/* 3409 */         RSyntaxTextArea.this.isScanningForLinks = true;
/* 3410 */         Token t = RSyntaxTextArea.this.viewToToken(e.getPoint());
/* 3411 */         if (t != null)
/*      */         {
/* 3413 */           t = new TokenImpl(t);
/*      */         }
/* 3415 */         Cursor c2 = null;
/* 3416 */         if (t != null && t.isHyperlink()) {
/* 3417 */           if (RSyntaxTextArea.this.hoveredOverLinkOffset == -1 || RSyntaxTextArea.this
/* 3418 */             .hoveredOverLinkOffset != t.getOffset()) {
/* 3419 */             RSyntaxTextArea.this.hoveredOverLinkOffset = t.getOffset();
/* 3420 */             RSyntaxTextArea.this.repaint();
/*      */           } 
/* 3422 */           c2 = Cursor.getPredefinedCursor(12);
/*      */         }
/* 3424 */         else if (t != null && RSyntaxTextArea.this.linkGenerator != null) {
/* 3425 */           int offs = RSyntaxTextArea.this.viewToModel(e.getPoint());
/*      */           
/* 3427 */           LinkGeneratorResult newResult = RSyntaxTextArea.this.linkGenerator.isLinkAtOffset(RSyntaxTextArea.this, offs);
/* 3428 */           if (newResult != null) {
/*      */             
/* 3430 */             if (RSyntaxTextArea.this.linkGeneratorResult == null || 
/* 3431 */               !equal(newResult, RSyntaxTextArea.this.linkGeneratorResult)) {
/* 3432 */               RSyntaxTextArea.this.repaint();
/*      */             }
/* 3434 */             RSyntaxTextArea.this.linkGeneratorResult = newResult;
/* 3435 */             RSyntaxTextArea.this.hoveredOverLinkOffset = t.getOffset();
/* 3436 */             c2 = Cursor.getPredefinedCursor(12);
/*      */           }
/*      */           else {
/*      */             
/* 3440 */             if (RSyntaxTextArea.this.linkGeneratorResult != null) {
/* 3441 */               RSyntaxTextArea.this.repaint();
/*      */             }
/* 3443 */             c2 = Cursor.getPredefinedCursor(2);
/* 3444 */             RSyntaxTextArea.this.hoveredOverLinkOffset = -1;
/* 3445 */             RSyntaxTextArea.this.linkGeneratorResult = null;
/*      */           } 
/*      */         } else {
/*      */           
/* 3449 */           c2 = Cursor.getPredefinedCursor(2);
/* 3450 */           RSyntaxTextArea.this.hoveredOverLinkOffset = -1;
/* 3451 */           RSyntaxTextArea.this.linkGeneratorResult = null;
/*      */         } 
/* 3453 */         if (RSyntaxTextArea.this.getCursor() != c2) {
/* 3454 */           RSyntaxTextArea.this.setCursor(c2);
/*      */           
/* 3456 */           RSyntaxTextArea.this.repaint();
/*      */         }
/*      */       
/*      */       }
/* 3460 */       else if (RSyntaxTextArea.this.isScanningForLinks) {
/* 3461 */         RSyntaxTextArea.this.stopScanningForLinks();
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/RSyntaxTextArea.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */