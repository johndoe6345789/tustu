package org.fife.ui.rsyntaxtextarea;

import javax.swing.event.HyperlinkEvent;

public interface LinkGeneratorResult {
  HyperlinkEvent execute();
  
  int getSourceOffset();
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/LinkGeneratorResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */