/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Point;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.ActionMap;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.InputMap;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JWindow;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import org.fife.ui.rsyntaxtextarea.focusabletip.TipUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MatchedBracketPopup
/*     */   extends JWindow
/*     */ {
/*     */   private RSyntaxTextArea textArea;
/*     */   private transient Listener listener;
/*     */   private static final int LEFT_EMPTY_BORDER = 5;
/*     */   
/*     */   MatchedBracketPopup(Window parent, RSyntaxTextArea textArea, int offsToRender) {
/*  57 */     super(parent);
/*  58 */     this.textArea = textArea;
/*  59 */     JPanel cp = new JPanel(new BorderLayout());
/*  60 */     cp.setBorder(BorderFactory.createCompoundBorder(
/*  61 */           TipUtil.getToolTipBorder(), 
/*  62 */           BorderFactory.createEmptyBorder(2, 5, 5, 5)));
/*  63 */     cp.setBackground(TipUtil.getToolTipBackground());
/*  64 */     setContentPane(cp);
/*     */     
/*  66 */     cp.add(new JLabel(getText(offsToRender)));
/*     */     
/*  68 */     installKeyBindings();
/*  69 */     this.listener = new Listener();
/*  70 */     setLocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize() {
/*  80 */     Dimension size = super.getPreferredSize();
/*  81 */     if (size != null) {
/*  82 */       size.width = Math.min(size.width, 800);
/*     */     }
/*  84 */     return size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getText(int offsToRender) {
/*  90 */     int line = 0;
/*     */     try {
/*  92 */       line = this.textArea.getLineOfOffset(offsToRender);
/*  93 */     } catch (BadLocationException ble) {
/*  94 */       ble.printStackTrace();
/*  95 */       return null;
/*     */     } 
/*     */     
/*  98 */     int lastLine = line + 1;
/*     */ 
/*     */     
/* 101 */     if (line > 0) {
/*     */       try {
/* 103 */         int startOffs = this.textArea.getLineStartOffset(line);
/* 104 */         int length = this.textArea.getLineEndOffset(line) - startOffs;
/* 105 */         String text = this.textArea.getText(startOffs, length);
/* 106 */         if (text.trim().length() == 1) {
/* 107 */           line--;
/*     */         }
/* 109 */       } catch (BadLocationException ble) {
/* 110 */         UIManager.getLookAndFeel().provideErrorFeedback(this.textArea);
/* 111 */         ble.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 115 */     Font font = this.textArea.getFontForTokenType(20);
/* 116 */     StringBuilder sb = new StringBuilder("<html>");
/* 117 */     sb.append("<style>body { font-size:\"").append(font.getSize());
/* 118 */     sb.append("pt\" }</style><nobr>");
/* 119 */     while (line < lastLine) {
/* 120 */       Token t = this.textArea.getTokenListForLine(line);
/* 121 */       while (t != null && t.isPaintable()) {
/* 122 */         t.appendHTMLRepresentation(sb, this.textArea, true, true);
/* 123 */         t = t.getNextToken();
/*     */       } 
/* 125 */       sb.append("<br>");
/* 126 */       line++;
/*     */     } 
/*     */     
/* 129 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void installKeyBindings() {
/* 139 */     InputMap im = getRootPane().getInputMap(1);
/*     */     
/* 141 */     ActionMap am = getRootPane().getActionMap();
/*     */     
/* 143 */     KeyStroke escapeKS = KeyStroke.getKeyStroke(27, 0);
/* 144 */     im.put(escapeKS, "onEscape");
/* 145 */     am.put("onEscape", new EscapeAction());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setLocation() {
/* 154 */     Point topLeft = this.textArea.getVisibleRect().getLocation();
/* 155 */     SwingUtilities.convertPointToScreen(topLeft, this.textArea);
/* 156 */     topLeft.y = Math.max(topLeft.y - 24, 0);
/* 157 */     setLocation(topLeft.x - 5, topLeft.y);
/*     */   }
/*     */ 
/*     */   
/*     */   private class EscapeAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private EscapeAction() {}
/*     */ 
/*     */     
/*     */     public void actionPerformed(ActionEvent e) {
/* 168 */       MatchedBracketPopup.this.listener.uninstallAndHide();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class Listener
/*     */     extends WindowAdapter
/*     */     implements ComponentListener
/*     */   {
/*     */     Listener() {
/* 181 */       MatchedBracketPopup.this.addWindowFocusListener(this);
/*     */ 
/*     */       
/* 184 */       Window parent = (Window)MatchedBracketPopup.this.getParent();
/* 185 */       parent.addWindowFocusListener(this);
/* 186 */       parent.addWindowListener(this);
/* 187 */       parent.addComponentListener(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void componentResized(ComponentEvent e) {
/* 193 */       uninstallAndHide();
/*     */     }
/*     */ 
/*     */     
/*     */     public void componentMoved(ComponentEvent e) {
/* 198 */       uninstallAndHide();
/*     */     }
/*     */ 
/*     */     
/*     */     public void componentShown(ComponentEvent e) {
/* 203 */       uninstallAndHide();
/*     */     }
/*     */ 
/*     */     
/*     */     public void componentHidden(ComponentEvent e) {
/* 208 */       uninstallAndHide();
/*     */     }
/*     */ 
/*     */     
/*     */     public void windowActivated(WindowEvent e) {
/* 213 */       checkForParentWindowEvent(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public void windowLostFocus(WindowEvent e) {
/* 218 */       uninstallAndHide();
/*     */     }
/*     */ 
/*     */     
/*     */     public void windowIconified(WindowEvent e) {
/* 223 */       checkForParentWindowEvent(e);
/*     */     }
/*     */     
/*     */     private boolean checkForParentWindowEvent(WindowEvent e) {
/* 227 */       if (e.getSource() == MatchedBracketPopup.this.getParent()) {
/* 228 */         uninstallAndHide();
/* 229 */         return true;
/*     */       } 
/* 231 */       return false;
/*     */     }
/*     */     
/*     */     private void uninstallAndHide() {
/* 235 */       Window parent = (Window)MatchedBracketPopup.this.getParent();
/* 236 */       parent.removeWindowFocusListener(this);
/* 237 */       parent.removeWindowListener(this);
/* 238 */       parent.removeComponentListener(this);
/* 239 */       MatchedBracketPopup.this.removeWindowFocusListener(this);
/* 240 */       MatchedBracketPopup.this.setVisible(false);
/* 241 */       MatchedBracketPopup.this.dispose();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/MatchedBracketPopup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */