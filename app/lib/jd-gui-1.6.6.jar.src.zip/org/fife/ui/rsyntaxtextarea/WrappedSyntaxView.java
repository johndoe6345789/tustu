/*      */ package org.fife.ui.rsyntaxtextarea;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Shape;
/*      */ import javax.swing.event.DocumentEvent;
/*      */ import javax.swing.text.BadLocationException;
/*      */ import javax.swing.text.BoxView;
/*      */ import javax.swing.text.Document;
/*      */ import javax.swing.text.Element;
/*      */ import javax.swing.text.LayeredHighlighter;
/*      */ import javax.swing.text.Position;
/*      */ import javax.swing.text.Segment;
/*      */ import javax.swing.text.TabExpander;
/*      */ import javax.swing.text.View;
/*      */ import javax.swing.text.ViewFactory;
/*      */ import org.fife.ui.rsyntaxtextarea.folding.Fold;
/*      */ import org.fife.ui.rsyntaxtextarea.folding.FoldManager;
/*      */ import org.fife.ui.rtextarea.Gutter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WrappedSyntaxView
/*      */   extends BoxView
/*      */   implements TabExpander, RSTAView
/*      */ {
/*      */   private int tabBase;
/*      */   private int tabSize;
/*      */   private Segment s;
/*      */   private Segment drawSeg;
/*      */   private Rectangle tempRect;
/*      */   private RSyntaxTextArea host;
/*      */   private FontMetrics metrics;
/*      */   private TokenImpl tempToken;
/*      */   private TokenImpl lineCountTempToken;
/*      */   private static final int MIN_WIDTH = 20;
/*      */   
/*      */   public WrappedSyntaxView(Element elem) {
/*   91 */     super(elem, 1);
/*   92 */     this.tempToken = new TokenImpl();
/*   93 */     this.s = new Segment();
/*   94 */     this.drawSeg = new Segment();
/*   95 */     this.tempRect = new Rectangle();
/*   96 */     this.lineCountTempToken = new TokenImpl();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int calculateBreakPosition(int p0, Token tokenList, float x0) {
/*  111 */     int p = p0;
/*  112 */     RSyntaxTextArea textArea = (RSyntaxTextArea)getContainer();
/*  113 */     float currentWidth = getWidth();
/*  114 */     if (currentWidth == 2.1474836E9F) {
/*  115 */       currentWidth = getPreferredSpan(0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  122 */     currentWidth = Math.max(currentWidth, 20.0F);
/*  123 */     Token t = tokenList;
/*  124 */     while (t != null && t.isPaintable()) {
/*      */ 
/*      */ 
/*      */       
/*  128 */       float tokenWidth = t.getWidth(textArea, this, x0);
/*  129 */       if (tokenWidth > currentWidth) {
/*      */ 
/*      */         
/*  132 */         if (p == p0) {
/*  133 */           return t.getOffsetBeforeX(textArea, this, 0.0F, currentWidth);
/*      */         }
/*      */ 
/*      */         
/*  137 */         return t.isWhitespace() ? (p + t.length()) : p;
/*      */       } 
/*      */       
/*  140 */       currentWidth -= tokenWidth;
/*  141 */       x0 += tokenWidth;
/*  142 */       p += t.length();
/*      */       
/*  144 */       t = t.getNextToken();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  150 */     return p + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void changedUpdate(DocumentEvent e, Shape a, ViewFactory f) {
/*  173 */     updateChildren(e, a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void childAllocation2(int line, int y, Rectangle alloc) {
/*  188 */     alloc.x += getOffset(0, line);
/*  189 */     alloc.y += y;
/*  190 */     alloc.width = getSpan(0, line);
/*  191 */     alloc.height = getSpan(1, line);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  196 */     Insets margin = this.host.getMargin();
/*  197 */     if (margin != null) {
/*  198 */       alloc.y -= margin.top;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void drawView(TokenPainter painter, Graphics2D g, Rectangle r, View view, int fontHeight, int y, int line) {
/*  218 */     float x = r.x;
/*      */     
/*  220 */     LayeredHighlighter h = (LayeredHighlighter)this.host.getHighlighter();
/*      */     
/*  222 */     RSyntaxDocument document = (RSyntaxDocument)getDocument();
/*  223 */     Element map = getElement();
/*      */     
/*  225 */     int p0 = view.getStartOffset();
/*  226 */     int lineNumber = map.getElementIndex(p0);
/*  227 */     int p1 = view.getEndOffset();
/*      */     
/*  229 */     setSegment(p0, p1 - 1, document, this.drawSeg);
/*      */     
/*  231 */     int start = p0 - this.drawSeg.offset;
/*  232 */     Token token = document.getTokenListForLine(lineNumber);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  237 */     if (token != null && token.getType() == 0) {
/*  238 */       h.paintLayeredHighlights(g, p0, p1, r, this.host, this);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  243 */     while (token != null && token.isPaintable()) {
/*      */       
/*  245 */       int p = calculateBreakPosition(p0, token, x);
/*  246 */       x = r.x;
/*      */       
/*  248 */       h.paintLayeredHighlights(g, p0, p, r, this.host, this);
/*      */       
/*  250 */       while (token != null && token.isPaintable() && token.getEndOffset() - 1 < p) {
/*  251 */         boolean paintBG = this.host.getPaintTokenBackgrounds(line, y);
/*  252 */         x = painter.paint(token, g, x, y, this.host, this, 0.0F, paintBG);
/*  253 */         token = token.getNextToken();
/*      */       } 
/*      */       
/*  256 */       if (token != null && token.isPaintable() && token.getOffset() < p) {
/*  257 */         int tokenOffset = token.getOffset();
/*  258 */         this.tempToken.set(this.drawSeg.array, tokenOffset - start, p - 1 - start, tokenOffset, token
/*  259 */             .getType());
/*  260 */         this.tempToken.setLanguageIndex(token.getLanguageIndex());
/*  261 */         boolean paintBG = this.host.getPaintTokenBackgrounds(line, y);
/*  262 */         painter.paint(this.tempToken, g, x, y, this.host, this, 0.0F, paintBG);
/*  263 */         this.tempToken.copyFrom(token);
/*  264 */         this.tempToken.makeStartAt(p);
/*  265 */         token = new TokenImpl(this.tempToken);
/*      */       } 
/*      */       
/*  268 */       p0 = (p == p0) ? p1 : p;
/*  269 */       y += fontHeight;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  275 */     if (this.host.getEOLMarkersVisible()) {
/*  276 */       g.setColor(this.host.getForegroundForTokenType(21));
/*  277 */       g.setFont(this.host.getFontForTokenType(21));
/*  278 */       g.drawString("¶", x, y - fontHeight);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void drawViewWithSelection(TokenPainter painter, Graphics2D g, Rectangle r, View view, int fontHeight, int y, int selStart, int selEnd) {
/*  302 */     float x = r.x;
/*  303 */     boolean useSTC = this.host.getUseSelectedTextColor();
/*      */     
/*  305 */     LayeredHighlighter h = (LayeredHighlighter)this.host.getHighlighter();
/*      */     
/*  307 */     RSyntaxDocument document = (RSyntaxDocument)getDocument();
/*  308 */     Element map = getElement();
/*      */     
/*  310 */     int p0 = view.getStartOffset();
/*  311 */     int lineNumber = map.getElementIndex(p0);
/*  312 */     int p1 = view.getEndOffset();
/*      */     
/*  314 */     setSegment(p0, p1 - 1, document, this.drawSeg);
/*      */     
/*  316 */     int start = p0 - this.drawSeg.offset;
/*  317 */     Token token = document.getTokenListForLine(lineNumber);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  322 */     if (token != null && token.getType() == 0) {
/*  323 */       h.paintLayeredHighlights(g, p0, p1, r, this.host, this);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  328 */     while (token != null && token.isPaintable()) {
/*      */       
/*  330 */       int p = calculateBreakPosition(p0, token, x);
/*  331 */       x = r.x;
/*      */       
/*  333 */       h.paintLayeredHighlights(g, p0, p, r, this.host, this);
/*      */       
/*  335 */       while (token != null && token.isPaintable() && token.getEndOffset() - 1 < p) {
/*      */ 
/*      */         
/*  338 */         if (token.containsPosition(selStart)) {
/*      */ 
/*      */           
/*  341 */           if (selStart > token.getOffset()) {
/*  342 */             this.tempToken.copyFrom(token);
/*  343 */             this.tempToken.textCount = selStart - this.tempToken.getOffset();
/*  344 */             x = painter.paint(this.tempToken, g, x, y, this.host, this);
/*  345 */             this.tempToken.textCount = token.length();
/*  346 */             this.tempToken.makeStartAt(selStart);
/*      */ 
/*      */             
/*  349 */             token = new TokenImpl(this.tempToken);
/*      */           } 
/*      */           
/*  352 */           int selCount = Math.min(token.length(), selEnd - token.getOffset());
/*  353 */           if (selCount == token.length()) {
/*  354 */             x = painter.paintSelected(token, g, x, y, this.host, this, useSTC);
/*      */           }
/*      */           else {
/*      */             
/*  358 */             this.tempToken.copyFrom(token);
/*  359 */             this.tempToken.textCount = selCount;
/*  360 */             x = painter.paintSelected(this.tempToken, g, x, y, this.host, this, useSTC);
/*      */             
/*  362 */             this.tempToken.textCount = token.length();
/*  363 */             this.tempToken.makeStartAt(token.getOffset() + selCount);
/*  364 */             token = this.tempToken;
/*  365 */             x = painter.paint(token, g, x, y, this.host, this);
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*  371 */         else if (token.containsPosition(selEnd)) {
/*  372 */           this.tempToken.copyFrom(token);
/*  373 */           this.tempToken.textCount = selEnd - this.tempToken.getOffset();
/*  374 */           x = painter.paintSelected(this.tempToken, g, x, y, this.host, this, useSTC);
/*      */           
/*  376 */           this.tempToken.textCount = token.length();
/*  377 */           this.tempToken.makeStartAt(selEnd);
/*  378 */           token = this.tempToken;
/*  379 */           x = painter.paint(token, g, x, y, this.host, this);
/*      */ 
/*      */         
/*      */         }
/*  383 */         else if (token.getOffset() >= selStart && token
/*  384 */           .getEndOffset() <= selEnd) {
/*  385 */           x = painter.paintSelected(token, g, x, y, this.host, this, useSTC);
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  390 */           x = painter.paint(token, g, x, y, this.host, this);
/*      */         } 
/*      */         
/*  393 */         token = token.getNextToken();
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  398 */       if (token != null && token.isPaintable() && token.getOffset() < p) {
/*      */         
/*  400 */         int tokenOffset = token.getOffset();
/*  401 */         Token orig = token;
/*      */         
/*  403 */         token = new TokenImpl(this.drawSeg, tokenOffset - start, p - 1 - start, tokenOffset, token.getType(), token.getLanguageIndex());
/*  404 */         token.setLanguageIndex(token.getLanguageIndex());
/*      */ 
/*      */         
/*  407 */         if (token.containsPosition(selStart)) {
/*      */           
/*  409 */           if (selStart > token.getOffset()) {
/*  410 */             this.tempToken.copyFrom(token);
/*  411 */             this.tempToken.textCount = selStart - this.tempToken.getOffset();
/*  412 */             x = painter.paint(this.tempToken, g, x, y, this.host, this);
/*  413 */             this.tempToken.textCount = token.length();
/*  414 */             this.tempToken.makeStartAt(selStart);
/*      */ 
/*      */             
/*  417 */             token = new TokenImpl(this.tempToken);
/*      */           } 
/*      */           
/*  420 */           int selCount = Math.min(token.length(), selEnd - token.getOffset());
/*  421 */           if (selCount == token.length()) {
/*  422 */             x = painter.paintSelected(token, g, x, y, this.host, this, useSTC);
/*      */           }
/*      */           else {
/*      */             
/*  426 */             this.tempToken.copyFrom(token);
/*  427 */             this.tempToken.textCount = selCount;
/*  428 */             x = painter.paintSelected(this.tempToken, g, x, y, this.host, this, useSTC);
/*      */             
/*  430 */             this.tempToken.textCount = token.length();
/*  431 */             this.tempToken.makeStartAt(token.getOffset() + selCount);
/*  432 */             token = this.tempToken;
/*  433 */             x = painter.paint(token, g, x, y, this.host, this);
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*  439 */         else if (token.containsPosition(selEnd)) {
/*  440 */           this.tempToken.copyFrom(token);
/*  441 */           this.tempToken.textCount = selEnd - this.tempToken.getOffset();
/*  442 */           x = painter.paintSelected(this.tempToken, g, x, y, this.host, this, useSTC);
/*      */           
/*  444 */           this.tempToken.textCount = token.length();
/*  445 */           this.tempToken.makeStartAt(selEnd);
/*  446 */           token = this.tempToken;
/*  447 */           x = painter.paint(token, g, x, y, this.host, this);
/*      */ 
/*      */         
/*      */         }
/*  451 */         else if (token.getOffset() >= selStart && token
/*  452 */           .getEndOffset() <= selEnd) {
/*  453 */           x = painter.paintSelected(token, g, x, y, this.host, this, useSTC);
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  458 */           x = painter.paint(token, g, x, y, this.host, this);
/*      */         } 
/*      */         
/*  461 */         token = new TokenImpl(orig);
/*  462 */         ((TokenImpl)token).makeStartAt(p);
/*      */       } 
/*      */ 
/*      */       
/*  466 */       p0 = (p == p0) ? p1 : p;
/*  467 */       y += fontHeight;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  473 */     if (this.host.getEOLMarkersVisible()) {
/*  474 */       g.setColor(this.host.getForegroundForTokenType(21));
/*  475 */       g.setFont(this.host.getFontForTokenType(21));
/*  476 */       g.drawString("¶", x, y - fontHeight);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape getChildAllocation(int index, Shape a) {
/*  494 */     if (a != null) {
/*  495 */       Shape ca = getChildAllocationImpl(index, a);
/*  496 */       if (ca != null && !isAllocationValid()) {
/*      */ 
/*      */         
/*  499 */         Rectangle r = (ca instanceof Rectangle) ? (Rectangle)ca : ca.getBounds();
/*  500 */         if (r.width == 0 && r.height == 0) {
/*  501 */           return null;
/*      */         }
/*      */       } 
/*  504 */       return ca;
/*      */     } 
/*  506 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape getChildAllocationImpl(int line, Shape a) {
/*  519 */     Rectangle alloc = getInsideAllocation(a);
/*  520 */     this.host = (RSyntaxTextArea)getContainer();
/*  521 */     FoldManager fm = this.host.getFoldManager();
/*  522 */     int y = alloc.y;
/*      */ 
/*      */ 
/*      */     
/*  526 */     for (int i = 0; i < line; i++) {
/*  527 */       y += getSpan(1, i);
/*  528 */       Fold fold = fm.getFoldForLine(i);
/*  529 */       if (fold != null && fold.isCollapsed()) {
/*  530 */         i += fold.getCollapsedLineCount();
/*      */       }
/*      */     } 
/*      */     
/*  534 */     childAllocation2(line, y, alloc);
/*  535 */     return alloc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMaximumSpan(int axis) {
/*  557 */     updateMetrics();
/*  558 */     float span = super.getPreferredSpan(axis);
/*  559 */     if (axis == 0) {
/*  560 */       span += this.metrics.charWidth('¶');
/*      */     }
/*  562 */     return span;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMinimumSpan(int axis) {
/*  583 */     updateMetrics();
/*  584 */     float span = super.getPreferredSpan(axis);
/*  585 */     if (axis == 0) {
/*  586 */       span += this.metrics.charWidth('¶');
/*      */     }
/*  588 */     return span;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getPreferredSpan(int axis) {
/*  609 */     updateMetrics();
/*  610 */     float span = 0.0F;
/*  611 */     if (axis == 0) {
/*  612 */       span = super.getPreferredSpan(axis);
/*  613 */       span += this.metrics.charWidth('¶');
/*      */     } else {
/*      */       
/*  616 */       span = super.getPreferredSpan(axis);
/*  617 */       this.host = (RSyntaxTextArea)getContainer();
/*  618 */       if (this.host.isCodeFoldingEnabled()) {
/*      */ 
/*      */         
/*  621 */         int lineCount = this.host.getLineCount();
/*  622 */         FoldManager fm = this.host.getFoldManager();
/*  623 */         for (int i = 0; i < lineCount; i++) {
/*  624 */           if (fm.isLineHidden(i)) {
/*  625 */             span -= getSpan(1, i);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  630 */     return span;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getTabSize() {
/*  641 */     Integer i = (Integer)getDocument().getProperty("tabSize");
/*  642 */     int size = (i != null) ? i.intValue() : 5;
/*  643 */     return size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected View getViewAtPoint(int x, int y, Rectangle alloc) {
/*  653 */     int lineCount = getViewCount();
/*  654 */     int curY = alloc.y + getOffset(1, 0);
/*  655 */     this.host = (RSyntaxTextArea)getContainer();
/*  656 */     FoldManager fm = this.host.getFoldManager();
/*      */     
/*  658 */     for (int line = 1; line < lineCount; line++) {
/*  659 */       int span = getSpan(1, line - 1);
/*  660 */       if (y < curY + span) {
/*  661 */         childAllocation2(line - 1, curY, alloc);
/*  662 */         return getView(line - 1);
/*      */       } 
/*  664 */       curY += span;
/*  665 */       Fold fold = fm.getFoldForLine(line - 1);
/*  666 */       if (fold != null && fold.isCollapsed()) {
/*  667 */         line += fold.getCollapsedLineCount();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  672 */     childAllocation2(lineCount - 1, curY, alloc);
/*  673 */     return getView(lineCount - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertUpdate(DocumentEvent changes, Shape a, ViewFactory f) {
/*  690 */     updateChildren(changes, a);
/*      */     
/*  692 */     Rectangle alloc = (a != null && isAllocationValid()) ? getInsideAllocation(a) : null;
/*  693 */     int pos = changes.getOffset();
/*  694 */     View v = getViewAtPosition(pos, alloc);
/*  695 */     if (v != null) {
/*  696 */       v.insertUpdate(changes, alloc, f);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void loadChildren(ViewFactory f) {
/*  713 */     Element e = getElement();
/*  714 */     int n = e.getElementCount();
/*  715 */     if (n > 0) {
/*  716 */       View[] added = new View[n];
/*  717 */       for (int i = 0; i < n; i++) {
/*  718 */         added[i] = new WrappedLine(e.getElement(i));
/*      */       }
/*  720 */       replace(0, 0, added);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape modelToView(int pos, Shape a, Position.Bias b) throws BadLocationException {
/*  729 */     if (!isAllocationValid()) {
/*  730 */       Rectangle alloc = a.getBounds();
/*  731 */       setSize(alloc.width, alloc.height);
/*      */     } 
/*      */     
/*  734 */     boolean isBackward = (b == Position.Bias.Backward);
/*  735 */     int testPos = isBackward ? Math.max(0, pos - 1) : pos;
/*  736 */     if (isBackward && testPos < getStartOffset()) {
/*  737 */       return null;
/*      */     }
/*      */     
/*  740 */     int vIndex = getViewIndexAtPosition(testPos);
/*  741 */     if (vIndex != -1 && vIndex < getViewCount()) {
/*  742 */       View v = getView(vIndex);
/*  743 */       if (v != null && testPos >= v.getStartOffset() && testPos < v
/*  744 */         .getEndOffset()) {
/*  745 */         Shape childShape = getChildAllocation(vIndex, a);
/*  746 */         if (childShape == null)
/*      */         {
/*  748 */           return null;
/*      */         }
/*  750 */         Shape retShape = v.modelToView(pos, childShape, b);
/*  751 */         if (retShape == null && v.getEndOffset() == pos && 
/*  752 */           ++vIndex < getViewCount()) {
/*  753 */           v = getView(vIndex);
/*  754 */           retShape = v.modelToView(pos, getChildAllocation(vIndex, a), b);
/*      */         } 
/*      */         
/*  757 */         return retShape;
/*      */       } 
/*      */     } 
/*      */     
/*  761 */     throw new BadLocationException("Position not represented by view", pos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape modelToView(int p0, Position.Bias b0, int p1, Position.Bias b1, Shape a) throws BadLocationException {
/*  806 */     Shape s1, s0 = modelToView(p0, a, b0);
/*      */     
/*  808 */     if (p1 == getEndOffset()) {
/*      */       try {
/*  810 */         s1 = modelToView(p1, a, b1);
/*  811 */       } catch (BadLocationException ble) {
/*  812 */         s1 = null;
/*      */       } 
/*  814 */       if (s1 == null)
/*      */       {
/*      */         
/*  817 */         Rectangle alloc = (a instanceof Rectangle) ? (Rectangle)a : a.getBounds();
/*  818 */         s1 = new Rectangle(alloc.x + alloc.width - 1, alloc.y, 1, alloc.height);
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  823 */       s1 = modelToView(p1, a, b1);
/*      */     } 
/*  825 */     Rectangle r0 = s0.getBounds();
/*      */     
/*  827 */     Rectangle r1 = (s1 instanceof Rectangle) ? (Rectangle)s1 : s1.getBounds();
/*  828 */     if (r0.y != r1.y) {
/*      */ 
/*      */       
/*  831 */       Rectangle alloc = (a instanceof Rectangle) ? (Rectangle)a : a.getBounds();
/*  832 */       r0.x = alloc.x;
/*  833 */       r0.width = alloc.width;
/*      */     } 
/*      */     
/*  836 */     r0.add(r1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  844 */     if (p1 > p0) {
/*  845 */       r0.width -= r1.width;
/*      */     }
/*  847 */     return r0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float nextTabStop(float x, int tabOffset) {
/*  864 */     if (this.tabSize == 0) {
/*  865 */       return x;
/*      */     }
/*  867 */     int ntabs = ((int)x - this.tabBase) / this.tabSize;
/*  868 */     return this.tabBase + (ntabs + 1.0F) * this.tabSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void paint(Graphics g, Shape a) {
/*  882 */     Rectangle alloc = (a instanceof Rectangle) ? (Rectangle)a : a.getBounds();
/*  883 */     this.tabBase = alloc.x;
/*      */     
/*  885 */     Graphics2D g2d = (Graphics2D)g;
/*  886 */     this.host = (RSyntaxTextArea)getContainer();
/*  887 */     int ascent = this.host.getMaxAscent();
/*  888 */     int fontHeight = this.host.getLineHeight();
/*  889 */     FoldManager fm = this.host.getFoldManager();
/*  890 */     TokenPainter painter = this.host.getTokenPainter();
/*  891 */     Element root = getElement();
/*      */ 
/*      */     
/*  894 */     int selStart = this.host.getSelectionStart();
/*  895 */     int selEnd = this.host.getSelectionEnd();
/*      */     
/*  897 */     int n = getViewCount();
/*  898 */     int x = alloc.x + getLeftInset();
/*  899 */     alloc.y += getTopInset();
/*  900 */     Rectangle clip = g.getClipBounds();
/*  901 */     for (int i = 0; i < n; i++) {
/*      */       
/*  903 */       this.tempRect.x = x + getOffset(0, i);
/*      */       
/*  905 */       this.tempRect.width = getSpan(0, i);
/*  906 */       this.tempRect.height = getSpan(1, i);
/*      */ 
/*      */       
/*  909 */       if (this.tempRect.intersects(clip)) {
/*  910 */         Element lineElement = root.getElement(i);
/*  911 */         int startOffset = lineElement.getStartOffset();
/*  912 */         int endOffset = lineElement.getEndOffset() - 1;
/*  913 */         View view = getView(i);
/*  914 */         if (selStart == selEnd || startOffset >= selEnd || endOffset < selStart) {
/*      */           
/*  916 */           drawView(painter, g2d, alloc, view, fontHeight, this.tempRect.y + ascent, i);
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  921 */           drawViewWithSelection(painter, g2d, alloc, view, fontHeight, this.tempRect.y + ascent, selStart, selEnd);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  926 */       this.tempRect.y += this.tempRect.height;
/*      */       
/*  928 */       Fold possibleFold = fm.getFoldForLine(i);
/*  929 */       if (possibleFold != null && possibleFold.isCollapsed()) {
/*  930 */         i += possibleFold.getCollapsedLineCount();
/*      */         
/*  932 */         Color c = RSyntaxUtilities.getFoldedLineBottomColor(this.host);
/*  933 */         if (c != null) {
/*  934 */           g.setColor(c);
/*  935 */           g.drawLine(x, this.tempRect.y - 1, this.host.getWidth(), this.tempRect.y - 1);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeUpdate(DocumentEvent changes, Shape a, ViewFactory f) {
/*  957 */     updateChildren(changes, a);
/*      */ 
/*      */     
/*  960 */     Rectangle alloc = (a != null && isAllocationValid()) ? getInsideAllocation(a) : null;
/*  961 */     int pos = changes.getOffset();
/*  962 */     View v = getViewAtPosition(pos, alloc);
/*  963 */     if (v != null) {
/*  964 */       v.removeUpdate(changes, alloc, f);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setSegment(int p0, int p1, Document document, Segment seg) {
/*      */     try {
/*  984 */       document.getText(p0, p1 - p0, seg);
/*      */     }
/*  986 */     catch (BadLocationException ble) {
/*  987 */       ble.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSize(float width, float height) {
/* 1001 */     updateMetrics();
/* 1002 */     if ((int)width != getWidth()) {
/*      */ 
/*      */       
/* 1005 */       preferenceChanged((View)null, true, true);
/* 1006 */       setWidthChangePending(true);
/*      */     } 
/* 1008 */     super.setSize(width, height);
/* 1009 */     setWidthChangePending(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private void setWidthChangePending(boolean widthChangePending) {
/* 1014 */     int count = getViewCount();
/* 1015 */     for (int i = 0; i < count; i++) {
/* 1016 */       View v = getView(i);
/* 1017 */       if (v instanceof WrappedLine) {
/* 1018 */         ((WrappedLine)v).widthChangePending = widthChangePending;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateChildren(DocumentEvent e, Shape a) {
/* 1030 */     Element elem = getElement();
/* 1031 */     DocumentEvent.ElementChange ec = e.getChange(elem);
/*      */ 
/*      */ 
/*      */     
/* 1035 */     if (e.getType() == DocumentEvent.EventType.CHANGE) {
/*      */ 
/*      */       
/* 1038 */       getContainer().repaint();
/*      */ 
/*      */     
/*      */     }
/* 1042 */     else if (ec != null) {
/*      */ 
/*      */       
/* 1045 */       Element[] removedElems = ec.getChildrenRemoved();
/* 1046 */       Element[] addedElems = ec.getChildrenAdded();
/* 1047 */       View[] added = new View[addedElems.length];
/*      */       
/* 1049 */       for (int i = 0; i < addedElems.length; i++) {
/* 1050 */         added[i] = new WrappedLine(addedElems[i]);
/*      */       }
/*      */ 
/*      */       
/* 1054 */       replace(ec.getIndex(), removedElems.length, added);
/*      */ 
/*      */       
/* 1057 */       if (a != null) {
/* 1058 */         preferenceChanged((View)null, true, true);
/* 1059 */         getContainer().repaint();
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1065 */     updateMetrics();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void updateMetrics() {
/* 1071 */     Component host = getContainer();
/* 1072 */     Font f = host.getFont();
/* 1073 */     this.metrics = host.getFontMetrics(f);
/* 1074 */     this.tabSize = getTabSize() * this.metrics.charWidth('m');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int viewToModel(float x, float y, Shape a, Position.Bias[] bias) {
/* 1081 */     int offs = -1;
/*      */     
/* 1083 */     if (!isAllocationValid()) {
/* 1084 */       Rectangle rectangle = a.getBounds();
/* 1085 */       setSize(rectangle.width, rectangle.height);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1090 */     Rectangle alloc = getInsideAllocation(a);
/* 1091 */     View v = getViewAtPoint((int)x, (int)y, alloc);
/* 1092 */     if (v != null) {
/* 1093 */       offs = v.viewToModel(x, y, alloc, bias);
/*      */ 
/*      */ 
/*      */       
/* 1097 */       if (this.host.isCodeFoldingEnabled() && v == getView(getViewCount() - 1) && offs == v
/* 1098 */         .getEndOffset() - 1) {
/* 1099 */         offs = this.host.getLastVisibleOffset();
/*      */       }
/*      */     } 
/* 1102 */     return offs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int yForLine(Rectangle alloc, int line) throws BadLocationException {
/* 1109 */     return yForLineContaining(alloc, 
/* 1110 */         getElement().getElement(line).getStartOffset());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int yForLineContaining(Rectangle alloc, int offs) throws BadLocationException {
/* 1118 */     if (isAllocationValid()) {
/*      */ 
/*      */       
/* 1121 */       Rectangle r = (Rectangle)modelToView(offs, alloc, Position.Bias.Forward);
/* 1122 */       if (r != null) {
/* 1123 */         if (this.host.isCodeFoldingEnabled()) {
/* 1124 */           int line = this.host.getLineOfOffset(offs);
/* 1125 */           FoldManager fm = this.host.getFoldManager();
/* 1126 */           if (fm.isLineHidden(line)) {
/* 1127 */             return -1;
/*      */           }
/*      */         } 
/* 1130 */         return r.y;
/*      */       } 
/*      */     } 
/* 1133 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class WrappedLine
/*      */     extends View
/*      */   {
/*      */     private int nlines;
/*      */ 
/*      */     
/*      */     private boolean widthChangePending;
/*      */ 
/*      */ 
/*      */     
/*      */     WrappedLine(Element elem) {
/* 1150 */       super(elem);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final int calculateLineCount() {
/* 1159 */       int nlines = 0;
/* 1160 */       int startOffset = getStartOffset();
/* 1161 */       int p1 = getEndOffset();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1166 */       RSyntaxTextArea textArea = (RSyntaxTextArea)getContainer();
/* 1167 */       RSyntaxDocument doc = (RSyntaxDocument)getDocument();
/* 1168 */       Element map = doc.getDefaultRootElement();
/* 1169 */       int line = map.getElementIndex(startOffset);
/* 1170 */       Token tokenList = doc.getTokenListForLine(line);
/* 1171 */       float x0 = 0.0F;
/*      */       
/*      */       int p0;
/*      */       
/* 1175 */       for (p0 = startOffset; p0 < p1; ) {
/*      */         
/* 1177 */         nlines++;
/* 1178 */         TokenUtils.TokenSubList subList = TokenUtils.getSubTokenList(tokenList, p0, WrappedSyntaxView.this, textArea, x0, WrappedSyntaxView.this
/* 1179 */             .lineCountTempToken);
/* 1180 */         x0 = (subList != null) ? subList.x : x0;
/* 1181 */         tokenList = (subList != null) ? subList.tokenList : null;
/* 1182 */         int p = WrappedSyntaxView.this.calculateBreakPosition(p0, tokenList, x0);
/*      */ 
/*      */         
/* 1185 */         p0 = (p == p0) ? ++p : p;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1201 */       return nlines;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public float getPreferredSpan(int axis) {
/*      */       float width;
/* 1217 */       switch (axis) {
/*      */         case 0:
/* 1219 */           width = WrappedSyntaxView.this.getWidth();
/* 1220 */           if (width == 2.1474836E9F)
/*      */           {
/*      */             
/* 1223 */             return 100.0F;
/*      */           }
/* 1225 */           return width;
/*      */         case 1:
/* 1227 */           if (this.nlines == 0 || this.widthChangePending) {
/* 1228 */             this.nlines = calculateLineCount();
/* 1229 */             this.widthChangePending = false;
/*      */           } 
/* 1231 */           return (this.nlines * ((RSyntaxTextArea)getContainer()).getLineHeight());
/*      */       } 
/* 1233 */       throw new IllegalArgumentException("Invalid axis: " + axis);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void paint(Graphics g, Shape a) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Shape modelToView(int pos, Shape a, Position.Bias b) throws BadLocationException {
/* 1266 */       Rectangle alloc = a.getBounds();
/* 1267 */       RSyntaxTextArea textArea = (RSyntaxTextArea)getContainer();
/* 1268 */       alloc.height = textArea.getLineHeight();
/* 1269 */       alloc.width = 1;
/* 1270 */       int p0 = getStartOffset();
/* 1271 */       int p1 = getEndOffset();
/*      */       
/* 1273 */       int testP = (b == Position.Bias.Forward) ? pos : Math.max(p0, pos - 1);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1278 */       RSyntaxDocument doc = (RSyntaxDocument)getDocument();
/* 1279 */       Element map = doc.getDefaultRootElement();
/* 1280 */       int line = map.getElementIndex(p0);
/* 1281 */       Token tokenList = doc.getTokenListForLine(line);
/* 1282 */       float x0 = alloc.x;
/*      */       
/* 1284 */       while (p0 < p1) {
/* 1285 */         TokenUtils.TokenSubList subList = TokenUtils.getSubTokenList(tokenList, p0, WrappedSyntaxView.this, textArea, x0, WrappedSyntaxView.this
/* 1286 */             .lineCountTempToken);
/* 1287 */         x0 = (subList != null) ? subList.x : x0;
/* 1288 */         tokenList = (subList != null) ? subList.tokenList : null;
/* 1289 */         int p = WrappedSyntaxView.this.calculateBreakPosition(p0, tokenList, x0);
/* 1290 */         if (pos >= p0 && testP < p) {
/*      */           
/* 1292 */           alloc = RSyntaxUtilities.getLineWidthUpTo(textArea, WrappedSyntaxView.this
/* 1293 */               .s, p0, pos, WrappedSyntaxView.this, alloc, alloc.x);
/*      */ 
/*      */ 
/*      */           
/* 1297 */           return alloc;
/*      */         } 
/*      */         
/* 1300 */         if (p == p1 - 1 && pos == p1 - 1) {
/*      */           
/* 1302 */           if (pos > p0) {
/* 1303 */             alloc = RSyntaxUtilities.getLineWidthUpTo(textArea, WrappedSyntaxView.this
/* 1304 */                 .s, p0, pos, WrappedSyntaxView.this, alloc, alloc.x);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 1309 */           return alloc;
/*      */         } 
/*      */         
/* 1312 */         p0 = (p == p0) ? p1 : p;
/*      */         
/* 1314 */         alloc.y += alloc.height;
/*      */       } 
/*      */ 
/*      */       
/* 1318 */       throw new BadLocationException(null, pos);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int viewToModel(float fx, float fy, Shape a, Position.Bias[] bias) {
/* 1337 */       bias[0] = Position.Bias.Forward;
/*      */       
/* 1339 */       Rectangle alloc = (Rectangle)a;
/* 1340 */       RSyntaxDocument doc = (RSyntaxDocument)getDocument();
/* 1341 */       int x = (int)fx;
/* 1342 */       int y = (int)fy;
/* 1343 */       if (y < alloc.y)
/*      */       {
/*      */         
/* 1346 */         return getStartOffset();
/*      */       }
/* 1348 */       if (y > alloc.y + alloc.height)
/*      */       {
/*      */         
/* 1351 */         return getEndOffset() - 1;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1361 */       RSyntaxTextArea textArea = (RSyntaxTextArea)getContainer();
/* 1362 */       alloc.height = textArea.getLineHeight();
/* 1363 */       int p1 = getEndOffset();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1368 */       Element map = doc.getDefaultRootElement();
/* 1369 */       int p0 = getStartOffset();
/* 1370 */       int line = map.getElementIndex(p0);
/* 1371 */       Token tlist = doc.getTokenListForLine(line);
/*      */ 
/*      */       
/* 1374 */       while (p0 < p1) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1379 */         TokenUtils.TokenSubList subList = TokenUtils.getSubTokenList(tlist, p0, WrappedSyntaxView.this, textArea, alloc.x, WrappedSyntaxView.this
/* 1380 */             .lineCountTempToken);
/* 1381 */         tlist = (subList != null) ? subList.tokenList : null;
/* 1382 */         int p = WrappedSyntaxView.this.calculateBreakPosition(p0, tlist, alloc.x);
/*      */ 
/*      */         
/* 1385 */         if (y >= alloc.y && y < alloc.y + alloc.height) {
/*      */ 
/*      */           
/* 1388 */           if (x < alloc.x) {
/* 1389 */             return p0;
/*      */           }
/*      */ 
/*      */           
/* 1393 */           if (x > alloc.x + alloc.width) {
/* 1394 */             return p - 1;
/*      */           }
/*      */ 
/*      */           
/* 1398 */           if (tlist != null) {
/*      */ 
/*      */ 
/*      */             
/* 1402 */             int n = tlist.getListOffset(textArea, WrappedSyntaxView.this, alloc.x, x);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1412 */             return Math.max(Math.min(n, p - 1), p0);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1418 */         p0 = (p == p0) ? p1 : p;
/* 1419 */         alloc.y += alloc.height;
/*      */       } 
/*      */ 
/*      */       
/* 1423 */       return getEndOffset() - 1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void handleDocumentEvent(DocumentEvent e, Shape a, ViewFactory f) {
/* 1431 */       int n = calculateLineCount();
/* 1432 */       if (this.nlines != n) {
/* 1433 */         this.nlines = n;
/* 1434 */         WrappedSyntaxView.this.preferenceChanged(this, false, true);
/*      */         
/* 1436 */         RSyntaxTextArea textArea = (RSyntaxTextArea)getContainer();
/* 1437 */         textArea.repaint();
/*      */ 
/*      */         
/* 1440 */         Gutter gutter = RSyntaxUtilities.getGutter(textArea);
/* 1441 */         if (gutter != null) {
/* 1442 */           gutter.revalidate();
/* 1443 */           gutter.repaint();
/*      */         }
/*      */       
/* 1446 */       } else if (a != null) {
/* 1447 */         Component c = getContainer();
/* 1448 */         Rectangle alloc = (Rectangle)a;
/* 1449 */         c.repaint(alloc.x, alloc.y, alloc.width, alloc.height);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void insertUpdate(DocumentEvent e, Shape a, ViewFactory f) {
/* 1455 */       handleDocumentEvent(e, a, f);
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeUpdate(DocumentEvent e, Shape a, ViewFactory f) {
/* 1460 */       handleDocumentEvent(e, a, f);
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/WrappedSyntaxView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */