/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import javax.swing.text.TabExpander;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TokenUtils
/*     */ {
/*     */   public static TokenSubList getSubTokenList(Token tokenList, int pos, TabExpander e, RSyntaxTextArea textArea, float x0) {
/*  61 */     return getSubTokenList(tokenList, pos, e, textArea, x0, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TokenSubList getSubTokenList(Token tokenList, int pos, TabExpander e, RSyntaxTextArea textArea, float x0, TokenImpl tempToken) {
/* 110 */     if (tempToken == null) {
/* 111 */       tempToken = new TokenImpl();
/*     */     }
/* 113 */     Token t = tokenList;
/*     */ 
/*     */ 
/*     */     
/* 117 */     while (t != null && t.isPaintable() && !t.containsPosition(pos)) {
/* 118 */       x0 += t.getWidth(textArea, e, x0);
/* 119 */       t = t.getNextToken();
/*     */     } 
/*     */ 
/*     */     
/* 123 */     if (t != null && t.isPaintable()) {
/*     */       
/* 125 */       if (t.getOffset() != pos) {
/*     */         
/* 127 */         int difference = pos - t.getOffset();
/* 128 */         x0 += t.getWidthUpTo(t.length() - difference + 1, textArea, e, x0);
/* 129 */         tempToken.copyFrom(t);
/* 130 */         tempToken.makeStartAt(pos);
/*     */         
/* 132 */         return new TokenSubList(tempToken, x0);
/*     */       } 
/*     */ 
/*     */       
/* 136 */       return new TokenSubList(t, x0);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     return new TokenSubList(tokenList, x0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String tokenToHtml(RSyntaxTextArea textArea, Token token) {
/* 159 */     StringBuilder style = new StringBuilder();
/*     */     
/* 161 */     Font font = textArea.getFontForTokenType(token.getType());
/* 162 */     if (font.isBold()) {
/* 163 */       style.append("font-weight: bold;\n");
/*     */     }
/* 165 */     if (font.isItalic()) {
/* 166 */       style.append("font-style: italic;\n");
/*     */     }
/*     */     
/* 169 */     Color c = textArea.getForegroundForToken(token);
/* 170 */     style.append("color: ").append(HtmlUtil.getHexString(c)).append(";\n");
/*     */     
/* 172 */     return "<span style=\"" + style + "\">" + 
/* 173 */       HtmlUtil.escapeForHtml(token.getLexeme(), "\n", true) + "</span>";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TokenSubList
/*     */   {
/*     */     public Token tokenList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public float x;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TokenSubList(Token tokenList, float x) {
/* 196 */       this.tokenList = tokenList;
/* 197 */       this.x = x;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/TokenUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */