/*     */ package org.fife.ui.rsyntaxtextarea.modes;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import javax.swing.text.Segment;
/*     */ import org.fife.ui.rsyntaxtextarea.AbstractJFlexCTokenMaker;
/*     */ import org.fife.ui.rsyntaxtextarea.Token;
/*     */ import org.fife.ui.rsyntaxtextarea.TokenImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsvTokenMaker
/*     */   extends AbstractJFlexCTokenMaker
/*     */ {
/*     */   public static final int YYEOF = -1;
/*     */   public static final int STRING = 1;
/*     */   public static final int YYINITIAL = 0;
/*     */   private static final String ZZ_CMAP_PACKED = "\n\000\001\003\027\000\001\001\t\000\001\002ￓ\000";
/*  76 */   private static final char[] ZZ_CMAP = zzUnpackCMap("\n\000\001\003\027\000\001\001\t\000\001\002ￓ\000");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*     */ 
/*     */   
/*     */   private static final String ZZ_ACTION_PACKED_0 = "\002\000\001\001\001\002\001\003\001\004\001\005\001\006\001\007\001\005";
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackAction() {
/*  88 */     int[] result = new int[10];
/*  89 */     int offset = 0;
/*  90 */     offset = zzUnpackAction("\002\000\001\001\001\002\001\003\001\004\001\005\001\006\001\007\001\005", offset, result);
/*  91 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/*  95 */     int i = 0;
/*  96 */     int j = offset;
/*  97 */     int l = packed.length();
/*  98 */     label10: while (i < l) {
/*  99 */       int count = packed.charAt(i++);
/* 100 */       int value = packed.charAt(i++); while (true)
/* 101 */       { result[j++] = value; if (--count <= 0)
/*     */           continue label10;  } 
/* 103 */     }  return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*     */ 
/*     */   
/*     */   private static final String ZZ_ROWMAP_PACKED_0 = "\000\000\000\004\000\b\000\f\000\f\000\f\000\020\000\024\000\f\000\f";
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackRowMap() {
/* 117 */     int[] result = new int[10];
/* 118 */     int offset = 0;
/* 119 */     offset = zzUnpackRowMap("\000\000\000\004\000\b\000\f\000\f\000\f\000\020\000\024\000\f\000\f", offset, result);
/* 120 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/* 124 */     int i = 0;
/* 125 */     int j = offset;
/* 126 */     int l = packed.length();
/* 127 */     while (i < l) {
/* 128 */       int high = packed.charAt(i++) << 16;
/* 129 */       result[j++] = high | packed.charAt(i++);
/*     */     } 
/* 131 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*     */   private static final String ZZ_TRANS_PACKED_0 = "\001\003\001\004\001\005\001\006\001\007\001\b\001\007\001\t\001\003\007\000\001\007\001\000\001\007\002\000\001\n\002\000";
/*     */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*     */   private static final int ZZ_NO_MATCH = 1;
/*     */   private static final int ZZ_PUSHBACK_2BIG = 2;
/*     */   
/*     */   private static int[] zzUnpackTrans() {
/* 144 */     int[] result = new int[24];
/* 145 */     int offset = 0;
/* 146 */     offset = zzUnpackTrans("\001\003\001\004\001\005\001\006\001\007\001\b\001\007\001\t\001\003\007\000\001\007\001\000\001\007\002\000\001\n\002\000", offset, result);
/* 147 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 151 */     int i = 0;
/* 152 */     int j = offset;
/* 153 */     int l = packed.length();
/* 154 */     label10: while (i < l) {
/* 155 */       int count = packed.charAt(i++);
/* 156 */       int value = packed.charAt(i++);
/* 157 */       value--; while (true)
/* 158 */       { result[j++] = value; if (--count <= 0)
/*     */           continue label10;  } 
/* 160 */     }  return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   private static final String[] ZZ_ERROR_MSG = new String[] { "Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*     */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "\002\000\001\001\003\t\002\001\002\t";
/*     */   private Reader zzReader;
/*     */   private int zzState;
/*     */   
/*     */   private static int[] zzUnpackAttribute() {
/* 185 */     int[] result = new int[10];
/* 186 */     int offset = 0;
/* 187 */     offset = zzUnpackAttribute("\002\000\001\001\003\t\002\001\002\t", offset, result);
/* 188 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 192 */     int i = 0;
/* 193 */     int j = offset;
/* 194 */     int l = packed.length();
/* 195 */     label10: while (i < l) {
/* 196 */       int count = packed.charAt(i++);
/* 197 */       int value = packed.charAt(i++); while (true)
/* 198 */       { result[j++] = value; if (--count <= 0)
/*     */           continue label10;  } 
/* 200 */     }  return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   private int zzLexicalState = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char[] zzBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzMarkedPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzPushbackPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzCurrentPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzStartRead;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzEndRead;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int yyline;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int yychar;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int yycolumn;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzAtBOL = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzAtEOF;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int INTERNAL_STRING = -2048;
/*     */ 
/*     */ 
/*     */   
/*     */   private int evenOdd;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsvTokenMaker() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addEndToken(int tokenType) {
/* 282 */     addToken(this.zzMarkedPos, this.zzMarkedPos, tokenType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addEvenOrOddColumnToken() {
/* 290 */     addEvenOrOddColumnToken(this.zzStartRead, this.zzMarkedPos - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addEvenOrOddColumnToken(int start, int end) {
/* 298 */     addToken(start, end, (this.evenOdd == 0) ? 20 : 16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addToken(int tokenType) {
/* 308 */     addToken(this.zzStartRead, this.zzMarkedPos - 1, tokenType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addToken(int start, int end, int tokenType) {
/* 318 */     int so = start + this.offsetShift;
/* 319 */     addToken(this.zzBuffer, start, end, tokenType, so);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addToken(char[] array, int start, int end, int tokenType, int startOffset) {
/* 335 */     super.addToken(array, start, end, tokenType, startOffset);
/* 336 */     this.zzStartRead = this.zzMarkedPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getClosestStandardTokenTypeForInternalType(int type) {
/* 346 */     return (type == -2048) ? 13 : type;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getMarkOccurrencesOfTokenType(int type) {
/* 352 */     return (type == 20 || type == 16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token getTokenList(Segment text, int initialTokenType, int startOffset) {
/* 370 */     resetTokenList();
/* 371 */     this.offsetShift = -text.offset + startOffset;
/*     */ 
/*     */     
/* 374 */     int state = 0;
/* 375 */     this.evenOdd = 0;
/* 376 */     if (initialTokenType < -1024) {
/* 377 */       state = 1;
/* 378 */       this.evenOdd = initialTokenType & 0x1;
/* 379 */       this.start = text.offset;
/*     */     } 
/*     */     
/* 382 */     this.s = text;
/*     */     try {
/* 384 */       yyreset(this.zzReader);
/* 385 */       yybegin(state);
/* 386 */       return yylex();
/* 387 */     } catch (IOException ioe) {
/* 388 */       ioe.printStackTrace();
/* 389 */       return new TokenImpl();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIdentifierChar(int languageIndex, char ch) {
/* 400 */     return (Character.isLetterOrDigit(ch) || ch == '-' || ch == '.' || ch == '_');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzRefill() {
/* 411 */     return (this.zzCurrentPos >= this.s.offset + this.s.count);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void yyreset(Reader reader) {
/* 427 */     this.zzBuffer = this.s.array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 435 */     this.zzStartRead = this.s.offset;
/* 436 */     this.zzEndRead = this.zzStartRead + this.s.count - 1;
/* 437 */     this.zzCurrentPos = this.zzMarkedPos = this.zzPushbackPos = this.s.offset;
/* 438 */     this.zzLexicalState = 0;
/* 439 */     this.zzReader = reader;
/* 440 */     this.zzAtBOL = true;
/* 441 */     this.zzAtEOF = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsvTokenMaker(Reader in) {
/* 454 */     this.zzReader = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CsvTokenMaker(InputStream in) {
/* 464 */     this(new InputStreamReader(in));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char[] zzUnpackCMap(String packed) {
/* 474 */     char[] map = new char[65536];
/* 475 */     int i = 0;
/* 476 */     int j = 0;
/* 477 */     label10: while (i < 14) {
/* 478 */       int count = packed.charAt(i++);
/* 479 */       char value = packed.charAt(i++); while (true)
/* 480 */       { map[j++] = value; if (--count <= 0)
/*     */           continue label10;  } 
/* 482 */     }  return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void yyclose() throws IOException {
/* 490 */     this.zzAtEOF = true;
/* 491 */     this.zzEndRead = this.zzStartRead;
/*     */     
/* 493 */     if (this.zzReader != null) {
/* 494 */       this.zzReader.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int yystate() {
/* 502 */     return this.zzLexicalState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void yybegin(int newState) {
/* 512 */     this.zzLexicalState = newState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String yytext() {
/* 520 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final char yycharat(int pos) {
/* 536 */     return this.zzBuffer[this.zzStartRead + pos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int yylength() {
/* 544 */     return this.zzMarkedPos - this.zzStartRead;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void zzScanError(int errorCode) {
/*     */     String message;
/*     */     try {
/* 565 */       message = ZZ_ERROR_MSG[errorCode];
/*     */     }
/* 567 */     catch (ArrayIndexOutOfBoundsException e) {
/* 568 */       message = ZZ_ERROR_MSG[0];
/*     */     } 
/*     */     
/* 571 */     throw new Error(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void yypushback(int number) {
/* 584 */     if (number > yylength()) {
/* 585 */       zzScanError(2);
/*     */     }
/* 587 */     this.zzMarkedPos -= number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token yylex() throws IOException {
/* 605 */     int zzEndReadL = this.zzEndRead;
/* 606 */     char[] zzBufferL = this.zzBuffer;
/* 607 */     char[] zzCMapL = ZZ_CMAP;
/*     */     
/* 609 */     int[] zzTransL = ZZ_TRANS;
/* 610 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 611 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*     */     
/*     */     while (true) {
/* 614 */       int zzInput, zzMarkedPosL = this.zzMarkedPos;
/*     */       
/* 616 */       int zzAction = -1;
/*     */       
/* 618 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*     */       
/* 620 */       this.zzState = this.zzLexicalState;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 626 */         if (zzCurrentPosL < zzEndReadL)
/* 627 */         { zzInput = zzBufferL[zzCurrentPosL++]; }
/* 628 */         else { if (this.zzAtEOF) {
/* 629 */             int i = -1;
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 634 */           this.zzCurrentPos = zzCurrentPosL;
/* 635 */           this.zzMarkedPos = zzMarkedPosL;
/* 636 */           boolean eof = zzRefill();
/*     */           
/* 638 */           zzCurrentPosL = this.zzCurrentPos;
/* 639 */           zzMarkedPosL = this.zzMarkedPos;
/* 640 */           zzBufferL = this.zzBuffer;
/* 641 */           zzEndReadL = this.zzEndRead;
/* 642 */           if (eof) {
/* 643 */             int i = -1;
/*     */             
/*     */             break;
/*     */           } 
/* 647 */           zzInput = zzBufferL[zzCurrentPosL++]; }
/*     */ 
/*     */         
/* 650 */         int zzNext = zzTransL[zzRowMapL[this.zzState] + zzCMapL[zzInput]];
/* 651 */         if (zzNext == -1)
/* 652 */           break;  this.zzState = zzNext;
/*     */         
/* 654 */         int zzAttributes = zzAttrL[this.zzState];
/* 655 */         if ((zzAttributes & 0x1) == 1) {
/* 656 */           zzAction = this.zzState;
/* 657 */           zzMarkedPosL = zzCurrentPosL;
/* 658 */           if ((zzAttributes & 0x8) == 8) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 665 */       this.zzMarkedPos = zzMarkedPosL;
/*     */       
/* 667 */       switch ((zzAction < 0) ? zzAction : ZZ_ACTION[zzAction]) {
/*     */         case 6:
/* 669 */           yybegin(0); addEvenOrOddColumnToken(this.start, this.zzStartRead); continue;
/*     */         case 8:
/*     */           continue;
/*     */         case 4:
/* 673 */           addNullToken(); return this.firstToken;
/*     */         case 9:
/*     */           continue;
/*     */         case 7:
/* 677 */           addEvenOrOddColumnToken(this.start, this.zzEndRead);
/* 678 */           addEndToken(0xFFFFF800 | this.evenOdd); return this.firstToken;
/*     */         case 10:
/*     */           continue;
/*     */         case 3:
/* 682 */           addToken(23);
/* 683 */           this.evenOdd = this.evenOdd + 1 & 0x1; continue;
/*     */         case 11:
/*     */           continue;
/*     */         case 1:
/* 687 */           addEvenOrOddColumnToken(); continue;
/*     */         case 12:
/*     */           continue;
/*     */         case 2:
/* 691 */           this.start = this.zzMarkedPos - 1; yybegin(1);
/*     */           continue;
/*     */         
/*     */         case 13:
/*     */         case 5:
/*     */         case 14:
/*     */           continue;
/*     */       } 
/* 699 */       if (zzInput == -1 && this.zzStartRead == this.zzCurrentPos) {
/* 700 */         this.zzAtEOF = true;
/* 701 */         switch (this.zzLexicalState) {
/*     */           case 1:
/* 703 */             addEvenOrOddColumnToken(this.start, this.zzEndRead);
/* 704 */             addEndToken(0xFFFFF800 | this.evenOdd); return this.firstToken;
/*     */           case 11:
/*     */             continue;
/*     */           case 0:
/* 708 */             addNullToken(); return this.firstToken;
/*     */           case 12:
/*     */             continue;
/*     */         } 
/* 712 */         return null;
/*     */       } 
/*     */ 
/*     */       
/* 716 */       zzScanError(1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/modes/CsvTokenMaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */