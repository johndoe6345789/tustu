/*      */ package org.fife.ui.rsyntaxtextarea.modes;
/*      */ 
/*      */ import javax.swing.text.Segment;
/*      */ import org.fife.ui.rsyntaxtextarea.AbstractTokenMaker;
/*      */ import org.fife.ui.rsyntaxtextarea.RSyntaxUtilities;
/*      */ import org.fife.ui.rsyntaxtextarea.Token;
/*      */ import org.fife.ui.rsyntaxtextarea.TokenMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UnixShellTokenMaker
/*      */   extends AbstractTokenMaker
/*      */ {
/*   25 */   protected final String operators = "=|><&";
/*   26 */   protected final String separators = "()[]";
/*   27 */   protected final String separators2 = ".,;";
/*   28 */   protected final String shellVariables = "#-?$!*@_";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int currentTokenStart;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int currentTokenType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addToken(Segment segment, int start, int end, int tokenType, int startOffset) {
/*      */     int value;
/*   56 */     switch (tokenType) {
/*      */ 
/*      */       
/*      */       case 20:
/*   60 */         value = this.wordsToHighlight.get(segment, start, end);
/*   61 */         if (value != -1) {
/*   62 */           tokenType = value;
/*      */         }
/*      */         break;
/*      */       case 1:
/*      */       case 10:
/*      */       case 13:
/*      */       case 14:
/*      */       case 15:
/*      */       case 17:
/*      */       case 21:
/*      */       case 22:
/*      */       case 23:
/*      */       case 24:
/*      */         break;
/*      */       default:
/*   77 */         tokenType = 20;
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*   82 */     super.addToken(segment, start, end, tokenType, startOffset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getLineCommentStartAndEnd(int languageIndex) {
/*   92 */     return new String[] { "#", null };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMarkOccurrencesOfTokenType(int type) {
/*  106 */     return (type == 20 || type == 17);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenMap getWordsToHighlight() {
/*  120 */     TokenMap tokenMap = new TokenMap();
/*      */     
/*  122 */     int reservedWord = 6;
/*  123 */     tokenMap.put("case", reservedWord);
/*  124 */     tokenMap.put("do", reservedWord);
/*  125 */     tokenMap.put("done", reservedWord);
/*  126 */     tokenMap.put("elif", reservedWord);
/*  127 */     tokenMap.put("else", reservedWord);
/*  128 */     tokenMap.put("esac", reservedWord);
/*  129 */     tokenMap.put("fi", reservedWord);
/*  130 */     tokenMap.put("for", reservedWord);
/*  131 */     tokenMap.put("if", reservedWord);
/*  132 */     tokenMap.put("in", reservedWord);
/*  133 */     tokenMap.put("select", reservedWord);
/*  134 */     tokenMap.put("then", reservedWord);
/*  135 */     tokenMap.put("until", reservedWord);
/*  136 */     tokenMap.put("while", reservedWord);
/*      */     
/*  138 */     int function = 8;
/*  139 */     tokenMap.put("addbib", function);
/*  140 */     tokenMap.put("admin", function);
/*  141 */     tokenMap.put("alias", function);
/*  142 */     tokenMap.put("apropos", function);
/*  143 */     tokenMap.put("ar", function);
/*  144 */     tokenMap.put("at", function);
/*  145 */     tokenMap.put("awk", function);
/*  146 */     tokenMap.put("banner", function);
/*  147 */     tokenMap.put("basename", function);
/*  148 */     tokenMap.put("batch", function);
/*  149 */     tokenMap.put("bg", function);
/*  150 */     tokenMap.put("biff", function);
/*  151 */     tokenMap.put("bin-mail", function);
/*  152 */     tokenMap.put("binmail", function);
/*  153 */     tokenMap.put("break", function);
/*  154 */     tokenMap.put("cal", function);
/*  155 */     tokenMap.put("calendar", function);
/*  156 */     tokenMap.put("cancel", function);
/*  157 */     tokenMap.put("cat", function);
/*  158 */     tokenMap.put("cb", function);
/*  159 */     tokenMap.put("cc", function);
/*  160 */     tokenMap.put("cd", function);
/*  161 */     tokenMap.put("cdc", function);
/*  162 */     tokenMap.put("chdir", function);
/*  163 */     tokenMap.put("checkeq", function);
/*  164 */     tokenMap.put("checknr", function);
/*  165 */     tokenMap.put("chfn", function);
/*  166 */     tokenMap.put("chgrp", function);
/*  167 */     tokenMap.put("chmod", function);
/*  168 */     tokenMap.put("chown", function);
/*  169 */     tokenMap.put("chsh", function);
/*  170 */     tokenMap.put("clear", function);
/*  171 */     tokenMap.put("cmp", function);
/*  172 */     tokenMap.put("colcrt", function);
/*  173 */     tokenMap.put("comb", function);
/*  174 */     tokenMap.put("comm", function);
/*  175 */     tokenMap.put("command", function);
/*  176 */     tokenMap.put("compress", function);
/*  177 */     tokenMap.put("continue", function);
/*  178 */     tokenMap.put("cp", function);
/*  179 */     tokenMap.put("cpio", function);
/*  180 */     tokenMap.put("cpp", function);
/*  181 */     tokenMap.put("crontab", function);
/*  182 */     tokenMap.put("csh", function);
/*  183 */     tokenMap.put("ctags", function);
/*  184 */     tokenMap.put("curl", function);
/*  185 */     tokenMap.put("cut", function);
/*  186 */     tokenMap.put("cvs", function);
/*  187 */     tokenMap.put("date", function);
/*  188 */     tokenMap.put("dbx", function);
/*  189 */     tokenMap.put("delta", function);
/*  190 */     tokenMap.put("deroff", function);
/*  191 */     tokenMap.put("df", function);
/*  192 */     tokenMap.put("diff", function);
/*  193 */     tokenMap.put("dtree", function);
/*  194 */     tokenMap.put("du", function);
/*  195 */     tokenMap.put("e", function);
/*  196 */     tokenMap.put("echo", function);
/*  197 */     tokenMap.put("ed", function);
/*  198 */     tokenMap.put("edit", function);
/*  199 */     tokenMap.put("enscript", function);
/*  200 */     tokenMap.put("eqn", function);
/*  201 */     tokenMap.put("error", function);
/*  202 */     tokenMap.put("eval", function);
/*  203 */     tokenMap.put("ex", function);
/*  204 */     tokenMap.put("exec", function);
/*  205 */     tokenMap.put("exit", function);
/*  206 */     tokenMap.put("expand", function);
/*  207 */     tokenMap.put("export", function);
/*  208 */     tokenMap.put("expr", function);
/*  209 */     tokenMap.put("false", function);
/*  210 */     tokenMap.put("fc", function);
/*  211 */     tokenMap.put("fg", function);
/*  212 */     tokenMap.put("file", function);
/*  213 */     tokenMap.put("find", function);
/*  214 */     tokenMap.put("finger", function);
/*  215 */     tokenMap.put("fmt", function);
/*  216 */     tokenMap.put("fmt_mail", function);
/*  217 */     tokenMap.put("fold", function);
/*  218 */     tokenMap.put("ftp", function);
/*  219 */     tokenMap.put("function", function);
/*  220 */     tokenMap.put("gcore", function);
/*  221 */     tokenMap.put("get", function);
/*  222 */     tokenMap.put("getopts", function);
/*  223 */     tokenMap.put("gprof", function);
/*  224 */     tokenMap.put("grep", function);
/*  225 */     tokenMap.put("groups", function);
/*  226 */     tokenMap.put("gunzip", function);
/*  227 */     tokenMap.put("gzip", function);
/*  228 */     tokenMap.put("hashcheck", function);
/*  229 */     tokenMap.put("hashmake", function);
/*  230 */     tokenMap.put("head", function);
/*  231 */     tokenMap.put("help", function);
/*  232 */     tokenMap.put("history", function);
/*  233 */     tokenMap.put("imake", function);
/*  234 */     tokenMap.put("indent", function);
/*  235 */     tokenMap.put("install", function);
/*  236 */     tokenMap.put("jobs", function);
/*  237 */     tokenMap.put("join", function);
/*  238 */     tokenMap.put("kill", function);
/*  239 */     tokenMap.put("last", function);
/*  240 */     tokenMap.put("ld", function);
/*  241 */     tokenMap.put("leave", function);
/*  242 */     tokenMap.put("less", function);
/*  243 */     tokenMap.put("let", function);
/*  244 */     tokenMap.put("lex", function);
/*  245 */     tokenMap.put("lint", function);
/*  246 */     tokenMap.put("ln", function);
/*  247 */     tokenMap.put("login", function);
/*  248 */     tokenMap.put("look", function);
/*  249 */     tokenMap.put("lookbib", function);
/*  250 */     tokenMap.put("lorder", function);
/*  251 */     tokenMap.put("lp", function);
/*  252 */     tokenMap.put("lpq", function);
/*  253 */     tokenMap.put("lpr", function);
/*  254 */     tokenMap.put("lprm", function);
/*  255 */     tokenMap.put("ls", function);
/*  256 */     tokenMap.put("mail", function);
/*  257 */     tokenMap.put("Mail", function);
/*  258 */     tokenMap.put("make", function);
/*  259 */     tokenMap.put("man", function);
/*  260 */     tokenMap.put("md", function);
/*  261 */     tokenMap.put("mesg", function);
/*  262 */     tokenMap.put("mkdir", function);
/*  263 */     tokenMap.put("mkstr", function);
/*  264 */     tokenMap.put("more", function);
/*  265 */     tokenMap.put("mount", function);
/*  266 */     tokenMap.put("mv", function);
/*  267 */     tokenMap.put("nawk", function);
/*  268 */     tokenMap.put("neqn", function);
/*  269 */     tokenMap.put("nice", function);
/*  270 */     tokenMap.put("nm", function);
/*  271 */     tokenMap.put("nroff", function);
/*  272 */     tokenMap.put("od", function);
/*  273 */     tokenMap.put("page", function);
/*  274 */     tokenMap.put("passwd", function);
/*  275 */     tokenMap.put("paste", function);
/*  276 */     tokenMap.put("pr", function);
/*  277 */     tokenMap.put("print", function);
/*  278 */     tokenMap.put("printf", function);
/*  279 */     tokenMap.put("printenv", function);
/*  280 */     tokenMap.put("prof", function);
/*  281 */     tokenMap.put("prs", function);
/*  282 */     tokenMap.put("prt", function);
/*  283 */     tokenMap.put("ps", function);
/*  284 */     tokenMap.put("ptx", function);
/*  285 */     tokenMap.put("pwd", function);
/*  286 */     tokenMap.put("quota", function);
/*  287 */     tokenMap.put("ranlib", function);
/*  288 */     tokenMap.put("rcp", function);
/*  289 */     tokenMap.put("rcs", function);
/*  290 */     tokenMap.put("rcsdiff", function);
/*  291 */     tokenMap.put("read", function);
/*  292 */     tokenMap.put("readonly", function);
/*  293 */     tokenMap.put("red", function);
/*  294 */     tokenMap.put("return", function);
/*  295 */     tokenMap.put("rev", function);
/*  296 */     tokenMap.put("rlogin", function);
/*  297 */     tokenMap.put("rm", function);
/*  298 */     tokenMap.put("rmdel", function);
/*  299 */     tokenMap.put("rmdir", function);
/*  300 */     tokenMap.put("roffbib", function);
/*  301 */     tokenMap.put("rsh", function);
/*  302 */     tokenMap.put("rup", function);
/*  303 */     tokenMap.put("ruptime", function);
/*  304 */     tokenMap.put("rusers", function);
/*  305 */     tokenMap.put("rwall", function);
/*  306 */     tokenMap.put("rwho", function);
/*  307 */     tokenMap.put("sact", function);
/*  308 */     tokenMap.put("sccs", function);
/*  309 */     tokenMap.put("sccsdiff", function);
/*  310 */     tokenMap.put("script", function);
/*  311 */     tokenMap.put("sed", function);
/*  312 */     tokenMap.put("set", function);
/*  313 */     tokenMap.put("setgroups", function);
/*  314 */     tokenMap.put("setsenv", function);
/*  315 */     tokenMap.put("sh", function);
/*  316 */     tokenMap.put("shift", function);
/*  317 */     tokenMap.put("size", function);
/*  318 */     tokenMap.put("sleep", function);
/*  319 */     tokenMap.put("sort", function);
/*  320 */     tokenMap.put("sortbib", function);
/*  321 */     tokenMap.put("spell", function);
/*  322 */     tokenMap.put("split", function);
/*  323 */     tokenMap.put("ssh", function);
/*  324 */     tokenMap.put("strings", function);
/*  325 */     tokenMap.put("strip", function);
/*  326 */     tokenMap.put("stty", function);
/*  327 */     tokenMap.put("su", function);
/*  328 */     tokenMap.put("sudo", function);
/*  329 */     tokenMap.put("symorder", function);
/*  330 */     tokenMap.put("tabs", function);
/*  331 */     tokenMap.put("tail", function);
/*  332 */     tokenMap.put("talk", function);
/*  333 */     tokenMap.put("tar", function);
/*  334 */     tokenMap.put("tbl", function);
/*  335 */     tokenMap.put("tee", function);
/*  336 */     tokenMap.put("telnet", function);
/*  337 */     tokenMap.put("test", function);
/*  338 */     tokenMap.put("tftp", function);
/*  339 */     tokenMap.put("time", function);
/*  340 */     tokenMap.put("times", function);
/*  341 */     tokenMap.put("touch", function);
/*  342 */     tokenMap.put("trap", function);
/*  343 */     tokenMap.put("troff", function);
/*  344 */     tokenMap.put("true", function);
/*  345 */     tokenMap.put("tsort", function);
/*  346 */     tokenMap.put("tty", function);
/*  347 */     tokenMap.put("type", function);
/*  348 */     tokenMap.put("typeset", function);
/*  349 */     tokenMap.put("ue", function);
/*  350 */     tokenMap.put("ul", function);
/*  351 */     tokenMap.put("ulimit", function);
/*  352 */     tokenMap.put("umask", function);
/*  353 */     tokenMap.put("unalias", function);
/*  354 */     tokenMap.put("uncompress", function);
/*  355 */     tokenMap.put("unexpand", function);
/*  356 */     tokenMap.put("unget", function);
/*  357 */     tokenMap.put("unifdef", function);
/*  358 */     tokenMap.put("uniq", function);
/*  359 */     tokenMap.put("units", function);
/*  360 */     tokenMap.put("unset", function);
/*  361 */     tokenMap.put("uptime", function);
/*  362 */     tokenMap.put("users", function);
/*  363 */     tokenMap.put("uucp", function);
/*  364 */     tokenMap.put("uudecode", function);
/*  365 */     tokenMap.put("uuencode", function);
/*  366 */     tokenMap.put("uulog", function);
/*  367 */     tokenMap.put("uuname", function);
/*  368 */     tokenMap.put("uusend", function);
/*  369 */     tokenMap.put("uux", function);
/*  370 */     tokenMap.put("vacation", function);
/*  371 */     tokenMap.put("val", function);
/*  372 */     tokenMap.put("vedit", function);
/*  373 */     tokenMap.put("vgrind", function);
/*  374 */     tokenMap.put("vi", function);
/*  375 */     tokenMap.put("view", function);
/*  376 */     tokenMap.put("vtroff", function);
/*  377 */     tokenMap.put("w", function);
/*  378 */     tokenMap.put("wait", function);
/*  379 */     tokenMap.put("wall", function);
/*  380 */     tokenMap.put("wc", function);
/*  381 */     tokenMap.put("wait", function);
/*  382 */     tokenMap.put("what", function);
/*  383 */     tokenMap.put("whatis", function);
/*  384 */     tokenMap.put("whence", function);
/*  385 */     tokenMap.put("whereis", function);
/*  386 */     tokenMap.put("which", function);
/*  387 */     tokenMap.put("who", function);
/*  388 */     tokenMap.put("whoami", function);
/*  389 */     tokenMap.put("write", function);
/*  390 */     tokenMap.put("xargs", function);
/*  391 */     tokenMap.put("xstr", function);
/*  392 */     tokenMap.put("yacc", function);
/*  393 */     tokenMap.put("yes", function);
/*  394 */     tokenMap.put("zcat", function);
/*      */     
/*  396 */     return tokenMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Token getTokenList(Segment text, int startTokenType, int startOffset) {
/*  412 */     resetTokenList();
/*      */     
/*  414 */     char[] array = text.array;
/*  415 */     int offset = text.offset;
/*  416 */     int count = text.count;
/*  417 */     int end = offset + count;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  423 */     int newStartOffset = startOffset - offset;
/*      */     
/*  425 */     this.currentTokenStart = offset;
/*  426 */     this.currentTokenType = startTokenType;
/*  427 */     boolean backslash = false;
/*      */ 
/*      */     
/*  430 */     for (int i = offset; i < end; i++) {
/*      */       int indexOf;
/*  432 */       char c = array[i];
/*      */       
/*  434 */       switch (this.currentTokenType) {
/*      */ 
/*      */         
/*      */         case 0:
/*  438 */           this.currentTokenStart = i;
/*      */           
/*  440 */           switch (c) {
/*      */             
/*      */             case '\t':
/*      */             case ' ':
/*  444 */               this.currentTokenType = 21;
/*      */               break;
/*      */             
/*      */             case '`':
/*  448 */               if (backslash) {
/*  449 */                 addToken(text, this.currentTokenStart, i, 20, newStartOffset + this.currentTokenStart);
/*  450 */                 backslash = false;
/*      */                 break;
/*      */               } 
/*  453 */               this.currentTokenType = 15;
/*      */               break;
/*      */ 
/*      */             
/*      */             case '"':
/*  458 */               if (backslash) {
/*  459 */                 addToken(text, this.currentTokenStart, i, 20, newStartOffset + this.currentTokenStart);
/*  460 */                 backslash = false;
/*      */                 break;
/*      */               } 
/*  463 */               this.currentTokenType = 13;
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\'':
/*  468 */               if (backslash) {
/*  469 */                 addToken(text, this.currentTokenStart, i, 20, newStartOffset + this.currentTokenStart);
/*  470 */                 backslash = false;
/*      */                 break;
/*      */               } 
/*  473 */               this.currentTokenType = 14;
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\\':
/*  478 */               addToken(text, this.currentTokenStart, i, 20, newStartOffset + this.currentTokenStart);
/*  479 */               this.currentTokenType = 0;
/*  480 */               backslash = !backslash;
/*      */               break;
/*      */             
/*      */             case '$':
/*  484 */               if (backslash) {
/*  485 */                 addToken(text, this.currentTokenStart, i, 20, newStartOffset + this.currentTokenStart);
/*  486 */                 backslash = false;
/*      */                 break;
/*      */               } 
/*  489 */               this.currentTokenType = 17;
/*      */               break;
/*      */ 
/*      */             
/*      */             case '#':
/*  494 */               backslash = false;
/*  495 */               this.currentTokenType = 1;
/*      */               break;
/*      */           } 
/*      */           
/*  499 */           if (RSyntaxUtilities.isDigit(c)) {
/*  500 */             this.currentTokenType = 10;
/*      */             break;
/*      */           } 
/*  503 */           if (RSyntaxUtilities.isLetter(c) || c == '/' || c == '_') {
/*  504 */             this.currentTokenType = 20;
/*      */             break;
/*      */           } 
/*  507 */           indexOf = "=|><&".indexOf(c, 0);
/*  508 */           if (indexOf > -1) {
/*  509 */             addToken(text, this.currentTokenStart, i, 23, newStartOffset + this.currentTokenStart);
/*  510 */             this.currentTokenType = 0;
/*      */             break;
/*      */           } 
/*  513 */           indexOf = "()[]".indexOf(c, 0);
/*  514 */           if (indexOf > -1) {
/*  515 */             addToken(text, this.currentTokenStart, i, 22, newStartOffset + this.currentTokenStart);
/*  516 */             this.currentTokenType = 0;
/*      */             break;
/*      */           } 
/*  519 */           indexOf = ".,;".indexOf(c, 0);
/*  520 */           if (indexOf > -1) {
/*  521 */             addToken(text, this.currentTokenStart, i, 20, newStartOffset + this.currentTokenStart);
/*  522 */             this.currentTokenType = 0;
/*      */             
/*      */             break;
/*      */           } 
/*  526 */           this.currentTokenType = 20;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 21:
/*  536 */           switch (c) {
/*      */             case '\t':
/*      */             case ' ':
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\\':
/*  543 */               addToken(text, this.currentTokenStart, i - 1, 21, newStartOffset + this.currentTokenStart);
/*  544 */               addToken(text, i, i, 20, newStartOffset + i);
/*  545 */               this.currentTokenType = 0;
/*  546 */               backslash = true;
/*      */               break;
/*      */             
/*      */             case '`':
/*  550 */               addToken(text, this.currentTokenStart, i - 1, 21, newStartOffset + this.currentTokenStart);
/*  551 */               this.currentTokenStart = i;
/*  552 */               this.currentTokenType = 15;
/*  553 */               backslash = false;
/*      */               break;
/*      */             
/*      */             case '"':
/*  557 */               addToken(text, this.currentTokenStart, i - 1, 21, newStartOffset + this.currentTokenStart);
/*  558 */               this.currentTokenStart = i;
/*  559 */               this.currentTokenType = 13;
/*  560 */               backslash = false;
/*      */               break;
/*      */             
/*      */             case '\'':
/*  564 */               addToken(text, this.currentTokenStart, i - 1, 21, newStartOffset + this.currentTokenStart);
/*  565 */               this.currentTokenStart = i;
/*  566 */               this.currentTokenType = 14;
/*  567 */               backslash = false;
/*      */               break;
/*      */             
/*      */             case '$':
/*  571 */               addToken(text, this.currentTokenStart, i - 1, 21, newStartOffset + this.currentTokenStart);
/*  572 */               this.currentTokenStart = i;
/*  573 */               this.currentTokenType = 17;
/*  574 */               backslash = false;
/*      */               break;
/*      */             
/*      */             case '#':
/*  578 */               addToken(text, this.currentTokenStart, i - 1, 21, newStartOffset + this.currentTokenStart);
/*  579 */               this.currentTokenStart = i;
/*  580 */               this.currentTokenType = 1;
/*      */               break;
/*      */           } 
/*      */ 
/*      */           
/*  585 */           addToken(text, this.currentTokenStart, i - 1, 21, newStartOffset + this.currentTokenStart);
/*  586 */           this.currentTokenStart = i;
/*      */           
/*  588 */           if (RSyntaxUtilities.isDigit(c)) {
/*  589 */             this.currentTokenType = 10;
/*      */             break;
/*      */           } 
/*  592 */           if (RSyntaxUtilities.isLetter(c) || c == '/' || c == '_') {
/*  593 */             this.currentTokenType = 20;
/*      */             break;
/*      */           } 
/*  596 */           indexOf = "=|><&".indexOf(c, 0);
/*  597 */           if (indexOf > -1) {
/*  598 */             addToken(text, i, i, 23, newStartOffset + i);
/*  599 */             this.currentTokenType = 0;
/*      */             break;
/*      */           } 
/*  602 */           indexOf = "()[]".indexOf(c, 0);
/*  603 */           if (indexOf > -1) {
/*  604 */             addToken(text, i, i, 22, newStartOffset + i);
/*  605 */             this.currentTokenType = 0;
/*      */             break;
/*      */           } 
/*  608 */           indexOf = ".,;".indexOf(c, 0);
/*  609 */           if (indexOf > -1) {
/*  610 */             addToken(text, i, i, 20, newStartOffset + i);
/*  611 */             this.currentTokenType = 0;
/*      */             
/*      */             break;
/*      */           } 
/*  615 */           this.currentTokenType = 20;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/*  625 */           switch (c) {
/*      */             
/*      */             case '\t':
/*      */             case ' ':
/*  629 */               addToken(text, this.currentTokenStart, i - 1, 20, newStartOffset + this.currentTokenStart);
/*  630 */               this.currentTokenStart = i;
/*  631 */               this.currentTokenType = 21;
/*      */               break;
/*      */             
/*      */             case '/':
/*  635 */               addToken(text, this.currentTokenStart, i, 20, newStartOffset + this.currentTokenStart);
/*  636 */               this.currentTokenStart = i + 1;
/*  637 */               this.currentTokenType = 0;
/*      */               break;
/*      */             
/*      */             case '`':
/*  641 */               addToken(text, this.currentTokenStart, i - 1, 20, newStartOffset + this.currentTokenStart);
/*  642 */               this.currentTokenStart = i;
/*  643 */               this.currentTokenType = 15;
/*  644 */               backslash = false;
/*      */               break;
/*      */             
/*      */             case '"':
/*  648 */               addToken(text, this.currentTokenStart, i - 1, 20, newStartOffset + this.currentTokenStart);
/*  649 */               this.currentTokenStart = i;
/*  650 */               this.currentTokenType = 13;
/*  651 */               backslash = false;
/*      */               break;
/*      */             
/*      */             case '\'':
/*  655 */               addToken(text, this.currentTokenStart, i - 1, 20, newStartOffset + this.currentTokenStart);
/*  656 */               this.currentTokenStart = i;
/*  657 */               this.currentTokenType = 14;
/*  658 */               backslash = false;
/*      */               break;
/*      */             
/*      */             case '\\':
/*  662 */               addToken(text, this.currentTokenStart, i - 1, 20, newStartOffset + this.currentTokenStart);
/*  663 */               addToken(text, i, i, 20, newStartOffset + i);
/*  664 */               this.currentTokenType = 0;
/*  665 */               backslash = true;
/*      */               break;
/*      */             
/*      */             case '$':
/*  669 */               addToken(text, this.currentTokenStart, i - 1, 20, newStartOffset + this.currentTokenStart);
/*  670 */               this.currentTokenStart = i;
/*  671 */               this.currentTokenType = 17;
/*  672 */               backslash = false;
/*      */               break;
/*      */             
/*      */             case '=':
/*  676 */               addToken(text, this.currentTokenStart, i - 1, 17, newStartOffset + this.currentTokenStart);
/*  677 */               addToken(text, i, i, 23, newStartOffset + i);
/*  678 */               this.currentTokenType = 0;
/*      */               break;
/*      */           } 
/*      */           
/*  682 */           if (RSyntaxUtilities.isLetterOrDigit(c) || c == '/' || c == '_') {
/*      */             break;
/*      */           }
/*  685 */           indexOf = "=|><&".indexOf(c);
/*  686 */           if (indexOf > -1) {
/*  687 */             addToken(text, this.currentTokenStart, i - 1, 20, newStartOffset + this.currentTokenStart);
/*  688 */             addToken(text, i, i, 23, newStartOffset + i);
/*  689 */             this.currentTokenType = 0;
/*      */             break;
/*      */           } 
/*  692 */           indexOf = "()[]".indexOf(c, 0);
/*  693 */           if (indexOf > -1) {
/*  694 */             addToken(text, this.currentTokenStart, i - 1, 20, newStartOffset + this.currentTokenStart);
/*  695 */             addToken(text, i, i, 22, newStartOffset + i);
/*  696 */             this.currentTokenType = 0;
/*      */             break;
/*      */           } 
/*  699 */           indexOf = ".,;".indexOf(c, 0);
/*  700 */           if (indexOf > -1) {
/*  701 */             addToken(text, this.currentTokenStart, i - 1, 20, newStartOffset + this.currentTokenStart);
/*  702 */             addToken(text, i, i, 20, newStartOffset + i);
/*  703 */             this.currentTokenType = 0;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 10:
/*  714 */           switch (c) {
/*      */             
/*      */             case '\t':
/*      */             case ' ':
/*  718 */               addToken(text, this.currentTokenStart, i - 1, 10, newStartOffset + this.currentTokenStart);
/*  719 */               this.currentTokenStart = i;
/*  720 */               this.currentTokenType = 21;
/*      */               break;
/*      */             
/*      */             case '`':
/*  724 */               addToken(text, this.currentTokenStart, i - 1, 10, newStartOffset + this.currentTokenStart);
/*  725 */               this.currentTokenStart = i;
/*  726 */               this.currentTokenType = 15;
/*  727 */               backslash = false;
/*      */               break;
/*      */             
/*      */             case '"':
/*  731 */               addToken(text, this.currentTokenStart, i - 1, 10, newStartOffset + this.currentTokenStart);
/*  732 */               this.currentTokenStart = i;
/*  733 */               this.currentTokenType = 13;
/*  734 */               backslash = false;
/*      */               break;
/*      */             
/*      */             case '\'':
/*  738 */               addToken(text, this.currentTokenStart, i - 1, 10, newStartOffset + this.currentTokenStart);
/*  739 */               this.currentTokenStart = i;
/*  740 */               this.currentTokenType = 14;
/*  741 */               backslash = false;
/*      */               break;
/*      */             
/*      */             case '$':
/*  745 */               addToken(text, this.currentTokenStart, i - 1, 10, newStartOffset + this.currentTokenStart);
/*  746 */               this.currentTokenStart = i;
/*  747 */               this.currentTokenType = 17;
/*  748 */               backslash = false;
/*      */               break;
/*      */             
/*      */             case '\\':
/*  752 */               addToken(text, this.currentTokenStart, i - 1, 10, newStartOffset + this.currentTokenStart);
/*  753 */               addToken(text, i, i, 20, newStartOffset + i);
/*  754 */               this.currentTokenType = 0;
/*  755 */               backslash = true;
/*      */               break;
/*      */           } 
/*      */ 
/*      */           
/*  760 */           if (RSyntaxUtilities.isDigit(c)) {
/*      */             break;
/*      */           }
/*  763 */           indexOf = "=|><&".indexOf(c);
/*  764 */           if (indexOf > -1) {
/*  765 */             addToken(text, this.currentTokenStart, i - 1, 10, newStartOffset + this.currentTokenStart);
/*  766 */             addToken(text, i, i, 23, newStartOffset + i);
/*  767 */             this.currentTokenType = 0;
/*      */             break;
/*      */           } 
/*  770 */           indexOf = "()[]".indexOf(c);
/*  771 */           if (indexOf > -1) {
/*  772 */             addToken(text, this.currentTokenStart, i - 1, 10, newStartOffset + this.currentTokenStart);
/*  773 */             addToken(text, i, i, 22, newStartOffset + i);
/*  774 */             this.currentTokenType = 0;
/*      */             break;
/*      */           } 
/*  777 */           indexOf = ".,;".indexOf(c);
/*  778 */           if (indexOf > -1) {
/*  779 */             addToken(text, this.currentTokenStart, i - 1, 10, newStartOffset + this.currentTokenStart);
/*  780 */             addToken(text, i, i, 20, newStartOffset + i);
/*  781 */             this.currentTokenType = 0;
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/*  786 */           addToken(text, this.currentTokenStart, i - 1, 10, newStartOffset + this.currentTokenStart);
/*  787 */           i--;
/*  788 */           this.currentTokenType = 0;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 17:
/*  798 */           if (c == '{') {
/*  799 */             while (++i < end) {
/*  800 */               if (array[i] == '}') {
/*  801 */                 addToken(text, this.currentTokenStart, i, 17, newStartOffset + this.currentTokenStart);
/*  802 */                 this.currentTokenType = 0;
/*      */                 break;
/*      */               } 
/*      */             } 
/*  806 */             if (i == end) {
/*  807 */               addToken(text, this.currentTokenStart, end - 1, 17, newStartOffset + this.currentTokenStart);
/*  808 */               this.currentTokenType = 0;
/*      */             } 
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/*  814 */           while (i < end) {
/*  815 */             c = array[i];
/*  816 */             if (!RSyntaxUtilities.isLetterOrDigit(c) && "#-?$!*@_".indexOf(c) == -1 && c != '_') {
/*  817 */               addToken(text, this.currentTokenStart, i - 1, 17, newStartOffset + this.currentTokenStart);
/*  818 */               i--;
/*  819 */               this.currentTokenType = 0;
/*      */               break;
/*      */             } 
/*  822 */             i++;
/*      */           } 
/*      */ 
/*      */           
/*  826 */           if (i == end) {
/*  827 */             addToken(text, this.currentTokenStart, i - 1, 17, newStartOffset + this.currentTokenStart);
/*  828 */             this.currentTokenType = 0;
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 1:
/*  835 */           if (c == '!')
/*  836 */             this.currentTokenType = 24; 
/*  837 */           i = end - 1;
/*  838 */           addToken(text, this.currentTokenStart, i, this.currentTokenType, newStartOffset + this.currentTokenStart);
/*      */           
/*  840 */           this.currentTokenType = 0;
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 14:
/*  846 */           if (c == '\\') {
/*  847 */             backslash = !backslash;
/*      */             break;
/*      */           } 
/*  850 */           if (c == '\'' && !backslash) {
/*  851 */             addToken(text, this.currentTokenStart, i, 14, newStartOffset + this.currentTokenStart);
/*  852 */             this.currentTokenStart = i + 1;
/*  853 */             this.currentTokenType = 0;
/*      */           } 
/*      */ 
/*      */           
/*  857 */           backslash = false;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 15:
/*  866 */           switch (c) {
/*      */             
/*      */             case '\\':
/*  869 */               backslash = !backslash;
/*      */               break;
/*      */             
/*      */             case '`':
/*  873 */               if (!backslash) {
/*  874 */                 addToken(text, this.currentTokenStart, i, 15, newStartOffset + this.currentTokenStart);
/*  875 */                 this.currentTokenType = 0;
/*      */                 
/*      */                 break;
/*      */               } 
/*  879 */               backslash = false;
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case '$':
/*  885 */               if (backslash == true) {
/*  886 */                 backslash = false;
/*      */                 
/*      */                 break;
/*      */               } 
/*      */               
/*  891 */               addToken(text, this.currentTokenStart, i - 1, 15, newStartOffset + this.currentTokenStart);
/*  892 */               this.currentTokenType = 17;
/*  893 */               this.currentTokenStart = i;
/*      */ 
/*      */               
/*  896 */               if (i < end - 1 && array[i + 1] == '{') {
/*  897 */                 i++;
/*  898 */                 while (++i < end) {
/*  899 */                   if (array[i] == '}') {
/*  900 */                     addToken(text, this.currentTokenStart, i, 17, newStartOffset + this.currentTokenStart);
/*  901 */                     i++;
/*  902 */                     if (i < end) {
/*  903 */                       c = array[i];
/*  904 */                       if (c == '`') {
/*  905 */                         addToken(text, i, i, 15, newStartOffset + i);
/*  906 */                         this.currentTokenType = 0;
/*      */                         
/*      */                         break;
/*      */                       } 
/*  910 */                       this.currentTokenStart = i;
/*  911 */                       this.currentTokenType = 15;
/*  912 */                       i--;
/*      */                       
/*      */                       break;
/*      */                     } 
/*      */                     
/*  917 */                     this.currentTokenStart = i;
/*  918 */                     this.currentTokenType = 15;
/*      */                     
/*      */                     break;
/*      */                   } 
/*      */                 } 
/*  923 */                 if (i == end) {
/*  924 */                   addToken(text, this.currentTokenStart, end - 1, 17, newStartOffset + this.currentTokenStart);
/*  925 */                   this.currentTokenStart = end;
/*  926 */                   this.currentTokenType = 15;
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */               
/*  932 */               if (this.currentTokenType == 0 || this.currentTokenType == 15) {
/*      */                 break;
/*      */               }
/*      */ 
/*      */               
/*  937 */               while (++i < end) {
/*  938 */                 c = array[i];
/*  939 */                 if (!RSyntaxUtilities.isLetterOrDigit(c) && "#-?$!*@_".indexOf(c) == -1 && c != '_') {
/*  940 */                   addToken(text, this.currentTokenStart, i - 1, 17, newStartOffset + this.currentTokenStart);
/*  941 */                   if (c == '`') {
/*  942 */                     addToken(text, i, i, 15, newStartOffset + i);
/*  943 */                     this.currentTokenType = 0;
/*      */                     
/*      */                     break;
/*      */                   } 
/*  947 */                   this.currentTokenStart = i;
/*  948 */                   this.currentTokenType = 15;
/*  949 */                   i--;
/*      */ 
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */ 
/*      */               
/*  957 */               if (i == end) {
/*  958 */                 addToken(text, this.currentTokenStart, i - 1, 17, newStartOffset + this.currentTokenStart);
/*  959 */                 this.currentTokenStart = i;
/*  960 */                 this.currentTokenType = 15;
/*      */               } 
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  967 */           backslash = false;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 13:
/*  975 */           switch (c) {
/*      */             
/*      */             case '\\':
/*  978 */               backslash = !backslash;
/*      */               break;
/*      */             
/*      */             case '"':
/*  982 */               if (!backslash) {
/*  983 */                 addToken(text, this.currentTokenStart, i, 13, newStartOffset + this.currentTokenStart);
/*  984 */                 this.currentTokenType = 0;
/*      */                 
/*      */                 break;
/*      */               } 
/*  988 */               backslash = false;
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case '$':
/*  994 */               if (backslash == true) {
/*  995 */                 backslash = false;
/*      */                 
/*      */                 break;
/*      */               } 
/*      */               
/* 1000 */               addToken(text, this.currentTokenStart, i - 1, 13, newStartOffset + this.currentTokenStart);
/* 1001 */               this.currentTokenType = 17;
/* 1002 */               this.currentTokenStart = i;
/*      */ 
/*      */               
/* 1005 */               if (i < end - 1 && array[i + 1] == '{') {
/* 1006 */                 i++;
/* 1007 */                 while (++i < end) {
/* 1008 */                   if (array[i] == '}') {
/* 1009 */                     addToken(text, this.currentTokenStart, i, 17, newStartOffset + this.currentTokenStart);
/* 1010 */                     i++;
/* 1011 */                     if (i < end) {
/* 1012 */                       c = array[i];
/* 1013 */                       if (c == '"') {
/* 1014 */                         addToken(text, i, i, 13, newStartOffset + i);
/* 1015 */                         this.currentTokenType = 0;
/*      */                         
/*      */                         break;
/*      */                       } 
/* 1019 */                       this.currentTokenStart = i;
/* 1020 */                       this.currentTokenType = 13;
/* 1021 */                       i--;
/*      */                       
/*      */                       break;
/*      */                     } 
/*      */                     
/* 1026 */                     this.currentTokenStart = i;
/* 1027 */                     this.currentTokenType = 13;
/*      */                     
/*      */                     break;
/*      */                   } 
/*      */                 } 
/* 1032 */                 if (i == end) {
/* 1033 */                   addToken(text, this.currentTokenStart, end - 1, 17, newStartOffset + this.currentTokenStart);
/* 1034 */                   this.currentTokenStart = end;
/* 1035 */                   this.currentTokenType = 13;
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */               
/* 1041 */               if (this.currentTokenType == 0 || this.currentTokenType == 13) {
/*      */                 break;
/*      */               }
/*      */ 
/*      */               
/* 1046 */               while (++i < end) {
/* 1047 */                 c = array[i];
/* 1048 */                 if (!RSyntaxUtilities.isLetterOrDigit(c) && "#-?$!*@_".indexOf(c) == -1 && c != '_') {
/* 1049 */                   addToken(text, this.currentTokenStart, i - 1, 17, newStartOffset + this.currentTokenStart);
/* 1050 */                   if (c == '"') {
/* 1051 */                     addToken(text, i, i, 13, newStartOffset + i);
/* 1052 */                     this.currentTokenType = 0;
/*      */                     
/*      */                     break;
/*      */                   } 
/* 1056 */                   this.currentTokenStart = i;
/* 1057 */                   this.currentTokenType = 13;
/* 1058 */                   i--;
/*      */ 
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */ 
/*      */               
/* 1066 */               if (i == end) {
/* 1067 */                 addToken(text, this.currentTokenStart, i - 1, 17, newStartOffset + this.currentTokenStart);
/* 1068 */                 this.currentTokenStart = i;
/* 1069 */                 this.currentTokenType = 13;
/*      */               } 
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1076 */           backslash = false;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/* 1086 */     switch (this.currentTokenType)
/*      */     
/*      */     { 
/*      */       case 13:
/*      */       case 14:
/*      */       case 15:
/* 1092 */         addToken(text, this.currentTokenStart, end - 1, this.currentTokenType, newStartOffset + this.currentTokenStart);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1108 */         return this.firstToken;case 0: addNullToken(); return this.firstToken; }  addToken(text, this.currentTokenStart, end - 1, this.currentTokenType, newStartOffset + this.currentTokenStart); addNullToken(); return this.firstToken;
/*      */   }
/*      */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/modes/UnixShellTokenMaker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */