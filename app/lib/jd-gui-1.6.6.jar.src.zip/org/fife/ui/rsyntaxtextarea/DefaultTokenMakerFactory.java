/*    */ package org.fife.ui.rsyntaxtextarea;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultTokenMakerFactory
/*    */   extends AbstractTokenMakerFactory
/*    */   implements SyntaxConstants
/*    */ {
/*    */   protected void initTokenMakerMap() {
/* 30 */     String pkg = "org.fife.ui.rsyntaxtextarea.modes.";
/*    */     
/* 32 */     putMapping("text/plain", pkg + "PlainTextTokenMaker");
/* 33 */     putMapping("text/actionscript", pkg + "ActionScriptTokenMaker");
/* 34 */     putMapping("text/asm", pkg + "AssemblerX86TokenMaker");
/* 35 */     putMapping("text/bbcode", pkg + "BBCodeTokenMaker");
/* 36 */     putMapping("text/c", pkg + "CTokenMaker");
/* 37 */     putMapping("text/clojure", pkg + "ClojureTokenMaker");
/* 38 */     putMapping("text/cpp", pkg + "CPlusPlusTokenMaker");
/* 39 */     putMapping("text/cs", pkg + "CSharpTokenMaker");
/* 40 */     putMapping("text/css", pkg + "CSSTokenMaker");
/* 41 */     putMapping("text/csv", pkg + "CsvTokenMaker");
/* 42 */     putMapping("text/d", pkg + "DTokenMaker");
/* 43 */     putMapping("text/dart", pkg + "DartTokenMaker");
/* 44 */     putMapping("text/delphi", pkg + "DelphiTokenMaker");
/* 45 */     putMapping("text/dockerfile", pkg + "DockerTokenMaker");
/* 46 */     putMapping("text/dtd", pkg + "DtdTokenMaker");
/* 47 */     putMapping("text/fortran", pkg + "FortranTokenMaker");
/* 48 */     putMapping("text/golang", pkg + "GoTokenMaker");
/* 49 */     putMapping("text/groovy", pkg + "GroovyTokenMaker");
/* 50 */     putMapping("text/hosts", pkg + "HostsTokenMaker");
/* 51 */     putMapping("text/htaccess", pkg + "HtaccessTokenMaker");
/* 52 */     putMapping("text/html", pkg + "HTMLTokenMaker");
/* 53 */     putMapping("text/ini", pkg + "IniTokenMaker");
/* 54 */     putMapping("text/java", pkg + "JavaTokenMaker");
/* 55 */     putMapping("text/javascript", pkg + "JavaScriptTokenMaker");
/* 56 */     putMapping("text/jshintrc", pkg + "JshintrcTokenMaker");
/* 57 */     putMapping("text/json", pkg + "JsonTokenMaker");
/* 58 */     putMapping("text/jsp", pkg + "JSPTokenMaker");
/* 59 */     putMapping("text/latex", pkg + "LatexTokenMaker");
/* 60 */     putMapping("text/less", pkg + "LessTokenMaker");
/* 61 */     putMapping("text/lisp", pkg + "LispTokenMaker");
/* 62 */     putMapping("text/lua", pkg + "LuaTokenMaker");
/* 63 */     putMapping("text/makefile", pkg + "MakefileTokenMaker");
/* 64 */     putMapping("text/mxml", pkg + "MxmlTokenMaker");
/* 65 */     putMapping("text/nsis", pkg + "NSISTokenMaker");
/* 66 */     putMapping("text/perl", pkg + "PerlTokenMaker");
/* 67 */     putMapping("text/php", pkg + "PHPTokenMaker");
/* 68 */     putMapping("text/properties", pkg + "PropertiesFileTokenMaker");
/* 69 */     putMapping("text/python", pkg + "PythonTokenMaker");
/* 70 */     putMapping("text/ruby", pkg + "RubyTokenMaker");
/* 71 */     putMapping("text/sas", pkg + "SASTokenMaker");
/* 72 */     putMapping("text/scala", pkg + "ScalaTokenMaker");
/* 73 */     putMapping("text/sql", pkg + "SQLTokenMaker");
/* 74 */     putMapping("text/tcl", pkg + "TclTokenMaker");
/* 75 */     putMapping("text/typescript", pkg + "TypeScriptTokenMaker");
/* 76 */     putMapping("text/unix", pkg + "UnixShellTokenMaker");
/* 77 */     putMapping("text/vb", pkg + "VisualBasicTokenMaker");
/* 78 */     putMapping("text/bat", pkg + "WindowsBatchTokenMaker");
/* 79 */     putMapping("text/xml", pkg + "XMLTokenMaker");
/* 80 */     putMapping("text/yaml", pkg + "YamlTokenMaker");
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/DefaultTokenMakerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */