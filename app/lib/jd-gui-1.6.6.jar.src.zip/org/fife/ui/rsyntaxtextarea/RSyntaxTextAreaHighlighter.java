/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Shape;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.swing.plaf.TextUI;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.text.Highlighter;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import javax.swing.text.View;
/*     */ import org.fife.ui.rsyntaxtextarea.parser.Parser;
/*     */ import org.fife.ui.rsyntaxtextarea.parser.ParserNotice;
/*     */ import org.fife.ui.rtextarea.RTextAreaHighlighter;
/*     */ import org.fife.ui.rtextarea.SmartHighlightPainter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RSyntaxTextAreaHighlighter
/*     */   extends RTextAreaHighlighter
/*     */ {
/*  59 */   private static final Color DEFAULT_PARSER_NOTICE_COLOR = Color.RED;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private List<SyntaxLayeredHighlightInfoImpl> markedOccurrences = new ArrayList<>();
/*  67 */   private List<SyntaxLayeredHighlightInfoImpl> parserHighlights = new ArrayList<>(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object addMarkedOccurrenceHighlight(int start, int end, SmartHighlightPainter p) throws BadLocationException {
/*  83 */     Document doc = this.textArea.getDocument();
/*  84 */     TextUI mapper = this.textArea.getUI();
/*     */     
/*  86 */     SyntaxLayeredHighlightInfoImpl i = new SyntaxLayeredHighlightInfoImpl();
/*  87 */     i.setPainter(p);
/*  88 */     i.setStartOffset(doc.createPosition(start));
/*     */ 
/*     */ 
/*     */     
/*  92 */     i.setEndOffset(doc.createPosition(end - 1));
/*  93 */     this.markedOccurrences.add(i);
/*  94 */     mapper.damageRange(this.textArea, start, end);
/*  95 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RTextAreaHighlighter.HighlightInfo addParserHighlight(ParserNotice notice, Highlighter.HighlightPainter p) throws BadLocationException {
/* 111 */     Document doc = this.textArea.getDocument();
/* 112 */     TextUI mapper = this.textArea.getUI();
/*     */     
/* 114 */     int start = notice.getOffset();
/* 115 */     int end = 0;
/* 116 */     if (start == -1) {
/* 117 */       int line = notice.getLine();
/* 118 */       Element root = doc.getDefaultRootElement();
/* 119 */       if (line >= 0 && line < root.getElementCount()) {
/* 120 */         Element elem = root.getElement(line);
/* 121 */         start = elem.getStartOffset();
/* 122 */         end = elem.getEndOffset();
/*     */       } 
/*     */     } else {
/*     */       
/* 126 */       end = start + notice.getLength();
/*     */     } 
/*     */ 
/*     */     
/* 130 */     SyntaxLayeredHighlightInfoImpl i = new SyntaxLayeredHighlightInfoImpl();
/* 131 */     i.setPainter(p);
/* 132 */     i.setStartOffset(doc.createPosition(start));
/*     */ 
/*     */ 
/*     */     
/* 136 */     i.setEndOffset(doc.createPosition(end - 1));
/* 137 */     i.notice = notice;
/*     */     
/* 139 */     this.parserHighlights.add(i);
/* 140 */     mapper.damageRange(this.textArea, start, end);
/* 141 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clearMarkOccurrencesHighlights() {
/* 154 */     for (RTextAreaHighlighter.HighlightInfo info : this.markedOccurrences) {
/* 155 */       repaintListHighlight(info);
/*     */     }
/* 157 */     this.markedOccurrences.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clearParserHighlights() {
/* 169 */     for (SyntaxLayeredHighlightInfoImpl parserHighlight : this.parserHighlights) {
/* 170 */       repaintListHighlight(parserHighlight);
/*     */     }
/* 172 */     this.parserHighlights.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearParserHighlights(Parser parser) {
/* 183 */     Iterator<SyntaxLayeredHighlightInfoImpl> i = this.parserHighlights.iterator();
/* 184 */     while (i.hasNext()) {
/*     */       
/* 186 */       SyntaxLayeredHighlightInfoImpl info = i.next();
/*     */       
/* 188 */       if (info.notice.getParser() == parser) {
/* 189 */         if (info.width > 0 && info.height > 0) {
/* 190 */           this.textArea.repaint(info.x, info.y, info.width, info.height);
/*     */         }
/* 192 */         i.remove();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deinstall(JTextComponent c) {
/* 205 */     super.deinstall(c);
/* 206 */     this.markedOccurrences.clear();
/* 207 */     this.parserHighlights.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DocumentRange> getMarkedOccurrences() {
/* 219 */     List<DocumentRange> list = new ArrayList<>(this.markedOccurrences.size());
/* 220 */     for (RTextAreaHighlighter.HighlightInfo info : this.markedOccurrences) {
/* 221 */       int start = info.getStartOffset();
/* 222 */       int end = info.getEndOffset() + 1;
/* 223 */       if (start <= end) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 228 */         DocumentRange range = new DocumentRange(start, end);
/* 229 */         list.add(range);
/*     */       } 
/*     */     } 
/* 232 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintLayeredHighlights(Graphics g, int lineStart, int lineEnd, Shape viewBounds, JTextComponent editor, View view) {
/* 239 */     paintListLayered(g, lineStart, lineEnd, viewBounds, editor, view, (List)this.markedOccurrences);
/* 240 */     super.paintLayeredHighlights(g, lineStart, lineEnd, viewBounds, editor, view);
/* 241 */     paintListLayered(g, lineStart, lineEnd, viewBounds, editor, view, (List)this.parserHighlights);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeParserHighlight(RTextAreaHighlighter.HighlightInfo tag) {
/* 252 */     repaintListHighlight(tag);
/* 253 */     this.parserHighlights.remove(tag);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SyntaxLayeredHighlightInfoImpl
/*     */     extends RTextAreaHighlighter.LayeredHighlightInfoImpl
/*     */   {
/*     */     private ParserNotice notice;
/*     */ 
/*     */ 
/*     */     
/*     */     private SyntaxLayeredHighlightInfoImpl() {}
/*     */ 
/*     */     
/*     */     public Color getColor() {
/* 269 */       Color color = null;
/* 270 */       if (this.notice != null) {
/* 271 */         color = this.notice.getColor();
/* 272 */         if (color == null) {
/* 273 */           color = RSyntaxTextAreaHighlighter.DEFAULT_PARSER_NOTICE_COLOR;
/*     */         }
/*     */       } 
/* 276 */       return color;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 281 */       return "[SyntaxLayeredHighlightInfoImpl: startOffs=" + 
/* 282 */         getStartOffset() + ", endOffs=" + 
/* 283 */         getEndOffset() + ", color=" + 
/* 284 */         getColor() + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/RSyntaxTextAreaHighlighter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */