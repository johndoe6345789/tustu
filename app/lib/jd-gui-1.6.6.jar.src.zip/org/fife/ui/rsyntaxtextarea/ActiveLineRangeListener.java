package org.fife.ui.rsyntaxtextarea;

import java.util.EventListener;

public interface ActiveLineRangeListener extends EventListener {
  void activeLineRangeChanged(ActiveLineRangeEvent paramActiveLineRangeEvent);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/ActiveLineRangeListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */