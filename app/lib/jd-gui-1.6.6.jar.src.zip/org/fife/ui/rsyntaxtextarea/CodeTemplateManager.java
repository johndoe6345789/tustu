/*     */ package org.fife.ui.rsyntaxtextarea;
/*     */ 
/*     */ import java.beans.XMLDecoder;
/*     */ import java.beans.XMLEncoder;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Segment;
/*     */ import org.fife.ui.rsyntaxtextarea.templates.CodeTemplate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodeTemplateManager
/*     */ {
/*  66 */   private Segment s = new Segment();
/*  67 */   private TemplateComparator comparator = new TemplateComparator();
/*  68 */   private List<CodeTemplate> templates = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private int maxTemplateIDLength;
/*     */ 
/*     */ 
/*     */   
/*     */   private File directory;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addTemplate(CodeTemplate template) {
/*  82 */     if (template == null) {
/*  83 */       throw new IllegalArgumentException("template cannot be null");
/*     */     }
/*  85 */     this.templates.add(template);
/*  86 */     sortTemplates();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized CodeTemplate getTemplate(RSyntaxTextArea textArea) {
/*  99 */     int caretPos = textArea.getCaretPosition();
/* 100 */     int charsToGet = Math.min(caretPos, this.maxTemplateIDLength);
/*     */     try {
/* 102 */       Document doc = textArea.getDocument();
/* 103 */       doc.getText(caretPos - charsToGet, charsToGet, this.s);
/*     */       
/* 105 */       int index = Collections.binarySearch(this.templates, this.s, this.comparator);
/* 106 */       return (index >= 0) ? this.templates.get(index) : null;
/* 107 */     } catch (BadLocationException ble) {
/* 108 */       ble.printStackTrace();
/* 109 */       throw new InternalError("Error in CodeTemplateManager");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int getTemplateCount() {
/* 120 */     return this.templates.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized CodeTemplate[] getTemplates() {
/* 130 */     CodeTemplate[] temp = new CodeTemplate[this.templates.size()];
/* 131 */     return this.templates.<CodeTemplate>toArray(temp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidChar(char ch) {
/* 143 */     return (RSyntaxUtilities.isLetterOrDigit(ch) || ch == '_');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean removeTemplate(CodeTemplate template) {
/* 160 */     if (template == null) {
/* 161 */       throw new IllegalArgumentException("template cannot be null");
/*     */     }
/*     */ 
/*     */     
/* 165 */     return this.templates.remove(template);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized CodeTemplate removeTemplate(String id) {
/* 182 */     if (id == null) {
/* 183 */       throw new IllegalArgumentException("id cannot be null");
/*     */     }
/*     */ 
/*     */     
/* 187 */     for (Iterator<CodeTemplate> i = this.templates.iterator(); i.hasNext(); ) {
/* 188 */       CodeTemplate template = i.next();
/* 189 */       if (id.equals(template.getID())) {
/* 190 */         i.remove();
/* 191 */         return template;
/*     */       } 
/*     */     } 
/*     */     
/* 195 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void replaceTemplates(CodeTemplate[] newTemplates) {
/* 208 */     this.templates.clear();
/* 209 */     if (newTemplates != null) {
/* 210 */       Collections.addAll(this.templates, newTemplates);
/*     */     }
/* 212 */     sortTemplates();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean saveTemplates() {
/* 223 */     if (this.templates == null) {
/* 224 */       return true;
/*     */     }
/* 226 */     if (this.directory == null || !this.directory.isDirectory()) {
/* 227 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 232 */     File[] oldXMLFiles = this.directory.listFiles(new XMLFileFilter());
/* 233 */     if (oldXMLFiles == null) {
/* 234 */       return false;
/*     */     }
/* 236 */     int count = oldXMLFiles.length;
/* 237 */     for (File oldXMLFile : oldXMLFiles)
/*     */     {
/* 239 */       oldXMLFile.delete();
/*     */     }
/*     */ 
/*     */     
/* 243 */     boolean wasSuccessful = true;
/* 244 */     for (CodeTemplate template : this.templates) {
/* 245 */       File xmlFile = new File(this.directory, template.getID() + ".xml");
/*     */       try {
/* 247 */         XMLEncoder e = new XMLEncoder(new BufferedOutputStream(new FileOutputStream(xmlFile)));
/*     */         
/* 249 */         e.writeObject(template);
/* 250 */         e.close();
/* 251 */       } catch (IOException ioe) {
/* 252 */         ioe.printStackTrace();
/* 253 */         wasSuccessful = false;
/*     */       } 
/*     */     } 
/*     */     
/* 257 */     return wasSuccessful;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int setTemplateDirectory(File dir) {
/* 273 */     if (dir != null && dir.isDirectory()) {
/*     */       
/* 275 */       this.directory = dir;
/*     */       
/* 277 */       File[] files = dir.listFiles(new XMLFileFilter());
/* 278 */       int newCount = (files == null) ? 0 : files.length;
/* 279 */       int oldCount = this.templates.size();
/*     */       
/* 281 */       List<CodeTemplate> temp = new ArrayList<>(oldCount + newCount);
/*     */       
/* 283 */       temp.addAll(this.templates);
/*     */       
/* 285 */       for (int i = 0; i < newCount; i++) {
/*     */         try {
/* 287 */           XMLDecoder d = new XMLDecoder(new BufferedInputStream(new FileInputStream(files[i])));
/*     */           
/* 289 */           Object obj = d.readObject();
/* 290 */           if (!(obj instanceof CodeTemplate)) {
/* 291 */             d.close();
/* 292 */             throw new IOException("Not a CodeTemplate: " + files[i]
/* 293 */                 .getAbsolutePath());
/*     */           } 
/* 295 */           temp.add((CodeTemplate)obj);
/* 296 */           d.close();
/* 297 */         } catch (Exception e) {
/*     */ 
/*     */ 
/*     */           
/* 301 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/* 304 */       this.templates = temp;
/* 305 */       sortTemplates();
/*     */       
/* 307 */       return getTemplateCount();
/*     */     } 
/*     */ 
/*     */     
/* 311 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void sortTemplates() {
/* 324 */     this.maxTemplateIDLength = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 329 */     for (Iterator<CodeTemplate> i = this.templates.iterator(); i.hasNext(); ) {
/* 330 */       CodeTemplate temp = i.next();
/* 331 */       if (temp == null || temp.getID() == null) {
/* 332 */         i.remove();
/*     */         continue;
/*     */       } 
/* 335 */       this.maxTemplateIDLength = Math.max(this.maxTemplateIDLength, temp
/* 336 */           .getID().length());
/*     */     } 
/*     */ 
/*     */     
/* 340 */     Collections.sort(this.templates);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class TemplateComparator
/*     */     implements Comparator, Serializable
/*     */   {
/*     */     private TemplateComparator() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(Object template, Object segment) {
/* 357 */       CodeTemplate t = (CodeTemplate)template;
/* 358 */       char[] templateArray = t.getID().toCharArray();
/* 359 */       int i = 0;
/* 360 */       int len1 = templateArray.length;
/*     */ 
/*     */       
/* 363 */       Segment s = (Segment)segment;
/* 364 */       char[] segArray = s.array;
/* 365 */       int len2 = s.count;
/* 366 */       int j = s.offset + len2 - 1;
/* 367 */       while (j >= s.offset && CodeTemplateManager.isValidChar(segArray[j])) {
/* 368 */         j--;
/*     */       }
/* 370 */       j++;
/* 371 */       int segShift = j - s.offset;
/* 372 */       len2 -= segShift;
/*     */       
/* 374 */       int n = Math.min(len1, len2);
/* 375 */       while (n-- != 0) {
/* 376 */         char c1 = templateArray[i++];
/* 377 */         char c2 = segArray[j++];
/* 378 */         if (c1 != c2) {
/* 379 */           return c1 - c2;
/*     */         }
/*     */       } 
/* 382 */       return len1 - len2;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class XMLFileFilter
/*     */     implements FileFilter
/*     */   {
/*     */     private XMLFileFilter() {}
/*     */ 
/*     */     
/*     */     public boolean accept(File f) {
/* 395 */       return f.getName().toLowerCase().endsWith(".xml");
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/fife/ui/rsyntaxtextarea/CodeTemplateManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */