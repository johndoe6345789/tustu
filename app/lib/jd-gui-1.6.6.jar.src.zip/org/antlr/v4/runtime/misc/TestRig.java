/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.print.PrintException;
/*     */ import org.antlr.v4.runtime.ANTLRInputStream;
/*     */ import org.antlr.v4.runtime.CharStream;
/*     */ import org.antlr.v4.runtime.CommonTokenStream;
/*     */ import org.antlr.v4.runtime.DiagnosticErrorListener;
/*     */ import org.antlr.v4.runtime.Lexer;
/*     */ import org.antlr.v4.runtime.Parser;
/*     */ import org.antlr.v4.runtime.ParserRuleContext;
/*     */ import org.antlr.v4.runtime.Token;
/*     */ import org.antlr.v4.runtime.TokenStream;
/*     */ import org.antlr.v4.runtime.atn.PredictionMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestRig
/*     */ {
/*     */   public static final String LEXER_START_RULE_NAME = "tokens";
/*     */   protected String grammarName;
/*     */   protected String startRuleName;
/*  71 */   protected final List<String> inputFiles = new ArrayList<String>();
/*     */   protected boolean printTree = false;
/*     */   protected boolean gui = false;
/*  74 */   protected String psFile = null;
/*     */   protected boolean showTokens = false;
/*     */   protected boolean trace = false;
/*     */   protected boolean diagnostics = false;
/*  78 */   protected String encoding = null;
/*     */   protected boolean SLL = false;
/*     */   
/*     */   public TestRig(String[] args) throws Exception {
/*  82 */     if (args.length < 2) {
/*  83 */       System.err.println("java org.antlr.v4.runtime.misc.TestRig GrammarName startRuleName\n  [-tokens] [-tree] [-gui] [-ps file.ps] [-encoding encodingname]\n  [-trace] [-diagnostics] [-SLL]\n  [input-filename(s)]");
/*     */ 
/*     */ 
/*     */       
/*  87 */       System.err.println("Use startRuleName='tokens' if GrammarName is a lexer grammar.");
/*  88 */       System.err.println("Omitting input-filename makes rig read from stdin.");
/*     */       return;
/*     */     } 
/*  91 */     int i = 0;
/*  92 */     this.grammarName = args[i];
/*  93 */     i++;
/*  94 */     this.startRuleName = args[i];
/*  95 */     i++;
/*  96 */     while (i < args.length) {
/*  97 */       String arg = args[i];
/*  98 */       i++;
/*  99 */       if (arg.charAt(0) != '-') {
/* 100 */         this.inputFiles.add(arg);
/*     */         continue;
/*     */       } 
/* 103 */       if (arg.equals("-tree")) {
/* 104 */         this.printTree = true;
/*     */       }
/* 106 */       if (arg.equals("-gui")) {
/* 107 */         this.gui = true;
/*     */       }
/* 109 */       if (arg.equals("-tokens")) {
/* 110 */         this.showTokens = true; continue;
/*     */       } 
/* 112 */       if (arg.equals("-trace")) {
/* 113 */         this.trace = true; continue;
/*     */       } 
/* 115 */       if (arg.equals("-SLL")) {
/* 116 */         this.SLL = true; continue;
/*     */       } 
/* 118 */       if (arg.equals("-diagnostics")) {
/* 119 */         this.diagnostics = true; continue;
/*     */       } 
/* 121 */       if (arg.equals("-encoding")) {
/* 122 */         if (i >= args.length) {
/* 123 */           System.err.println("missing encoding on -encoding");
/*     */           return;
/*     */         } 
/* 126 */         this.encoding = args[i];
/* 127 */         i++; continue;
/*     */       } 
/* 129 */       if (arg.equals("-ps")) {
/* 130 */         if (i >= args.length) {
/* 131 */           System.err.println("missing filename on -ps");
/*     */           return;
/*     */         } 
/* 134 */         this.psFile = args[i];
/* 135 */         i++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/* 141 */     TestRig testRig = new TestRig(args);
/* 142 */     if (args.length >= 2) {
/* 143 */       testRig.process();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void process() throws Exception {
/* 149 */     String lexerName = this.grammarName + "Lexer";
/* 150 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 151 */     Class<? extends Lexer> lexerClass = null;
/*     */     try {
/* 153 */       lexerClass = cl.loadClass(lexerName).asSubclass(Lexer.class);
/*     */     }
/* 155 */     catch (ClassNotFoundException cnfe) {
/*     */       
/* 157 */       lexerName = this.grammarName;
/*     */       try {
/* 159 */         lexerClass = cl.loadClass(lexerName).asSubclass(Lexer.class);
/*     */       }
/* 161 */       catch (ClassNotFoundException cnfe2) {
/* 162 */         System.err.println("Can't load " + lexerName + " as lexer or parser");
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 167 */     Constructor<? extends Lexer> lexerCtor = lexerClass.getConstructor(new Class[] { CharStream.class });
/* 168 */     Lexer lexer = lexerCtor.newInstance(new Object[] { null });
/*     */     
/* 170 */     Class<? extends Parser> parserClass = null;
/* 171 */     Parser parser = null;
/* 172 */     if (!this.startRuleName.equals("tokens")) {
/* 173 */       String parserName = this.grammarName + "Parser";
/* 174 */       parserClass = cl.loadClass(parserName).asSubclass(Parser.class);
/* 175 */       if (parserClass == null) {
/* 176 */         System.err.println("Can't load " + parserName);
/*     */       }
/* 178 */       Constructor<? extends Parser> parserCtor = parserClass.getConstructor(new Class[] { TokenStream.class });
/* 179 */       parser = parserCtor.newInstance(new Object[] { null });
/*     */     } 
/*     */     
/* 182 */     if (this.inputFiles.size() == 0) {
/* 183 */       Reader r; InputStream is = System.in;
/*     */       
/* 185 */       if (this.encoding != null) {
/* 186 */         r = new InputStreamReader(is, this.encoding);
/*     */       } else {
/*     */         
/* 189 */         r = new InputStreamReader(is);
/*     */       } 
/*     */       
/* 192 */       process(lexer, parserClass, parser, is, r);
/*     */       return;
/*     */     } 
/* 195 */     for (String inputFile : this.inputFiles) {
/* 196 */       Reader r; InputStream is = System.in;
/* 197 */       if (inputFile != null) {
/* 198 */         is = new FileInputStream(inputFile);
/*     */       }
/*     */       
/* 201 */       if (this.encoding != null) {
/* 202 */         r = new InputStreamReader(is, this.encoding);
/*     */       } else {
/*     */         
/* 205 */         r = new InputStreamReader(is);
/*     */       } 
/*     */       
/* 208 */       if (this.inputFiles.size() > 1) {
/* 209 */         System.err.println(inputFile);
/*     */       }
/* 211 */       process(lexer, parserClass, parser, is, r);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void process(Lexer lexer, Class<? extends Parser> parserClass, Parser parser, InputStream is, Reader r) throws IOException, IllegalAccessException, InvocationTargetException, PrintException {
/*     */     try {
/* 217 */       ANTLRInputStream input = new ANTLRInputStream(r);
/* 218 */       lexer.setInputStream(input);
/* 219 */       CommonTokenStream tokens = new CommonTokenStream(lexer);
/*     */       
/* 221 */       tokens.fill();
/*     */       
/* 223 */       if (this.showTokens) {
/* 224 */         for (Token tok : tokens.getTokens()) {
/* 225 */           System.out.println(tok);
/*     */         }
/*     */       }
/*     */       
/* 229 */       if (this.startRuleName.equals("tokens"))
/*     */         return; 
/* 231 */       if (this.diagnostics) {
/* 232 */         parser.addErrorListener(new DiagnosticErrorListener());
/* 233 */         parser.getInterpreter().setPredictionMode(PredictionMode.LL_EXACT_AMBIG_DETECTION);
/*     */       } 
/*     */       
/* 236 */       if (this.printTree || this.gui || this.psFile != null) {
/* 237 */         parser.setBuildParseTree(true);
/*     */       }
/*     */       
/* 240 */       if (this.SLL) {
/* 241 */         parser.getInterpreter().setPredictionMode(PredictionMode.SLL);
/*     */       }
/*     */       
/* 244 */       parser.setTokenStream(tokens);
/* 245 */       parser.setTrace(this.trace);
/*     */       
/*     */       try {
/* 248 */         Method startRule = parserClass.getMethod(this.startRuleName, new Class[0]);
/* 249 */         ParserRuleContext tree = (ParserRuleContext)startRule.invoke(parser, (Object[])null);
/*     */         
/* 251 */         if (this.printTree) {
/* 252 */           System.out.println(tree.toStringTree(parser));
/*     */         }
/* 254 */         if (this.gui) {
/* 255 */           tree.inspect(parser);
/*     */         }
/* 257 */         if (this.psFile != null) {
/* 258 */           tree.save(parser, this.psFile);
/*     */         }
/*     */       }
/* 261 */       catch (NoSuchMethodException nsme) {
/* 262 */         System.err.println("No method for rule " + this.startRuleName + " or it has arguments");
/*     */       } 
/*     */     } finally {
/*     */       
/* 266 */       if (r != null) r.close(); 
/* 267 */       if (is != null) is.close(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/misc/TestRig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */