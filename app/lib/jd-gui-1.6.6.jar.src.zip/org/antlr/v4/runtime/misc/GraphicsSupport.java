/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.print.PageFormat;
/*     */ import java.awt.print.Printable;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.print.DocFlavor;
/*     */ import javax.print.DocPrintJob;
/*     */ import javax.print.PrintException;
/*     */ import javax.print.PrintService;
/*     */ import javax.print.SimpleDoc;
/*     */ import javax.print.StreamPrintServiceFactory;
/*     */ import javax.print.attribute.HashPrintRequestAttributeSet;
/*     */ import javax.print.attribute.PrintRequestAttributeSet;
/*     */ import javax.swing.JComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphicsSupport
/*     */ {
/*     */   public static void saveImage(final JComponent comp, String fileName) throws IOException, PrintException {
/*  84 */     if (fileName.endsWith(".ps") || fileName.endsWith(".eps")) {
/*  85 */       DocFlavor flavor = DocFlavor.SERVICE_FORMATTED.PRINTABLE;
/*  86 */       String mimeType = "application/postscript";
/*  87 */       StreamPrintServiceFactory[] factories = StreamPrintServiceFactory.lookupStreamPrintServiceFactories(flavor, mimeType);
/*     */       
/*  89 */       System.out.println(Arrays.toString((Object[])factories));
/*  90 */       if (factories.length > 0) {
/*  91 */         FileOutputStream out = new FileOutputStream(fileName);
/*  92 */         PrintService service = factories[0].getPrintService(out);
/*  93 */         SimpleDoc doc = new SimpleDoc(new Printable()
/*     */             {
/*     */               public int print(Graphics g, PageFormat pf, int page) {
/*  96 */                 if (page >= 1) return 1;
/*     */                 
/*  98 */                 Graphics2D g2 = (Graphics2D)g;
/*  99 */                 g2.translate((pf.getWidth() - pf.getImageableWidth()) / 2.0D, (pf.getHeight() - pf.getImageableHeight()) / 2.0D);
/*     */                 
/* 101 */                 if (comp.getWidth() > pf.getImageableWidth() || comp.getHeight() > pf.getImageableHeight()) {
/*     */ 
/*     */                   
/* 104 */                   double sf1 = pf.getImageableWidth() / (comp.getWidth() + 1);
/* 105 */                   double sf2 = pf.getImageableHeight() / (comp.getHeight() + 1);
/* 106 */                   double s = Math.min(sf1, sf2);
/* 107 */                   g2.scale(s, s);
/*     */                 } 
/*     */                 
/* 110 */                 comp.paint(g);
/* 111 */                 return 0;
/*     */               }
/*     */             }flavor, null);
/*     */         
/* 115 */         DocPrintJob job = service.createPrintJob();
/* 116 */         PrintRequestAttributeSet attributes = new HashPrintRequestAttributeSet();
/* 117 */         job.print(doc, attributes);
/* 118 */         out.close();
/*     */       } 
/*     */     } else {
/*     */       
/* 122 */       Rectangle rect = comp.getBounds();
/* 123 */       BufferedImage image = new BufferedImage(rect.width, rect.height, 1);
/*     */       
/* 125 */       Graphics2D g = (Graphics2D)image.getGraphics();
/* 126 */       g.setColor(Color.WHITE);
/* 127 */       g.fill(rect);
/*     */       
/* 129 */       comp.paint(g);
/* 130 */       String extension = fileName.substring(fileName.lastIndexOf('.') + 1);
/* 131 */       boolean result = ImageIO.write(image, extension, new File(fileName));
/* 132 */       if (!result) {
/* 133 */         System.err.println("Now imager for " + extension);
/*     */       }
/* 135 */       g.dispose();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/misc/GraphicsSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */