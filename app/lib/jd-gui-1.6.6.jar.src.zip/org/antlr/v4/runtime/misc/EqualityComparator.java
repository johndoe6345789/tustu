package org.antlr.v4.runtime.misc;

public interface EqualityComparator<T> {
  int hashCode(T paramT);
  
  boolean equals(T paramT1, T paramT2);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/misc/EqualityComparator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */