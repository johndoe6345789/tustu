package org.antlr.v4.runtime.misc;

public abstract class AbstractEqualityComparator<T> implements EqualityComparator<T> {}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/misc/AbstractEqualityComparator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */