/*    */ package org.antlr.v4.runtime.misc;
/*    */ 
/*    */ import java.io.File;
/*    */ import javax.swing.JFileChooser;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JFileChooserConfirmOverwrite
/*    */   extends JFileChooser
/*    */ {
/*    */   public JFileChooserConfirmOverwrite() {
/* 42 */     setMultiSelectionEnabled(false);
/*    */   }
/*    */ 
/*    */   
/*    */   public void approveSelection() {
/* 47 */     File selectedFile = getSelectedFile();
/*    */     
/* 49 */     if (selectedFile.exists()) {
/* 50 */       int answer = JOptionPane.showConfirmDialog(this, "Overwrite existing file?", "Overwrite?", 0);
/*    */ 
/*    */ 
/*    */       
/* 54 */       if (answer != 0) {
/*    */         return;
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 60 */     super.approveSelection();
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/misc/JFileChooserConfirmOverwrite.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */