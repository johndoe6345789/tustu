/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.annotation.processing.AbstractProcessor;
/*     */ import javax.annotation.processing.RoundEnvironment;
/*     */ import javax.annotation.processing.SupportedAnnotationTypes;
/*     */ import javax.lang.model.SourceVersion;
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.ExecutableElement;
/*     */ import javax.lang.model.element.TypeElement;
/*     */ import javax.lang.model.element.VariableElement;
/*     */ import javax.lang.model.type.TypeKind;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import javax.tools.Diagnostic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @SupportedAnnotationTypes({"org.antlr.v4.runtime.misc.NotNull", "org.antlr.v4.runtime.misc.Nullable"})
/*     */ public class NullUsageProcessor
/*     */   extends AbstractProcessor
/*     */ {
/*     */   public static final String NotNullClassName = "org.antlr.v4.runtime.misc.NotNull";
/*     */   public static final String NullableClassName = "org.antlr.v4.runtime.misc.Nullable";
/*     */   private TypeElement notNullType;
/*     */   private TypeElement nullableType;
/*     */   
/*     */   public SourceVersion getSupportedSourceVersion() {
/*  96 */     SourceVersion latestSupported = SourceVersion.latestSupported();
/*     */     
/*  98 */     if (latestSupported.ordinal() <= 6) {
/*  99 */       return SourceVersion.RELEASE_6;
/*     */     }
/* 101 */     if (latestSupported.ordinal() <= 8) {
/* 102 */       return latestSupported;
/*     */     }
/*     */ 
/*     */     
/* 106 */     return SourceVersion.values()[8];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
/* 112 */     if (!checkClassNameConstants()) {
/* 113 */       return true;
/*     */     }
/*     */     
/* 116 */     this.notNullType = this.processingEnv.getElementUtils().getTypeElement("org.antlr.v4.runtime.misc.NotNull");
/* 117 */     this.nullableType = this.processingEnv.getElementUtils().getTypeElement("org.antlr.v4.runtime.misc.Nullable");
/* 118 */     Set<? extends Element> notNullElements = roundEnv.getElementsAnnotatedWith(this.notNullType);
/* 119 */     Set<? extends Element> nullableElements = roundEnv.getElementsAnnotatedWith(this.nullableType);
/*     */     
/* 121 */     Set<Element> intersection = new HashSet<Element>(notNullElements);
/* 122 */     intersection.retainAll(nullableElements);
/* 123 */     for (Element element : intersection) {
/* 124 */       String error = String.format("%s cannot be annotated with both %s and %s", new Object[] { element.getKind().toString().replace('_', ' ').toLowerCase(), this.notNullType.getSimpleName(), this.nullableType.getSimpleName() });
/* 125 */       this.processingEnv.getMessager().printMessage(Diagnostic.Kind.ERROR, error, element);
/*     */     } 
/*     */     
/* 128 */     checkVoidMethodAnnotations(notNullElements, this.notNullType);
/* 129 */     checkVoidMethodAnnotations(nullableElements, this.nullableType);
/*     */     
/* 131 */     checkPrimitiveTypeAnnotations(nullableElements, Diagnostic.Kind.ERROR, this.nullableType);
/* 132 */     checkPrimitiveTypeAnnotations(notNullElements, Diagnostic.Kind.WARNING, this.notNullType);
/*     */ 
/*     */     
/* 135 */     Map<String, Map<ExecutableElement, List<Element>>> namedMethodMap = new HashMap<String, Map<ExecutableElement, List<Element>>>();
/*     */     
/* 137 */     addElementsToNamedMethodMap(notNullElements, namedMethodMap);
/* 138 */     addElementsToNamedMethodMap(nullableElements, namedMethodMap);
/*     */     
/* 140 */     for (Map.Entry<String, Map<ExecutableElement, List<Element>>> entry : namedMethodMap.entrySet()) {
/* 141 */       for (Map.Entry<ExecutableElement, List<Element>> subentry : (Iterable<Map.Entry<ExecutableElement, List<Element>>>)((Map)entry.getValue()).entrySet()) {
/* 142 */         checkOverriddenMethods(subentry.getKey());
/*     */       }
/*     */     } 
/*     */     
/* 146 */     return true;
/*     */   }
/*     */   
/*     */   private boolean checkClassNameConstants() {
/* 150 */     boolean success = checkClassNameConstant("org.antlr.v4.runtime.misc.NotNull", NotNull.class);
/* 151 */     success &= checkClassNameConstant("org.antlr.v4.runtime.misc.Nullable", Nullable.class);
/* 152 */     return success;
/*     */   }
/*     */   
/*     */   private boolean checkClassNameConstant(String className, Class<?> clazz) {
/* 156 */     if (className == null) {
/* 157 */       throw new NullPointerException("className");
/*     */     }
/*     */     
/* 160 */     if (clazz == null) {
/* 161 */       throw new NullPointerException("clazz");
/*     */     }
/*     */     
/* 164 */     if (!className.equals(clazz.getCanonicalName())) {
/* 165 */       this.processingEnv.getMessager().printMessage(Diagnostic.Kind.ERROR, String.format("Unable to process null usage annotations due to class name mismatch: %s != %s", new Object[] { className, clazz.getCanonicalName() }));
/* 166 */       return false;
/*     */     } 
/*     */     
/* 169 */     return true;
/*     */   }
/*     */   
/*     */   private void checkVoidMethodAnnotations(Set<? extends Element> elements, TypeElement annotationType) {
/* 173 */     for (Element element : elements) {
/* 174 */       if (element.getKind() != ElementKind.METHOD) {
/*     */         continue;
/*     */       }
/*     */       
/* 178 */       ExecutableElement executableElement = (ExecutableElement)element;
/* 179 */       TypeMirror returnType = executableElement.getReturnType();
/* 180 */       if (returnType instanceof javax.lang.model.type.NoType && returnType.getKind() == TypeKind.VOID) {
/* 181 */         String error = String.format("void method cannot be annotated with %s", new Object[] { annotationType.getSimpleName() });
/* 182 */         this.processingEnv.getMessager().printMessage(Diagnostic.Kind.ERROR, error, element, getAnnotationMirror(element, annotationType));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkPrimitiveTypeAnnotations(Set<? extends Element> elements, Diagnostic.Kind kind, TypeElement annotationType) {
/* 188 */     for (Element element : elements) {
/*     */       TypeMirror typeToCheck; VariableElement variableElement; ExecutableElement executableElement;
/* 190 */       switch (element.getKind()) {
/*     */         
/*     */         case FIELD:
/*     */         case PARAMETER:
/*     */         case LOCAL_VARIABLE:
/* 195 */           variableElement = (VariableElement)element;
/* 196 */           typeToCheck = variableElement.asType();
/*     */           break;
/*     */ 
/*     */         
/*     */         case METHOD:
/* 201 */           executableElement = (ExecutableElement)element;
/* 202 */           typeToCheck = executableElement.getReturnType();
/*     */           break;
/*     */         
/*     */         default:
/*     */           continue;
/*     */       } 
/*     */       
/* 209 */       if (typeToCheck instanceof javax.lang.model.type.PrimitiveType && typeToCheck.getKind().isPrimitive()) {
/* 210 */         String error = String.format("%s with a primitive type %s be annotated with %s", new Object[] { element.getKind().toString().replace('_', ' ').toLowerCase(), (kind == Diagnostic.Kind.ERROR) ? "cannot" : "should not", annotationType.getSimpleName() });
/* 211 */         this.processingEnv.getMessager().printMessage(kind, error, element, getAnnotationMirror(element, annotationType));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addElementsToNamedMethodMap(Set<? extends Element> elements, Map<String, Map<ExecutableElement, List<Element>>> namedMethodMap) {
/* 217 */     for (Element element : elements) {
/*     */       ExecutableElement method;
/* 219 */       switch (element.getKind()) {
/*     */         case PARAMETER:
/* 221 */           method = (ExecutableElement)element.getEnclosingElement();
/* 222 */           assert method.getKind() == ElementKind.METHOD;
/*     */           break;
/*     */         
/*     */         case METHOD:
/* 226 */           method = (ExecutableElement)element;
/*     */           break;
/*     */         
/*     */         default:
/*     */           continue;
/*     */       } 
/*     */       
/* 233 */       Map<ExecutableElement, List<Element>> annotatedMethodWithName = namedMethodMap.get(method.getSimpleName().toString());
/*     */       
/* 235 */       if (annotatedMethodWithName == null) {
/* 236 */         annotatedMethodWithName = new HashMap<ExecutableElement, List<Element>>();
/* 237 */         namedMethodMap.put(method.getSimpleName().toString(), annotatedMethodWithName);
/*     */       } 
/*     */       
/* 240 */       List<Element> annotatedElementsOfMethod = annotatedMethodWithName.get(method);
/* 241 */       if (annotatedElementsOfMethod == null) {
/* 242 */         annotatedElementsOfMethod = new ArrayList<Element>();
/* 243 */         annotatedMethodWithName.put(method, annotatedElementsOfMethod);
/*     */       } 
/*     */       
/* 246 */       annotatedElementsOfMethod.add(element);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkOverriddenMethods(ExecutableElement method) {
/* 251 */     TypeElement declaringType = (TypeElement)method.getEnclosingElement();
/* 252 */     Set<Element> errorElements = new HashSet<Element>();
/* 253 */     Set<Element> warnedElements = new HashSet<Element>();
/*     */     
/* 255 */     for (TypeMirror supertypeMirror : getAllSupertypes(this.processingEnv.getTypeUtils().getDeclaredType(declaringType, new TypeMirror[0]))) {
/* 256 */       for (Element element : ((TypeElement)this.processingEnv.getTypeUtils().asElement(supertypeMirror)).getEnclosedElements()) {
/* 257 */         if (element instanceof ExecutableElement && 
/* 258 */           this.processingEnv.getElementUtils().overrides(method, (ExecutableElement)element, declaringType)) {
/* 259 */           checkOverriddenMethod(method, (ExecutableElement)element, errorElements, warnedElements);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<? extends TypeMirror> getAllSupertypes(TypeMirror type) {
/* 268 */     Set<TypeMirror> supertypes = new HashSet<TypeMirror>();
/* 269 */     Deque<TypeMirror> worklist = new ArrayDeque<TypeMirror>();
/* 270 */     worklist.add(type);
/* 271 */     while (!worklist.isEmpty()) {
/* 272 */       List<? extends TypeMirror> next = this.processingEnv.getTypeUtils().directSupertypes(worklist.poll());
/* 273 */       if (supertypes.addAll(next)) {
/* 274 */         worklist.addAll(next);
/*     */       }
/*     */     } 
/*     */     
/* 278 */     return new ArrayList<TypeMirror>(supertypes);
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkOverriddenMethod(ExecutableElement overrider, ExecutableElement overridden, Set<Element> errorElements, Set<Element> warnedElements) {
/* 283 */     if (isNullable(overrider) && isNotNull(overridden) && errorElements.add(overrider)) {
/* 284 */       String error = String.format("method annotated with %s cannot override or implement a method annotated with %s", new Object[] { this.nullableType.getSimpleName(), this.notNullType.getSimpleName() });
/* 285 */       this.processingEnv.getMessager().printMessage(Diagnostic.Kind.ERROR, error, overrider, getNullableAnnotationMirror(overrider));
/*     */     }
/* 287 */     else if (isNullable(overrider) && !isNullable(overridden) && !isNotNull(overridden) && !errorElements.contains(overrider) && warnedElements.add(overrider)) {
/* 288 */       String error = String.format("method annotated with %s overrides a method that is not annotated", new Object[] { this.nullableType.getSimpleName() });
/* 289 */       this.processingEnv.getMessager().printMessage(Diagnostic.Kind.WARNING, error, overrider, getNullableAnnotationMirror(overrider));
/*     */     } 
/*     */     
/* 292 */     List<? extends VariableElement> overriderParameters = overrider.getParameters();
/* 293 */     List<? extends VariableElement> overriddenParameters = overridden.getParameters();
/* 294 */     for (int i = 0; i < overriderParameters.size(); i++) {
/* 295 */       if (isNotNull(overriderParameters.get(i)) && isNullable(overriddenParameters.get(i)) && errorElements.add(overriderParameters.get(i))) {
/* 296 */         String error = String.format("parameter %s annotated with %s cannot override or implement a parameter annotated with %s", new Object[] { ((VariableElement)overriderParameters.get(i)).getSimpleName(), this.notNullType.getSimpleName(), this.nullableType.getSimpleName() });
/* 297 */         this.processingEnv.getMessager().printMessage(Diagnostic.Kind.ERROR, error, overriderParameters.get(i), getNotNullAnnotationMirror(overriderParameters.get(i)));
/*     */       }
/* 299 */       else if (isNotNull(overriderParameters.get(i)) && !isNullable(overriddenParameters.get(i)) && !isNotNull(overriddenParameters.get(i)) && !errorElements.contains(overriderParameters.get(i)) && warnedElements.add(overriderParameters.get(i))) {
/* 300 */         String error = String.format("parameter %s annotated with %s overrides a parameter that is not annotated", new Object[] { ((VariableElement)overriderParameters.get(i)).getSimpleName(), this.notNullType.getSimpleName() });
/* 301 */         this.processingEnv.getMessager().printMessage(Diagnostic.Kind.WARNING, error, overriderParameters.get(i), getNotNullAnnotationMirror(overriderParameters.get(i)));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isNotNull(Element element) {
/* 307 */     return (getNotNullAnnotationMirror(element) != null);
/*     */   }
/*     */   
/*     */   private boolean isNullable(Element element) {
/* 311 */     return (getNullableAnnotationMirror(element) != null);
/*     */   }
/*     */   
/*     */   private AnnotationMirror getNotNullAnnotationMirror(Element element) {
/* 315 */     return getAnnotationMirror(element, this.notNullType);
/*     */   }
/*     */   
/*     */   private AnnotationMirror getNullableAnnotationMirror(Element element) {
/* 319 */     return getAnnotationMirror(element, this.nullableType);
/*     */   }
/*     */   
/*     */   private AnnotationMirror getAnnotationMirror(Element element, TypeElement annotationType) {
/* 323 */     for (AnnotationMirror annotationMirror : element.getAnnotationMirrors()) {
/* 324 */       if (annotationMirror.getAnnotationType().asElement() == annotationType) {
/* 325 */         return annotationMirror;
/*     */       }
/*     */     } 
/*     */     
/* 329 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/misc/NullUsageProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */