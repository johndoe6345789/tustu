/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ import java.awt.Window;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utils
/*     */ {
/*     */   public static <T> String join(Iterator<T> iter, String separator) {
/*  51 */     StringBuilder buf = new StringBuilder();
/*  52 */     while (iter.hasNext()) {
/*  53 */       buf.append(iter.next());
/*  54 */       if (iter.hasNext()) {
/*  55 */         buf.append(separator);
/*     */       }
/*     */     } 
/*  58 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public static <T> String join(T[] array, String separator) {
/*  62 */     StringBuilder builder = new StringBuilder();
/*  63 */     for (int i = 0; i < array.length; i++) {
/*  64 */       builder.append(array[i]);
/*  65 */       if (i < array.length - 1) {
/*  66 */         builder.append(separator);
/*     */       }
/*     */     } 
/*     */     
/*  70 */     return builder.toString();
/*     */   }
/*     */   
/*     */   public static int numNonnull(Object[] data) {
/*  74 */     int n = 0;
/*  75 */     if (data == null) return n; 
/*  76 */     for (Object o : data) {
/*  77 */       if (o != null) n++; 
/*     */     } 
/*  79 */     return n;
/*     */   }
/*     */   
/*     */   public static <T> void removeAllElements(Collection<T> data, T value) {
/*  83 */     if (data == null)
/*  84 */       return;  for (; data.contains(value); data.remove(value));
/*     */   }
/*     */   
/*     */   public static String escapeWhitespace(String s, boolean escapeSpaces) {
/*  88 */     StringBuilder buf = new StringBuilder();
/*  89 */     for (char c : s.toCharArray()) {
/*  90 */       if (c == ' ' && escapeSpaces) { buf.append('·'); }
/*  91 */       else if (c == '\t') { buf.append("\\t"); }
/*  92 */       else if (c == '\n') { buf.append("\\n"); }
/*  93 */       else if (c == '\r') { buf.append("\\r"); }
/*  94 */       else { buf.append(c); }
/*     */     
/*  96 */     }  return buf.toString();
/*     */   }
/*     */   
/*     */   public static void writeFile(String fileName, String content) throws IOException {
/* 100 */     writeFile(fileName, content, null);
/*     */   }
/*     */   public static void writeFile(String fileName, String content, String encoding) throws IOException {
/*     */     OutputStreamWriter osw;
/* 104 */     File f = new File(fileName);
/* 105 */     FileOutputStream fos = new FileOutputStream(f);
/*     */     
/* 107 */     if (encoding != null) {
/* 108 */       osw = new OutputStreamWriter(fos, encoding);
/*     */     } else {
/*     */       
/* 111 */       osw = new OutputStreamWriter(fos);
/*     */     } 
/*     */     
/*     */     try {
/* 115 */       osw.write(content);
/*     */     } finally {
/*     */       
/* 118 */       osw.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static char[] readFile(String fileName) throws IOException {
/* 124 */     return readFile(fileName, null);
/*     */   }
/*     */   
/*     */   public static char[] readFile(String fileName, String encoding) throws IOException {
/*     */     InputStreamReader isr;
/* 129 */     File f = new File(fileName);
/* 130 */     int size = (int)f.length();
/*     */     
/* 132 */     FileInputStream fis = new FileInputStream(fileName);
/* 133 */     if (encoding != null) {
/* 134 */       isr = new InputStreamReader(fis, encoding);
/*     */     } else {
/*     */       
/* 137 */       isr = new InputStreamReader(fis);
/*     */     } 
/* 139 */     char[] data = null;
/*     */     try {
/* 141 */       data = new char[size];
/* 142 */       int n = isr.read(data);
/* 143 */       if (n < data.length) {
/* 144 */         data = Arrays.copyOf(data, n);
/*     */       }
/*     */     } finally {
/*     */       
/* 148 */       isr.close();
/*     */     } 
/* 150 */     return data;
/*     */   }
/*     */   
/*     */   public static void waitForClose(final Window window) throws InterruptedException {
/* 154 */     final Object lock = new Object();
/*     */     
/* 156 */     Thread t = new Thread()
/*     */       {
/*     */         public void run() {
/* 159 */           synchronized (lock) {
/* 160 */             while (window.isVisible()) {
/*     */               try {
/* 162 */                 lock.wait(500L);
/* 163 */               } catch (InterruptedException e) {}
/*     */             } 
/*     */           } 
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 170 */     t.start();
/*     */     
/* 172 */     window.addWindowListener(new WindowAdapter()
/*     */         {
/*     */           public void windowClosing(WindowEvent arg0) {
/* 175 */             synchronized (lock) {
/* 176 */               window.setVisible(false);
/* 177 */               lock.notify();
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 182 */     t.join();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Integer> toMap(String[] keys) {
/* 189 */     Map<String, Integer> m = new HashMap<String, Integer>();
/* 190 */     for (int i = 0; i < keys.length; i++) {
/* 191 */       m.put(keys[i], Integer.valueOf(i));
/*     */     }
/* 193 */     return m;
/*     */   }
/*     */   
/*     */   public static char[] toCharArray(IntegerList data) {
/* 197 */     if (data == null) return null; 
/* 198 */     char[] cdata = new char[data.size()];
/* 199 */     for (int i = 0; i < data.size(); i++) {
/* 200 */       cdata[i] = (char)data.get(i);
/*     */     }
/* 202 */     return cdata;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/misc/Utils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */