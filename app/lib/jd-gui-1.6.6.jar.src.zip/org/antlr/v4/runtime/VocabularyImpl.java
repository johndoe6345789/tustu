/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VocabularyImpl
/*     */   implements Vocabulary
/*     */ {
/*  44 */   private static final String[] EMPTY_NAMES = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final VocabularyImpl EMPTY_VOCABULARY = new VocabularyImpl(EMPTY_NAMES, EMPTY_NAMES, EMPTY_NAMES);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String[] literalNames;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String[] symbolicNames;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String[] displayNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VocabularyImpl(String[] literalNames, String[] symbolicNames) {
/*  76 */     this(literalNames, symbolicNames, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VocabularyImpl(String[] literalNames, String[] symbolicNames, String[] displayNames) {
/*  97 */     this.literalNames = (literalNames != null) ? literalNames : EMPTY_NAMES;
/*  98 */     this.symbolicNames = (symbolicNames != null) ? symbolicNames : EMPTY_NAMES;
/*  99 */     this.displayNames = (displayNames != null) ? displayNames : EMPTY_NAMES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vocabulary fromTokenNames(String[] tokenNames) {
/* 117 */     if (tokenNames == null || tokenNames.length == 0) {
/* 118 */       return EMPTY_VOCABULARY;
/*     */     }
/*     */     
/* 121 */     String[] literalNames = Arrays.<String>copyOf(tokenNames, tokenNames.length);
/* 122 */     String[] symbolicNames = Arrays.<String>copyOf(tokenNames, tokenNames.length);
/* 123 */     for (int i = 0; i < tokenNames.length; i++) {
/* 124 */       String tokenName = tokenNames[i];
/* 125 */       if (tokenName == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 129 */       if (!tokenName.isEmpty()) {
/* 130 */         char firstChar = tokenName.charAt(0);
/* 131 */         if (firstChar == '\'') {
/* 132 */           symbolicNames[i] = null;
/*     */           continue;
/*     */         } 
/* 135 */         if (Character.isUpperCase(firstChar)) {
/* 136 */           literalNames[i] = null;
/*     */           
/*     */           continue;
/*     */         } 
/*     */       } 
/*     */       
/* 142 */       literalNames[i] = null;
/* 143 */       symbolicNames[i] = null;
/*     */       continue;
/*     */     } 
/* 146 */     return new VocabularyImpl(literalNames, symbolicNames, tokenNames);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLiteralName(int tokenType) {
/* 151 */     if (tokenType >= 0 && tokenType < this.literalNames.length) {
/* 152 */       return this.literalNames[tokenType];
/*     */     }
/*     */     
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSymbolicName(int tokenType) {
/* 160 */     if (tokenType >= 0 && tokenType < this.symbolicNames.length) {
/* 161 */       return this.symbolicNames[tokenType];
/*     */     }
/*     */     
/* 164 */     if (tokenType == -1) {
/* 165 */       return "EOF";
/*     */     }
/*     */     
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayName(int tokenType) {
/* 173 */     if (tokenType >= 0 && tokenType < this.displayNames.length) {
/* 174 */       String displayName = this.displayNames[tokenType];
/* 175 */       if (displayName != null) {
/* 176 */         return displayName;
/*     */       }
/*     */     } 
/*     */     
/* 180 */     String literalName = getLiteralName(tokenType);
/* 181 */     if (literalName != null) {
/* 182 */       return literalName;
/*     */     }
/*     */     
/* 185 */     String symbolicName = getSymbolicName(tokenType);
/* 186 */     if (symbolicName != null) {
/* 187 */       return symbolicName;
/*     */     }
/*     */     
/* 190 */     return Integer.toString(tokenType);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/VocabularyImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */