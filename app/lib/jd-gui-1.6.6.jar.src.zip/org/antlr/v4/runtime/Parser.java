/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.antlr.v4.runtime.atn.ATN;
/*     */ import org.antlr.v4.runtime.atn.ATNDeserializationOptions;
/*     */ import org.antlr.v4.runtime.atn.ATNDeserializer;
/*     */ import org.antlr.v4.runtime.atn.ATNSimulator;
/*     */ import org.antlr.v4.runtime.atn.ATNState;
/*     */ import org.antlr.v4.runtime.atn.ParseInfo;
/*     */ import org.antlr.v4.runtime.atn.ParserATNSimulator;
/*     */ import org.antlr.v4.runtime.atn.ProfilingATNSimulator;
/*     */ import org.antlr.v4.runtime.atn.RuleTransition;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ import org.antlr.v4.runtime.misc.IntegerStack;
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ import org.antlr.v4.runtime.tree.ErrorNode;
/*     */ import org.antlr.v4.runtime.tree.ParseTreeListener;
/*     */ import org.antlr.v4.runtime.tree.TerminalNode;
/*     */ import org.antlr.v4.runtime.tree.pattern.ParseTreePattern;
/*     */ import org.antlr.v4.runtime.tree.pattern.ParseTreePatternMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Parser
/*     */   extends Recognizer<Token, ParserATNSimulator>
/*     */ {
/*     */   public class TraceListener
/*     */     implements ParseTreeListener
/*     */   {
/*     */     public void enterEveryRule(ParserRuleContext ctx) {
/*  64 */       System.out.println("enter   " + Parser.this.getRuleNames()[ctx.getRuleIndex()] + ", LT(1)=" + Parser.this._input.LT(1).getText());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void visitTerminal(TerminalNode node) {
/*  70 */       System.out.println("consume " + node.getSymbol() + " rule " + Parser.this.getRuleNames()[Parser.this._ctx.getRuleIndex()]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void visitErrorNode(ErrorNode node) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void exitEveryRule(ParserRuleContext ctx) {
/*  80 */       System.out.println("exit    " + Parser.this.getRuleNames()[ctx.getRuleIndex()] + ", LT(1)=" + Parser.this._input.LT(1).getText());
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TrimToSizeListener
/*     */     implements ParseTreeListener {
/*  86 */     public static final TrimToSizeListener INSTANCE = new TrimToSizeListener();
/*     */ 
/*     */     
/*     */     public void enterEveryRule(ParserRuleContext ctx) {}
/*     */ 
/*     */     
/*     */     public void visitTerminal(TerminalNode node) {}
/*     */ 
/*     */     
/*     */     public void visitErrorNode(ErrorNode node) {}
/*     */ 
/*     */     
/*     */     public void exitEveryRule(ParserRuleContext ctx) {
/*  99 */       if (ctx.children instanceof ArrayList) {
/* 100 */         ((ArrayList)ctx.children).trimToSize();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   private static final Map<String, ATN> bypassAltsAtnCache = new WeakHashMap<String, ATN>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   protected ANTLRErrorStrategy _errHandler = new DefaultErrorStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TokenStream _input;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   protected final IntegerStack _precedenceStack = new IntegerStack(); protected ParserRuleContext _ctx; protected boolean _buildParseTrees; public Parser(TokenStream input) {
/* 135 */     this._precedenceStack.push(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     this._buildParseTrees = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     setInputStream(input);
/*     */   }
/*     */   private TraceListener _tracer; protected List<ParseTreeListener> _parseListeners; protected int _syntaxErrors;
/*     */   
/*     */   public void reset() {
/* 183 */     if (getInputStream() != null) getInputStream().seek(0); 
/* 184 */     this._errHandler.reset(this);
/* 185 */     this._ctx = null;
/* 186 */     this._syntaxErrors = 0;
/* 187 */     setTrace(false);
/* 188 */     this._precedenceStack.clear();
/* 189 */     this._precedenceStack.push(0);
/* 190 */     ATNSimulator interpreter = getInterpreter();
/* 191 */     if (interpreter != null) {
/* 192 */       interpreter.reset();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token match(int ttype) throws RecognitionException {
/* 215 */     Token t = getCurrentToken();
/* 216 */     if (t.getType() == ttype) {
/* 217 */       this._errHandler.reportMatch(this);
/* 218 */       consume();
/*     */     } else {
/*     */       
/* 221 */       t = this._errHandler.recoverInline(this);
/* 222 */       if (this._buildParseTrees && t.getTokenIndex() == -1)
/*     */       {
/*     */         
/* 225 */         this._ctx.addErrorNode(t);
/*     */       }
/*     */     } 
/* 228 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token matchWildcard() throws RecognitionException {
/* 249 */     Token t = getCurrentToken();
/* 250 */     if (t.getType() > 0) {
/* 251 */       this._errHandler.reportMatch(this);
/* 252 */       consume();
/*     */     } else {
/*     */       
/* 255 */       t = this._errHandler.recoverInline(this);
/* 256 */       if (this._buildParseTrees && t.getTokenIndex() == -1)
/*     */       {
/*     */         
/* 259 */         this._ctx.addErrorNode(t);
/*     */       }
/*     */     } 
/*     */     
/* 263 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuildParseTree(boolean buildParseTrees) {
/* 282 */     this._buildParseTrees = buildParseTrees;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBuildParseTree() {
/* 293 */     return this._buildParseTrees;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrimParseTree(boolean trimParseTrees) {
/* 304 */     if (trimParseTrees) {
/* 305 */       if (getTrimParseTree())
/* 306 */         return;  addParseListener(TrimToSizeListener.INSTANCE);
/*     */     } else {
/*     */       
/* 309 */       removeParseListener(TrimToSizeListener.INSTANCE);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getTrimParseTree() {
/* 318 */     return getParseListeners().contains(TrimToSizeListener.INSTANCE);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ParseTreeListener> getParseListeners() {
/* 323 */     List<ParseTreeListener> listeners = this._parseListeners;
/* 324 */     if (listeners == null) {
/* 325 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 328 */     return listeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParseListener(ParseTreeListener listener) {
/* 361 */     if (listener == null) {
/* 362 */       throw new NullPointerException("listener");
/*     */     }
/*     */     
/* 365 */     if (this._parseListeners == null) {
/* 366 */       this._parseListeners = new ArrayList<ParseTreeListener>();
/*     */     }
/*     */     
/* 369 */     this._parseListeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeParseListener(ParseTreeListener listener) {
/* 383 */     if (this._parseListeners != null && 
/* 384 */       this._parseListeners.remove(listener) && 
/* 385 */       this._parseListeners.isEmpty()) {
/* 386 */       this._parseListeners = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeParseListeners() {
/* 398 */     this._parseListeners = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void triggerEnterRuleEvent() {
/* 407 */     for (ParseTreeListener listener : this._parseListeners) {
/* 408 */       listener.enterEveryRule(this._ctx);
/* 409 */       this._ctx.enterRule(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void triggerExitRuleEvent() {
/* 420 */     for (int i = this._parseListeners.size() - 1; i >= 0; i--) {
/* 421 */       ParseTreeListener listener = this._parseListeners.get(i);
/* 422 */       this._ctx.exitRule(listener);
/* 423 */       listener.exitEveryRule(this._ctx);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfSyntaxErrors() {
/* 434 */     return this._syntaxErrors;
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenFactory<?> getTokenFactory() {
/* 439 */     return this._input.getTokenSource().getTokenFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTokenFactory(TokenFactory<?> factory) {
/* 445 */     this._input.getTokenSource().setTokenFactory(factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATN getATNWithBypassAlts() {
/* 457 */     String serializedAtn = getSerializedATN();
/* 458 */     if (serializedAtn == null) {
/* 459 */       throw new UnsupportedOperationException("The current parser does not support an ATN with bypass alternatives.");
/*     */     }
/*     */     
/* 462 */     synchronized (bypassAltsAtnCache) {
/* 463 */       ATN result = bypassAltsAtnCache.get(serializedAtn);
/* 464 */       if (result == null) {
/* 465 */         ATNDeserializationOptions deserializationOptions = new ATNDeserializationOptions();
/* 466 */         deserializationOptions.setGenerateRuleBypassTransitions(true);
/* 467 */         result = (new ATNDeserializer(deserializationOptions)).deserialize(serializedAtn.toCharArray());
/* 468 */         bypassAltsAtnCache.put(serializedAtn, result);
/*     */       } 
/*     */       
/* 471 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreePattern compileParseTreePattern(String pattern, int patternRuleIndex) {
/* 487 */     if (getTokenStream() != null) {
/* 488 */       TokenSource tokenSource = getTokenStream().getTokenSource();
/* 489 */       if (tokenSource instanceof Lexer) {
/* 490 */         Lexer lexer = (Lexer)tokenSource;
/* 491 */         return compileParseTreePattern(pattern, patternRuleIndex, lexer);
/*     */       } 
/*     */     } 
/* 494 */     throw new UnsupportedOperationException("Parser can't discover a lexer to use");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreePattern compileParseTreePattern(String pattern, int patternRuleIndex, Lexer lexer) {
/* 504 */     ParseTreePatternMatcher m = new ParseTreePatternMatcher(lexer, this);
/* 505 */     return m.compile(pattern, patternRuleIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public ANTLRErrorStrategy getErrorHandler() {
/* 510 */     return this._errHandler;
/*     */   }
/*     */   
/*     */   public void setErrorHandler(ANTLRErrorStrategy handler) {
/* 514 */     this._errHandler = handler;
/*     */   }
/*     */   
/*     */   public TokenStream getInputStream() {
/* 518 */     return getTokenStream();
/*     */   }
/*     */   
/*     */   public final void setInputStream(IntStream input) {
/* 522 */     setTokenStream((TokenStream)input);
/*     */   }
/*     */   
/*     */   public TokenStream getTokenStream() {
/* 526 */     return this._input;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTokenStream(TokenStream input) {
/* 531 */     this._input = null;
/* 532 */     reset();
/* 533 */     this._input = input;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token getCurrentToken() {
/* 541 */     return this._input.LT(1);
/*     */   }
/*     */   
/*     */   public final void notifyErrorListeners(String msg) {
/* 545 */     notifyErrorListeners(getCurrentToken(), msg, (RecognitionException)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyErrorListeners(Token offendingToken, String msg, RecognitionException e) {
/* 551 */     this._syntaxErrors++;
/* 552 */     int line = -1;
/* 553 */     int charPositionInLine = -1;
/* 554 */     line = offendingToken.getLine();
/* 555 */     charPositionInLine = offendingToken.getCharPositionInLine();
/*     */     
/* 557 */     ANTLRErrorListener listener = getErrorListenerDispatch();
/* 558 */     listener.syntaxError(this, offendingToken, line, charPositionInLine, msg, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token consume() {
/* 583 */     Token o = getCurrentToken();
/* 584 */     if (o.getType() != -1) {
/* 585 */       getInputStream().consume();
/*     */     }
/* 587 */     boolean hasListener = (this._parseListeners != null && !this._parseListeners.isEmpty());
/* 588 */     if (this._buildParseTrees || hasListener) {
/* 589 */       if (this._errHandler.inErrorRecoveryMode(this)) {
/* 590 */         ErrorNode node = this._ctx.addErrorNode(o);
/* 591 */         if (this._parseListeners != null) {
/* 592 */           for (ParseTreeListener listener : this._parseListeners) {
/* 593 */             listener.visitErrorNode(node);
/*     */           }
/*     */         }
/*     */       } else {
/*     */         
/* 598 */         TerminalNode node = this._ctx.addChild(o);
/* 599 */         if (this._parseListeners != null) {
/* 600 */           for (ParseTreeListener listener : this._parseListeners) {
/* 601 */             listener.visitTerminal(node);
/*     */           }
/*     */         }
/*     */       } 
/*     */     }
/* 606 */     return o;
/*     */   }
/*     */   
/*     */   protected void addContextToParseTree() {
/* 610 */     ParserRuleContext parent = (ParserRuleContext)this._ctx.parent;
/*     */     
/* 612 */     if (parent != null) {
/* 613 */       parent.addChild(this._ctx);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enterRule(ParserRuleContext localctx, int state, int ruleIndex) {
/* 622 */     setState(state);
/* 623 */     this._ctx = localctx;
/* 624 */     this._ctx.start = this._input.LT(1);
/* 625 */     if (this._buildParseTrees) addContextToParseTree(); 
/* 626 */     if (this._parseListeners != null) triggerEnterRuleEvent(); 
/*     */   }
/*     */   
/*     */   public void exitRule() {
/* 630 */     this._ctx.stop = this._input.LT(-1);
/*     */     
/* 632 */     if (this._parseListeners != null) triggerExitRuleEvent(); 
/* 633 */     setState(this._ctx.invokingState);
/* 634 */     this._ctx = (ParserRuleContext)this._ctx.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void enterOuterAlt(ParserRuleContext localctx, int altNum) {
/* 640 */     if (this._buildParseTrees && this._ctx != localctx) {
/* 641 */       ParserRuleContext parent = (ParserRuleContext)this._ctx.parent;
/* 642 */       if (parent != null) {
/* 643 */         parent.removeLastChild();
/* 644 */         parent.addChild(localctx);
/*     */       } 
/*     */     } 
/* 647 */     this._ctx = localctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getPrecedence() {
/* 657 */     if (this._precedenceStack.isEmpty()) {
/* 658 */       return -1;
/*     */     }
/*     */     
/* 661 */     return this._precedenceStack.peek();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void enterRecursionRule(ParserRuleContext localctx, int ruleIndex) {
/* 670 */     enterRecursionRule(localctx, ((getATN()).ruleToStartState[ruleIndex]).stateNumber, ruleIndex, 0);
/*     */   }
/*     */   
/*     */   public void enterRecursionRule(ParserRuleContext localctx, int state, int ruleIndex, int precedence) {
/* 674 */     setState(state);
/* 675 */     this._precedenceStack.push(precedence);
/* 676 */     this._ctx = localctx;
/* 677 */     this._ctx.start = this._input.LT(1);
/* 678 */     if (this._parseListeners != null) {
/* 679 */       triggerEnterRuleEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushNewRecursionContext(ParserRuleContext localctx, int state, int ruleIndex) {
/* 687 */     ParserRuleContext previous = this._ctx;
/* 688 */     previous.parent = localctx;
/* 689 */     previous.invokingState = state;
/* 690 */     previous.stop = this._input.LT(-1);
/*     */     
/* 692 */     this._ctx = localctx;
/* 693 */     this._ctx.start = previous.start;
/* 694 */     if (this._buildParseTrees) {
/* 695 */       this._ctx.addChild(previous);
/*     */     }
/*     */     
/* 698 */     if (this._parseListeners != null) {
/* 699 */       triggerEnterRuleEvent();
/*     */     }
/*     */   }
/*     */   
/*     */   public void unrollRecursionContexts(ParserRuleContext _parentctx) {
/* 704 */     this._precedenceStack.pop();
/* 705 */     this._ctx.stop = this._input.LT(-1);
/* 706 */     ParserRuleContext retctx = this._ctx;
/*     */ 
/*     */     
/* 709 */     if (this._parseListeners != null) {
/* 710 */       while (this._ctx != _parentctx) {
/* 711 */         triggerExitRuleEvent();
/* 712 */         this._ctx = (ParserRuleContext)this._ctx.parent;
/*     */       } 
/*     */     } else {
/*     */       
/* 716 */       this._ctx = _parentctx;
/*     */     } 
/*     */ 
/*     */     
/* 720 */     retctx.parent = _parentctx;
/*     */     
/* 722 */     if (this._buildParseTrees && _parentctx != null)
/*     */     {
/* 724 */       _parentctx.addChild(retctx);
/*     */     }
/*     */   }
/*     */   
/*     */   public ParserRuleContext getInvokingContext(int ruleIndex) {
/* 729 */     ParserRuleContext p = this._ctx;
/* 730 */     while (p != null) {
/* 731 */       if (p.getRuleIndex() == ruleIndex) return p; 
/* 732 */       p = (ParserRuleContext)p.parent;
/*     */     } 
/* 734 */     return null;
/*     */   }
/*     */   
/*     */   public ParserRuleContext getContext() {
/* 738 */     return this._ctx;
/*     */   }
/*     */   
/*     */   public void setContext(ParserRuleContext ctx) {
/* 742 */     this._ctx = ctx;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean precpred(RuleContext localctx, int precedence) {
/* 747 */     return (precedence >= this._precedenceStack.peek());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean inContext(String context) {
/* 752 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExpectedToken(int symbol) {
/* 771 */     ATN atn = (getInterpreter()).atn;
/* 772 */     ParserRuleContext ctx = this._ctx;
/* 773 */     ATNState s = atn.states.get(getState());
/* 774 */     IntervalSet following = atn.nextTokens(s);
/* 775 */     if (following.contains(symbol)) {
/* 776 */       return true;
/*     */     }
/*     */     
/* 779 */     if (!following.contains(-2)) return false;
/*     */     
/* 781 */     while (ctx != null && ctx.invokingState >= 0 && following.contains(-2)) {
/* 782 */       ATNState invokingState = atn.states.get(ctx.invokingState);
/* 783 */       RuleTransition rt = (RuleTransition)invokingState.transition(0);
/* 784 */       following = atn.nextTokens(rt.followState);
/* 785 */       if (following.contains(symbol)) {
/* 786 */         return true;
/*     */       }
/*     */       
/* 789 */       ctx = (ParserRuleContext)ctx.parent;
/*     */     } 
/*     */     
/* 792 */     if (following.contains(-2) && symbol == -1) {
/* 793 */       return true;
/*     */     }
/*     */     
/* 796 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet getExpectedTokens() {
/* 807 */     return getATN().getExpectedTokens(getState(), getContext());
/*     */   }
/*     */ 
/*     */   
/*     */   public IntervalSet getExpectedTokensWithinCurrentRule() {
/* 812 */     ATN atn = (getInterpreter()).atn;
/* 813 */     ATNState s = atn.states.get(getState());
/* 814 */     return atn.nextTokens(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRuleIndex(String ruleName) {
/* 819 */     Integer ruleIndex = getRuleIndexMap().get(ruleName);
/* 820 */     if (ruleIndex != null) return ruleIndex.intValue(); 
/* 821 */     return -1;
/*     */   }
/*     */   public ParserRuleContext getRuleContext() {
/* 824 */     return this._ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getRuleInvocationStack() {
/* 834 */     return getRuleInvocationStack(this._ctx);
/*     */   }
/*     */   
/*     */   public List<String> getRuleInvocationStack(RuleContext p) {
/* 838 */     String[] ruleNames = getRuleNames();
/* 839 */     List<String> stack = new ArrayList<String>();
/* 840 */     while (p != null) {
/*     */       
/* 842 */       int ruleIndex = p.getRuleIndex();
/* 843 */       if (ruleIndex < 0) { stack.add("n/a"); }
/* 844 */       else { stack.add(ruleNames[ruleIndex]); }
/* 845 */        p = p.parent;
/*     */     } 
/* 847 */     return stack;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getDFAStrings() {
/* 852 */     synchronized (this._interp.decisionToDFA) {
/* 853 */       List<String> s = new ArrayList<String>();
/* 854 */       for (int d = 0; d < this._interp.decisionToDFA.length; d++) {
/* 855 */         DFA dfa = this._interp.decisionToDFA[d];
/* 856 */         s.add(dfa.toString(getVocabulary()));
/*     */       } 
/* 858 */       return s;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void dumpDFA() {
/* 864 */     synchronized (this._interp.decisionToDFA) {
/* 865 */       boolean seenOne = false;
/* 866 */       for (int d = 0; d < this._interp.decisionToDFA.length; d++) {
/* 867 */         DFA dfa = this._interp.decisionToDFA[d];
/* 868 */         if (!dfa.states.isEmpty()) {
/* 869 */           if (seenOne) System.out.println(); 
/* 870 */           System.out.println("Decision " + dfa.decision + ":");
/* 871 */           System.out.print(dfa.toString(getVocabulary()));
/* 872 */           seenOne = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getSourceName() {
/* 879 */     return this._input.getSourceName();
/*     */   }
/*     */ 
/*     */   
/*     */   public ParseInfo getParseInfo() {
/* 884 */     ParserATNSimulator interp = getInterpreter();
/* 885 */     if (interp instanceof ProfilingATNSimulator) {
/* 886 */       return new ParseInfo((ProfilingATNSimulator)interp);
/*     */     }
/* 888 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProfile(boolean profile) {
/* 895 */     ParserATNSimulator interp = getInterpreter();
/* 896 */     if (profile) {
/* 897 */       if (!(interp instanceof ProfilingATNSimulator)) {
/* 898 */         setInterpreter(new ProfilingATNSimulator(this));
/*     */       }
/*     */     }
/* 901 */     else if (interp instanceof ProfilingATNSimulator) {
/* 902 */       setInterpreter(new ParserATNSimulator(this, getATN(), interp.decisionToDFA, interp.getSharedContextCache()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrace(boolean trace) {
/* 910 */     if (!trace) {
/* 911 */       removeParseListener(this._tracer);
/* 912 */       this._tracer = null;
/*     */     } else {
/*     */       
/* 915 */       if (this._tracer != null) { removeParseListener(this._tracer); }
/* 916 */       else { this._tracer = new TraceListener(); }
/* 917 */        addParseListener(this._tracer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTrace() {
/* 928 */     return (this._tracer != null);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/Parser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */