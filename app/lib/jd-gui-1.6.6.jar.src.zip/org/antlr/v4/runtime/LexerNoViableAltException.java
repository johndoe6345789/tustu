/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.antlr.v4.runtime.atn.ATNConfigSet;
/*    */ import org.antlr.v4.runtime.misc.Interval;
/*    */ import org.antlr.v4.runtime.misc.Utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LexerNoViableAltException
/*    */   extends RecognitionException
/*    */ {
/*    */   private final int startIndex;
/*    */   private final ATNConfigSet deadEndConfigs;
/*    */   
/*    */   public LexerNoViableAltException(Lexer lexer, CharStream input, int startIndex, ATNConfigSet deadEndConfigs) {
/* 51 */     super(lexer, input, null);
/* 52 */     this.startIndex = startIndex;
/* 53 */     this.deadEndConfigs = deadEndConfigs;
/*    */   }
/*    */   
/*    */   public int getStartIndex() {
/* 57 */     return this.startIndex;
/*    */   }
/*    */ 
/*    */   
/*    */   public ATNConfigSet getDeadEndConfigs() {
/* 62 */     return this.deadEndConfigs;
/*    */   }
/*    */ 
/*    */   
/*    */   public CharStream getInputStream() {
/* 67 */     return (CharStream)super.getInputStream();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     String symbol = "";
/* 73 */     if (this.startIndex >= 0 && this.startIndex < getInputStream().size()) {
/* 74 */       symbol = getInputStream().getText(Interval.of(this.startIndex, this.startIndex));
/* 75 */       symbol = Utils.escapeWhitespace(symbol, false);
/*    */     } 
/*    */     
/* 78 */     return String.format(Locale.getDefault(), "%s('%s')", new Object[] { LexerNoViableAltException.class.getSimpleName(), symbol });
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/LexerNoViableAltException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */