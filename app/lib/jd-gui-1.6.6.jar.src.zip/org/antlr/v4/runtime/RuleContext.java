/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Future;
/*     */ import javax.print.PrintException;
/*     */ import javax.swing.JDialog;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ import org.antlr.v4.runtime.tree.ParseTreeVisitor;
/*     */ import org.antlr.v4.runtime.tree.RuleNode;
/*     */ import org.antlr.v4.runtime.tree.Tree;
/*     */ import org.antlr.v4.runtime.tree.Trees;
/*     */ import org.antlr.v4.runtime.tree.gui.TreeViewer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuleContext
/*     */   implements RuleNode
/*     */ {
/*  67 */   public static final ParserRuleContext EMPTY = new ParserRuleContext();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleContext parent;
/*     */ 
/*     */ 
/*     */   
/*  76 */   public int invokingState = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleContext(RuleContext parent, int invokingState) {
/*  81 */     this.parent = parent;
/*     */     
/*  83 */     this.invokingState = invokingState;
/*     */   }
/*     */   
/*     */   public int depth() {
/*  87 */     int n = 0;
/*  88 */     RuleContext p = this;
/*  89 */     while (p != null) {
/*  90 */       p = p.parent;
/*  91 */       n++;
/*     */     } 
/*  93 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 100 */     return (this.invokingState == -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Interval getSourceInterval() {
/* 107 */     return Interval.INVALID;
/*     */   }
/*     */   
/*     */   public RuleContext getRuleContext() {
/* 111 */     return this;
/*     */   }
/*     */   public RuleContext getParent() {
/* 114 */     return this.parent;
/*     */   }
/*     */   public RuleContext getPayload() {
/* 117 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 128 */     if (getChildCount() == 0) {
/* 129 */       return "";
/*     */     }
/*     */     
/* 132 */     StringBuilder builder = new StringBuilder();
/* 133 */     for (int i = 0; i < getChildCount(); i++) {
/* 134 */       builder.append(getChild(i).getText());
/*     */     }
/*     */     
/* 137 */     return builder.toString();
/*     */   }
/*     */   public int getRuleIndex() {
/* 140 */     return -1;
/*     */   }
/*     */   
/*     */   public ParseTree getChild(int i) {
/* 144 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/* 149 */     return 0;
/*     */   }
/*     */   
/*     */   public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
/* 153 */     return visitor.visitChildren(this);
/*     */   }
/*     */   
/*     */   public Future<JDialog> inspect(Parser parser) {
/* 157 */     List<String> ruleNames = (parser != null) ? Arrays.<String>asList(parser.getRuleNames()) : null;
/* 158 */     return inspect(ruleNames);
/*     */   }
/*     */   
/*     */   public Future<JDialog> inspect(List<String> ruleNames) {
/* 162 */     TreeViewer viewer = new TreeViewer(ruleNames, this);
/* 163 */     return viewer.open();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(Parser parser, String fileName) throws IOException, PrintException {
/* 170 */     List<String> ruleNames = (parser != null) ? Arrays.<String>asList(parser.getRuleNames()) : null;
/* 171 */     save(ruleNames, fileName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(Parser parser, String fileName, String fontName, int fontSize) throws IOException {
/* 179 */     List<String> ruleNames = (parser != null) ? Arrays.<String>asList(parser.getRuleNames()) : null;
/* 180 */     save(ruleNames, fileName, fontName, fontSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(List<String> ruleNames, String fileName) throws IOException, PrintException {
/* 187 */     Trees.writePS(this, ruleNames, fileName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(List<String> ruleNames, String fileName, String fontName, int fontSize) throws IOException {
/* 195 */     Trees.writePS(this, ruleNames, fileName, fontName, fontSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringTree(Parser recog) {
/* 204 */     return Trees.toStringTree(this, recog);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringTree(List<String> ruleNames) {
/* 211 */     return Trees.toStringTree(this, ruleNames);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringTree() {
/* 216 */     return toStringTree((List<String>)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 221 */     return toString((List<String>)null, (RuleContext)null);
/*     */   }
/*     */   
/*     */   public final String toString(Recognizer<?, ?> recog) {
/* 225 */     return toString(recog, ParserRuleContext.EMPTY);
/*     */   }
/*     */   
/*     */   public final String toString(List<String> ruleNames) {
/* 229 */     return toString(ruleNames, (RuleContext)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString(Recognizer<?, ?> recog, RuleContext stop) {
/* 234 */     String[] ruleNames = (recog != null) ? recog.getRuleNames() : null;
/* 235 */     List<String> ruleNamesList = (ruleNames != null) ? Arrays.<String>asList(ruleNames) : null;
/* 236 */     return toString(ruleNamesList, stop);
/*     */   }
/*     */   
/*     */   public String toString(List<String> ruleNames, RuleContext stop) {
/* 240 */     StringBuilder buf = new StringBuilder();
/* 241 */     RuleContext p = this;
/* 242 */     buf.append("[");
/* 243 */     while (p != null && p != stop) {
/* 244 */       if (ruleNames == null) {
/* 245 */         if (!p.isEmpty()) {
/* 246 */           buf.append(p.invokingState);
/*     */         }
/*     */       } else {
/*     */         
/* 250 */         int ruleIndex = p.getRuleIndex();
/* 251 */         String ruleName = (ruleIndex >= 0 && ruleIndex < ruleNames.size()) ? ruleNames.get(ruleIndex) : Integer.toString(ruleIndex);
/* 252 */         buf.append(ruleName);
/*     */       } 
/*     */       
/* 255 */       if (p.parent != null && (ruleNames != null || !p.parent.isEmpty())) {
/* 256 */         buf.append(" ");
/*     */       }
/*     */       
/* 259 */       p = p.parent;
/*     */     } 
/*     */     
/* 262 */     buf.append("]");
/* 263 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public RuleContext() {}
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/RuleContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */