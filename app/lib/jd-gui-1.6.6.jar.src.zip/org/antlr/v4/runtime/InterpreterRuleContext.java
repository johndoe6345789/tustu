/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterpreterRuleContext
/*    */   extends ParserRuleContext
/*    */ {
/*    */   private final int ruleIndex;
/*    */   
/*    */   public InterpreterRuleContext(ParserRuleContext parent, int invokingStateNumber, int ruleIndex) {
/* 62 */     super(parent, invokingStateNumber);
/* 63 */     this.ruleIndex = ruleIndex;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRuleIndex() {
/* 68 */     return this.ruleIndex;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/InterpreterRuleContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */