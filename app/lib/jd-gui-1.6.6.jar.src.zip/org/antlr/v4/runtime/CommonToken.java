/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ import org.antlr.v4.runtime.misc.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonToken
/*     */   implements WritableToken, Serializable
/*     */ {
/*  43 */   protected static final Pair<TokenSource, CharStream> EMPTY_SOURCE = new Pair<TokenSource, CharStream>(null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int line;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   protected int charPositionInLine = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   protected int channel = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Pair<TokenSource, CharStream> source;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   protected int index = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int start;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int stop;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommonToken(int type) {
/* 113 */     this.type = type;
/* 114 */     this.source = EMPTY_SOURCE;
/*     */   }
/*     */   
/*     */   public CommonToken(Pair<TokenSource, CharStream> source, int type, int channel, int start, int stop) {
/* 118 */     this.source = source;
/* 119 */     this.type = type;
/* 120 */     this.channel = channel;
/* 121 */     this.start = start;
/* 122 */     this.stop = stop;
/* 123 */     if (source.a != null) {
/* 124 */       this.line = ((TokenSource)source.a).getLine();
/* 125 */       this.charPositionInLine = ((TokenSource)source.a).getCharPositionInLine();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommonToken(int type, String text) {
/* 137 */     this.type = type;
/* 138 */     this.channel = 0;
/* 139 */     this.text = text;
/* 140 */     this.source = EMPTY_SOURCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommonToken(Token oldToken) {
/* 157 */     this.type = oldToken.getType();
/* 158 */     this.line = oldToken.getLine();
/* 159 */     this.index = oldToken.getTokenIndex();
/* 160 */     this.charPositionInLine = oldToken.getCharPositionInLine();
/* 161 */     this.channel = oldToken.getChannel();
/* 162 */     this.start = oldToken.getStartIndex();
/* 163 */     this.stop = oldToken.getStopIndex();
/*     */     
/* 165 */     if (oldToken instanceof CommonToken) {
/* 166 */       this.text = ((CommonToken)oldToken).text;
/* 167 */       this.source = ((CommonToken)oldToken).source;
/*     */     } else {
/*     */       
/* 170 */       this.text = oldToken.getText();
/* 171 */       this.source = new Pair<TokenSource, CharStream>(oldToken.getTokenSource(), oldToken.getInputStream());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/* 177 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLine(int line) {
/* 182 */     this.line = line;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() {
/* 187 */     if (this.text != null) {
/* 188 */       return this.text;
/*     */     }
/*     */     
/* 191 */     CharStream input = getInputStream();
/* 192 */     if (input == null) return null; 
/* 193 */     int n = input.size();
/* 194 */     if (this.start < n && this.stop < n) {
/* 195 */       return input.getText(Interval.of(this.start, this.stop));
/*     */     }
/*     */     
/* 198 */     return "<EOF>";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/* 213 */     this.text = text;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLine() {
/* 218 */     return this.line;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCharPositionInLine() {
/* 223 */     return this.charPositionInLine;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCharPositionInLine(int charPositionInLine) {
/* 228 */     this.charPositionInLine = charPositionInLine;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChannel() {
/* 233 */     return this.channel;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChannel(int channel) {
/* 238 */     this.channel = channel;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setType(int type) {
/* 243 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStartIndex() {
/* 248 */     return this.start;
/*     */   }
/*     */   
/*     */   public void setStartIndex(int start) {
/* 252 */     this.start = start;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStopIndex() {
/* 257 */     return this.stop;
/*     */   }
/*     */   
/*     */   public void setStopIndex(int stop) {
/* 261 */     this.stop = stop;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTokenIndex() {
/* 266 */     return this.index;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTokenIndex(int index) {
/* 271 */     this.index = index;
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenSource getTokenSource() {
/* 276 */     return (TokenSource)this.source.a;
/*     */   }
/*     */ 
/*     */   
/*     */   public CharStream getInputStream() {
/* 281 */     return (CharStream)this.source.b;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 286 */     String channelStr = "";
/* 287 */     if (this.channel > 0) {
/* 288 */       channelStr = ",channel=" + this.channel;
/*     */     }
/* 290 */     String txt = getText();
/* 291 */     if (txt != null) {
/* 292 */       txt = txt.replace("\n", "\\n");
/* 293 */       txt = txt.replace("\r", "\\r");
/* 294 */       txt = txt.replace("\t", "\\t");
/*     */     } else {
/*     */       
/* 297 */       txt = "<no text>";
/*     */     } 
/* 299 */     return "[@" + getTokenIndex() + "," + this.start + ":" + this.stop + "='" + txt + "',<" + this.type + ">" + channelStr + "," + this.line + ":" + getCharPositionInLine() + "]";
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/CommonToken.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */