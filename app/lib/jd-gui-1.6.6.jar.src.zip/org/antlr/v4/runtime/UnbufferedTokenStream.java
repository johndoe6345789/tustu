/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnbufferedTokenStream<T extends Token>
/*     */   implements TokenStream
/*     */ {
/*     */   protected TokenSource tokenSource;
/*     */   protected Token[] tokens;
/*     */   protected int n;
/*  61 */   protected int p = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   protected int numMarkers = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Token lastToken;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Token lastTokenBufferStart;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   protected int currentTokenIndex = 0;
/*     */   
/*     */   public UnbufferedTokenStream(TokenSource tokenSource) {
/*  93 */     this(tokenSource, 256);
/*     */   }
/*     */   
/*     */   public UnbufferedTokenStream(TokenSource tokenSource, int bufferSize) {
/*  97 */     this.tokenSource = tokenSource;
/*  98 */     this.tokens = new Token[bufferSize];
/*  99 */     this.n = 0;
/* 100 */     fill(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Token get(int i) {
/* 105 */     int bufferStartIndex = getBufferStartIndex();
/* 106 */     if (i < bufferStartIndex || i >= bufferStartIndex + this.n) {
/* 107 */       throw new IndexOutOfBoundsException("get(" + i + ") outside buffer: " + bufferStartIndex + ".." + (bufferStartIndex + this.n));
/*     */     }
/*     */     
/* 110 */     return this.tokens[i - bufferStartIndex];
/*     */   }
/*     */ 
/*     */   
/*     */   public Token LT(int i) {
/* 115 */     if (i == -1) {
/* 116 */       return this.lastToken;
/*     */     }
/*     */     
/* 119 */     sync(i);
/* 120 */     int index = this.p + i - 1;
/* 121 */     if (index < 0) {
/* 122 */       throw new IndexOutOfBoundsException("LT(" + i + ") gives negative index");
/*     */     }
/*     */     
/* 125 */     if (index >= this.n) {
/* 126 */       assert this.n > 0 && this.tokens[this.n - 1].getType() == -1;
/* 127 */       return this.tokens[this.n - 1];
/*     */     } 
/*     */     
/* 130 */     return this.tokens[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public int LA(int i) {
/* 135 */     return LT(i).getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenSource getTokenSource() {
/* 140 */     return this.tokenSource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 146 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(RuleContext ctx) {
/* 152 */     return getText(ctx.getSourceInterval());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(Token start, Token stop) {
/* 158 */     return getText(Interval.of(start.getTokenIndex(), stop.getTokenIndex()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void consume() {
/* 163 */     if (LA(1) == -1) {
/* 164 */       throw new IllegalStateException("cannot consume EOF");
/*     */     }
/*     */ 
/*     */     
/* 168 */     this.lastToken = this.tokens[this.p];
/*     */ 
/*     */     
/* 171 */     if (this.p == this.n - 1 && this.numMarkers == 0) {
/* 172 */       this.n = 0;
/* 173 */       this.p = -1;
/* 174 */       this.lastTokenBufferStart = this.lastToken;
/*     */     } 
/*     */     
/* 177 */     this.p++;
/* 178 */     this.currentTokenIndex++;
/* 179 */     sync(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sync(int want) {
/* 187 */     int need = this.p + want - 1 - this.n + 1;
/* 188 */     if (need > 0) {
/* 189 */       fill(need);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int fill(int n) {
/* 199 */     for (int i = 0; i < n; i++) {
/* 200 */       if (this.n > 0 && this.tokens[this.n - 1].getType() == -1) {
/* 201 */         return i;
/*     */       }
/*     */       
/* 204 */       Token t = this.tokenSource.nextToken();
/* 205 */       add(t);
/*     */     } 
/*     */     
/* 208 */     return n;
/*     */   }
/*     */   
/*     */   protected void add(Token t) {
/* 212 */     if (this.n >= this.tokens.length) {
/* 213 */       this.tokens = Arrays.<Token>copyOf(this.tokens, this.tokens.length * 2);
/*     */     }
/*     */     
/* 216 */     if (t instanceof WritableToken) {
/* 217 */       ((WritableToken)t).setTokenIndex(getBufferStartIndex() + this.n);
/*     */     }
/*     */     
/* 220 */     this.tokens[this.n++] = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int mark() {
/* 232 */     if (this.numMarkers == 0) {
/* 233 */       this.lastTokenBufferStart = this.lastToken;
/*     */     }
/*     */     
/* 236 */     int mark = -this.numMarkers - 1;
/* 237 */     this.numMarkers++;
/* 238 */     return mark;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release(int marker) {
/* 243 */     int expectedMark = -this.numMarkers;
/* 244 */     if (marker != expectedMark) {
/* 245 */       throw new IllegalStateException("release() called with an invalid marker.");
/*     */     }
/*     */     
/* 248 */     this.numMarkers--;
/* 249 */     if (this.numMarkers == 0) {
/* 250 */       if (this.p > 0) {
/*     */ 
/*     */         
/* 253 */         System.arraycopy(this.tokens, this.p, this.tokens, 0, this.n - this.p);
/* 254 */         this.n -= this.p;
/* 255 */         this.p = 0;
/*     */       } 
/*     */       
/* 258 */       this.lastTokenBufferStart = this.lastToken;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int index() {
/* 264 */     return this.currentTokenIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void seek(int index) {
/* 269 */     if (index == this.currentTokenIndex) {
/*     */       return;
/*     */     }
/*     */     
/* 273 */     if (index > this.currentTokenIndex) {
/* 274 */       sync(index - this.currentTokenIndex);
/* 275 */       index = Math.min(index, getBufferStartIndex() + this.n - 1);
/*     */     } 
/*     */     
/* 278 */     int bufferStartIndex = getBufferStartIndex();
/* 279 */     int i = index - bufferStartIndex;
/* 280 */     if (i < 0) {
/* 281 */       throw new IllegalArgumentException("cannot seek to negative index " + index);
/*     */     }
/* 283 */     if (i >= this.n) {
/* 284 */       throw new UnsupportedOperationException("seek to index outside buffer: " + index + " not in " + bufferStartIndex + ".." + (bufferStartIndex + this.n));
/*     */     }
/*     */ 
/*     */     
/* 288 */     this.p = i;
/* 289 */     this.currentTokenIndex = index;
/* 290 */     if (this.p == 0) {
/* 291 */       this.lastToken = this.lastTokenBufferStart;
/*     */     } else {
/*     */       
/* 294 */       this.lastToken = this.tokens[this.p - 1];
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 300 */     throw new UnsupportedOperationException("Unbuffered stream cannot know its size");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceName() {
/* 305 */     return this.tokenSource.getSourceName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(Interval interval) {
/* 311 */     int bufferStartIndex = getBufferStartIndex();
/* 312 */     int bufferStopIndex = bufferStartIndex + this.tokens.length - 1;
/*     */     
/* 314 */     int start = interval.a;
/* 315 */     int stop = interval.b;
/* 316 */     if (start < bufferStartIndex || stop > bufferStopIndex) {
/* 317 */       throw new UnsupportedOperationException("interval " + interval + " not in token buffer window: " + bufferStartIndex + ".." + bufferStopIndex);
/*     */     }
/*     */ 
/*     */     
/* 321 */     int a = start - bufferStartIndex;
/* 322 */     int b = stop - bufferStartIndex;
/*     */     
/* 324 */     StringBuilder buf = new StringBuilder();
/* 325 */     for (int i = a; i <= b; i++) {
/* 326 */       Token t = this.tokens[i];
/* 327 */       buf.append(t.getText());
/*     */     } 
/*     */     
/* 330 */     return buf.toString();
/*     */   }
/*     */   
/*     */   protected final int getBufferStartIndex() {
/* 334 */     return this.currentTokenIndex - this.p;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/UnbufferedTokenStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */