/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import org.antlr.v4.runtime.atn.ATN;
/*     */ import org.antlr.v4.runtime.atn.ATNState;
/*     */ import org.antlr.v4.runtime.atn.RuleTransition;
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ import org.antlr.v4.runtime.misc.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultErrorStrategy
/*     */   implements ANTLRErrorStrategy
/*     */ {
/*     */   protected boolean errorRecoveryMode = false;
/*  61 */   protected int lastErrorIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IntervalSet lastErrorStates;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset(Parser recognizer) {
/*  73 */     endErrorCondition(recognizer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void beginErrorCondition(Parser recognizer) {
/*  83 */     this.errorRecoveryMode = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean inErrorRecoveryMode(Parser recognizer) {
/*  91 */     return this.errorRecoveryMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void endErrorCondition(Parser recognizer) {
/* 101 */     this.errorRecoveryMode = false;
/* 102 */     this.lastErrorStates = null;
/* 103 */     this.lastErrorIndex = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportMatch(Parser recognizer) {
/* 113 */     endErrorCondition(recognizer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportError(Parser recognizer, RecognitionException e) {
/* 141 */     if (inErrorRecoveryMode(recognizer)) {
/*     */       return;
/*     */     }
/*     */     
/* 145 */     beginErrorCondition(recognizer);
/* 146 */     if (e instanceof NoViableAltException) {
/* 147 */       reportNoViableAlternative(recognizer, (NoViableAltException)e);
/*     */     }
/* 149 */     else if (e instanceof InputMismatchException) {
/* 150 */       reportInputMismatch(recognizer, (InputMismatchException)e);
/*     */     }
/* 152 */     else if (e instanceof FailedPredicateException) {
/* 153 */       reportFailedPredicate(recognizer, (FailedPredicateException)e);
/*     */     } else {
/*     */       
/* 156 */       System.err.println("unknown recognition error type: " + e.getClass().getName());
/* 157 */       recognizer.notifyErrorListeners(e.getOffendingToken(), e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recover(Parser recognizer, RecognitionException e) {
/* 175 */     if (this.lastErrorIndex == recognizer.getInputStream().index() && this.lastErrorStates != null && this.lastErrorStates.contains(recognizer.getState()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 185 */       recognizer.consume();
/*     */     }
/* 187 */     this.lastErrorIndex = recognizer.getInputStream().index();
/* 188 */     if (this.lastErrorStates == null) this.lastErrorStates = new IntervalSet(new int[0]); 
/* 189 */     this.lastErrorStates.add(recognizer.getState());
/* 190 */     IntervalSet followSet = getErrorRecoverySet(recognizer);
/* 191 */     consumeUntil(recognizer, followSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sync(Parser recognizer) throws RecognitionException {
/*     */     IntervalSet expecting, whatFollowsLoopIterationOrRule;
/* 242 */     ATNState s = (recognizer.getInterpreter()).atn.states.get(recognizer.getState());
/*     */ 
/*     */     
/* 245 */     if (inErrorRecoveryMode(recognizer)) {
/*     */       return;
/*     */     }
/*     */     
/* 249 */     TokenStream tokens = recognizer.getInputStream();
/* 250 */     int la = tokens.LA(1);
/*     */ 
/*     */     
/* 253 */     if (recognizer.getATN().nextTokens(s).contains(la) || la == -1) {
/*     */       return;
/*     */     }
/* 256 */     if (recognizer.isExpectedToken(la)) {
/*     */       return;
/*     */     }
/*     */     
/* 260 */     switch (s.getStateType()) {
/*     */       
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 10:
/* 266 */         if (singleTokenDeletion(recognizer) != null) {
/*     */           return;
/*     */         }
/*     */         
/* 270 */         throw new InputMismatchException(recognizer);
/*     */ 
/*     */       
/*     */       case 9:
/*     */       case 11:
/* 275 */         reportUnwantedToken(recognizer);
/* 276 */         expecting = recognizer.getExpectedTokens();
/* 277 */         whatFollowsLoopIterationOrRule = expecting.or(getErrorRecoverySet(recognizer));
/*     */         
/* 279 */         consumeUntil(recognizer, whatFollowsLoopIterationOrRule);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportNoViableAlternative(Parser recognizer, NoViableAltException e) {
/*     */     String input;
/* 300 */     TokenStream tokens = recognizer.getInputStream();
/*     */     
/* 302 */     if (tokens != null) {
/* 303 */       if (e.getStartToken().getType() == -1) { input = "<EOF>"; }
/* 304 */       else { input = tokens.getText(e.getStartToken(), e.getOffendingToken()); }
/*     */     
/*     */     } else {
/* 307 */       input = "<unknown input>";
/*     */     } 
/* 309 */     String msg = "no viable alternative at input " + escapeWSAndQuote(input);
/* 310 */     recognizer.notifyErrorListeners(e.getOffendingToken(), msg, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportInputMismatch(Parser recognizer, InputMismatchException e) {
/* 325 */     String msg = "mismatched input " + getTokenErrorDisplay(e.getOffendingToken()) + " expecting " + e.getExpectedTokens().toString(recognizer.getVocabulary());
/*     */     
/* 327 */     recognizer.notifyErrorListeners(e.getOffendingToken(), msg, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportFailedPredicate(Parser recognizer, FailedPredicateException e) {
/* 342 */     String ruleName = recognizer.getRuleNames()[recognizer._ctx.getRuleIndex()];
/* 343 */     String msg = "rule " + ruleName + " " + e.getMessage();
/* 344 */     recognizer.notifyErrorListeners(e.getOffendingToken(), msg, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportUnwantedToken(Parser recognizer) {
/* 366 */     if (inErrorRecoveryMode(recognizer)) {
/*     */       return;
/*     */     }
/*     */     
/* 370 */     beginErrorCondition(recognizer);
/*     */     
/* 372 */     Token t = recognizer.getCurrentToken();
/* 373 */     String tokenName = getTokenErrorDisplay(t);
/* 374 */     IntervalSet expecting = getExpectedTokens(recognizer);
/* 375 */     String msg = "extraneous input " + tokenName + " expecting " + expecting.toString(recognizer.getVocabulary());
/*     */     
/* 377 */     recognizer.notifyErrorListeners(t, msg, (RecognitionException)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportMissingToken(Parser recognizer) {
/* 398 */     if (inErrorRecoveryMode(recognizer)) {
/*     */       return;
/*     */     }
/*     */     
/* 402 */     beginErrorCondition(recognizer);
/*     */     
/* 404 */     Token t = recognizer.getCurrentToken();
/* 405 */     IntervalSet expecting = getExpectedTokens(recognizer);
/* 406 */     String msg = "missing " + expecting.toString(recognizer.getVocabulary()) + " at " + getTokenErrorDisplay(t);
/*     */ 
/*     */     
/* 409 */     recognizer.notifyErrorListeners(t, msg, (RecognitionException)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token recoverInline(Parser recognizer) throws RecognitionException {
/* 467 */     Token matchedSymbol = singleTokenDeletion(recognizer);
/* 468 */     if (matchedSymbol != null) {
/*     */ 
/*     */       
/* 471 */       recognizer.consume();
/* 472 */       return matchedSymbol;
/*     */     } 
/*     */ 
/*     */     
/* 476 */     if (singleTokenInsertion(recognizer)) {
/* 477 */       return getMissingSymbol(recognizer);
/*     */     }
/*     */ 
/*     */     
/* 481 */     throw new InputMismatchException(recognizer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean singleTokenInsertion(Parser recognizer) {
/* 502 */     int currentSymbolType = recognizer.getInputStream().LA(1);
/*     */ 
/*     */ 
/*     */     
/* 506 */     ATNState currentState = (recognizer.getInterpreter()).atn.states.get(recognizer.getState());
/* 507 */     ATNState next = (currentState.transition(0)).target;
/* 508 */     ATN atn = (recognizer.getInterpreter()).atn;
/* 509 */     IntervalSet expectingAtLL2 = atn.nextTokens(next, recognizer._ctx);
/*     */     
/* 511 */     if (expectingAtLL2.contains(currentSymbolType)) {
/* 512 */       reportMissingToken(recognizer);
/* 513 */       return true;
/*     */     } 
/* 515 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Token singleTokenDeletion(Parser recognizer) {
/* 538 */     int nextTokenType = recognizer.getInputStream().LA(2);
/* 539 */     IntervalSet expecting = getExpectedTokens(recognizer);
/* 540 */     if (expecting.contains(nextTokenType)) {
/* 541 */       reportUnwantedToken(recognizer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 548 */       recognizer.consume();
/*     */       
/* 550 */       Token matchedSymbol = recognizer.getCurrentToken();
/* 551 */       reportMatch(recognizer);
/* 552 */       return matchedSymbol;
/*     */     } 
/* 554 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Token getMissingSymbol(Parser recognizer) {
/*     */     String tokenText;
/* 577 */     Token currentSymbol = recognizer.getCurrentToken();
/* 578 */     IntervalSet expecting = getExpectedTokens(recognizer);
/* 579 */     int expectedTokenType = expecting.getMinElement();
/*     */     
/* 581 */     if (expectedTokenType == -1) { tokenText = "<missing EOF>"; }
/* 582 */     else { tokenText = "<missing " + recognizer.getVocabulary().getDisplayName(expectedTokenType) + ">"; }
/* 583 */      Token current = currentSymbol;
/* 584 */     Token lookback = recognizer.getInputStream().LT(-1);
/* 585 */     if (current.getType() == -1 && lookback != null) {
/* 586 */       current = lookback;
/*     */     }
/* 588 */     return (Token)recognizer.getTokenFactory().create(new Pair<TokenSource, CharStream>(current.getTokenSource(), current.getTokenSource().getInputStream()), expectedTokenType, tokenText, 0, -1, -1, current.getLine(), current.getCharPositionInLine());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IntervalSet getExpectedTokens(Parser recognizer) {
/* 597 */     return recognizer.getExpectedTokens();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getTokenErrorDisplay(Token t) {
/* 609 */     if (t == null) return "<no token>"; 
/* 610 */     String s = getSymbolText(t);
/* 611 */     if (s == null) {
/* 612 */       if (getSymbolType(t) == -1) {
/* 613 */         s = "<EOF>";
/*     */       } else {
/*     */         
/* 616 */         s = "<" + getSymbolType(t) + ">";
/*     */       } 
/*     */     }
/* 619 */     return escapeWSAndQuote(s);
/*     */   }
/*     */   
/*     */   protected String getSymbolText(Token symbol) {
/* 623 */     return symbol.getText();
/*     */   }
/*     */   
/*     */   protected int getSymbolType(Token symbol) {
/* 627 */     return symbol.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String escapeWSAndQuote(String s) {
/* 633 */     s = s.replace("\n", "\\n");
/* 634 */     s = s.replace("\r", "\\r");
/* 635 */     s = s.replace("\t", "\\t");
/* 636 */     return "'" + s + "'";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IntervalSet getErrorRecoverySet(Parser recognizer) {
/* 732 */     ATN atn = (recognizer.getInterpreter()).atn;
/* 733 */     RuleContext ctx = recognizer._ctx;
/* 734 */     IntervalSet recoverSet = new IntervalSet(new int[0]);
/* 735 */     while (ctx != null && ctx.invokingState >= 0) {
/*     */       
/* 737 */       ATNState invokingState = atn.states.get(ctx.invokingState);
/* 738 */       RuleTransition rt = (RuleTransition)invokingState.transition(0);
/* 739 */       IntervalSet follow = atn.nextTokens(rt.followState);
/* 740 */       recoverSet.addAll(follow);
/* 741 */       ctx = ctx.parent;
/*     */     } 
/* 743 */     recoverSet.remove(-2);
/*     */     
/* 745 */     return recoverSet;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void consumeUntil(Parser recognizer, IntervalSet set) {
/* 751 */     int ttype = recognizer.getInputStream().LA(1);
/* 752 */     while (ttype != -1 && !set.contains(ttype)) {
/*     */ 
/*     */       
/* 755 */       recognizer.consume();
/* 756 */       ttype = recognizer.getInputStream().LA(1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/DefaultErrorStrategy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */