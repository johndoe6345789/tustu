/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import org.antlr.v4.runtime.atn.ATNConfig;
/*     */ import org.antlr.v4.runtime.atn.ATNConfigSet;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiagnosticErrorListener
/*     */   extends BaseErrorListener
/*     */ {
/*     */   protected final boolean exactOnly;
/*     */   
/*     */   public DiagnosticErrorListener() {
/*  73 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiagnosticErrorListener(boolean exactOnly) {
/*  84 */     this.exactOnly = exactOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportAmbiguity(Parser recognizer, DFA dfa, int startIndex, int stopIndex, boolean exact, BitSet ambigAlts, ATNConfigSet configs) {
/*  96 */     if (this.exactOnly && !exact) {
/*     */       return;
/*     */     }
/*     */     
/* 100 */     String format = "reportAmbiguity d=%s: ambigAlts=%s, input='%s'";
/* 101 */     String decision = getDecisionDescription(recognizer, dfa);
/* 102 */     BitSet conflictingAlts = getConflictingAlts(ambigAlts, configs);
/* 103 */     String text = recognizer.getTokenStream().getText(Interval.of(startIndex, stopIndex));
/* 104 */     String message = String.format(format, new Object[] { decision, conflictingAlts, text });
/* 105 */     recognizer.notifyErrorListeners(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportAttemptingFullContext(Parser recognizer, DFA dfa, int startIndex, int stopIndex, BitSet conflictingAlts, ATNConfigSet configs) {
/* 116 */     String format = "reportAttemptingFullContext d=%s, input='%s'";
/* 117 */     String decision = getDecisionDescription(recognizer, dfa);
/* 118 */     String text = recognizer.getTokenStream().getText(Interval.of(startIndex, stopIndex));
/* 119 */     String message = String.format(format, new Object[] { decision, text });
/* 120 */     recognizer.notifyErrorListeners(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportContextSensitivity(Parser recognizer, DFA dfa, int startIndex, int stopIndex, int prediction, ATNConfigSet configs) {
/* 131 */     String format = "reportContextSensitivity d=%s, input='%s'";
/* 132 */     String decision = getDecisionDescription(recognizer, dfa);
/* 133 */     String text = recognizer.getTokenStream().getText(Interval.of(startIndex, stopIndex));
/* 134 */     String message = String.format(format, new Object[] { decision, text });
/* 135 */     recognizer.notifyErrorListeners(message);
/*     */   }
/*     */   
/*     */   protected String getDecisionDescription(Parser recognizer, DFA dfa) {
/* 139 */     int decision = dfa.decision;
/* 140 */     int ruleIndex = dfa.atnStartState.ruleIndex;
/*     */     
/* 142 */     String[] ruleNames = recognizer.getRuleNames();
/* 143 */     if (ruleIndex < 0 || ruleIndex >= ruleNames.length) {
/* 144 */       return String.valueOf(decision);
/*     */     }
/*     */     
/* 147 */     String ruleName = ruleNames[ruleIndex];
/* 148 */     if (ruleName == null || ruleName.isEmpty()) {
/* 149 */       return String.valueOf(decision);
/*     */     }
/*     */     
/* 152 */     return String.format("%d (%s)", new Object[] { Integer.valueOf(decision), ruleName });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BitSet getConflictingAlts(BitSet reportedAlts, ATNConfigSet configs) {
/* 167 */     if (reportedAlts != null) {
/* 168 */       return reportedAlts;
/*     */     }
/*     */     
/* 171 */     BitSet result = new BitSet();
/* 172 */     for (ATNConfig config : configs) {
/* 173 */       result.set(config.alt);
/*     */     }
/*     */     
/* 176 */     return result;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/DiagnosticErrorListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */