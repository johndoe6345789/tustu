/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.misc.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListTokenSource
/*     */   implements TokenSource
/*     */ {
/*     */   protected final List<? extends Token> tokens;
/*     */   private final String sourceName;
/*     */   protected int i;
/*     */   protected Token eofToken;
/*  46 */   private TokenFactory<?> _factory = CommonTokenFactory.DEFAULT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListTokenSource(List<? extends Token> tokens) {
/*  57 */     this(tokens, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListTokenSource(List<? extends Token> tokens, String sourceName) {
/*  74 */     if (tokens == null) {
/*  75 */       throw new NullPointerException("tokens cannot be null");
/*     */     }
/*     */     
/*  78 */     this.tokens = tokens;
/*  79 */     this.sourceName = sourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCharPositionInLine() {
/*  87 */     if (this.i < this.tokens.size()) {
/*  88 */       return ((Token)this.tokens.get(this.i)).getCharPositionInLine();
/*     */     }
/*  90 */     if (this.eofToken != null) {
/*  91 */       return this.eofToken.getCharPositionInLine();
/*     */     }
/*  93 */     if (this.tokens.size() > 0) {
/*     */ 
/*     */       
/*  96 */       Token lastToken = this.tokens.get(this.tokens.size() - 1);
/*  97 */       String tokenText = lastToken.getText();
/*  98 */       if (tokenText != null) {
/*  99 */         int lastNewLine = tokenText.lastIndexOf('\n');
/* 100 */         if (lastNewLine >= 0) {
/* 101 */           return tokenText.length() - lastNewLine - 1;
/*     */         }
/*     */       } 
/*     */       
/* 105 */       return lastToken.getCharPositionInLine() + lastToken.getStopIndex() - lastToken.getStartIndex() + 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 110 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token nextToken() {
/* 118 */     if (this.i >= this.tokens.size()) {
/* 119 */       if (this.eofToken == null) {
/* 120 */         int start = -1;
/* 121 */         if (this.tokens.size() > 0) {
/* 122 */           int previousStop = ((Token)this.tokens.get(this.tokens.size() - 1)).getStopIndex();
/* 123 */           if (previousStop != -1) {
/* 124 */             start = previousStop + 1;
/*     */           }
/*     */         } 
/*     */         
/* 128 */         int stop = Math.max(-1, start - 1);
/* 129 */         this.eofToken = (Token)this._factory.create(new Pair<TokenSource, CharStream>(this, getInputStream()), -1, "EOF", 0, start, stop, getLine(), getCharPositionInLine());
/*     */       } 
/*     */       
/* 132 */       return this.eofToken;
/*     */     } 
/*     */     
/* 135 */     Token t = this.tokens.get(this.i);
/* 136 */     if (this.i == this.tokens.size() - 1 && t.getType() == -1) {
/* 137 */       this.eofToken = t;
/*     */     }
/*     */     
/* 140 */     this.i++;
/* 141 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLine() {
/* 149 */     if (this.i < this.tokens.size()) {
/* 150 */       return ((Token)this.tokens.get(this.i)).getLine();
/*     */     }
/* 152 */     if (this.eofToken != null) {
/* 153 */       return this.eofToken.getLine();
/*     */     }
/* 155 */     if (this.tokens.size() > 0) {
/*     */ 
/*     */       
/* 158 */       Token lastToken = this.tokens.get(this.tokens.size() - 1);
/* 159 */       int line = lastToken.getLine();
/*     */       
/* 161 */       String tokenText = lastToken.getText();
/* 162 */       if (tokenText != null) {
/* 163 */         for (int i = 0; i < tokenText.length(); i++) {
/* 164 */           if (tokenText.charAt(i) == '\n') {
/* 165 */             line++;
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 171 */       return line;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 176 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharStream getInputStream() {
/* 184 */     if (this.i < this.tokens.size()) {
/* 185 */       return ((Token)this.tokens.get(this.i)).getInputStream();
/*     */     }
/* 187 */     if (this.eofToken != null) {
/* 188 */       return this.eofToken.getInputStream();
/*     */     }
/* 190 */     if (this.tokens.size() > 0) {
/* 191 */       return ((Token)this.tokens.get(this.tokens.size() - 1)).getInputStream();
/*     */     }
/*     */ 
/*     */     
/* 195 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceName() {
/* 203 */     if (this.sourceName != null) {
/* 204 */       return this.sourceName;
/*     */     }
/*     */     
/* 207 */     CharStream inputStream = getInputStream();
/* 208 */     if (inputStream != null) {
/* 209 */       return inputStream.getSourceName();
/*     */     }
/*     */     
/* 212 */     return "List";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTokenFactory(TokenFactory<?> factory) {
/* 220 */     this._factory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenFactory<?> getTokenFactory() {
/* 228 */     return this._factory;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/ListTokenSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */