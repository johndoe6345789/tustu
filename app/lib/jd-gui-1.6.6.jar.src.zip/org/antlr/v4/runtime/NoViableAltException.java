/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ import org.antlr.v4.runtime.atn.ATNConfigSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoViableAltException
/*    */   extends RecognitionException
/*    */ {
/*    */   private final ATNConfigSet deadEndConfigs;
/*    */   private final Token startToken;
/*    */   
/*    */   public NoViableAltException(Parser recognizer) {
/* 55 */     this(recognizer, recognizer.getInputStream(), recognizer.getCurrentToken(), recognizer.getCurrentToken(), null, recognizer._ctx);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NoViableAltException(Parser recognizer, TokenStream input, Token startToken, Token offendingToken, ATNConfigSet deadEndConfigs, ParserRuleContext ctx) {
/* 70 */     super(recognizer, input, ctx);
/* 71 */     this.deadEndConfigs = deadEndConfigs;
/* 72 */     this.startToken = startToken;
/* 73 */     setOffendingToken(offendingToken);
/*    */   }
/*    */ 
/*    */   
/*    */   public Token getStartToken() {
/* 78 */     return this.startToken;
/*    */   }
/*    */ 
/*    */   
/*    */   public ATNConfigSet getDeadEndConfigs() {
/* 83 */     return this.deadEndConfigs;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/NoViableAltException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */