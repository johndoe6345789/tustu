/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenStreamRewriter
/*     */ {
/*     */   public static final String DEFAULT_PROGRAM_NAME = "default";
/*     */   public static final int PROGRAM_INIT_SIZE = 100;
/*     */   public static final int MIN_TOKEN_INDEX = 0;
/*     */   protected final TokenStream tokens;
/*     */   protected final Map<String, List<RewriteOperation>> programs;
/*     */   protected final Map<String, Integer> lastRewriteTokenIndexes;
/*     */   
/*     */   public class RewriteOperation
/*     */   {
/*     */     protected int instructionIndex;
/*     */     protected int index;
/*     */     protected Object text;
/*     */     
/*     */     protected RewriteOperation(int index) {
/* 130 */       this.index = index;
/*     */     }
/*     */     
/*     */     protected RewriteOperation(int index, Object text) {
/* 134 */       this.index = index;
/* 135 */       this.text = text;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int execute(StringBuilder buf) {
/* 141 */       return this.index;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 146 */       String opName = getClass().getName();
/* 147 */       int $index = opName.indexOf('$');
/* 148 */       opName = opName.substring($index + 1, opName.length());
/* 149 */       return "<" + opName + "@" + TokenStreamRewriter.this.tokens.get(this.index) + ":\"" + this.text + "\">";
/*     */     }
/*     */   }
/*     */   
/*     */   class InsertBeforeOp
/*     */     extends RewriteOperation {
/*     */     public InsertBeforeOp(int index, Object text) {
/* 156 */       super(index, text);
/*     */     }
/*     */ 
/*     */     
/*     */     public int execute(StringBuilder buf) {
/* 161 */       buf.append(this.text);
/* 162 */       if (TokenStreamRewriter.this.tokens.get(this.index).getType() != -1) {
/* 163 */         buf.append(TokenStreamRewriter.this.tokens.get(this.index).getText());
/*     */       }
/* 165 */       return this.index + 1;
/*     */     }
/*     */   }
/*     */   
/*     */   class ReplaceOp
/*     */     extends RewriteOperation
/*     */   {
/*     */     protected int lastIndex;
/*     */     
/*     */     public ReplaceOp(int from, int to, Object text) {
/* 175 */       super(from, text);
/* 176 */       this.lastIndex = to;
/*     */     }
/*     */     
/*     */     public int execute(StringBuilder buf) {
/* 180 */       if (this.text != null) {
/* 181 */         buf.append(this.text);
/*     */       }
/* 183 */       return this.lastIndex + 1;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 187 */       if (this.text == null) {
/* 188 */         return "<DeleteOp@" + TokenStreamRewriter.this.tokens.get(this.index) + ".." + TokenStreamRewriter.this.tokens.get(this.lastIndex) + ">";
/*     */       }
/*     */       
/* 191 */       return "<ReplaceOp@" + TokenStreamRewriter.this.tokens.get(this.index) + ".." + TokenStreamRewriter.this.tokens.get(this.lastIndex) + ":\"" + this.text + "\">";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenStreamRewriter(TokenStream tokens) {
/* 209 */     this.tokens = tokens;
/* 210 */     this.programs = new HashMap<String, List<RewriteOperation>>();
/* 211 */     this.programs.put("default", new ArrayList<RewriteOperation>(100));
/*     */     
/* 213 */     this.lastRewriteTokenIndexes = new HashMap<String, Integer>();
/*     */   }
/*     */   
/*     */   public final TokenStream getTokenStream() {
/* 217 */     return this.tokens;
/*     */   }
/*     */   
/*     */   public void rollback(int instructionIndex) {
/* 221 */     rollback("default", instructionIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback(String programName, int instructionIndex) {
/* 229 */     List<RewriteOperation> is = this.programs.get(programName);
/* 230 */     if (is != null) {
/* 231 */       this.programs.put(programName, is.subList(0, instructionIndex));
/*     */     }
/*     */   }
/*     */   
/*     */   public void deleteProgram() {
/* 236 */     deleteProgram("default");
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteProgram(String programName) {
/* 241 */     rollback(programName, 0);
/*     */   }
/*     */   
/*     */   public void insertAfter(Token t, Object text) {
/* 245 */     insertAfter("default", t, text);
/*     */   }
/*     */   
/*     */   public void insertAfter(int index, Object text) {
/* 249 */     insertAfter("default", index, text);
/*     */   }
/*     */   
/*     */   public void insertAfter(String programName, Token t, Object text) {
/* 253 */     insertAfter(programName, t.getTokenIndex(), text);
/*     */   }
/*     */ 
/*     */   
/*     */   public void insertAfter(String programName, int index, Object text) {
/* 258 */     insertBefore(programName, index + 1, text);
/*     */   }
/*     */   
/*     */   public void insertBefore(Token t, Object text) {
/* 262 */     insertBefore("default", t, text);
/*     */   }
/*     */   
/*     */   public void insertBefore(int index, Object text) {
/* 266 */     insertBefore("default", index, text);
/*     */   }
/*     */   
/*     */   public void insertBefore(String programName, Token t, Object text) {
/* 270 */     insertBefore(programName, t.getTokenIndex(), text);
/*     */   }
/*     */   
/*     */   public void insertBefore(String programName, int index, Object text) {
/* 274 */     RewriteOperation op = new InsertBeforeOp(index, text);
/* 275 */     List<RewriteOperation> rewrites = getProgram(programName);
/* 276 */     op.instructionIndex = rewrites.size();
/* 277 */     rewrites.add(op);
/*     */   }
/*     */   
/*     */   public void replace(int index, Object text) {
/* 281 */     replace("default", index, index, text);
/*     */   }
/*     */   
/*     */   public void replace(int from, int to, Object text) {
/* 285 */     replace("default", from, to, text);
/*     */   }
/*     */   
/*     */   public void replace(Token indexT, Object text) {
/* 289 */     replace("default", indexT, indexT, text);
/*     */   }
/*     */   
/*     */   public void replace(Token from, Token to, Object text) {
/* 293 */     replace("default", from, to, text);
/*     */   }
/*     */   
/*     */   public void replace(String programName, int from, int to, Object text) {
/* 297 */     if (from > to || from < 0 || to < 0 || to >= this.tokens.size()) {
/* 298 */       throw new IllegalArgumentException("replace: range invalid: " + from + ".." + to + "(size=" + this.tokens.size() + ")");
/*     */     }
/* 300 */     RewriteOperation op = new ReplaceOp(from, to, text);
/* 301 */     List<RewriteOperation> rewrites = getProgram(programName);
/* 302 */     op.instructionIndex = rewrites.size();
/* 303 */     rewrites.add(op);
/*     */   }
/*     */   
/*     */   public void replace(String programName, Token from, Token to, Object text) {
/* 307 */     replace(programName, from.getTokenIndex(), to.getTokenIndex(), text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(int index) {
/* 314 */     delete("default", index, index);
/*     */   }
/*     */   
/*     */   public void delete(int from, int to) {
/* 318 */     delete("default", from, to);
/*     */   }
/*     */   
/*     */   public void delete(Token indexT) {
/* 322 */     delete("default", indexT, indexT);
/*     */   }
/*     */   
/*     */   public void delete(Token from, Token to) {
/* 326 */     delete("default", from, to);
/*     */   }
/*     */   
/*     */   public void delete(String programName, int from, int to) {
/* 330 */     replace(programName, from, to, (Object)null);
/*     */   }
/*     */   
/*     */   public void delete(String programName, Token from, Token to) {
/* 334 */     replace(programName, from, to, (Object)null);
/*     */   }
/*     */   
/*     */   public int getLastRewriteTokenIndex() {
/* 338 */     return getLastRewriteTokenIndex("default");
/*     */   }
/*     */   
/*     */   protected int getLastRewriteTokenIndex(String programName) {
/* 342 */     Integer I = this.lastRewriteTokenIndexes.get(programName);
/* 343 */     if (I == null) {
/* 344 */       return -1;
/*     */     }
/* 346 */     return I.intValue();
/*     */   }
/*     */   
/*     */   protected void setLastRewriteTokenIndex(String programName, int i) {
/* 350 */     this.lastRewriteTokenIndexes.put(programName, Integer.valueOf(i));
/*     */   }
/*     */   
/*     */   protected List<RewriteOperation> getProgram(String name) {
/* 354 */     List<RewriteOperation> is = this.programs.get(name);
/* 355 */     if (is == null) {
/* 356 */       is = initializeProgram(name);
/*     */     }
/* 358 */     return is;
/*     */   }
/*     */   
/*     */   private List<RewriteOperation> initializeProgram(String name) {
/* 362 */     List<RewriteOperation> is = new ArrayList<RewriteOperation>(100);
/* 363 */     this.programs.put(name, is);
/* 364 */     return is;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 371 */     return getText("default", Interval.of(0, this.tokens.size() - 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(Interval interval) {
/* 384 */     return getText("default", interval);
/*     */   }
/*     */   
/*     */   public String getText(String programName, Interval interval) {
/* 388 */     List<RewriteOperation> rewrites = this.programs.get(programName);
/* 389 */     int start = interval.a;
/* 390 */     int stop = interval.b;
/*     */ 
/*     */     
/* 393 */     if (stop > this.tokens.size() - 1) stop = this.tokens.size() - 1; 
/* 394 */     if (start < 0) start = 0;
/*     */     
/* 396 */     if (rewrites == null || rewrites.isEmpty()) {
/* 397 */       return this.tokens.getText(interval);
/*     */     }
/* 399 */     StringBuilder buf = new StringBuilder();
/*     */ 
/*     */     
/* 402 */     Map<Integer, RewriteOperation> indexToOp = reduceToSingleOperationPerIndex(rewrites);
/*     */ 
/*     */     
/* 405 */     int i = start;
/* 406 */     while (i <= stop && i < this.tokens.size()) {
/* 407 */       RewriteOperation op = indexToOp.get(Integer.valueOf(i));
/* 408 */       indexToOp.remove(Integer.valueOf(i));
/* 409 */       Token t = this.tokens.get(i);
/* 410 */       if (op == null) {
/*     */         
/* 412 */         if (t.getType() != -1) buf.append(t.getText()); 
/* 413 */         i++;
/*     */         continue;
/*     */       } 
/* 416 */       i = op.execute(buf);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 423 */     if (stop == this.tokens.size() - 1)
/*     */     {
/*     */       
/* 426 */       for (RewriteOperation op : indexToOp.values()) {
/* 427 */         if (op.index >= this.tokens.size() - 1) buf.append(op.text); 
/*     */       } 
/*     */     }
/* 430 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<Integer, RewriteOperation> reduceToSingleOperationPerIndex(List<RewriteOperation> rewrites) {
/*     */     int i;
/* 486 */     for (i = 0; i < rewrites.size(); i++) {
/* 487 */       RewriteOperation op = rewrites.get(i);
/* 488 */       if (op != null && 
/* 489 */         op instanceof ReplaceOp) {
/* 490 */         ReplaceOp rop = (ReplaceOp)rewrites.get(i);
/*     */         
/* 492 */         List<? extends InsertBeforeOp> inserts = getKindOfOps(rewrites, InsertBeforeOp.class, i);
/* 493 */         for (InsertBeforeOp iop : inserts) {
/* 494 */           if (iop.index == rop.index) {
/*     */ 
/*     */             
/* 497 */             rewrites.set(iop.instructionIndex, null);
/* 498 */             rop.text = iop.text.toString() + ((rop.text != null) ? rop.text.toString() : ""); continue;
/*     */           } 
/* 500 */           if (iop.index > rop.index && iop.index <= rop.lastIndex)
/*     */           {
/* 502 */             rewrites.set(iop.instructionIndex, null);
/*     */           }
/*     */         } 
/*     */         
/* 506 */         List<? extends ReplaceOp> prevReplaces = getKindOfOps(rewrites, ReplaceOp.class, i);
/* 507 */         for (ReplaceOp prevRop : prevReplaces) {
/* 508 */           if (prevRop.index >= rop.index && prevRop.lastIndex <= rop.lastIndex) {
/*     */             
/* 510 */             rewrites.set(prevRop.instructionIndex, null);
/*     */             
/*     */             continue;
/*     */           } 
/* 514 */           boolean disjoint = (prevRop.lastIndex < rop.index || prevRop.index > rop.lastIndex);
/*     */           
/* 516 */           boolean same = (prevRop.index == rop.index && prevRop.lastIndex == rop.lastIndex);
/*     */ 
/*     */ 
/*     */           
/* 520 */           if (prevRop.text == null && rop.text == null && !disjoint) {
/*     */             
/* 522 */             rewrites.set(prevRop.instructionIndex, null);
/* 523 */             rop.index = Math.min(prevRop.index, rop.index);
/* 524 */             rop.lastIndex = Math.max(prevRop.lastIndex, rop.lastIndex);
/* 525 */             System.out.println("new rop " + rop); continue;
/*     */           } 
/* 527 */           if (!disjoint && !same) {
/* 528 */             throw new IllegalArgumentException("replace op boundaries of " + rop + " overlap with previous " + prevRop);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 534 */     for (i = 0; i < rewrites.size(); i++) {
/* 535 */       RewriteOperation op = rewrites.get(i);
/* 536 */       if (op != null && 
/* 537 */         op instanceof InsertBeforeOp) {
/* 538 */         InsertBeforeOp iop = (InsertBeforeOp)rewrites.get(i);
/*     */         
/* 540 */         List<? extends InsertBeforeOp> prevInserts = getKindOfOps(rewrites, InsertBeforeOp.class, i);
/* 541 */         for (InsertBeforeOp prevIop : prevInserts) {
/* 542 */           if (prevIop.index == iop.index) {
/*     */ 
/*     */             
/* 545 */             iop.text = catOpText(iop.text, prevIop.text);
/*     */             
/* 547 */             rewrites.set(prevIop.instructionIndex, null);
/*     */           } 
/*     */         } 
/*     */         
/* 551 */         List<? extends ReplaceOp> prevReplaces = getKindOfOps(rewrites, ReplaceOp.class, i);
/* 552 */         for (ReplaceOp rop : prevReplaces) {
/* 553 */           if (iop.index == rop.index) {
/* 554 */             rop.text = catOpText(iop.text, rop.text);
/* 555 */             rewrites.set(i, null);
/*     */             continue;
/*     */           } 
/* 558 */           if (iop.index >= rop.index && iop.index <= rop.lastIndex) {
/* 559 */             throw new IllegalArgumentException("insert op " + iop + " within boundaries of previous " + rop);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 564 */     Map<Integer, RewriteOperation> m = new HashMap<Integer, RewriteOperation>();
/* 565 */     for (int j = 0; j < rewrites.size(); j++) {
/* 566 */       RewriteOperation op = rewrites.get(j);
/* 567 */       if (op != null) {
/* 568 */         if (m.get(Integer.valueOf(op.index)) != null) {
/* 569 */           throw new Error("should only be one op per index");
/*     */         }
/* 571 */         m.put(Integer.valueOf(op.index), op);
/*     */       } 
/*     */     } 
/* 574 */     return m;
/*     */   }
/*     */   
/*     */   protected String catOpText(Object a, Object b) {
/* 578 */     String x = "";
/* 579 */     String y = "";
/* 580 */     if (a != null) x = a.toString(); 
/* 581 */     if (b != null) y = b.toString(); 
/* 582 */     return x + y;
/*     */   }
/*     */ 
/*     */   
/*     */   protected <T extends RewriteOperation> List<? extends T> getKindOfOps(List<? extends RewriteOperation> rewrites, Class<T> kind, int before) {
/* 587 */     List<T> ops = new ArrayList<T>();
/* 588 */     for (int i = 0; i < before && i < rewrites.size(); i++) {
/* 589 */       RewriteOperation op = rewrites.get(i);
/* 590 */       if (op != null && 
/* 591 */         kind.isInstance(op)) {
/* 592 */         ops.add(kind.cast(op));
/*     */       }
/*     */     } 
/* 595 */     return ops;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/TokenStreamRewriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */