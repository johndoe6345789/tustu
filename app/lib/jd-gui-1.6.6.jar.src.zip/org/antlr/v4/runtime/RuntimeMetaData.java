/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuntimeMetaData
/*     */ {
/*     */   public static final String VERSION = "4.5";
/*     */   
/*     */   public static String getRuntimeVersion() {
/* 109 */     return "4.5";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkVersion(String generatingToolVersion, String compileTimeVersion) {
/* 171 */     String runtimeVersion = "4.5";
/* 172 */     boolean runtimeConflictsWithGeneratingTool = false;
/* 173 */     boolean runtimeConflictsWithCompileTimeTool = false;
/*     */     
/* 175 */     if (generatingToolVersion != null) {
/* 176 */       runtimeConflictsWithGeneratingTool = (!runtimeVersion.equals(generatingToolVersion) && !getMajorMinorVersion(runtimeVersion).equals(getMajorMinorVersion(generatingToolVersion)));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 181 */     runtimeConflictsWithCompileTimeTool = (!runtimeVersion.equals(compileTimeVersion) && !getMajorMinorVersion(runtimeVersion).equals(getMajorMinorVersion(compileTimeVersion)));
/*     */ 
/*     */ 
/*     */     
/* 185 */     if (runtimeConflictsWithGeneratingTool) {
/* 186 */       System.err.printf("ANTLR Tool version %s used for code generation does not match the current runtime version %s", new Object[] { generatingToolVersion, runtimeVersion });
/*     */     }
/*     */     
/* 189 */     if (runtimeConflictsWithCompileTimeTool) {
/* 190 */       System.err.printf("ANTLR Runtime version %s used for parser compilation does not match the current runtime version %s", new Object[] { compileTimeVersion, runtimeVersion });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMajorMinorVersion(String version) {
/* 205 */     int firstDot = version.indexOf('.');
/* 206 */     int secondDot = (firstDot >= 0) ? version.indexOf('.', firstDot + 1) : -1;
/* 207 */     int firstDash = version.indexOf('-');
/* 208 */     int referenceLength = version.length();
/* 209 */     if (secondDot >= 0) {
/* 210 */       referenceLength = Math.min(referenceLength, secondDot);
/*     */     }
/*     */     
/* 213 */     if (firstDash >= 0) {
/* 214 */       referenceLength = Math.min(referenceLength, firstDash);
/*     */     }
/*     */     
/* 217 */     return version.substring(0, referenceLength);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/RuntimeMetaData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */