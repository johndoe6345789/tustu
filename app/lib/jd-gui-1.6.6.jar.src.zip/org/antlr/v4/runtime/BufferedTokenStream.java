/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferedTokenStream
/*     */   implements TokenStream
/*     */ {
/*     */   protected TokenSource tokenSource;
/*  64 */   protected List<Token> tokens = new ArrayList<Token>(100);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   protected int p = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean fetchedEOF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedTokenStream(TokenSource tokenSource) {
/*  95 */     if (tokenSource == null) {
/*  96 */       throw new NullPointerException("tokenSource cannot be null");
/*     */     }
/*  98 */     this.tokenSource = tokenSource;
/*     */   }
/*     */   
/*     */   public TokenSource getTokenSource() {
/* 102 */     return this.tokenSource;
/*     */   }
/*     */   public int index() {
/* 105 */     return this.p;
/*     */   }
/*     */   
/*     */   public int mark() {
/* 109 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release(int marker) {}
/*     */ 
/*     */   
/*     */   public void reset() {
/* 118 */     seek(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void seek(int index) {
/* 123 */     lazyInit();
/* 124 */     this.p = adjustSeekIndex(index);
/*     */   }
/*     */   
/*     */   public int size() {
/* 128 */     return this.tokens.size();
/*     */   }
/*     */   
/*     */   public void consume() {
/*     */     boolean skipEofCheck;
/* 133 */     if (this.p >= 0) {
/* 134 */       if (this.fetchedEOF)
/*     */       {
/*     */         
/* 137 */         skipEofCheck = (this.p < this.tokens.size() - 1);
/*     */       }
/*     */       else
/*     */       {
/* 141 */         skipEofCheck = (this.p < this.tokens.size());
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 146 */       skipEofCheck = false;
/*     */     } 
/*     */     
/* 149 */     if (!skipEofCheck && LA(1) == -1) {
/* 150 */       throw new IllegalStateException("cannot consume EOF");
/*     */     }
/*     */     
/* 153 */     if (sync(this.p + 1)) {
/* 154 */       this.p = adjustSeekIndex(this.p + 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean sync(int i) {
/* 165 */     assert i >= 0;
/* 166 */     int n = i - this.tokens.size() + 1;
/*     */     
/* 168 */     if (n > 0) {
/* 169 */       int fetched = fetch(n);
/* 170 */       return (fetched >= n);
/*     */     } 
/*     */     
/* 173 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int fetch(int n) {
/* 181 */     if (this.fetchedEOF) {
/* 182 */       return 0;
/*     */     }
/*     */     
/* 185 */     for (int i = 0; i < n; i++) {
/* 186 */       Token t = this.tokenSource.nextToken();
/* 187 */       if (t instanceof WritableToken) {
/* 188 */         ((WritableToken)t).setTokenIndex(this.tokens.size());
/*     */       }
/* 190 */       this.tokens.add(t);
/* 191 */       if (t.getType() == -1) {
/* 192 */         this.fetchedEOF = true;
/* 193 */         return i + 1;
/*     */       } 
/*     */     } 
/*     */     
/* 197 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   public Token get(int i) {
/* 202 */     if (i < 0 || i >= this.tokens.size()) {
/* 203 */       throw new IndexOutOfBoundsException("token index " + i + " out of range 0.." + (this.tokens.size() - 1));
/*     */     }
/* 205 */     return this.tokens.get(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Token> get(int start, int stop) {
/* 210 */     if (start < 0 || stop < 0) return null; 
/* 211 */     lazyInit();
/* 212 */     List<Token> subset = new ArrayList<Token>();
/* 213 */     if (stop >= this.tokens.size()) stop = this.tokens.size() - 1; 
/* 214 */     for (int i = start; i <= stop; i++) {
/* 215 */       Token t = this.tokens.get(i);
/* 216 */       if (t.getType() == -1)
/* 217 */         break;  subset.add(t);
/*     */     } 
/* 219 */     return subset;
/*     */   }
/*     */   
/*     */   public int LA(int i) {
/* 223 */     return LT(i).getType();
/*     */   }
/*     */   protected Token LB(int k) {
/* 226 */     if (this.p - k < 0) return null; 
/* 227 */     return this.tokens.get(this.p - k);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Token LT(int k) {
/* 233 */     lazyInit();
/* 234 */     if (k == 0) return null; 
/* 235 */     if (k < 0) return LB(-k);
/*     */     
/* 237 */     int i = this.p + k - 1;
/* 238 */     sync(i);
/* 239 */     if (i >= this.tokens.size())
/*     */     {
/* 241 */       return this.tokens.get(this.tokens.size() - 1);
/*     */     }
/*     */     
/* 244 */     return this.tokens.get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int adjustSeekIndex(int i) {
/* 261 */     return i;
/*     */   }
/*     */   
/*     */   protected final void lazyInit() {
/* 265 */     if (this.p == -1) {
/* 266 */       setup();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void setup() {
/* 271 */     sync(0);
/* 272 */     this.p = adjustSeekIndex(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTokenSource(TokenSource tokenSource) {
/* 277 */     this.tokenSource = tokenSource;
/* 278 */     this.tokens.clear();
/* 279 */     this.p = -1;
/*     */   }
/*     */   public List<Token> getTokens() {
/* 282 */     return this.tokens;
/*     */   }
/*     */   public List<Token> getTokens(int start, int stop) {
/* 285 */     return getTokens(start, stop, (Set<Integer>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Token> getTokens(int start, int stop, Set<Integer> types) {
/* 293 */     lazyInit();
/* 294 */     if (start < 0 || stop >= this.tokens.size() || stop < 0 || start >= this.tokens.size())
/*     */     {
/*     */       
/* 297 */       throw new IndexOutOfBoundsException("start " + start + " or stop " + stop + " not in 0.." + (this.tokens.size() - 1));
/*     */     }
/*     */     
/* 300 */     if (start > stop) return null;
/*     */ 
/*     */     
/* 303 */     List<Token> filteredTokens = new ArrayList<Token>();
/* 304 */     for (int i = start; i <= stop; i++) {
/* 305 */       Token t = this.tokens.get(i);
/* 306 */       if (types == null || types.contains(Integer.valueOf(t.getType()))) {
/* 307 */         filteredTokens.add(t);
/*     */       }
/*     */     } 
/* 310 */     if (filteredTokens.isEmpty()) {
/* 311 */       filteredTokens = null;
/*     */     }
/* 313 */     return filteredTokens;
/*     */   }
/*     */   
/*     */   public List<Token> getTokens(int start, int stop, int ttype) {
/* 317 */     HashSet<Integer> s = new HashSet<Integer>(ttype);
/* 318 */     s.add(Integer.valueOf(ttype));
/* 319 */     return getTokens(start, stop, s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int nextTokenOnChannel(int i, int channel) {
/* 329 */     sync(i);
/* 330 */     if (i >= size()) {
/* 331 */       return size() - 1;
/*     */     }
/*     */     
/* 334 */     Token token = this.tokens.get(i);
/* 335 */     while (token.getChannel() != channel) {
/* 336 */       if (token.getType() == -1) {
/* 337 */         return i;
/*     */       }
/*     */       
/* 340 */       i++;
/* 341 */       sync(i);
/* 342 */       token = this.tokens.get(i);
/*     */     } 
/*     */     
/* 345 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int previousTokenOnChannel(int i, int channel) {
/* 359 */     sync(i);
/* 360 */     if (i >= size())
/*     */     {
/* 362 */       return size() - 1;
/*     */     }
/*     */     
/* 365 */     while (i >= 0) {
/* 366 */       Token token = this.tokens.get(i);
/* 367 */       if (token.getType() == -1 || token.getChannel() == channel) {
/* 368 */         return i;
/*     */       }
/*     */       
/* 371 */       i--;
/*     */     } 
/*     */     
/* 374 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Token> getHiddenTokensToRight(int tokenIndex, int channel) {
/*     */     int to;
/* 382 */     lazyInit();
/* 383 */     if (tokenIndex < 0 || tokenIndex >= this.tokens.size()) {
/* 384 */       throw new IndexOutOfBoundsException(tokenIndex + " not in 0.." + (this.tokens.size() - 1));
/*     */     }
/*     */     
/* 387 */     int nextOnChannel = nextTokenOnChannel(tokenIndex + 1, 0);
/*     */ 
/*     */     
/* 390 */     int from = tokenIndex + 1;
/*     */     
/* 392 */     if (nextOnChannel == -1) { to = size() - 1; }
/* 393 */     else { to = nextOnChannel; }
/*     */     
/* 395 */     return filterForChannel(from, to, channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Token> getHiddenTokensToRight(int tokenIndex) {
/* 403 */     return getHiddenTokensToRight(tokenIndex, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Token> getHiddenTokensToLeft(int tokenIndex, int channel) {
/* 411 */     lazyInit();
/* 412 */     if (tokenIndex < 0 || tokenIndex >= this.tokens.size()) {
/* 413 */       throw new IndexOutOfBoundsException(tokenIndex + " not in 0.." + (this.tokens.size() - 1));
/*     */     }
/*     */     
/* 416 */     if (tokenIndex == 0)
/*     */     {
/* 418 */       return null;
/*     */     }
/*     */     
/* 421 */     int prevOnChannel = previousTokenOnChannel(tokenIndex - 1, 0);
/*     */     
/* 423 */     if (prevOnChannel == tokenIndex - 1) return null;
/*     */     
/* 425 */     int from = prevOnChannel + 1;
/* 426 */     int to = tokenIndex - 1;
/*     */     
/* 428 */     return filterForChannel(from, to, channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Token> getHiddenTokensToLeft(int tokenIndex) {
/* 435 */     return getHiddenTokensToLeft(tokenIndex, -1);
/*     */   }
/*     */   
/*     */   protected List<Token> filterForChannel(int from, int to, int channel) {
/* 439 */     List<Token> hidden = new ArrayList<Token>();
/* 440 */     for (int i = from; i <= to; i++) {
/* 441 */       Token t = this.tokens.get(i);
/* 442 */       if (channel == -1)
/* 443 */       { if (t.getChannel() != 0) hidden.add(t);
/*     */          }
/*     */       
/* 446 */       else if (t.getChannel() == channel) { hidden.add(t); }
/*     */     
/*     */     } 
/* 449 */     if (hidden.size() == 0) return null; 
/* 450 */     return hidden;
/*     */   }
/*     */   
/*     */   public String getSourceName() {
/* 454 */     return this.tokenSource.getSourceName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 460 */     lazyInit();
/* 461 */     fill();
/* 462 */     return getText(Interval.of(0, size() - 1));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(Interval interval) {
/* 468 */     int start = interval.a;
/* 469 */     int stop = interval.b;
/* 470 */     if (start < 0 || stop < 0) return ""; 
/* 471 */     lazyInit();
/* 472 */     if (stop >= this.tokens.size()) stop = this.tokens.size() - 1;
/*     */     
/* 474 */     StringBuilder buf = new StringBuilder();
/* 475 */     for (int i = start; i <= stop; i++) {
/* 476 */       Token t = this.tokens.get(i);
/* 477 */       if (t.getType() == -1)
/* 478 */         break;  buf.append(t.getText());
/*     */     } 
/* 480 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(RuleContext ctx) {
/* 486 */     return getText(ctx.getSourceInterval());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(Token start, Token stop) {
/* 492 */     if (start != null && stop != null) {
/* 493 */       return getText(Interval.of(start.getTokenIndex(), stop.getTokenIndex()));
/*     */     }
/*     */     
/* 496 */     return "";
/*     */   }
/*     */   
/*     */   public void fill() {
/*     */     int fetched;
/* 501 */     lazyInit();
/* 502 */     int blockSize = 1000;
/*     */     do {
/* 504 */       fetched = fetch(1000);
/* 505 */     } while (fetched >= 1000);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/BufferedTokenStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */