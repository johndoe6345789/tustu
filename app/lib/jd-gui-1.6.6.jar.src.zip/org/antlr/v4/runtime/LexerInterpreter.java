/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.antlr.v4.runtime.atn.ATN;
/*     */ import org.antlr.v4.runtime.atn.ATNType;
/*     */ import org.antlr.v4.runtime.atn.LexerATNSimulator;
/*     */ import org.antlr.v4.runtime.atn.PredictionContextCache;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LexerInterpreter
/*     */   extends Lexer
/*     */ {
/*     */   protected final String grammarFileName;
/*     */   protected final ATN atn;
/*     */   @Deprecated
/*     */   protected final String[] tokenNames;
/*     */   protected final String[] ruleNames;
/*     */   protected final String[] modeNames;
/*     */   private final Vocabulary vocabulary;
/*     */   protected final DFA[] _decisionToDFA;
/*  55 */   protected final PredictionContextCache _sharedContextCache = new PredictionContextCache();
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public LexerInterpreter(String grammarFileName, Collection<String> tokenNames, Collection<String> ruleNames, Collection<String> modeNames, ATN atn, CharStream input) {
/*  60 */     this(grammarFileName, VocabularyImpl.fromTokenNames(tokenNames.<String>toArray(new String[tokenNames.size()])), ruleNames, modeNames, atn, input);
/*     */   }
/*     */   
/*     */   public LexerInterpreter(String grammarFileName, Vocabulary vocabulary, Collection<String> ruleNames, Collection<String> modeNames, ATN atn, CharStream input) {
/*  64 */     super(input);
/*     */     
/*  66 */     if (atn.grammarType != ATNType.LEXER) {
/*  67 */       throw new IllegalArgumentException("The ATN must be a lexer ATN.");
/*     */     }
/*     */     
/*  70 */     this.grammarFileName = grammarFileName;
/*  71 */     this.atn = atn;
/*  72 */     this.tokenNames = new String[atn.maxTokenType]; int i;
/*  73 */     for (i = 0; i < this.tokenNames.length; i++) {
/*  74 */       this.tokenNames[i] = vocabulary.getDisplayName(i);
/*     */     }
/*     */     
/*  77 */     this.ruleNames = ruleNames.<String>toArray(new String[ruleNames.size()]);
/*  78 */     this.modeNames = modeNames.<String>toArray(new String[modeNames.size()]);
/*  79 */     this.vocabulary = vocabulary;
/*     */     
/*  81 */     this._decisionToDFA = new DFA[atn.getNumberOfDecisions()];
/*  82 */     for (i = 0; i < this._decisionToDFA.length; i++) {
/*  83 */       this._decisionToDFA[i] = new DFA(atn.getDecisionState(i), i);
/*     */     }
/*  85 */     this._interp = new LexerATNSimulator(this, atn, this._decisionToDFA, this._sharedContextCache);
/*     */   }
/*     */ 
/*     */   
/*     */   public ATN getATN() {
/*  90 */     return this.atn;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getGrammarFileName() {
/*  95 */     return this.grammarFileName;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String[] getTokenNames() {
/* 101 */     return this.tokenNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getRuleNames() {
/* 106 */     return this.ruleNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getModeNames() {
/* 111 */     return this.modeNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vocabulary getVocabulary() {
/* 116 */     if (this.vocabulary != null) {
/* 117 */       return this.vocabulary;
/*     */     }
/*     */     
/* 120 */     return super.getVocabulary();
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/LexerInterpreter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */