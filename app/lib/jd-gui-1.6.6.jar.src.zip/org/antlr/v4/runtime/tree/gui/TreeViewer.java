/*     */ package org.antlr.v4.runtime.tree.gui;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Desktop;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.geom.CubicCurve2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.print.PrintException;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.event.TreeSelectionEvent;
/*     */ import javax.swing.event.TreeSelectionListener;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ import javax.swing.tree.DefaultMutableTreeNode;
/*     */ import javax.swing.tree.TreePath;
/*     */ import org.abego.treelayout.NodeExtentProvider;
/*     */ import org.abego.treelayout.TreeForTreeLayout;
/*     */ import org.abego.treelayout.TreeLayout;
/*     */ import org.abego.treelayout.util.DefaultConfiguration;
/*     */ import org.antlr.v4.runtime.misc.GraphicsSupport;
/*     */ import org.antlr.v4.runtime.misc.JFileChooserConfirmOverwrite;
/*     */ import org.antlr.v4.runtime.misc.Utils;
/*     */ import org.antlr.v4.runtime.tree.Tree;
/*     */ import org.antlr.v4.runtime.tree.Trees;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeViewer
/*     */   extends JComponent
/*     */ {
/*  73 */   public static final Color LIGHT_RED = new Color(244, 213, 211); protected TreeTextProvider treeTextProvider; protected TreeLayout<Tree> treeLayout;
/*     */   protected List<Tree> highlightedNodes;
/*     */   
/*     */   public static class DefaultTreeTextProvider implements TreeTextProvider { private final List<String> ruleNames;
/*     */     
/*     */     public DefaultTreeTextProvider(List<String> ruleNames) {
/*  79 */       this.ruleNames = ruleNames;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getText(Tree node) {
/*  84 */       return String.valueOf(Trees.getNodeText(node, this.ruleNames));
/*     */     } }
/*     */   
/*     */   public static class VariableExtentProvide implements NodeExtentProvider<Tree> {
/*     */     TreeViewer viewer;
/*     */     
/*     */     public VariableExtentProvide(TreeViewer viewer) {
/*  91 */       this.viewer = viewer;
/*     */     }
/*     */     
/*     */     public double getWidth(Tree tree) {
/*  95 */       FontMetrics fontMetrics = this.viewer.getFontMetrics(this.viewer.font);
/*  96 */       String s = this.viewer.getText(tree);
/*  97 */       int w = fontMetrics.stringWidth(s) + this.viewer.nodeWidthPadding * 2;
/*  98 */       return w;
/*     */     }
/*     */ 
/*     */     
/*     */     public double getHeight(Tree tree) {
/* 103 */       FontMetrics fontMetrics = this.viewer.getFontMetrics(this.viewer.font);
/* 104 */       int h = fontMetrics.getHeight() + this.viewer.nodeHeightPadding * 2;
/* 105 */       String s = this.viewer.getText(tree);
/* 106 */       String[] lines = s.split("\n");
/* 107 */       return (h * lines.length);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   protected String fontName = "Helvetica";
/* 116 */   protected int fontStyle = 0;
/* 117 */   protected int fontSize = 11;
/* 118 */   protected Font font = new Font(this.fontName, this.fontStyle, this.fontSize);
/*     */   
/* 120 */   protected double gapBetweenLevels = 17.0D;
/* 121 */   protected double gapBetweenNodes = 7.0D;
/* 122 */   protected int nodeWidthPadding = 2;
/* 123 */   protected int nodeHeightPadding = 0;
/* 124 */   protected int arcSize = 0;
/*     */   
/* 126 */   protected double scale = 1.0D;
/*     */   
/* 128 */   protected Color boxColor = null;
/*     */   
/* 130 */   protected Color highlightedBoxColor = Color.lightGray;
/* 131 */   protected Color borderColor = null;
/* 132 */   protected Color textColor = Color.black;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean useCurvedEdges;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updatePreferredSize() {
/* 143 */     setPreferredSize(getScaledTreeSize());
/* 144 */     invalidate();
/* 145 */     if (getParent() != null) {
/* 146 */       getParent().validate();
/*     */     }
/* 148 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public TreeViewer(List<String> ruleNames, Tree tree) {
/* 153 */     this.useCurvedEdges = false; setRuleNames(ruleNames);
/*     */     if (tree != null)
/*     */       setTree(tree); 
/* 156 */     setFont(this.font); } public boolean getUseCurvedEdges() { return this.useCurvedEdges; }
/*     */ 
/*     */   
/*     */   public void setUseCurvedEdges(boolean useCurvedEdges) {
/* 160 */     this.useCurvedEdges = useCurvedEdges;
/*     */   }
/*     */   
/*     */   protected void paintEdges(Graphics g, Tree parent) {
/* 164 */     if (!getTree().isLeaf(parent)) {
/* 165 */       BasicStroke stroke = new BasicStroke(1.0F, 1, 1);
/*     */       
/* 167 */       ((Graphics2D)g).setStroke(stroke);
/*     */       
/* 169 */       Rectangle2D.Double parentBounds = getBoundsOfNode(parent);
/* 170 */       double x1 = parentBounds.getCenterX();
/* 171 */       double y1 = parentBounds.getMaxY();
/* 172 */       for (Tree child : getTree().getChildren(parent)) {
/* 173 */         Rectangle2D.Double childBounds = getBoundsOfNode(child);
/* 174 */         double x2 = childBounds.getCenterX();
/* 175 */         double y2 = childBounds.getMinY();
/* 176 */         if (getUseCurvedEdges()) {
/* 177 */           CubicCurve2D c = new CubicCurve2D.Double();
/* 178 */           double ctrlx1 = x1;
/* 179 */           double ctrly1 = (y1 + y2) / 2.0D;
/* 180 */           double ctrlx2 = x2;
/* 181 */           double ctrly2 = y1;
/* 182 */           c.setCurve(x1, y1, ctrlx1, ctrly1, ctrlx2, ctrly2, x2, y2);
/* 183 */           ((Graphics2D)g).draw(c);
/*     */         } else {
/* 185 */           g.drawLine((int)x1, (int)y1, (int)x2, (int)y2);
/*     */         } 
/*     */         
/* 188 */         paintEdges(g, child);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void paintBox(Graphics g, Tree tree) {
/* 194 */     Rectangle2D.Double box = getBoundsOfNode(tree);
/*     */     
/* 196 */     if (isHighlighted(tree) || this.boxColor != null || tree instanceof org.antlr.v4.runtime.tree.ErrorNode) {
/*     */ 
/*     */       
/* 199 */       if (isHighlighted(tree)) { g.setColor(this.highlightedBoxColor); }
/* 200 */       else if (tree instanceof org.antlr.v4.runtime.tree.ErrorNode) { g.setColor(LIGHT_RED); }
/* 201 */       else { g.setColor(this.boxColor); }
/* 202 */        g.fillRoundRect((int)box.x, (int)box.y, (int)box.width - 1, (int)box.height - 1, this.arcSize, this.arcSize);
/*     */     } 
/*     */     
/* 205 */     if (this.borderColor != null) {
/* 206 */       g.setColor(this.borderColor);
/* 207 */       g.drawRoundRect((int)box.x, (int)box.y, (int)box.width - 1, (int)box.height - 1, this.arcSize, this.arcSize);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 212 */     g.setColor(this.textColor);
/* 213 */     String s = getText(tree);
/* 214 */     String[] lines = s.split("\n");
/* 215 */     FontMetrics m = getFontMetrics(this.font);
/* 216 */     int x = (int)box.x + this.arcSize / 2 + this.nodeWidthPadding;
/* 217 */     int y = (int)box.y + m.getAscent() + m.getLeading() + 1 + this.nodeHeightPadding;
/* 218 */     for (int i = 0; i < lines.length; i++) {
/* 219 */       text(g, lines[i], x, y);
/* 220 */       y += m.getHeight();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void text(Graphics g, String s, int x, int y) {
/* 226 */     s = Utils.escapeWhitespace(s, true);
/* 227 */     g.drawString(s, x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/* 232 */     super.paint(g);
/*     */     
/* 234 */     if (this.treeLayout == null) {
/*     */       return;
/*     */     }
/*     */     
/* 238 */     Graphics2D g2 = (Graphics2D)g;
/*     */     
/* 240 */     g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/*     */ 
/*     */     
/* 244 */     g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     paintEdges(g, getTree().getRoot());
/*     */ 
/*     */     
/* 257 */     for (Tree Tree : this.treeLayout.getNodeBounds().keySet()) {
/* 258 */       paintBox(g, Tree);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Graphics getComponentGraphics(Graphics g) {
/* 264 */     Graphics2D g2d = (Graphics2D)g;
/* 265 */     g2d.scale(this.scale, this.scale);
/* 266 */     return super.getComponentGraphics(g2d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static JDialog showInDialog(final TreeViewer viewer) {
/* 273 */     final JDialog dialog = new JDialog();
/* 274 */     dialog.setTitle("Parse Tree Inspector");
/*     */ 
/*     */     
/* 277 */     Container mainPane = new JPanel(new BorderLayout(5, 5));
/* 278 */     Container contentPane = new JPanel(new BorderLayout(0, 0));
/* 279 */     contentPane.setBackground(Color.white);
/*     */ 
/*     */     
/* 282 */     JScrollPane scrollPane = new JScrollPane(viewer);
/*     */     
/* 284 */     contentPane.add(scrollPane, "Center");
/*     */     
/* 286 */     JPanel wrapper = new JPanel(new FlowLayout());
/*     */ 
/*     */     
/* 289 */     JPanel bottomPanel = new JPanel(new BorderLayout(0, 0));
/* 290 */     contentPane.add(bottomPanel, "South");
/*     */     
/* 292 */     JButton ok = new JButton("OK");
/* 293 */     ok.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 297 */             dialog.setVisible(false);
/* 298 */             dialog.dispose();
/*     */           }
/*     */         });
/*     */     
/* 302 */     wrapper.add(ok);
/*     */ 
/*     */     
/* 305 */     JButton png = new JButton("png");
/* 306 */     png.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 310 */             TreeViewer.generatePNGFile(viewer, dialog);
/*     */           }
/*     */         });
/*     */     
/* 314 */     wrapper.add(png);
/*     */     
/* 316 */     bottomPanel.add(wrapper, "South");
/*     */ 
/*     */     
/* 319 */     int sliderValue = (int)((viewer.getScale() - 1.0D) * 1000.0D);
/* 320 */     final JSlider scaleSlider = new JSlider(0, -999, 1000, sliderValue);
/*     */     
/* 322 */     scaleSlider.addChangeListener(new ChangeListener()
/*     */         {
/*     */           public void stateChanged(ChangeEvent e)
/*     */           {
/* 326 */             int v = scaleSlider.getValue();
/* 327 */             viewer.setScale(v / 1000.0D + 1.0D);
/*     */           }
/*     */         });
/*     */     
/* 331 */     bottomPanel.add(scaleSlider, "Center");
/*     */ 
/*     */     
/* 334 */     JPanel treePanel = new JPanel(new BorderLayout(5, 5));
/*     */ 
/*     */     
/* 337 */     Icon empty = new EmptyIcon();
/*     */     
/* 339 */     UIManager.put("Tree.closedIcon", empty);
/* 340 */     UIManager.put("Tree.openIcon", empty);
/* 341 */     UIManager.put("Tree.leafIcon", empty);
/*     */     
/* 343 */     Tree parseTreeRoot = viewer.getTree().getRoot();
/* 344 */     TreeNodeWrapper nodeRoot = new TreeNodeWrapper(parseTreeRoot, viewer);
/* 345 */     fillTree(nodeRoot, parseTreeRoot, viewer);
/* 346 */     JTree tree = new JTree(nodeRoot);
/* 347 */     tree.getSelectionModel().setSelectionMode(1);
/*     */     
/* 349 */     tree.addTreeSelectionListener(new TreeSelectionListener()
/*     */         {
/*     */           public void valueChanged(TreeSelectionEvent e)
/*     */           {
/* 353 */             JTree selectedTree = (JTree)e.getSource();
/* 354 */             TreePath path = selectedTree.getSelectionPath();
/* 355 */             TreeViewer.TreeNodeWrapper treeNode = (TreeViewer.TreeNodeWrapper)path.getLastPathComponent();
/*     */ 
/*     */             
/* 358 */             viewer.setTree((Tree)treeNode.getUserObject());
/*     */           }
/*     */         });
/*     */     
/* 362 */     treePanel.add(new JScrollPane(tree));
/*     */ 
/*     */     
/* 365 */     JSplitPane splitPane = new JSplitPane(1, treePanel, contentPane);
/*     */ 
/*     */     
/* 368 */     mainPane.add(splitPane, "Center");
/*     */     
/* 370 */     dialog.setContentPane(mainPane);
/*     */ 
/*     */     
/* 373 */     dialog.setDefaultCloseOperation(2);
/* 374 */     dialog.setPreferredSize(new Dimension(600, 500));
/* 375 */     dialog.pack();
/*     */ 
/*     */     
/* 378 */     splitPane.setDividerLocation(0.33D);
/*     */     
/* 380 */     dialog.setLocationRelativeTo((Component)null);
/* 381 */     dialog.setVisible(true);
/* 382 */     return dialog;
/*     */   }
/*     */   
/*     */   private static void generatePNGFile(TreeViewer viewer, JDialog dialog) {
/* 386 */     BufferedImage bi = new BufferedImage((viewer.getSize()).width, (viewer.getSize()).height, 2);
/*     */ 
/*     */     
/* 389 */     Graphics g = bi.createGraphics();
/* 390 */     viewer.paint(g);
/* 391 */     g.dispose();
/*     */     
/*     */     try {
/* 394 */       File suggestedFile = generateNonExistingPngFile();
/* 395 */       JFileChooser fileChooser = new JFileChooserConfirmOverwrite();
/* 396 */       fileChooser.setCurrentDirectory(suggestedFile.getParentFile());
/* 397 */       fileChooser.setSelectedFile(suggestedFile);
/* 398 */       FileFilter pngFilter = new FileFilter()
/*     */         {
/*     */           public boolean accept(File pathname)
/*     */           {
/* 402 */             if (pathname.isFile()) {
/* 403 */               return pathname.getName().toLowerCase().endsWith(".png");
/*     */             }
/*     */             
/* 406 */             return true;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getDescription() {
/* 411 */             return "PNG Files (*.png)";
/*     */           }
/*     */         };
/*     */       
/* 415 */       fileChooser.addChoosableFileFilter(pngFilter);
/* 416 */       fileChooser.setFileFilter(pngFilter);
/*     */       
/* 418 */       int returnValue = fileChooser.showSaveDialog(dialog);
/* 419 */       if (returnValue == 0) {
/* 420 */         File pngFile = fileChooser.getSelectedFile();
/* 421 */         ImageIO.write(bi, "png", pngFile);
/*     */ 
/*     */         
/*     */         try {
/* 425 */           Desktop.getDesktop().open(pngFile.getParentFile());
/*     */         }
/* 427 */         catch (Exception ex) {
/*     */ 
/*     */           
/* 430 */           JOptionPane.showMessageDialog(dialog, "Saved PNG to: " + pngFile.getAbsolutePath());
/*     */           
/* 432 */           ex.printStackTrace();
/*     */         }
/*     */       
/*     */       } 
/* 436 */     } catch (Exception ex) {
/* 437 */       JOptionPane.showMessageDialog(dialog, "Could not export to PNG: " + ex.getMessage(), "Error", 0);
/*     */ 
/*     */ 
/*     */       
/* 441 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static File generateNonExistingPngFile() {
/* 447 */     String parent = ".";
/* 448 */     String name = "antlr4_parse_tree";
/* 449 */     String extension = ".png";
/*     */     
/* 451 */     File pngFile = new File(".", "antlr4_parse_tree.png");
/*     */     
/* 453 */     int counter = 1;
/*     */ 
/*     */     
/* 456 */     while (pngFile.exists()) {
/* 457 */       pngFile = new File(".", "antlr4_parse_tree_" + counter + ".png");
/* 458 */       counter++;
/*     */     } 
/*     */     
/* 461 */     return pngFile;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void fillTree(TreeNodeWrapper node, Tree tree, TreeViewer viewer) {
/* 466 */     if (tree == null) {
/*     */       return;
/*     */     }
/*     */     
/* 470 */     for (int i = 0; i < tree.getChildCount(); i++) {
/*     */       
/* 472 */       Tree childTree = tree.getChild(i);
/* 473 */       TreeNodeWrapper childNode = new TreeNodeWrapper(childTree, viewer);
/*     */       
/* 475 */       node.add(childNode);
/*     */       
/* 477 */       fillTree(childNode, childTree, viewer);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Dimension getScaledTreeSize() {
/* 482 */     Dimension scaledTreeSize = this.treeLayout.getBounds().getBounds().getSize();
/*     */     
/* 484 */     scaledTreeSize = new Dimension((int)(scaledTreeSize.width * this.scale), (int)(scaledTreeSize.height * this.scale));
/*     */     
/* 486 */     return scaledTreeSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public Future<JDialog> open() {
/* 491 */     final TreeViewer viewer = this;
/* 492 */     viewer.setScale(1.5D);
/* 493 */     Callable<JDialog> callable = new Callable<JDialog>()
/*     */       {
/*     */         JDialog result;
/*     */         
/*     */         public JDialog call() throws Exception {
/* 498 */           SwingUtilities.invokeAndWait(new Runnable()
/*     */               {
/*     */                 public void run() {
/* 501 */                   TreeViewer.null.this.result = TreeViewer.showInDialog(viewer);
/*     */                 }
/*     */               });
/*     */           
/* 505 */           return this.result;
/*     */         }
/*     */       };
/*     */     
/* 509 */     ExecutorService executor = Executors.newSingleThreadExecutor();
/*     */     
/*     */     try {
/* 512 */       return executor.submit(callable);
/*     */     } finally {
/*     */       
/* 515 */       executor.shutdown();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void save(String fileName) throws IOException, PrintException {
/* 520 */     JDialog dialog = new JDialog();
/* 521 */     Container contentPane = dialog.getContentPane();
/* 522 */     ((JComponent)contentPane).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
/*     */     
/* 524 */     contentPane.add(this);
/* 525 */     contentPane.setBackground(Color.white);
/* 526 */     dialog.pack();
/* 527 */     dialog.setLocationRelativeTo((Component)null);
/* 528 */     dialog.dispose();
/* 529 */     GraphicsSupport.saveImage(this, fileName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Rectangle2D.Double getBoundsOfNode(Tree node) {
/* 535 */     return (Rectangle2D.Double)this.treeLayout.getNodeBounds().get(node);
/*     */   }
/*     */   
/*     */   protected String getText(Tree tree) {
/* 539 */     String s = this.treeTextProvider.getText(tree);
/* 540 */     s = Utils.escapeWhitespace(s, true);
/* 541 */     return s;
/*     */   }
/*     */   
/*     */   public TreeTextProvider getTreeTextProvider() {
/* 545 */     return this.treeTextProvider;
/*     */   }
/*     */   
/*     */   public void setTreeTextProvider(TreeTextProvider treeTextProvider) {
/* 549 */     this.treeTextProvider = treeTextProvider;
/*     */   }
/*     */   
/*     */   public void setFontSize(int sz) {
/* 553 */     this.fontSize = sz;
/* 554 */     this.font = new Font(this.fontName, this.fontStyle, this.fontSize);
/*     */   }
/*     */   
/*     */   public void setFontName(String name) {
/* 558 */     this.fontName = name;
/* 559 */     this.font = new Font(this.fontName, this.fontStyle, this.fontSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addHighlightedNodes(Collection<Tree> nodes) {
/* 564 */     this.highlightedNodes = new ArrayList<Tree>();
/* 565 */     this.highlightedNodes.addAll(nodes);
/*     */   }
/*     */   
/*     */   public void removeHighlightedNodes(Collection<Tree> nodes) {
/* 569 */     if (this.highlightedNodes != null)
/*     */     {
/* 571 */       for (Tree t : nodes) {
/* 572 */         int i = getHighlightedNodeIndex(t);
/* 573 */         if (i >= 0) this.highlightedNodes.remove(i); 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean isHighlighted(Tree node) {
/* 579 */     return (getHighlightedNodeIndex(node) >= 0);
/*     */   }
/*     */   
/*     */   protected int getHighlightedNodeIndex(Tree node) {
/* 583 */     if (this.highlightedNodes == null) return -1; 
/* 584 */     for (int i = 0; i < this.highlightedNodes.size(); i++) {
/* 585 */       Tree t = this.highlightedNodes.get(i);
/* 586 */       if (t == node) return i; 
/*     */     } 
/* 588 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Font getFont() {
/* 593 */     return this.font;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFont(Font font) {
/* 598 */     this.font = font;
/*     */   }
/*     */   
/*     */   public int getArcSize() {
/* 602 */     return this.arcSize;
/*     */   }
/*     */   
/*     */   public void setArcSize(int arcSize) {
/* 606 */     this.arcSize = arcSize;
/*     */   }
/*     */   
/*     */   public Color getBoxColor() {
/* 610 */     return this.boxColor;
/*     */   }
/*     */   
/*     */   public void setBoxColor(Color boxColor) {
/* 614 */     this.boxColor = boxColor;
/*     */   }
/*     */   
/*     */   public Color getHighlightedBoxColor() {
/* 618 */     return this.highlightedBoxColor;
/*     */   }
/*     */   
/*     */   public void setHighlightedBoxColor(Color highlightedBoxColor) {
/* 622 */     this.highlightedBoxColor = highlightedBoxColor;
/*     */   }
/*     */   
/*     */   public Color getBorderColor() {
/* 626 */     return this.borderColor;
/*     */   }
/*     */   
/*     */   public void setBorderColor(Color borderColor) {
/* 630 */     this.borderColor = borderColor;
/*     */   }
/*     */   
/*     */   public Color getTextColor() {
/* 634 */     return this.textColor;
/*     */   }
/*     */   
/*     */   public void setTextColor(Color textColor) {
/* 638 */     this.textColor = textColor;
/*     */   }
/*     */   
/*     */   protected TreeForTreeLayout<Tree> getTree() {
/* 642 */     return this.treeLayout.getTree();
/*     */   }
/*     */   
/*     */   public void setTree(Tree root) {
/* 646 */     if (root != null) {
/* 647 */       boolean useIdentity = true;
/* 648 */       this.treeLayout = new TreeLayout<Tree>(new TreeLayoutAdaptor(root), new VariableExtentProvide(this), new DefaultConfiguration<Tree>(this.gapBetweenLevels, this.gapBetweenNodes), useIdentity);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 655 */       updatePreferredSize();
/*     */     } else {
/*     */       
/* 658 */       this.treeLayout = null;
/* 659 */       repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public double getScale() {
/* 664 */     return this.scale;
/*     */   }
/*     */   
/*     */   public void setScale(double scale) {
/* 668 */     if (scale <= 0.0D) {
/* 669 */       scale = 1.0D;
/*     */     }
/* 671 */     this.scale = scale;
/* 672 */     updatePreferredSize();
/*     */   }
/*     */   
/*     */   public void setRuleNames(List<String> ruleNames) {
/* 676 */     setTreeTextProvider(new DefaultTreeTextProvider(ruleNames));
/*     */   }
/*     */   
/*     */   private static class TreeNodeWrapper
/*     */     extends DefaultMutableTreeNode {
/*     */     final TreeViewer viewer;
/*     */     
/*     */     TreeNodeWrapper(Tree tree, TreeViewer viewer) {
/* 684 */       super(tree);
/* 685 */       this.viewer = viewer;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 690 */       return this.viewer.getText((Tree)getUserObject());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class EmptyIcon implements Icon {
/*     */     private EmptyIcon() {}
/*     */     
/*     */     public int getIconWidth() {
/* 698 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getIconHeight() {
/* 703 */       return 0;
/*     */     }
/*     */     
/*     */     public void paintIcon(Component c, Graphics g, int x, int y) {}
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/tree/gui/TreeViewer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */