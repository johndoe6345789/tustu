/*     */ package org.antlr.v4.runtime.tree.gui;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.List;
/*     */ import org.abego.treelayout.Configuration;
/*     */ import org.abego.treelayout.NodeExtentProvider;
/*     */ import org.abego.treelayout.TreeForTreeLayout;
/*     */ import org.abego.treelayout.TreeLayout;
/*     */ import org.abego.treelayout.util.DefaultConfiguration;
/*     */ import org.antlr.v4.runtime.misc.Utils;
/*     */ import org.antlr.v4.runtime.tree.Tree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreePostScriptGenerator
/*     */ {
/*     */   public class VariableExtentProvide
/*     */     implements NodeExtentProvider<Tree>
/*     */   {
/*     */     public double getWidth(Tree tree) {
/*  50 */       String s = TreePostScriptGenerator.this.getText(tree);
/*  51 */       return TreePostScriptGenerator.this.doc.getWidth(s) + (TreePostScriptGenerator.this.nodeWidthPadding * 2);
/*     */     }
/*     */ 
/*     */     
/*     */     public double getHeight(Tree tree) {
/*  56 */       String s = TreePostScriptGenerator.this.getText(tree);
/*  57 */       double h = TreePostScriptGenerator.this.doc.getLineHeight() + TreePostScriptGenerator.this.nodeHeightPaddingAbove + TreePostScriptGenerator.this.nodeHeightPaddingBelow;
/*     */       
/*  59 */       String[] lines = s.split("\n");
/*  60 */       return h * lines.length;
/*     */     }
/*     */   }
/*     */   
/*  64 */   protected double gapBetweenLevels = 17.0D;
/*  65 */   protected double gapBetweenNodes = 7.0D;
/*  66 */   protected int nodeWidthPadding = 1;
/*  67 */   protected int nodeHeightPaddingAbove = 0;
/*  68 */   protected int nodeHeightPaddingBelow = 5;
/*     */   
/*     */   protected Tree root;
/*     */   
/*     */   protected TreeTextProvider treeTextProvider;
/*     */   protected TreeLayout<Tree> treeLayout;
/*     */   protected PostScriptDocument doc;
/*     */   
/*     */   public TreePostScriptGenerator(List<String> ruleNames, Tree root) {
/*  77 */     this(ruleNames, root, "CourierNew", 11);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TreePostScriptGenerator(List<String> ruleNames, Tree root, String fontName, int fontSize) {
/*  83 */     this.root = root;
/*  84 */     setTreeTextProvider(new TreeViewer.DefaultTreeTextProvider(ruleNames));
/*  85 */     this.doc = new PostScriptDocument(fontName, fontSize);
/*  86 */     boolean compareNodeIdentities = true;
/*  87 */     this.treeLayout = new TreeLayout<Tree>(new TreeLayoutAdaptor(root), new VariableExtentProvide(), new DefaultConfiguration<Tree>(this.gapBetweenLevels, this.gapBetweenNodes, Configuration.Location.Bottom), compareNodeIdentities);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPS() {
/*  98 */     generateEdges(getTree().getRoot());
/*  99 */     for (Tree node : this.treeLayout.getNodeBounds().keySet()) {
/* 100 */       generateNode(node);
/*     */     }
/*     */     
/* 103 */     Dimension size = this.treeLayout.getBounds().getBounds().getSize();
/* 104 */     this.doc.boundingBox(size.width, size.height);
/* 105 */     this.doc.close();
/* 106 */     return this.doc.getPS();
/*     */   }
/*     */   
/*     */   protected void generateEdges(Tree parent) {
/* 110 */     if (!getTree().isLeaf(parent)) {
/* 111 */       Rectangle2D.Double parentBounds = getBoundsOfNode(parent);
/*     */       
/* 113 */       double x1 = parentBounds.getCenterX();
/* 114 */       double y1 = parentBounds.y;
/* 115 */       for (Tree child : getChildren(parent)) {
/* 116 */         Rectangle2D.Double childBounds = getBoundsOfNode(child);
/*     */         
/* 118 */         double x2 = childBounds.getCenterX();
/* 119 */         double y2 = childBounds.getMaxY();
/* 120 */         this.doc.line(x1, y1, x2, y2);
/* 121 */         generateEdges(child);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void generateNode(Tree t) {
/* 128 */     String[] lines = getText(t).split("\n");
/* 129 */     Rectangle2D.Double box = getBoundsOfNode(t);
/*     */ 
/*     */ 
/*     */     
/* 133 */     if (t instanceof org.antlr.v4.runtime.tree.ErrorNode) {
/* 134 */       this.doc.highlight(box.x, box.y, box.width, box.height);
/*     */     }
/* 136 */     double x = box.x + this.nodeWidthPadding;
/* 137 */     double y = box.y + this.nodeHeightPaddingBelow;
/* 138 */     for (int i = 0; i < lines.length; i++) {
/* 139 */       this.doc.text(lines[i], x, y);
/* 140 */       y += this.doc.getLineHeight();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected TreeForTreeLayout<Tree> getTree() {
/* 145 */     return this.treeLayout.getTree();
/*     */   }
/*     */   
/*     */   protected Iterable<Tree> getChildren(Tree parent) {
/* 149 */     return getTree().getChildren(parent);
/*     */   }
/*     */   
/*     */   protected Rectangle2D.Double getBoundsOfNode(Tree node) {
/* 153 */     return (Rectangle2D.Double)this.treeLayout.getNodeBounds().get(node);
/*     */   }
/*     */   
/*     */   protected String getText(Tree tree) {
/* 157 */     String s = this.treeTextProvider.getText(tree);
/* 158 */     s = Utils.escapeWhitespace(s, false);
/* 159 */     return s;
/*     */   }
/*     */   
/*     */   public TreeTextProvider getTreeTextProvider() {
/* 163 */     return this.treeTextProvider;
/*     */   }
/*     */   
/*     */   public void setTreeTextProvider(TreeTextProvider treeTextProvider) {
/* 167 */     this.treeTextProvider = treeTextProvider;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/tree/gui/TreePostScriptGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */