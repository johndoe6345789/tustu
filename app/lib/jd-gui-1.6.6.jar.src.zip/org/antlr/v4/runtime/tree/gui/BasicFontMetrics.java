/*    */ package org.antlr.v4.runtime.tree.gui;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BasicFontMetrics
/*    */ {
/*    */   public static final int MAX_CHAR = 255;
/*    */   protected int maxCharHeight;
/* 77 */   protected int[] widths = new int[256];
/*    */   
/*    */   public double getWidth(String s, int fontSize) {
/* 80 */     double w = 0.0D;
/* 81 */     for (char c : s.toCharArray()) {
/* 82 */       w += getWidth(c, fontSize);
/*    */     }
/* 84 */     return w;
/*    */   }
/*    */   
/*    */   public double getWidth(char c, int fontSize) {
/* 88 */     if (c > 'ÿ' || this.widths[c] == 0) return this.widths[109] / 1000.0D; 
/* 89 */     return this.widths[c] / 1000.0D * fontSize;
/*    */   }
/*    */   
/*    */   public double getLineHeight(int fontSize) {
/* 93 */     return this.maxCharHeight / 1000.0D * fontSize;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/tree/gui/BasicFontMetrics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */