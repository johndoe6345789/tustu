/*    */ package org.antlr.v4.runtime.tree.gui;
/*    */ 
/*    */ import java.awt.Font;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.GraphicsEnvironment;
/*    */ import java.awt.font.FontRenderContext;
/*    */ import java.awt.font.TextLayout;
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemFontMetrics
/*    */   extends BasicFontMetrics
/*    */ {
/*    */   protected final Font font;
/*    */   
/*    */   public SystemFontMetrics(String fontName) {
/* 46 */     BufferedImage img = new BufferedImage(40, 40, 6);
/* 47 */     Graphics2D graphics = GraphicsEnvironment.getLocalGraphicsEnvironment().createGraphics(img);
/* 48 */     FontRenderContext fontRenderContext = graphics.getFontRenderContext();
/* 49 */     this.font = new Font(fontName, 0, 1000);
/* 50 */     double maxHeight = 0.0D;
/* 51 */     for (int i = 0; i < 255; i++) {
/* 52 */       TextLayout layout = new TextLayout(Character.toString((char)i), this.font, fontRenderContext);
/* 53 */       maxHeight = Math.max(maxHeight, layout.getBounds().getHeight());
/* 54 */       this.widths[i] = (int)layout.getAdvance();
/*    */     } 
/*    */     
/* 57 */     this.maxCharHeight = (int)Math.round(maxHeight);
/*    */   }
/*    */   
/*    */   public Font getFont() {
/* 61 */     return this.font;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/tree/gui/SystemFontMetrics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */