package org.antlr.v4.runtime.tree.gui;

import org.antlr.v4.runtime.tree.Tree;

public interface TreeTextProvider {
  String getText(Tree paramTree);
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/tree/gui/TreeTextProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */