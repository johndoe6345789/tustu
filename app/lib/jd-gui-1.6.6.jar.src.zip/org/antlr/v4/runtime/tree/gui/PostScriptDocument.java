/*     */ package org.antlr.v4.runtime.tree.gui;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PostScriptDocument
/*     */ {
/*     */   public static final String DEFAULT_FONT = "CourierNew";
/*  43 */   public static final Map<String, String> POSTSCRIPT_FONT_NAMES = new HashMap<String, String>(); static {
/*  44 */     POSTSCRIPT_FONT_NAMES.put("SansSerif.plain", "ArialMT");
/*  45 */     POSTSCRIPT_FONT_NAMES.put("SansSerif.bold", "Arial-BoldMT");
/*  46 */     POSTSCRIPT_FONT_NAMES.put("SansSerif.italic", "Arial-ItalicMT");
/*  47 */     POSTSCRIPT_FONT_NAMES.put("SansSerif.bolditalic", "Arial-BoldItalicMT");
/*  48 */     POSTSCRIPT_FONT_NAMES.put("Serif.plain", "TimesNewRomanPSMT");
/*  49 */     POSTSCRIPT_FONT_NAMES.put("Serif.bold", "TimesNewRomanPS-BoldMT");
/*  50 */     POSTSCRIPT_FONT_NAMES.put("Serif.italic", "TimesNewRomanPS-ItalicMT");
/*  51 */     POSTSCRIPT_FONT_NAMES.put("Serif.bolditalic", "TimesNewRomanPS-BoldItalicMT");
/*  52 */     POSTSCRIPT_FONT_NAMES.put("Monospaced.plain", "CourierNewPSMT");
/*  53 */     POSTSCRIPT_FONT_NAMES.put("Monospaced.bold", "CourierNewPS-BoldMT");
/*  54 */     POSTSCRIPT_FONT_NAMES.put("Monospaced.italic", "CourierNewPS-ItalicMT");
/*  55 */     POSTSCRIPT_FONT_NAMES.put("Monospaced.bolditalic", "CourierNewPS-BoldItalicMT");
/*     */   }
/*     */ 
/*     */   
/*     */   protected int boundingBoxWidth;
/*     */   protected int boundingBoxHeight;
/*     */   protected SystemFontMetrics fontMetrics;
/*     */   protected String fontName;
/*  63 */   protected int fontSize = 12;
/*  64 */   protected double lineWidth = 0.3D;
/*     */   
/*     */   protected String boundingBox;
/*  67 */   protected StringBuilder ps = new StringBuilder();
/*     */   protected boolean closed = false;
/*     */   
/*     */   public PostScriptDocument() {
/*  71 */     this("CourierNew", 12);
/*     */   }
/*     */   
/*     */   public PostScriptDocument(String fontName, int fontSize) {
/*  75 */     header();
/*  76 */     setFont(fontName, fontSize);
/*     */   }
/*     */   
/*     */   public String getPS() {
/*  80 */     close();
/*  81 */     return header() + this.ps.toString();
/*     */   }
/*     */   
/*     */   public void boundingBox(int w, int h) {
/*  85 */     this.boundingBoxWidth = w;
/*  86 */     this.boundingBoxHeight = h;
/*  87 */     this.boundingBox = String.format(Locale.US, "%%%%BoundingBox: %d %d %d %d\n", new Object[] { Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(this.boundingBoxWidth), Integer.valueOf(this.boundingBoxHeight) });
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*  92 */     if (this.closed)
/*     */       return; 
/*  94 */     this.ps.append("%%Trailer\n");
/*  95 */     this.closed = true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringBuilder header() {
/* 100 */     StringBuilder b = new StringBuilder();
/* 101 */     b.append("%!PS-Adobe-3.0 EPSF-3.0\n");
/* 102 */     b.append(this.boundingBox).append("\n");
/* 103 */     b.append("0.3 setlinewidth\n");
/* 104 */     b.append("%% x y w h highlight\n/highlight {\n        4 dict begin\n        /h exch def\n        /w exch def\n        /y exch def\n        /x exch def\n        gsave\n        newpath\n        x y moveto\n        0 h rlineto     % up to left corner\n        w 0 rlineto     % to upper right corner\n        0 h neg rlineto % to lower right corner\n        w neg 0 rlineto % back home to lower left corner\n        closepath\n        .95 .83 .82 setrgbcolor\n        fill\n        grestore\n        end\n} def\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     return b;
/*     */   }
/*     */   
/*     */   public void setFont(String fontName, int fontSize) {
/* 129 */     this.fontMetrics = new SystemFontMetrics(fontName);
/* 130 */     this.fontName = this.fontMetrics.getFont().getPSName();
/* 131 */     this.fontSize = fontSize;
/*     */     
/* 133 */     String psname = POSTSCRIPT_FONT_NAMES.get(this.fontName);
/* 134 */     if (psname == null) {
/* 135 */       psname = this.fontName;
/*     */     }
/*     */     
/* 138 */     this.ps.append(String.format(Locale.US, "/%s findfont %d scalefont setfont\n", new Object[] { psname, Integer.valueOf(fontSize) }));
/*     */   }
/*     */   
/*     */   public void lineWidth(double w) {
/* 142 */     this.lineWidth = w;
/* 143 */     this.ps.append(w).append(" setlinewidth\n");
/*     */   }
/*     */   
/*     */   public void move(double x, double y) {
/* 147 */     this.ps.append(String.format(Locale.US, "%1.3f %1.3f moveto\n", new Object[] { Double.valueOf(x), Double.valueOf(y) }));
/*     */   }
/*     */   
/*     */   public void lineto(double x, double y) {
/* 151 */     this.ps.append(String.format(Locale.US, "%1.3f %1.3f lineto\n", new Object[] { Double.valueOf(x), Double.valueOf(y) }));
/*     */   }
/*     */   
/*     */   public void line(double x1, double y1, double x2, double y2) {
/* 155 */     move(x1, y1);
/* 156 */     lineto(x2, y2);
/*     */   }
/*     */   
/*     */   public void rect(double x, double y, double width, double height) {
/* 160 */     line(x, y, x, y + height);
/* 161 */     line(x, y + height, x + width, y + height);
/* 162 */     line(x + width, y + height, x + width, y);
/* 163 */     line(x + width, y, x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void highlight(double x, double y, double width, double height) {
/* 168 */     this.ps.append(String.format(Locale.US, "%1.3f %1.3f %1.3f %1.3f highlight\n", new Object[] { Double.valueOf(x), Double.valueOf(y), Double.valueOf(width), Double.valueOf(height) }));
/*     */   }
/*     */   
/*     */   public void stroke() {
/* 172 */     this.ps.append("stroke\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void text(String s, double x, double y) {
/* 184 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 186 */     for (char c : s.toCharArray()) {
/* 187 */       switch (c) {
/*     */         case '(':
/*     */         case ')':
/*     */         case '\\':
/* 191 */           buf.append('\\');
/* 192 */           buf.append(c);
/*     */           break;
/*     */         default:
/* 195 */           buf.append(c);
/*     */           break;
/*     */       } 
/*     */     } 
/* 199 */     s = buf.toString();
/* 200 */     move(x, y);
/* 201 */     this.ps.append(String.format(Locale.US, "(%s) show\n", new Object[] { s }));
/* 202 */     stroke();
/*     */   }
/*     */   
/*     */   public double getWidth(char c)
/*     */   {
/* 207 */     return this.fontMetrics.getWidth(c, this.fontSize);
/* 208 */   } public double getWidth(String s) { return this.fontMetrics.getWidth(s, this.fontSize); } public double getLineHeight() {
/* 209 */     return this.fontMetrics.getLineHeight(this.fontSize);
/*     */   } public int getFontSize() {
/* 211 */     return this.fontSize;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/tree/gui/PostScriptDocument.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */