/*     */ package org.antlr.v4.runtime.tree.pattern;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.ANTLRInputStream;
/*     */ import org.antlr.v4.runtime.BailErrorStrategy;
/*     */ import org.antlr.v4.runtime.CommonTokenStream;
/*     */ import org.antlr.v4.runtime.Lexer;
/*     */ import org.antlr.v4.runtime.ListTokenSource;
/*     */ import org.antlr.v4.runtime.Parser;
/*     */ import org.antlr.v4.runtime.ParserInterpreter;
/*     */ import org.antlr.v4.runtime.ParserRuleContext;
/*     */ import org.antlr.v4.runtime.RecognitionException;
/*     */ import org.antlr.v4.runtime.Token;
/*     */ import org.antlr.v4.runtime.misc.MultiMap;
/*     */ import org.antlr.v4.runtime.misc.ParseCancellationException;
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ import org.antlr.v4.runtime.tree.RuleNode;
/*     */ import org.antlr.v4.runtime.tree.TerminalNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseTreePatternMatcher
/*     */ {
/*     */   private final Lexer lexer;
/*     */   private final Parser parser;
/*     */   
/*     */   public static class CannotInvokeStartRule
/*     */     extends RuntimeException
/*     */   {
/*     */     public CannotInvokeStartRule(Throwable e) {
/* 116 */       super(e);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class StartRuleDoesNotConsumeFullPattern
/*     */     extends RuntimeException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   protected String start = "<";
/* 136 */   protected String stop = ">";
/* 137 */   protected String escape = "\\";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreePatternMatcher(Lexer lexer, Parser parser) {
/* 146 */     this.lexer = lexer;
/* 147 */     this.parser = parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDelimiters(String start, String stop, String escapeLeft) {
/* 162 */     if (start == null || start.isEmpty()) {
/* 163 */       throw new IllegalArgumentException("start cannot be null or empty");
/*     */     }
/*     */     
/* 166 */     if (stop == null || stop.isEmpty()) {
/* 167 */       throw new IllegalArgumentException("stop cannot be null or empty");
/*     */     }
/*     */     
/* 170 */     this.start = start;
/* 171 */     this.stop = stop;
/* 172 */     this.escape = escapeLeft;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(ParseTree tree, String pattern, int patternRuleIndex) {
/* 177 */     ParseTreePattern p = compile(pattern, patternRuleIndex);
/* 178 */     return matches(tree, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(ParseTree tree, ParseTreePattern pattern) {
/* 185 */     MultiMap<String, ParseTree> labels = new MultiMap<String, ParseTree>();
/* 186 */     ParseTree mismatchedNode = matchImpl(tree, pattern.getPatternTree(), labels);
/* 187 */     return (mismatchedNode == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreeMatch match(ParseTree tree, String pattern, int patternRuleIndex) {
/* 196 */     ParseTreePattern p = compile(pattern, patternRuleIndex);
/* 197 */     return match(tree, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreeMatch match(ParseTree tree, ParseTreePattern pattern) {
/* 208 */     MultiMap<String, ParseTree> labels = new MultiMap<String, ParseTree>();
/* 209 */     ParseTree mismatchedNode = matchImpl(tree, pattern.getPatternTree(), labels);
/* 210 */     return new ParseTreeMatch(tree, pattern, labels, mismatchedNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreePattern compile(String pattern, int patternRuleIndex) {
/* 218 */     List<? extends Token> tokenList = tokenize(pattern);
/* 219 */     ListTokenSource tokenSrc = new ListTokenSource(tokenList);
/* 220 */     CommonTokenStream tokens = new CommonTokenStream(tokenSrc);
/*     */     
/* 222 */     ParserInterpreter parserInterp = new ParserInterpreter(this.parser.getGrammarFileName(), this.parser.getVocabulary(), Arrays.asList(this.parser.getRuleNames()), this.parser.getATNWithBypassAlts(), tokens);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     ParseTree tree = null;
/*     */     try {
/* 230 */       parserInterp.setErrorHandler(new BailErrorStrategy());
/* 231 */       tree = parserInterp.parse(patternRuleIndex);
/*     */     
/*     */     }
/* 234 */     catch (ParseCancellationException e) {
/* 235 */       throw (RecognitionException)e.getCause();
/*     */     }
/* 237 */     catch (RecognitionException re) {
/* 238 */       throw re;
/*     */     }
/* 240 */     catch (Exception e) {
/* 241 */       throw new CannotInvokeStartRule(e);
/*     */     } 
/*     */ 
/*     */     
/* 245 */     if (tokens.LA(1) != -1) {
/* 246 */       throw new StartRuleDoesNotConsumeFullPattern();
/*     */     }
/*     */     
/* 249 */     return new ParseTreePattern(this, pattern, patternRuleIndex, tree);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Lexer getLexer() {
/* 258 */     return this.lexer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Parser getParser() {
/* 267 */     return this.parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParseTree matchImpl(ParseTree tree, ParseTree patternTree, MultiMap<String, ParseTree> labels) {
/* 286 */     if (tree == null) {
/* 287 */       throw new IllegalArgumentException("tree cannot be null");
/*     */     }
/*     */     
/* 290 */     if (patternTree == null) {
/* 291 */       throw new IllegalArgumentException("patternTree cannot be null");
/*     */     }
/*     */ 
/*     */     
/* 295 */     if (tree instanceof TerminalNode && patternTree instanceof TerminalNode) {
/* 296 */       TerminalNode t1 = (TerminalNode)tree;
/* 297 */       TerminalNode t2 = (TerminalNode)patternTree;
/* 298 */       ParseTree mismatchedNode = null;
/*     */       
/* 300 */       if (t1.getSymbol().getType() == t2.getSymbol().getType()) {
/* 301 */         if (t2.getSymbol() instanceof TokenTagToken) {
/* 302 */           TokenTagToken tokenTagToken = (TokenTagToken)t2.getSymbol();
/*     */           
/* 304 */           labels.map(tokenTagToken.getTokenName(), tree);
/* 305 */           if (tokenTagToken.getLabel() != null) {
/* 306 */             labels.map(tokenTagToken.getLabel(), tree);
/*     */           }
/*     */         }
/* 309 */         else if (!t1.getText().equals(t2.getText())) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 314 */           if (mismatchedNode == null) {
/* 315 */             mismatchedNode = t1;
/*     */           }
/*     */         }
/*     */       
/*     */       }
/* 320 */       else if (mismatchedNode == null) {
/* 321 */         mismatchedNode = t1;
/*     */       } 
/*     */ 
/*     */       
/* 325 */       return mismatchedNode;
/*     */     } 
/*     */     
/* 328 */     if (tree instanceof ParserRuleContext && patternTree instanceof ParserRuleContext) {
/* 329 */       ParserRuleContext r1 = (ParserRuleContext)tree;
/* 330 */       ParserRuleContext r2 = (ParserRuleContext)patternTree;
/* 331 */       ParseTree mismatchedNode = null;
/*     */       
/* 333 */       RuleTagToken ruleTagToken = getRuleTagToken(r2);
/* 334 */       if (ruleTagToken != null) {
/* 335 */         ParseTreeMatch m = null;
/* 336 */         if (r1.getRuleContext().getRuleIndex() == r2.getRuleContext().getRuleIndex()) {
/*     */           
/* 338 */           labels.map(ruleTagToken.getRuleName(), tree);
/* 339 */           if (ruleTagToken.getLabel() != null) {
/* 340 */             labels.map(ruleTagToken.getLabel(), tree);
/*     */           
/*     */           }
/*     */         }
/* 344 */         else if (mismatchedNode == null) {
/* 345 */           mismatchedNode = r1;
/*     */         } 
/*     */ 
/*     */         
/* 349 */         return mismatchedNode;
/*     */       } 
/*     */ 
/*     */       
/* 353 */       if (r1.getChildCount() != r2.getChildCount()) {
/* 354 */         if (mismatchedNode == null) {
/* 355 */           mismatchedNode = r1;
/*     */         }
/*     */         
/* 358 */         return mismatchedNode;
/*     */       } 
/*     */       
/* 361 */       int n = r1.getChildCount();
/* 362 */       for (int i = 0; i < n; i++) {
/* 363 */         ParseTree childMatch = matchImpl(r1.getChild(i), patternTree.getChild(i), labels);
/* 364 */         if (childMatch != null) {
/* 365 */           return childMatch;
/*     */         }
/*     */       } 
/*     */       
/* 369 */       return mismatchedNode;
/*     */     } 
/*     */ 
/*     */     
/* 373 */     return tree;
/*     */   }
/*     */ 
/*     */   
/*     */   protected RuleTagToken getRuleTagToken(ParseTree t) {
/* 378 */     if (t instanceof RuleNode) {
/* 379 */       RuleNode r = (RuleNode)t;
/* 380 */       if (r.getChildCount() == 1 && r.getChild(0) instanceof TerminalNode) {
/* 381 */         TerminalNode c = (TerminalNode)r.getChild(0);
/* 382 */         if (c.getSymbol() instanceof RuleTagToken)
/*     */         {
/* 384 */           return (RuleTagToken)c.getSymbol();
/*     */         }
/*     */       } 
/*     */     } 
/* 388 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends Token> tokenize(String pattern) {
/* 393 */     List<Chunk> chunks = split(pattern);
/*     */ 
/*     */     
/* 396 */     List<Token> tokens = new ArrayList<Token>();
/* 397 */     for (Chunk chunk : chunks) {
/* 398 */       if (chunk instanceof TagChunk) {
/* 399 */         TagChunk tagChunk = (TagChunk)chunk;
/*     */         
/* 401 */         if (Character.isUpperCase(tagChunk.getTag().charAt(0))) {
/* 402 */           Integer ttype = Integer.valueOf(this.parser.getTokenType(tagChunk.getTag()));
/* 403 */           if (ttype.intValue() == 0) {
/* 404 */             throw new IllegalArgumentException("Unknown token " + tagChunk.getTag() + " in pattern: " + pattern);
/*     */           }
/* 406 */           TokenTagToken tokenTagToken = new TokenTagToken(tagChunk.getTag(), ttype.intValue(), tagChunk.getLabel());
/* 407 */           tokens.add(tokenTagToken); continue;
/*     */         } 
/* 409 */         if (Character.isLowerCase(tagChunk.getTag().charAt(0))) {
/* 410 */           int ruleIndex = this.parser.getRuleIndex(tagChunk.getTag());
/* 411 */           if (ruleIndex == -1) {
/* 412 */             throw new IllegalArgumentException("Unknown rule " + tagChunk.getTag() + " in pattern: " + pattern);
/*     */           }
/* 414 */           int ruleImaginaryTokenType = (this.parser.getATNWithBypassAlts()).ruleToTokenType[ruleIndex];
/* 415 */           tokens.add(new RuleTagToken(tagChunk.getTag(), ruleImaginaryTokenType, tagChunk.getLabel()));
/*     */           continue;
/*     */         } 
/* 418 */         throw new IllegalArgumentException("invalid tag: " + tagChunk.getTag() + " in pattern: " + pattern);
/*     */       } 
/*     */ 
/*     */       
/* 422 */       TextChunk textChunk = (TextChunk)chunk;
/* 423 */       ANTLRInputStream in = new ANTLRInputStream(textChunk.getText());
/* 424 */       this.lexer.setInputStream(in);
/* 425 */       Token t = this.lexer.nextToken();
/* 426 */       while (t.getType() != -1) {
/* 427 */         tokens.add(t);
/* 428 */         t = this.lexer.nextToken();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 434 */     return tokens;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Chunk> split(String pattern) {
/* 439 */     int p = 0;
/* 440 */     int n = pattern.length();
/* 441 */     List<Chunk> chunks = new ArrayList<Chunk>();
/* 442 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 444 */     List<Integer> starts = new ArrayList<Integer>();
/* 445 */     List<Integer> stops = new ArrayList<Integer>();
/* 446 */     while (p < n) {
/* 447 */       if (p == pattern.indexOf(this.escape + this.start, p)) {
/* 448 */         p += this.escape.length() + this.start.length(); continue;
/*     */       } 
/* 450 */       if (p == pattern.indexOf(this.escape + this.stop, p)) {
/* 451 */         p += this.escape.length() + this.stop.length(); continue;
/*     */       } 
/* 453 */       if (p == pattern.indexOf(this.start, p)) {
/* 454 */         starts.add(Integer.valueOf(p));
/* 455 */         p += this.start.length(); continue;
/*     */       } 
/* 457 */       if (p == pattern.indexOf(this.stop, p)) {
/* 458 */         stops.add(Integer.valueOf(p));
/* 459 */         p += this.stop.length();
/*     */         continue;
/*     */       } 
/* 462 */       p++;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 469 */     if (starts.size() > stops.size()) {
/* 470 */       throw new IllegalArgumentException("unterminated tag in pattern: " + pattern);
/*     */     }
/*     */     
/* 473 */     if (starts.size() < stops.size()) {
/* 474 */       throw new IllegalArgumentException("missing start tag in pattern: " + pattern);
/*     */     }
/*     */     
/* 477 */     int ntags = starts.size(); int i;
/* 478 */     for (i = 0; i < ntags; i++) {
/* 479 */       if (((Integer)starts.get(i)).intValue() >= ((Integer)stops.get(i)).intValue()) {
/* 480 */         throw new IllegalArgumentException("tag delimiters out of order in pattern: " + pattern);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 485 */     if (ntags == 0) {
/* 486 */       String text = pattern.substring(0, n);
/* 487 */       chunks.add(new TextChunk(text));
/*     */     } 
/*     */     
/* 490 */     if (ntags > 0 && ((Integer)starts.get(0)).intValue() > 0) {
/* 491 */       String text = pattern.substring(0, ((Integer)starts.get(0)).intValue());
/* 492 */       chunks.add(new TextChunk(text));
/*     */     } 
/* 494 */     for (i = 0; i < ntags; i++) {
/*     */       
/* 496 */       String tag = pattern.substring(((Integer)starts.get(i)).intValue() + this.start.length(), ((Integer)stops.get(i)).intValue());
/* 497 */       String ruleOrToken = tag;
/* 498 */       String label = null;
/* 499 */       int colon = tag.indexOf(':');
/* 500 */       if (colon >= 0) {
/* 501 */         label = tag.substring(0, colon);
/* 502 */         ruleOrToken = tag.substring(colon + 1, tag.length());
/*     */       } 
/* 504 */       chunks.add(new TagChunk(label, ruleOrToken));
/* 505 */       if (i + 1 < ntags) {
/*     */         
/* 507 */         String text = pattern.substring(((Integer)stops.get(i)).intValue() + this.stop.length(), ((Integer)starts.get(i + 1)).intValue());
/* 508 */         chunks.add(new TextChunk(text));
/*     */       } 
/*     */     } 
/* 511 */     if (ntags > 0) {
/* 512 */       int afterLastTag = ((Integer)stops.get(ntags - 1)).intValue() + this.stop.length();
/* 513 */       if (afterLastTag < n) {
/* 514 */         String text = pattern.substring(afterLastTag, n);
/* 515 */         chunks.add(new TextChunk(text));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 520 */     for (i = 0; i < chunks.size(); i++) {
/* 521 */       Chunk c = chunks.get(i);
/* 522 */       if (c instanceof TextChunk) {
/* 523 */         TextChunk tc = (TextChunk)c;
/* 524 */         String unescaped = tc.getText().replace(this.escape, "");
/* 525 */         if (unescaped.length() < tc.getText().length()) {
/* 526 */           chunks.set(i, new TextChunk(unescaped));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 531 */     return chunks;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/tree/pattern/ParseTreePatternMatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */