/*     */ package org.antlr.v4.runtime.tree.gui;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.abego.treelayout.TreeForTreeLayout;
/*     */ import org.antlr.v4.runtime.tree.Tree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeLayoutAdaptor
/*     */   implements TreeForTreeLayout<Tree>
/*     */ {
/*     */   private Tree root;
/*     */   
/*     */   private static class AntlrTreeChildrenIterable
/*     */     implements Iterable<Tree>
/*     */   {
/*     */     private final Tree tree;
/*     */     
/*     */     public AntlrTreeChildrenIterable(Tree tree) {
/*  45 */       this.tree = tree;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<Tree> iterator() {
/*  50 */       return new Iterator<Tree>() {
/*  51 */           private int i = 0;
/*     */ 
/*     */           
/*     */           public boolean hasNext() {
/*  55 */             return (TreeLayoutAdaptor.AntlrTreeChildrenIterable.this.tree.getChildCount() > this.i);
/*     */           }
/*     */ 
/*     */           
/*     */           public Tree next() {
/*  60 */             if (!hasNext()) {
/*  61 */               throw new NoSuchElementException();
/*     */             }
/*  63 */             return TreeLayoutAdaptor.AntlrTreeChildrenIterable.this.tree.getChild(this.i++);
/*     */           }
/*     */ 
/*     */           
/*     */           public void remove() {
/*  68 */             throw new UnsupportedOperationException();
/*     */           }
/*     */         };
/*     */     }
/*     */   }
/*     */   
/*     */   private static class AntlrTreeChildrenReverseIterable
/*     */     implements Iterable<Tree>
/*     */   {
/*     */     private final Tree tree;
/*     */     
/*     */     public AntlrTreeChildrenReverseIterable(Tree tree) {
/*  80 */       this.tree = tree;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<Tree> iterator() {
/*  85 */       return new Iterator<Tree>() {
/*  86 */           private int i = TreeLayoutAdaptor.AntlrTreeChildrenReverseIterable.this.tree.getChildCount();
/*     */ 
/*     */           
/*     */           public boolean hasNext() {
/*  90 */             return (this.i > 0);
/*     */           }
/*     */ 
/*     */           
/*     */           public Tree next() {
/*  95 */             if (!hasNext()) {
/*  96 */               throw new NoSuchElementException();
/*     */             }
/*  98 */             return TreeLayoutAdaptor.AntlrTreeChildrenReverseIterable.this.tree.getChild(--this.i);
/*     */           }
/*     */ 
/*     */           
/*     */           public void remove() {
/* 103 */             throw new UnsupportedOperationException();
/*     */           }
/*     */         };
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TreeLayoutAdaptor(Tree root) {
/* 112 */     this.root = root;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLeaf(Tree node) {
/* 117 */     return (node.getChildCount() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isChildOfParent(Tree node, Tree parentNode) {
/* 122 */     return (node.getParent() == parentNode);
/*     */   }
/*     */ 
/*     */   
/*     */   public Tree getRoot() {
/* 127 */     return this.root;
/*     */   }
/*     */ 
/*     */   
/*     */   public Tree getLastChild(Tree parentNode) {
/* 132 */     return parentNode.getChild(parentNode.getChildCount() - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Tree getFirstChild(Tree parentNode) {
/* 137 */     return parentNode.getChild(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<Tree> getChildrenReverse(Tree node) {
/* 142 */     return new AntlrTreeChildrenReverseIterable(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<Tree> getChildren(Tree node) {
/* 147 */     return new AntlrTreeChildrenIterable(node);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/tree/gui/TreeLayoutAdaptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */