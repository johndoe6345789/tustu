package org.antlr.v4.runtime.tree;

import org.antlr.v4.runtime.misc.Interval;

public interface SyntaxTree extends Tree {
  Interval getSourceInterval();
}


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/tree/SyntaxTree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */