/*     */ package org.antlr.v4.runtime.tree.pattern;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.misc.MultiMap;
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseTreeMatch
/*     */ {
/*     */   private final ParseTree tree;
/*     */   private final ParseTreePattern pattern;
/*     */   private final MultiMap<String, ParseTree> labels;
/*     */   private final ParseTree mismatchedNode;
/*     */   
/*     */   public ParseTreeMatch(ParseTree tree, ParseTreePattern pattern, MultiMap<String, ParseTree> labels, ParseTree mismatchedNode) {
/*  81 */     if (tree == null) {
/*  82 */       throw new IllegalArgumentException("tree cannot be null");
/*     */     }
/*     */     
/*  85 */     if (pattern == null) {
/*  86 */       throw new IllegalArgumentException("pattern cannot be null");
/*     */     }
/*     */     
/*  89 */     if (labels == null) {
/*  90 */       throw new IllegalArgumentException("labels cannot be null");
/*     */     }
/*     */     
/*  93 */     this.tree = tree;
/*  94 */     this.pattern = pattern;
/*  95 */     this.labels = labels;
/*  96 */     this.mismatchedNode = mismatchedNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTree get(String label) {
/* 117 */     List<ParseTree> parseTrees = this.labels.get(label);
/* 118 */     if (parseTrees == null || parseTrees.size() == 0) {
/* 119 */       return null;
/*     */     }
/*     */     
/* 122 */     return parseTrees.get(parseTrees.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ParseTree> getAll(String label) {
/* 150 */     List<ParseTree> nodes = this.labels.get(label);
/* 151 */     if (nodes == null) {
/* 152 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 155 */     return nodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiMap<String, ParseTree> getLabels() {
/* 170 */     return this.labels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTree getMismatchedNode() {
/* 181 */     return this.mismatchedNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean succeeded() {
/* 191 */     return (this.mismatchedNode == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreePattern getPattern() {
/* 201 */     return this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTree getTree() {
/* 211 */     return this.tree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 219 */     return String.format("Match %s; found %d labels", new Object[] { succeeded() ? "succeeded" : "failed", Integer.valueOf(getLabels().size()) });
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/tree/pattern/ParseTreeMatch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */