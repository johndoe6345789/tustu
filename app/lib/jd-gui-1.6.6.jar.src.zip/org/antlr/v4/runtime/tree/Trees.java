/*     */ package org.antlr.v4.runtime.tree;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.Parser;
/*     */ import org.antlr.v4.runtime.ParserRuleContext;
/*     */ import org.antlr.v4.runtime.Token;
/*     */ import org.antlr.v4.runtime.misc.Utils;
/*     */ import org.antlr.v4.runtime.tree.gui.TreePostScriptGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Trees
/*     */ {
/*     */   public static String getPS(Tree t, List<String> ruleNames, String fontName, int fontSize) {
/*  55 */     TreePostScriptGenerator psgen = new TreePostScriptGenerator(ruleNames, t, fontName, fontSize);
/*     */     
/*  57 */     return psgen.getPS();
/*     */   }
/*     */   
/*     */   public static String getPS(Tree t, List<String> ruleNames) {
/*  61 */     return getPS(t, ruleNames, "Helvetica", 11);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writePS(Tree t, List<String> ruleNames, String fileName, String fontName, int fontSize) throws IOException {
/*  69 */     String ps = getPS(t, ruleNames, fontName, fontSize);
/*  70 */     FileWriter f = new FileWriter(fileName);
/*  71 */     BufferedWriter bw = new BufferedWriter(f);
/*     */     try {
/*  73 */       bw.write(ps);
/*     */     } finally {
/*     */       
/*  76 */       bw.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writePS(Tree t, List<String> ruleNames, String fileName) throws IOException {
/*  83 */     writePS(t, ruleNames, fileName, "Helvetica", 11);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toStringTree(Tree t) {
/*  91 */     return toStringTree(t, (List<String>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toStringTree(Tree t, Parser recog) {
/*  99 */     String[] ruleNames = (recog != null) ? recog.getRuleNames() : null;
/* 100 */     List<String> ruleNamesList = (ruleNames != null) ? Arrays.<String>asList(ruleNames) : null;
/* 101 */     return toStringTree(t, ruleNamesList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toStringTree(Tree t, List<String> ruleNames) {
/* 109 */     String s = Utils.escapeWhitespace(getNodeText(t, ruleNames), false);
/* 110 */     if (t.getChildCount() == 0) return s; 
/* 111 */     StringBuilder buf = new StringBuilder();
/* 112 */     buf.append("(");
/* 113 */     s = Utils.escapeWhitespace(getNodeText(t, ruleNames), false);
/* 114 */     buf.append(s);
/* 115 */     buf.append(' ');
/* 116 */     for (int i = 0; i < t.getChildCount(); i++) {
/* 117 */       if (i > 0) buf.append(' '); 
/* 118 */       buf.append(toStringTree(t.getChild(i), ruleNames));
/*     */     } 
/* 120 */     buf.append(")");
/* 121 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public static String getNodeText(Tree t, Parser recog) {
/* 125 */     String[] ruleNames = (recog != null) ? recog.getRuleNames() : null;
/* 126 */     List<String> ruleNamesList = (ruleNames != null) ? Arrays.<String>asList(ruleNames) : null;
/* 127 */     return getNodeText(t, ruleNamesList);
/*     */   }
/*     */   
/*     */   public static String getNodeText(Tree t, List<String> ruleNames) {
/* 131 */     if (ruleNames != null) {
/* 132 */       if (t instanceof RuleNode) {
/* 133 */         int ruleIndex = ((RuleNode)t).getRuleContext().getRuleIndex();
/* 134 */         String ruleName = ruleNames.get(ruleIndex);
/* 135 */         return ruleName;
/*     */       } 
/* 137 */       if (t instanceof ErrorNode) {
/* 138 */         return t.toString();
/*     */       }
/* 140 */       if (t instanceof TerminalNode) {
/* 141 */         Token symbol = ((TerminalNode)t).getSymbol();
/* 142 */         if (symbol != null) {
/* 143 */           String s = symbol.getText();
/* 144 */           return s;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 149 */     Object payload = t.getPayload();
/* 150 */     if (payload instanceof Token) {
/* 151 */       return ((Token)payload).getText();
/*     */     }
/* 153 */     return t.getPayload().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Tree> getChildren(Tree t) {
/* 159 */     List<Tree> kids = new ArrayList<Tree>();
/* 160 */     for (int i = 0; i < t.getChildCount(); i++) {
/* 161 */       kids.add(t.getChild(i));
/*     */     }
/* 163 */     return kids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<? extends Tree> getAncestors(Tree t) {
/* 171 */     if (t.getParent() == null) return Collections.emptyList(); 
/* 172 */     List<Tree> ancestors = new ArrayList<Tree>();
/* 173 */     t = t.getParent();
/* 174 */     while (t != null) {
/* 175 */       ancestors.add(0, t);
/* 176 */       t = t.getParent();
/*     */     } 
/* 178 */     return ancestors;
/*     */   }
/*     */   
/*     */   public static Collection<ParseTree> findAllTokenNodes(ParseTree t, int ttype) {
/* 182 */     return findAllNodes(t, ttype, true);
/*     */   }
/*     */   
/*     */   public static Collection<ParseTree> findAllRuleNodes(ParseTree t, int ruleIndex) {
/* 186 */     return findAllNodes(t, ruleIndex, false);
/*     */   }
/*     */   
/*     */   public static List<ParseTree> findAllNodes(ParseTree t, int index, boolean findTokens) {
/* 190 */     List<ParseTree> nodes = new ArrayList<ParseTree>();
/* 191 */     _findAllNodes(t, index, findTokens, nodes);
/* 192 */     return nodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void _findAllNodes(ParseTree t, int index, boolean findTokens, List<? super ParseTree> nodes) {
/* 199 */     if (findTokens && t instanceof TerminalNode) {
/* 200 */       TerminalNode tnode = (TerminalNode)t;
/* 201 */       if (tnode.getSymbol().getType() == index) nodes.add(t);
/*     */     
/* 203 */     } else if (!findTokens && t instanceof ParserRuleContext) {
/* 204 */       ParserRuleContext ctx = (ParserRuleContext)t;
/* 205 */       if (ctx.getRuleIndex() == index) nodes.add(t);
/*     */     
/*     */     } 
/* 208 */     for (int i = 0; i < t.getChildCount(); i++) {
/* 209 */       _findAllNodes(t.getChild(i), index, findTokens, nodes);
/*     */     }
/*     */   }
/*     */   
/*     */   public static List<ParseTree> descendants(ParseTree t) {
/* 214 */     List<ParseTree> nodes = new ArrayList<ParseTree>();
/* 215 */     nodes.add(t);
/*     */     
/* 217 */     int n = t.getChildCount();
/* 218 */     for (int i = 0; i < n; i++) {
/* 219 */       nodes.addAll(descendants(t.getChild(i)));
/*     */     }
/* 221 */     return nodes;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/tree/Trees.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */