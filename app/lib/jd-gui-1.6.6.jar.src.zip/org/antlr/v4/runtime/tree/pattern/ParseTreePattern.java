/*     */ package org.antlr.v4.runtime.tree.pattern;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ import org.antlr.v4.runtime.tree.xpath.XPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseTreePattern
/*     */ {
/*     */   private final int patternRuleIndex;
/*     */   private final String pattern;
/*     */   private final ParseTree patternTree;
/*     */   private final ParseTreePatternMatcher matcher;
/*     */   
/*     */   public ParseTreePattern(ParseTreePatternMatcher matcher, String pattern, int patternRuleIndex, ParseTree patternTree) {
/*  82 */     this.matcher = matcher;
/*  83 */     this.patternRuleIndex = patternRuleIndex;
/*  84 */     this.pattern = pattern;
/*  85 */     this.patternTree = patternTree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreeMatch match(ParseTree tree) {
/*  98 */     return this.matcher.match(tree, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(ParseTree tree) {
/* 109 */     return this.matcher.match(tree, this).succeeded();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ParseTreeMatch> findAll(ParseTree tree, String xpath) {
/* 125 */     Collection<ParseTree> subtrees = XPath.findAll(tree, xpath, this.matcher.getParser());
/* 126 */     List<ParseTreeMatch> matches = new ArrayList<ParseTreeMatch>();
/* 127 */     for (ParseTree t : subtrees) {
/* 128 */       ParseTreeMatch match = match(t);
/* 129 */       if (match.succeeded()) {
/* 130 */         matches.add(match);
/*     */       }
/*     */     } 
/* 133 */     return matches;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreePatternMatcher getMatcher() {
/* 144 */     return this.matcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPattern() {
/* 154 */     return this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPatternRuleIndex() {
/* 165 */     return this.patternRuleIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTree getPatternTree() {
/* 177 */     return this.patternTree;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/tree/pattern/ParseTreePattern.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */