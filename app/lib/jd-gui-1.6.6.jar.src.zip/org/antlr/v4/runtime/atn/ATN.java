/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.antlr.v4.runtime.RuleContext;
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ATN
/*     */ {
/*     */   public static final int INVALID_ALT_NUMBER = 0;
/*  49 */   public final List<ATNState> states = new ArrayList<ATNState>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public final List<DecisionState> decisionToState = new ArrayList<DecisionState>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleStartState[] ruleToStartState;
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleStopState[] ruleToStopState;
/*     */ 
/*     */ 
/*     */   
/*  68 */   public final Map<String, TokensStartState> modeNameToStartState = new LinkedHashMap<String, TokensStartState>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ATNType grammarType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int maxTokenType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] ruleToTokenType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerAction[] lexerActions;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public final List<TokensStartState> modeToStartState = new ArrayList<TokensStartState>();
/*     */ 
/*     */   
/*     */   public ATN(ATNType grammarType, int maxTokenType) {
/* 100 */     this.grammarType = grammarType;
/* 101 */     this.maxTokenType = maxTokenType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet nextTokens(ATNState s, RuleContext ctx) {
/* 110 */     LL1Analyzer anal = new LL1Analyzer(this);
/* 111 */     IntervalSet next = anal.LOOK(s, ctx);
/* 112 */     return next;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet nextTokens(ATNState s) {
/* 121 */     if (s.nextTokenWithinRule != null) return s.nextTokenWithinRule; 
/* 122 */     s.nextTokenWithinRule = nextTokens(s, null);
/* 123 */     s.nextTokenWithinRule.setReadonly(true);
/* 124 */     return s.nextTokenWithinRule;
/*     */   }
/*     */   
/*     */   public void addState(ATNState state) {
/* 128 */     if (state != null) {
/* 129 */       state.atn = this;
/* 130 */       state.stateNumber = this.states.size();
/*     */     } 
/*     */     
/* 133 */     this.states.add(state);
/*     */   }
/*     */   
/*     */   public void removeState(ATNState state) {
/* 137 */     this.states.set(state.stateNumber, null);
/*     */   }
/*     */   
/*     */   public int defineDecisionState(DecisionState s) {
/* 141 */     this.decisionToState.add(s);
/* 142 */     s.decision = this.decisionToState.size() - 1;
/* 143 */     return s.decision;
/*     */   }
/*     */   
/*     */   public DecisionState getDecisionState(int decision) {
/* 147 */     if (!this.decisionToState.isEmpty()) {
/* 148 */       return this.decisionToState.get(decision);
/*     */     }
/* 150 */     return null;
/*     */   }
/*     */   
/*     */   public int getNumberOfDecisions() {
/* 154 */     return this.decisionToState.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet getExpectedTokens(int stateNumber, RuleContext context) {
/* 177 */     if (stateNumber < 0 || stateNumber >= this.states.size()) {
/* 178 */       throw new IllegalArgumentException("Invalid state number.");
/*     */     }
/*     */     
/* 181 */     RuleContext ctx = context;
/* 182 */     ATNState s = this.states.get(stateNumber);
/* 183 */     IntervalSet following = nextTokens(s);
/* 184 */     if (!following.contains(-2)) {
/* 185 */       return following;
/*     */     }
/*     */     
/* 188 */     IntervalSet expected = new IntervalSet(new int[0]);
/* 189 */     expected.addAll(following);
/* 190 */     expected.remove(-2);
/* 191 */     while (ctx != null && ctx.invokingState >= 0 && following.contains(-2)) {
/* 192 */       ATNState invokingState = this.states.get(ctx.invokingState);
/* 193 */       RuleTransition rt = (RuleTransition)invokingState.transition(0);
/* 194 */       following = nextTokens(rt.followState);
/* 195 */       expected.addAll(following);
/* 196 */       expected.remove(-2);
/* 197 */       ctx = ctx.parent;
/*     */     } 
/*     */     
/* 200 */     if (following.contains(-2)) {
/* 201 */       expected.add(-1);
/*     */     }
/*     */     
/* 204 */     return expected;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/ATN.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */