/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PredicateTransition
/*    */   extends AbstractPredicateTransition
/*    */ {
/*    */   public final int ruleIndex;
/*    */   public final int predIndex;
/*    */   public final boolean isCtxDependent;
/*    */   
/*    */   public PredicateTransition(ATNState target, int ruleIndex, int predIndex, boolean isCtxDependent) {
/* 47 */     super(target);
/* 48 */     this.ruleIndex = ruleIndex;
/* 49 */     this.predIndex = predIndex;
/* 50 */     this.isCtxDependent = isCtxDependent;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 55 */     return 4;
/*    */   }
/*    */   
/*    */   public boolean isEpsilon() {
/* 59 */     return true;
/*    */   }
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 63 */     return false;
/*    */   }
/*    */   
/*    */   public SemanticContext.Predicate getPredicate() {
/* 67 */     return new SemanticContext.Predicate(this.ruleIndex, this.predIndex, this.isCtxDependent);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     return "pred_" + this.ruleIndex + ":" + this.predIndex;
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/PredicateTransition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */