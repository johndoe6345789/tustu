/*      */ package org.antlr.v4.runtime.atn;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.BitSet;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.antlr.v4.runtime.NoViableAltException;
/*      */ import org.antlr.v4.runtime.Parser;
/*      */ import org.antlr.v4.runtime.ParserRuleContext;
/*      */ import org.antlr.v4.runtime.RuleContext;
/*      */ import org.antlr.v4.runtime.TokenStream;
/*      */ import org.antlr.v4.runtime.Vocabulary;
/*      */ import org.antlr.v4.runtime.VocabularyImpl;
/*      */ import org.antlr.v4.runtime.dfa.DFA;
/*      */ import org.antlr.v4.runtime.dfa.DFAState;
/*      */ import org.antlr.v4.runtime.misc.DoubleKeyMap;
/*      */ import org.antlr.v4.runtime.misc.IntervalSet;
/*      */ import org.antlr.v4.runtime.misc.Pair;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ParserATNSimulator
/*      */   extends ATNSimulator
/*      */ {
/*      */   public static final boolean debug = false;
/*      */   public static final boolean debug_list_atn_decisions = false;
/*      */   public static final boolean dfa_debug = false;
/*      */   public static final boolean retry_debug = false;
/*      */   protected final Parser parser;
/*      */   public final DFA[] decisionToDFA;
/*  302 */   private PredictionMode mode = PredictionMode.LL;
/*      */ 
/*      */ 
/*      */   
/*      */   protected DoubleKeyMap<PredictionContext, PredictionContext, PredictionContext> mergeCache;
/*      */ 
/*      */ 
/*      */   
/*      */   protected TokenStream _input;
/*      */ 
/*      */   
/*      */   protected int _startIndex;
/*      */ 
/*      */   
/*      */   protected ParserRuleContext _outerContext;
/*      */ 
/*      */   
/*      */   protected DFA _dfa;
/*      */ 
/*      */ 
/*      */   
/*      */   public ParserATNSimulator(ATN atn, DFA[] decisionToDFA, PredictionContextCache sharedContextCache) {
/*  324 */     this((Parser)null, atn, decisionToDFA, sharedContextCache);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParserATNSimulator(Parser parser, ATN atn, DFA[] decisionToDFA, PredictionContextCache sharedContextCache) {
/*  331 */     super(atn, sharedContextCache);
/*  332 */     this.parser = parser;
/*  333 */     this.decisionToDFA = decisionToDFA;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDFA() {
/*  345 */     for (int d = 0; d < this.decisionToDFA.length; d++) {
/*  346 */       this.decisionToDFA[d] = new DFA(this.atn.getDecisionState(d), d);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int adaptivePredict(TokenStream input, int decision, ParserRuleContext outerContext) {
/*  359 */     this._input = input;
/*  360 */     this._startIndex = input.index();
/*  361 */     this._outerContext = outerContext;
/*  362 */     DFA dfa = this.decisionToDFA[decision];
/*  363 */     this._dfa = dfa;
/*      */     
/*  365 */     int m = input.mark();
/*  366 */     int index = this._startIndex;
/*      */ 
/*      */     
/*      */     try {
/*      */       DFAState s0;
/*      */       
/*  372 */       if (dfa.isPrecedenceDfa()) {
/*      */ 
/*      */         
/*  375 */         s0 = dfa.getPrecedenceStartState(this.parser.getPrecedence());
/*      */       }
/*      */       else {
/*      */         
/*  379 */         s0 = dfa.s0;
/*      */       } 
/*      */       
/*  382 */       if (s0 == null) {
/*  383 */         if (outerContext == null) outerContext = ParserRuleContext.EMPTY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  395 */         if (!dfa.isPrecedenceDfa() && dfa.atnStartState instanceof StarLoopEntryState && 
/*  396 */           ((StarLoopEntryState)dfa.atnStartState).precedenceRuleDecision) {
/*  397 */           dfa.setPrecedenceDfa(true);
/*      */         }
/*      */ 
/*      */         
/*  401 */         boolean fullCtx = false;
/*  402 */         ATNConfigSet s0_closure = computeStartState(dfa.atnStartState, ParserRuleContext.EMPTY, fullCtx);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  407 */         if (dfa.isPrecedenceDfa()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  414 */           s0_closure = applyPrecedenceFilter(s0_closure);
/*  415 */           s0 = addDFAState(dfa, new DFAState(s0_closure));
/*  416 */           dfa.setPrecedenceStartState(this.parser.getPrecedence(), s0);
/*      */         } else {
/*      */           
/*  419 */           s0 = addDFAState(dfa, new DFAState(s0_closure));
/*  420 */           dfa.s0 = s0;
/*      */         } 
/*      */       } 
/*      */       
/*  424 */       int alt = execATN(dfa, s0, input, index, outerContext);
/*      */       
/*  426 */       return alt;
/*      */     } finally {
/*      */       
/*  429 */       this.mergeCache = null;
/*  430 */       this._dfa = null;
/*  431 */       input.seek(index);
/*  432 */       input.release(m);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int execATN(DFA dfa, DFAState s0, TokenStream input, int startIndex, ParserRuleContext outerContext) {
/*  476 */     DFAState previousD = s0;
/*      */ 
/*      */ 
/*      */     
/*  480 */     int t = input.LA(1);
/*      */     
/*      */     while (true) {
/*  483 */       DFAState D = getExistingTargetState(previousD, t);
/*  484 */       if (D == null) {
/*  485 */         D = computeTargetState(dfa, previousD, t);
/*      */       }
/*      */       
/*  488 */       if (D == ERROR) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  498 */         NoViableAltException e = noViableAlt(input, outerContext, previousD.configs, startIndex);
/*  499 */         input.seek(startIndex);
/*  500 */         int alt = getSynValidOrSemInvalidAltThatFinishedDecisionEntryRule(previousD.configs, outerContext);
/*  501 */         if (alt != 0) {
/*  502 */           return alt;
/*      */         }
/*  504 */         throw e;
/*      */       } 
/*      */       
/*  507 */       if (D.requiresFullContext && this.mode != PredictionMode.SLL) {
/*      */         
/*  509 */         BitSet conflictingAlts = D.configs.conflictingAlts;
/*  510 */         if (D.predicates != null) {
/*      */           
/*  512 */           int conflictIndex = input.index();
/*  513 */           if (conflictIndex != startIndex) {
/*  514 */             input.seek(startIndex);
/*      */           }
/*      */           
/*  517 */           conflictingAlts = evalSemanticContext(D.predicates, outerContext, true);
/*  518 */           if (conflictingAlts.cardinality() == 1)
/*      */           {
/*  520 */             return conflictingAlts.nextSetBit(0);
/*      */           }
/*      */           
/*  523 */           if (conflictIndex != startIndex)
/*      */           {
/*      */             
/*  526 */             input.seek(conflictIndex);
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  531 */         boolean fullCtx = true;
/*  532 */         ATNConfigSet s0_closure = computeStartState(dfa.atnStartState, outerContext, fullCtx);
/*      */ 
/*      */         
/*  535 */         reportAttemptingFullContext(dfa, conflictingAlts, D.configs, startIndex, input.index());
/*  536 */         int alt = execATNWithFullContext(dfa, D, s0_closure, input, startIndex, outerContext);
/*      */ 
/*      */         
/*  539 */         return alt;
/*      */       } 
/*      */       
/*  542 */       if (D.isAcceptState) {
/*  543 */         if (D.predicates == null) {
/*  544 */           return D.prediction;
/*      */         }
/*      */         
/*  547 */         int stopIndex = input.index();
/*  548 */         input.seek(startIndex);
/*  549 */         BitSet alts = evalSemanticContext(D.predicates, outerContext, true);
/*  550 */         switch (alts.cardinality()) {
/*      */           case 0:
/*  552 */             throw noViableAlt(input, outerContext, D.configs, startIndex);
/*      */           
/*      */           case 1:
/*  555 */             return alts.nextSetBit(0);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  560 */         reportAmbiguity(dfa, D, startIndex, stopIndex, false, alts, D.configs);
/*  561 */         return alts.nextSetBit(0);
/*      */       } 
/*      */ 
/*      */       
/*  565 */       previousD = D;
/*      */       
/*  567 */       if (t != -1) {
/*  568 */         input.consume();
/*  569 */         t = input.LA(1);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DFAState getExistingTargetState(DFAState previousD, int t) {
/*  586 */     DFAState[] edges = previousD.edges;
/*  587 */     if (edges == null || t + 1 < 0 || t + 1 >= edges.length) {
/*  588 */       return null;
/*      */     }
/*      */     
/*  591 */     return edges[t + 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DFAState computeTargetState(DFA dfa, DFAState previousD, int t) {
/*  607 */     ATNConfigSet reach = computeReachSet(previousD.configs, t, false);
/*  608 */     if (reach == null) {
/*  609 */       addDFAEdge(dfa, previousD, t, ERROR);
/*  610 */       return ERROR;
/*      */     } 
/*      */ 
/*      */     
/*  614 */     DFAState D = new DFAState(reach);
/*      */     
/*  616 */     int predictedAlt = getUniqueAlt(reach);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  627 */     if (predictedAlt != 0) {
/*      */       
/*  629 */       D.isAcceptState = true;
/*  630 */       D.configs.uniqueAlt = predictedAlt;
/*  631 */       D.prediction = predictedAlt;
/*      */     }
/*  633 */     else if (PredictionMode.hasSLLConflictTerminatingPrediction(this.mode, reach)) {
/*      */       
/*  635 */       D.configs.conflictingAlts = getConflictingAlts(reach);
/*  636 */       D.requiresFullContext = true;
/*      */       
/*  638 */       D.isAcceptState = true;
/*  639 */       D.prediction = D.configs.conflictingAlts.nextSetBit(0);
/*      */     } 
/*      */     
/*  642 */     if (D.isAcceptState && D.configs.hasSemanticContext) {
/*  643 */       predicateDFAState(D, this.atn.getDecisionState(dfa.decision));
/*  644 */       if (D.predicates != null) {
/*  645 */         D.prediction = 0;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  650 */     D = addDFAEdge(dfa, previousD, t, D);
/*  651 */     return D;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void predicateDFAState(DFAState dfaState, DecisionState decisionState) {
/*  657 */     int nalts = decisionState.getNumberOfTransitions();
/*      */ 
/*      */     
/*  660 */     BitSet altsToCollectPredsFrom = getConflictingAltsOrUniqueAlt(dfaState.configs);
/*  661 */     SemanticContext[] altToPred = getPredsForAmbigAlts(altsToCollectPredsFrom, dfaState.configs, nalts);
/*  662 */     if (altToPred != null) {
/*  663 */       dfaState.predicates = getPredicatePredictions(altsToCollectPredsFrom, altToPred);
/*  664 */       dfaState.prediction = 0;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  670 */       dfaState.prediction = altsToCollectPredsFrom.nextSetBit(0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int execATNWithFullContext(DFA dfa, DFAState D, ATNConfigSet s0, TokenStream input, int startIndex, ParserRuleContext outerContext) {
/*      */     int predictedAlt;
/*  684 */     boolean fullCtx = true;
/*  685 */     boolean foundExactAmbig = false;
/*  686 */     ATNConfigSet reach = null;
/*  687 */     ATNConfigSet previous = s0;
/*  688 */     input.seek(startIndex);
/*  689 */     int t = input.LA(1);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  695 */       reach = computeReachSet(previous, t, fullCtx);
/*  696 */       if (reach == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  706 */         NoViableAltException e = noViableAlt(input, outerContext, previous, startIndex);
/*  707 */         input.seek(startIndex);
/*  708 */         int alt = getSynValidOrSemInvalidAltThatFinishedDecisionEntryRule(previous, outerContext);
/*  709 */         if (alt != 0) {
/*  710 */           return alt;
/*      */         }
/*  712 */         throw e;
/*      */       } 
/*      */       
/*  715 */       Collection<BitSet> altSubSets = PredictionMode.getConflictingAltSubsets(reach);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  724 */       reach.uniqueAlt = getUniqueAlt(reach);
/*      */       
/*  726 */       if (reach.uniqueAlt != 0) {
/*  727 */         predictedAlt = reach.uniqueAlt;
/*      */         break;
/*      */       } 
/*  730 */       if (this.mode != PredictionMode.LL_EXACT_AMBIG_DETECTION) {
/*  731 */         predictedAlt = PredictionMode.resolvesToJustOneViableAlt(altSubSets);
/*  732 */         if (predictedAlt != 0)
/*      */         {
/*      */           break;
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  739 */       else if (PredictionMode.allSubsetsConflict(altSubSets) && PredictionMode.allSubsetsEqual(altSubSets)) {
/*      */ 
/*      */         
/*  742 */         foundExactAmbig = true;
/*  743 */         predictedAlt = PredictionMode.getSingleViableAlt(altSubSets);
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*      */ 
/*      */       
/*  751 */       previous = reach;
/*  752 */       if (t != -1) {
/*  753 */         input.consume();
/*  754 */         t = input.LA(1);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  761 */     if (reach.uniqueAlt != 0) {
/*  762 */       reportContextSensitivity(dfa, predictedAlt, reach, startIndex, input.index());
/*  763 */       return predictedAlt;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  793 */     reportAmbiguity(dfa, D, startIndex, input.index(), foundExactAmbig, (BitSet)null, reach);
/*      */     
/*  795 */     return predictedAlt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfigSet computeReachSet(ATNConfigSet closure, int t, boolean fullCtx) {
/*  803 */     if (this.mergeCache == null) {
/*  804 */       this.mergeCache = new DoubleKeyMap<PredictionContext, PredictionContext, PredictionContext>();
/*      */     }
/*      */     
/*  807 */     ATNConfigSet intermediate = new ATNConfigSet(fullCtx);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  819 */     List<ATNConfig> skippedStopStates = null;
/*      */ 
/*      */     
/*  822 */     for (ATNConfig c : closure) {
/*      */ 
/*      */       
/*  825 */       if (c.state instanceof RuleStopState) {
/*  826 */         assert c.context.isEmpty();
/*  827 */         if (fullCtx || t == -1) {
/*  828 */           if (skippedStopStates == null) {
/*  829 */             skippedStopStates = new ArrayList<ATNConfig>();
/*      */           }
/*      */           
/*  832 */           skippedStopStates.add(c);
/*      */         } 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  838 */       int n = c.state.getNumberOfTransitions();
/*  839 */       for (int ti = 0; ti < n; ti++) {
/*  840 */         Transition trans = c.state.transition(ti);
/*  841 */         ATNState target = getReachableTarget(trans, t);
/*  842 */         if (target != null) {
/*  843 */           intermediate.add(new ATNConfig(c, target), this.mergeCache);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  850 */     ATNConfigSet reach = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  861 */     if (skippedStopStates == null && t != -1) {
/*  862 */       if (intermediate.size() == 1) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  867 */         reach = intermediate;
/*      */       }
/*  869 */       else if (getUniqueAlt(intermediate) != 0) {
/*      */ 
/*      */         
/*  872 */         reach = intermediate;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  879 */     if (reach == null) {
/*  880 */       reach = new ATNConfigSet(fullCtx);
/*  881 */       Set<ATNConfig> closureBusy = new HashSet<ATNConfig>();
/*  882 */       boolean treatEofAsEpsilon = (t == -1);
/*  883 */       for (ATNConfig c : intermediate) {
/*  884 */         closure(c, reach, closureBusy, false, fullCtx, treatEofAsEpsilon);
/*      */       }
/*      */     } 
/*      */     
/*  888 */     if (t == -1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  906 */       reach = removeAllConfigsNotInRuleStopState(reach, (reach == intermediate));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  917 */     if (skippedStopStates != null && (!fullCtx || !PredictionMode.hasConfigInRuleStopState(reach))) {
/*  918 */       assert !skippedStopStates.isEmpty();
/*  919 */       for (ATNConfig c : skippedStopStates) {
/*  920 */         reach.add(c, this.mergeCache);
/*      */       }
/*      */     } 
/*      */     
/*  924 */     if (reach.isEmpty()) return null; 
/*  925 */     return reach;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfigSet removeAllConfigsNotInRuleStopState(ATNConfigSet configs, boolean lookToEndOfRule) {
/*  949 */     if (PredictionMode.allConfigsInRuleStopStates(configs)) {
/*  950 */       return configs;
/*      */     }
/*      */     
/*  953 */     ATNConfigSet result = new ATNConfigSet(configs.fullCtx);
/*  954 */     for (ATNConfig config : configs) {
/*  955 */       if (config.state instanceof RuleStopState) {
/*  956 */         result.add(config, this.mergeCache);
/*      */         
/*      */         continue;
/*      */       } 
/*  960 */       if (lookToEndOfRule && config.state.onlyHasEpsilonTransitions()) {
/*  961 */         IntervalSet nextTokens = this.atn.nextTokens(config.state);
/*  962 */         if (nextTokens.contains(-2)) {
/*  963 */           ATNState endOfRuleState = this.atn.ruleToStopState[config.state.ruleIndex];
/*  964 */           result.add(new ATNConfig(config, endOfRuleState), this.mergeCache);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  969 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfigSet computeStartState(ATNState p, RuleContext ctx, boolean fullCtx) {
/*  978 */     PredictionContext initialContext = PredictionContext.fromRuleContext(this.atn, ctx);
/*  979 */     ATNConfigSet configs = new ATNConfigSet(fullCtx);
/*      */     
/*  981 */     for (int i = 0; i < p.getNumberOfTransitions(); i++) {
/*  982 */       ATNState target = (p.transition(i)).target;
/*  983 */       ATNConfig c = new ATNConfig(target, i + 1, initialContext);
/*  984 */       Set<ATNConfig> closureBusy = new HashSet<ATNConfig>();
/*  985 */       closure(c, configs, closureBusy, true, fullCtx, false);
/*      */     } 
/*      */     
/*  988 */     return configs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfigSet applyPrecedenceFilter(ATNConfigSet configs) {
/* 1159 */     Map<Integer, PredictionContext> statesFromAlt1 = new HashMap<Integer, PredictionContext>();
/* 1160 */     ATNConfigSet configSet = new ATNConfigSet(configs.fullCtx);
/* 1161 */     for (ATNConfig config : configs) {
/*      */       
/* 1163 */       if (config.alt != 1) {
/*      */         continue;
/*      */       }
/*      */       
/* 1167 */       SemanticContext updatedContext = config.semanticContext.evalPrecedence(this.parser, this._outerContext);
/* 1168 */       if (updatedContext == null) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1173 */       statesFromAlt1.put(Integer.valueOf(config.state.stateNumber), config.context);
/* 1174 */       if (updatedContext != config.semanticContext) {
/* 1175 */         configSet.add(new ATNConfig(config, updatedContext), this.mergeCache);
/*      */         continue;
/*      */       } 
/* 1178 */       configSet.add(config, this.mergeCache);
/*      */     } 
/*      */ 
/*      */     
/* 1182 */     for (ATNConfig config : configs) {
/* 1183 */       if (config.alt == 1) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1188 */       if (!config.isPrecedenceFilterSuppressed()) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1193 */         PredictionContext context = statesFromAlt1.get(Integer.valueOf(config.state.stateNumber));
/* 1194 */         if (context != null && context.equals(config.context)) {
/*      */           continue;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1200 */       configSet.add(config, this.mergeCache);
/*      */     } 
/*      */     
/* 1203 */     return configSet;
/*      */   }
/*      */   
/*      */   protected ATNState getReachableTarget(Transition trans, int ttype) {
/* 1207 */     if (trans.matches(ttype, 0, this.atn.maxTokenType)) {
/* 1208 */       return trans.target;
/*      */     }
/*      */     
/* 1211 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SemanticContext[] getPredsForAmbigAlts(BitSet ambigAlts, ATNConfigSet configs, int nalts) {
/* 1230 */     SemanticContext[] altToPred = new SemanticContext[nalts + 1];
/* 1231 */     for (ATNConfig c : configs) {
/* 1232 */       if (ambigAlts.get(c.alt)) {
/* 1233 */         altToPred[c.alt] = SemanticContext.or(altToPred[c.alt], c.semanticContext);
/*      */       }
/*      */     } 
/*      */     
/* 1237 */     int nPredAlts = 0;
/* 1238 */     for (int i = 1; i <= nalts; i++) {
/* 1239 */       if (altToPred[i] == null) {
/* 1240 */         altToPred[i] = SemanticContext.NONE;
/*      */       }
/* 1242 */       else if (altToPred[i] != SemanticContext.NONE) {
/* 1243 */         nPredAlts++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1253 */     if (nPredAlts == 0) altToPred = null;
/*      */     
/* 1255 */     return altToPred;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected DFAState.PredPrediction[] getPredicatePredictions(BitSet ambigAlts, SemanticContext[] altToPred) {
/* 1261 */     List<DFAState.PredPrediction> pairs = new ArrayList<DFAState.PredPrediction>();
/* 1262 */     boolean containsPredicate = false;
/* 1263 */     for (int i = 1; i < altToPred.length; i++) {
/* 1264 */       SemanticContext pred = altToPred[i];
/*      */ 
/*      */       
/* 1267 */       assert pred != null;
/*      */       
/* 1269 */       if (ambigAlts != null && ambigAlts.get(i)) {
/* 1270 */         pairs.add(new DFAState.PredPrediction(pred, i));
/*      */       }
/* 1272 */       if (pred != SemanticContext.NONE) containsPredicate = true;
/*      */     
/*      */     } 
/* 1275 */     if (!containsPredicate) {
/* 1276 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1280 */     return pairs.<DFAState.PredPrediction>toArray(new DFAState.PredPrediction[pairs.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getSynValidOrSemInvalidAltThatFinishedDecisionEntryRule(ATNConfigSet configs, ParserRuleContext outerContext) {
/* 1332 */     Pair<ATNConfigSet, ATNConfigSet> sets = splitAccordingToSemanticValidity(configs, outerContext);
/*      */     
/* 1334 */     ATNConfigSet semValidConfigs = (ATNConfigSet)sets.a;
/* 1335 */     ATNConfigSet semInvalidConfigs = (ATNConfigSet)sets.b;
/* 1336 */     int alt = getAltThatFinishedDecisionEntryRule(semValidConfigs);
/* 1337 */     if (alt != 0) {
/* 1338 */       return alt;
/*      */     }
/*      */     
/* 1341 */     if (semInvalidConfigs.size() > 0) {
/* 1342 */       alt = getAltThatFinishedDecisionEntryRule(semInvalidConfigs);
/* 1343 */       if (alt != 0) {
/* 1344 */         return alt;
/*      */       }
/*      */     } 
/* 1347 */     return 0;
/*      */   }
/*      */   
/*      */   protected int getAltThatFinishedDecisionEntryRule(ATNConfigSet configs) {
/* 1351 */     IntervalSet alts = new IntervalSet(new int[0]);
/* 1352 */     for (ATNConfig c : configs) {
/* 1353 */       if (c.getOuterContextDepth() > 0 || (c.state instanceof RuleStopState && c.context.hasEmptyPath())) {
/* 1354 */         alts.add(c.alt);
/*      */       }
/*      */     } 
/* 1357 */     if (alts.size() == 0) return 0; 
/* 1358 */     return alts.getMinElement();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Pair<ATNConfigSet, ATNConfigSet> splitAccordingToSemanticValidity(ATNConfigSet configs, ParserRuleContext outerContext) {
/* 1374 */     ATNConfigSet succeeded = new ATNConfigSet(configs.fullCtx);
/* 1375 */     ATNConfigSet failed = new ATNConfigSet(configs.fullCtx);
/* 1376 */     for (ATNConfig c : configs) {
/* 1377 */       if (c.semanticContext != SemanticContext.NONE) {
/* 1378 */         boolean predicateEvaluationResult = evalSemanticContext(c.semanticContext, outerContext, c.alt, configs.fullCtx);
/* 1379 */         if (predicateEvaluationResult) {
/* 1380 */           succeeded.add(c);
/*      */           continue;
/*      */         } 
/* 1383 */         failed.add(c);
/*      */         
/*      */         continue;
/*      */       } 
/* 1387 */       succeeded.add(c);
/*      */     } 
/*      */     
/* 1390 */     return new Pair<ATNConfigSet, ATNConfigSet>(succeeded, failed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BitSet evalSemanticContext(DFAState.PredPrediction[] predPredictions, ParserRuleContext outerContext, boolean complete) {
/* 1403 */     BitSet predictions = new BitSet();
/* 1404 */     for (DFAState.PredPrediction pair : predPredictions) {
/* 1405 */       if (pair.pred == SemanticContext.NONE) {
/* 1406 */         predictions.set(pair.alt);
/* 1407 */         if (!complete) {
/*      */           break;
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1413 */         boolean fullCtx = false;
/* 1414 */         boolean predicateEvaluationResult = evalSemanticContext(pair.pred, outerContext, pair.alt, fullCtx);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1419 */         if (predicateEvaluationResult) {
/*      */           
/* 1421 */           predictions.set(pair.alt);
/* 1422 */           if (!complete) {
/*      */             break;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1428 */     return predictions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean evalSemanticContext(SemanticContext pred, ParserRuleContext parserCallStack, int alt, boolean fullCtx) {
/* 1462 */     return pred.eval(this.parser, parserCallStack);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closure(ATNConfig config, ATNConfigSet configs, Set<ATNConfig> closureBusy, boolean collectPredicates, boolean fullCtx, boolean treatEofAsEpsilon) {
/* 1479 */     int initialDepth = 0;
/* 1480 */     closureCheckingStopState(config, configs, closureBusy, collectPredicates, fullCtx, 0, treatEofAsEpsilon);
/*      */ 
/*      */     
/* 1483 */     assert !fullCtx || !configs.dipsIntoOuterContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closureCheckingStopState(ATNConfig config, ATNConfigSet configs, Set<ATNConfig> closureBusy, boolean collectPredicates, boolean fullCtx, int depth, boolean treatEofAsEpsilon) {
/* 1496 */     if (config.state instanceof RuleStopState) {
/*      */ 
/*      */       
/* 1499 */       if (!config.context.isEmpty()) {
/* 1500 */         for (int i = 0; i < config.context.size(); i++) {
/* 1501 */           if (config.context.getReturnState(i) == Integer.MAX_VALUE) {
/* 1502 */             if (fullCtx) {
/* 1503 */               configs.add(new ATNConfig(config, config.state, PredictionContext.EMPTY), this.mergeCache);
/*      */ 
/*      */             
/*      */             }
/*      */             else {
/*      */ 
/*      */               
/* 1510 */               closure_(config, configs, closureBusy, collectPredicates, fullCtx, depth, treatEofAsEpsilon);
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/* 1515 */             ATNState returnState = this.atn.states.get(config.context.getReturnState(i));
/* 1516 */             PredictionContext newContext = config.context.getParent(i);
/* 1517 */             ATNConfig c = new ATNConfig(returnState, config.alt, newContext, config.semanticContext);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1526 */             c.reachesIntoOuterContext = config.reachesIntoOuterContext;
/* 1527 */             assert depth > Integer.MIN_VALUE;
/* 1528 */             closureCheckingStopState(c, configs, closureBusy, collectPredicates, fullCtx, depth - 1, treatEofAsEpsilon);
/*      */           } 
/*      */         } 
/*      */         return;
/*      */       } 
/* 1533 */       if (fullCtx) {
/*      */         
/* 1535 */         configs.add(config, this.mergeCache);
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1545 */     closure_(config, configs, closureBusy, collectPredicates, fullCtx, depth, treatEofAsEpsilon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closure_(ATNConfig config, ATNConfigSet configs, Set<ATNConfig> closureBusy, boolean collectPredicates, boolean fullCtx, int depth, boolean treatEofAsEpsilon) {
/* 1558 */     ATNState p = config.state;
/*      */     
/* 1560 */     if (!p.onlyHasEpsilonTransitions()) {
/* 1561 */       configs.add(config, this.mergeCache);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1567 */     for (int i = 0; i < p.getNumberOfTransitions(); i++) {
/* 1568 */       Transition t = p.transition(i);
/* 1569 */       boolean continueCollecting = (!(t instanceof ActionTransition) && collectPredicates);
/*      */       
/* 1571 */       ATNConfig c = getEpsilonTarget(config, t, continueCollecting, (depth == 0), fullCtx, treatEofAsEpsilon);
/*      */       
/* 1573 */       if (c == null || (
/* 1574 */         !t.isEpsilon() && !closureBusy.add(c))) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1579 */       int newDepth = depth;
/* 1580 */       if (config.state instanceof RuleStopState) {
/* 1581 */         assert !fullCtx;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1588 */         if (!closureBusy.add(c)) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/* 1593 */         if (this._dfa != null && this._dfa.isPrecedenceDfa()) {
/* 1594 */           int outermostPrecedenceReturn = ((EpsilonTransition)t).outermostPrecedenceReturn();
/* 1595 */           if (outermostPrecedenceReturn == this._dfa.atnStartState.ruleIndex) {
/* 1596 */             c.setPrecedenceFilterSuppressed(true);
/*      */           }
/*      */         } 
/*      */         
/* 1600 */         c.reachesIntoOuterContext++;
/* 1601 */         configs.dipsIntoOuterContext = true;
/* 1602 */         assert newDepth > Integer.MIN_VALUE;
/* 1603 */         newDepth--;
/*      */       
/*      */       }
/* 1606 */       else if (t instanceof RuleTransition) {
/*      */         
/* 1608 */         if (newDepth >= 0) {
/* 1609 */           newDepth++;
/*      */         }
/*      */       } 
/*      */       
/* 1613 */       closureCheckingStopState(c, configs, closureBusy, continueCollecting, fullCtx, newDepth, treatEofAsEpsilon);
/*      */       continue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRuleName(int index) {
/* 1621 */     if (this.parser != null && index >= 0) return this.parser.getRuleNames()[index]; 
/* 1622 */     return "<rule " + index + ">";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfig getEpsilonTarget(ATNConfig config, Transition t, boolean collectPredicates, boolean inContext, boolean fullCtx, boolean treatEofAsEpsilon) {
/* 1633 */     switch (t.getSerializationType()) {
/*      */       case 3:
/* 1635 */         return ruleTransition(config, (RuleTransition)t);
/*      */       
/*      */       case 10:
/* 1638 */         return precedenceTransition(config, (PrecedencePredicateTransition)t, collectPredicates, inContext, fullCtx);
/*      */       
/*      */       case 4:
/* 1641 */         return predTransition(config, (PredicateTransition)t, collectPredicates, inContext, fullCtx);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/* 1647 */         return actionTransition(config, (ActionTransition)t);
/*      */       
/*      */       case 1:
/* 1650 */         return new ATNConfig(config, t.target);
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 5:
/*      */       case 7:
/* 1657 */         if (treatEofAsEpsilon && 
/* 1658 */           t.matches(-1, 0, 1)) {
/* 1659 */           return new ATNConfig(config, t.target);
/*      */         }
/*      */ 
/*      */         
/* 1663 */         return null;
/*      */     } 
/*      */     
/* 1666 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfig actionTransition(ATNConfig config, ActionTransition t) {
/* 1673 */     return new ATNConfig(config, t.target);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ATNConfig precedenceTransition(ATNConfig config, PrecedencePredicateTransition pt, boolean collectPredicates, boolean inContext, boolean fullCtx) {
/* 1693 */     ATNConfig c = null;
/* 1694 */     if (collectPredicates && inContext) {
/* 1695 */       if (fullCtx) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1700 */         int currentPosition = this._input.index();
/* 1701 */         this._input.seek(this._startIndex);
/* 1702 */         boolean predSucceeds = evalSemanticContext(pt.getPredicate(), this._outerContext, config.alt, fullCtx);
/* 1703 */         this._input.seek(currentPosition);
/* 1704 */         if (predSucceeds) {
/* 1705 */           c = new ATNConfig(config, pt.target);
/*      */         }
/*      */       } else {
/*      */         
/* 1709 */         SemanticContext newSemCtx = SemanticContext.and(config.semanticContext, pt.getPredicate());
/*      */         
/* 1711 */         c = new ATNConfig(config, pt.target, newSemCtx);
/*      */       } 
/*      */     } else {
/*      */       
/* 1715 */       c = new ATNConfig(config, pt.target);
/*      */     } 
/*      */ 
/*      */     
/* 1719 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfig predTransition(ATNConfig config, PredicateTransition pt, boolean collectPredicates, boolean inContext, boolean fullCtx) {
/* 1739 */     ATNConfig c = null;
/* 1740 */     if (collectPredicates && (!pt.isCtxDependent || (pt.isCtxDependent && inContext))) {
/*      */ 
/*      */       
/* 1743 */       if (fullCtx) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1748 */         int currentPosition = this._input.index();
/* 1749 */         this._input.seek(this._startIndex);
/* 1750 */         boolean predSucceeds = evalSemanticContext(pt.getPredicate(), this._outerContext, config.alt, fullCtx);
/* 1751 */         this._input.seek(currentPosition);
/* 1752 */         if (predSucceeds) {
/* 1753 */           c = new ATNConfig(config, pt.target);
/*      */         }
/*      */       } else {
/*      */         
/* 1757 */         SemanticContext newSemCtx = SemanticContext.and(config.semanticContext, pt.getPredicate());
/*      */         
/* 1759 */         c = new ATNConfig(config, pt.target, newSemCtx);
/*      */       } 
/*      */     } else {
/*      */       
/* 1763 */       c = new ATNConfig(config, pt.target);
/*      */     } 
/*      */ 
/*      */     
/* 1767 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfig ruleTransition(ATNConfig config, RuleTransition t) {
/* 1777 */     ATNState returnState = t.followState;
/* 1778 */     PredictionContext newContext = SingletonPredictionContext.create(config.context, returnState.stateNumber);
/*      */     
/* 1780 */     return new ATNConfig(config, t.target, newContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BitSet getConflictingAlts(ATNConfigSet configs) {
/* 1793 */     Collection<BitSet> altsets = PredictionMode.getConflictingAltSubsets(configs);
/* 1794 */     return PredictionMode.getAlts(altsets);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BitSet getConflictingAltsOrUniqueAlt(ATNConfigSet configs) {
/*      */     BitSet conflictingAlts;
/* 1835 */     if (configs.uniqueAlt != 0) {
/* 1836 */       conflictingAlts = new BitSet();
/* 1837 */       conflictingAlts.set(configs.uniqueAlt);
/*      */     } else {
/*      */       
/* 1840 */       conflictingAlts = configs.conflictingAlts;
/*      */     } 
/* 1842 */     return conflictingAlts;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getTokenName(int t) {
/* 1847 */     if (t == -1) {
/* 1848 */       return "EOF";
/*      */     }
/*      */     
/* 1851 */     Vocabulary vocabulary = (this.parser != null) ? this.parser.getVocabulary() : VocabularyImpl.EMPTY_VOCABULARY;
/* 1852 */     String displayName = vocabulary.getDisplayName(t);
/* 1853 */     if (displayName.equals(Integer.toString(t))) {
/* 1854 */       return displayName;
/*      */     }
/*      */     
/* 1857 */     return displayName + "<" + t + ">";
/*      */   }
/*      */   
/*      */   public String getLookaheadName(TokenStream input) {
/* 1861 */     return getTokenName(input.LA(1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dumpDeadEndConfigs(NoViableAltException nvae) {
/* 1869 */     System.err.println("dead end configs: ");
/* 1870 */     for (ATNConfig c : nvae.getDeadEndConfigs()) {
/* 1871 */       String trans = "no edges";
/* 1872 */       if (c.state.getNumberOfTransitions() > 0) {
/* 1873 */         Transition t = c.state.transition(0);
/* 1874 */         if (t instanceof AtomTransition) {
/* 1875 */           AtomTransition at = (AtomTransition)t;
/* 1876 */           trans = "Atom " + getTokenName(at.label);
/*      */         }
/* 1878 */         else if (t instanceof SetTransition) {
/* 1879 */           SetTransition st = (SetTransition)t;
/* 1880 */           boolean not = st instanceof NotSetTransition;
/* 1881 */           trans = (not ? "~" : "") + "Set " + st.set.toString();
/*      */         } 
/*      */       } 
/* 1884 */       System.err.println(c.toString(this.parser, true) + ":" + trans);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected NoViableAltException noViableAlt(TokenStream input, ParserRuleContext outerContext, ATNConfigSet configs, int startIndex) {
/* 1894 */     return new NoViableAltException(this.parser, input, input.get(startIndex), input.LT(1), configs, outerContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static int getUniqueAlt(ATNConfigSet configs) {
/* 1901 */     int alt = 0;
/* 1902 */     for (ATNConfig c : configs) {
/* 1903 */       if (alt == 0) {
/* 1904 */         alt = c.alt; continue;
/*      */       } 
/* 1906 */       if (c.alt != alt) {
/* 1907 */         return 0;
/*      */       }
/*      */     } 
/* 1910 */     return alt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DFAState addDFAEdge(DFA dfa, DFAState from, int t, DFAState to) {
/* 1942 */     if (to == null) {
/* 1943 */       return null;
/*      */     }
/*      */     
/* 1946 */     to = addDFAState(dfa, to);
/* 1947 */     if (from == null || t < -1 || t > this.atn.maxTokenType) {
/* 1948 */       return to;
/*      */     }
/*      */     
/* 1951 */     synchronized (from) {
/* 1952 */       if (from.edges == null) {
/* 1953 */         from.edges = new DFAState[this.atn.maxTokenType + 1 + 1];
/*      */       }
/*      */       
/* 1956 */       from.edges[t + 1] = to;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1963 */     return to;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DFAState addDFAState(DFA dfa, DFAState D) {
/* 1982 */     if (D == ERROR) {
/* 1983 */       return D;
/*      */     }
/*      */     
/* 1986 */     synchronized (dfa.states) {
/* 1987 */       DFAState existing = dfa.states.get(D);
/* 1988 */       if (existing != null) return existing;
/*      */       
/* 1990 */       D.stateNumber = dfa.states.size();
/* 1991 */       if (!D.configs.isReadonly()) {
/* 1992 */         D.configs.optimizeConfigs(this);
/* 1993 */         D.configs.setReadonly(true);
/*      */       } 
/* 1995 */       dfa.states.put(D, D);
/*      */       
/* 1997 */       return D;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void reportAttemptingFullContext(DFA dfa, BitSet conflictingAlts, ATNConfigSet configs, int startIndex, int stopIndex) {
/* 2007 */     if (this.parser != null) this.parser.getErrorListenerDispatch().reportAttemptingFullContext(this.parser, dfa, startIndex, stopIndex, conflictingAlts, configs);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void reportContextSensitivity(DFA dfa, int prediction, ATNConfigSet configs, int startIndex, int stopIndex) {
/* 2016 */     if (this.parser != null) this.parser.getErrorListenerDispatch().reportContextSensitivity(this.parser, dfa, startIndex, stopIndex, prediction, configs);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void reportAmbiguity(DFA dfa, DFAState D, int startIndex, int stopIndex, boolean exact, BitSet ambigAlts, ATNConfigSet configs) {
/* 2031 */     if (this.parser != null) this.parser.getErrorListenerDispatch().reportAmbiguity(this.parser, dfa, startIndex, stopIndex, exact, ambigAlts, configs);
/*      */   
/*      */   }
/*      */   
/*      */   public final void setPredictionMode(PredictionMode mode) {
/* 2036 */     this.mode = mode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final PredictionMode getPredictionMode() {
/* 2041 */     return this.mode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parser getParser() {
/* 2048 */     return this.parser;
/*      */   }
/*      */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/ParserATNSimulator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */