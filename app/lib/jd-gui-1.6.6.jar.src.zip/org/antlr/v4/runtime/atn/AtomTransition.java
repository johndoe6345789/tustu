/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.misc.IntervalSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AtomTransition
/*    */   extends Transition
/*    */ {
/*    */   public final int label;
/*    */   
/*    */   public AtomTransition(ATNState target, int label) {
/* 42 */     super(target);
/* 43 */     this.label = label;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 48 */     return 5;
/*    */   }
/*    */ 
/*    */   
/*    */   public IntervalSet label() {
/* 53 */     return IntervalSet.of(this.label);
/*    */   }
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 57 */     return (this.label == symbol);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 62 */     return String.valueOf(this.label);
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/AtomTransition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */