/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import org.antlr.v4.runtime.Lexer;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LexerIndexedCustomAction
/*     */   implements LexerAction
/*     */ {
/*     */   private final int offset;
/*     */   private final LexerAction action;
/*     */   
/*     */   public LexerIndexedCustomAction(int offset, LexerAction action) {
/*  69 */     this.offset = offset;
/*  70 */     this.action = action;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  82 */     return this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerAction getAction() {
/*  91 */     return this.action;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerActionType getActionType() {
/* 102 */     return this.action.getActionType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPositionDependent() {
/* 111 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(Lexer lexer) {
/* 123 */     this.action.execute(lexer);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 128 */     int hash = MurmurHash.initialize();
/* 129 */     hash = MurmurHash.update(hash, this.offset);
/* 130 */     hash = MurmurHash.update(hash, this.action);
/* 131 */     return MurmurHash.finish(hash, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 136 */     if (obj == this) {
/* 137 */       return true;
/*     */     }
/* 139 */     if (!(obj instanceof LexerIndexedCustomAction)) {
/* 140 */       return false;
/*     */     }
/*     */     
/* 143 */     LexerIndexedCustomAction other = (LexerIndexedCustomAction)obj;
/* 144 */     return (this.offset == other.offset && this.action.equals(other.action));
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/LexerIndexedCustomAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */