/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WildcardTransition
/*    */   extends Transition
/*    */ {
/*    */   public WildcardTransition(ATNState target) {
/* 36 */     super(target);
/*    */   }
/*    */   
/*    */   public int getSerializationType() {
/* 40 */     return 9;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 45 */     return (symbol >= minVocabSymbol && symbol <= maxVocabSymbol);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     return ".";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/WildcardTransition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */