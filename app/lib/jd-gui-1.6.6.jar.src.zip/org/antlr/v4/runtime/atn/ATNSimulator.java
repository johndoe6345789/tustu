/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import org.antlr.v4.runtime.dfa.DFAState;
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ATNSimulator
/*     */ {
/*     */   @Deprecated
/*  48 */   public static final int SERIALIZED_VERSION = ATNDeserializer.SERIALIZED_VERSION;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  58 */   public static final UUID SERIALIZED_UUID = ATNDeserializer.SERIALIZED_UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public static final DFAState ERROR = new DFAState(new ATNConfigSet()); static {
/*  91 */     ERROR.stateNumber = Integer.MAX_VALUE;
/*     */   }
/*     */   public final ATN atn;
/*     */   protected final PredictionContextCache sharedContextCache;
/*     */   
/*     */   public ATNSimulator(ATN atn, PredictionContextCache sharedContextCache) {
/*  97 */     this.atn = atn;
/*  98 */     this.sharedContextCache = sharedContextCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearDFA() {
/* 115 */     throw new UnsupportedOperationException("This ATN simulator does not support clearing the DFA.");
/*     */   }
/*     */   
/*     */   public PredictionContextCache getSharedContextCache() {
/* 119 */     return this.sharedContextCache;
/*     */   }
/*     */   
/*     */   public PredictionContext getCachedContext(PredictionContext context) {
/* 123 */     if (this.sharedContextCache == null) return context;
/*     */     
/* 125 */     synchronized (this.sharedContextCache) {
/* 126 */       IdentityHashMap<PredictionContext, PredictionContext> visited = new IdentityHashMap<PredictionContext, PredictionContext>();
/*     */       
/* 128 */       return PredictionContext.getCachedContext(context, this.sharedContextCache, visited);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static ATN deserialize(char[] data) {
/* 139 */     return (new ATNDeserializer()).deserialize(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void checkCondition(boolean condition) {
/* 147 */     (new ATNDeserializer()).checkCondition(condition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void checkCondition(boolean condition, String message) {
/* 155 */     (new ATNDeserializer()).checkCondition(condition, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int toInt(char c) {
/* 163 */     return ATNDeserializer.toInt(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int toInt32(char[] data, int offset) {
/* 171 */     return ATNDeserializer.toInt32(data, offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static long toLong(char[] data, int offset) {
/* 179 */     return ATNDeserializer.toLong(data, offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static UUID toUUID(char[] data, int offset) {
/* 187 */     return ATNDeserializer.toUUID(data, offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Transition edgeFactory(ATN atn, int type, int src, int trg, int arg1, int arg2, int arg3, List<IntervalSet> sets) {
/* 200 */     return (new ATNDeserializer()).edgeFactory(atn, type, src, trg, arg1, arg2, arg3, sets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static ATNState stateFactory(int type, int ruleIndex) {
/* 208 */     return (new ATNDeserializer()).stateFactory(type, ruleIndex);
/*     */   }
/*     */   
/*     */   public abstract void reset();
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/ATNSimulator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */