/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import org.antlr.v4.runtime.CharStream;
/*     */ import org.antlr.v4.runtime.Lexer;
/*     */ import org.antlr.v4.runtime.LexerNoViableAltException;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ import org.antlr.v4.runtime.dfa.DFAState;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LexerATNSimulator
/*     */   extends ATNSimulator
/*     */ {
/*     */   public static final boolean debug = false;
/*     */   public static final boolean dfa_debug = false;
/*     */   public static final int MIN_DFA_EDGE = 0;
/*     */   public static final int MAX_DFA_EDGE = 127;
/*     */   protected final Lexer recog;
/*     */   
/*     */   protected static class SimState
/*     */   {
/*  70 */     protected int index = -1;
/*  71 */     protected int line = 0;
/*  72 */     protected int charPos = -1;
/*     */     protected DFAState dfaState;
/*     */     
/*     */     protected void reset() {
/*  76 */       this.index = -1;
/*  77 */       this.line = 0;
/*  78 */       this.charPos = -1;
/*  79 */       this.dfaState = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   protected int startIndex = -1;
/*     */ 
/*     */   
/*  94 */   protected int line = 1;
/*     */ 
/*     */   
/*  97 */   protected int charPositionInLine = 0;
/*     */   
/*     */   public final DFA[] decisionToDFA;
/*     */   
/* 101 */   protected int mode = 0;
/*     */ 
/*     */ 
/*     */   
/* 105 */   protected final SimState prevAccept = new SimState();
/*     */   
/* 107 */   public static int match_calls = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerATNSimulator(ATN atn, DFA[] decisionToDFA, PredictionContextCache sharedContextCache) {
/* 112 */     this((Lexer)null, atn, decisionToDFA, sharedContextCache);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerATNSimulator(Lexer recog, ATN atn, DFA[] decisionToDFA, PredictionContextCache sharedContextCache) {
/* 119 */     super(atn, sharedContextCache);
/* 120 */     this.decisionToDFA = decisionToDFA;
/* 121 */     this.recog = recog;
/*     */   }
/*     */   
/*     */   public void copyState(LexerATNSimulator simulator) {
/* 125 */     this.charPositionInLine = simulator.charPositionInLine;
/* 126 */     this.line = simulator.line;
/* 127 */     this.mode = simulator.mode;
/* 128 */     this.startIndex = simulator.startIndex;
/*     */   }
/*     */   
/*     */   public int match(CharStream input, int mode) {
/* 132 */     match_calls++;
/* 133 */     this.mode = mode;
/* 134 */     int mark = input.mark();
/*     */     try {
/* 136 */       this.startIndex = input.index();
/* 137 */       this.prevAccept.reset();
/* 138 */       DFA dfa = this.decisionToDFA[mode];
/* 139 */       if (dfa.s0 == null) {
/* 140 */         return matchATN(input);
/*     */       }
/*     */       
/* 143 */       return execATN(input, dfa.s0);
/*     */     }
/*     */     finally {
/*     */       
/* 147 */       input.release(mark);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 153 */     this.prevAccept.reset();
/* 154 */     this.startIndex = -1;
/* 155 */     this.line = 1;
/* 156 */     this.charPositionInLine = 0;
/* 157 */     this.mode = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearDFA() {
/* 162 */     for (int d = 0; d < this.decisionToDFA.length; d++) {
/* 163 */       this.decisionToDFA[d] = new DFA(this.atn.getDecisionState(d), d);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int matchATN(CharStream input) {
/* 168 */     ATNState startState = this.atn.modeToStartState.get(this.mode);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     int old_mode = this.mode;
/*     */     
/* 176 */     ATNConfigSet s0_closure = computeStartState(input, startState);
/* 177 */     boolean suppressEdge = s0_closure.hasSemanticContext;
/* 178 */     s0_closure.hasSemanticContext = false;
/*     */     
/* 180 */     DFAState next = addDFAState(s0_closure);
/* 181 */     if (!suppressEdge) {
/* 182 */       (this.decisionToDFA[this.mode]).s0 = next;
/*     */     }
/*     */     
/* 185 */     int predict = execATN(input, next);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     return predict;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int execATN(CharStream input, DFAState ds0) {
/* 200 */     if (ds0.isAcceptState)
/*     */     {
/* 202 */       captureSimState(this.prevAccept, input, ds0);
/*     */     }
/*     */     
/* 205 */     int t = input.LA(1);
/*     */     
/* 207 */     DFAState s = ds0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 231 */       DFAState target = getExistingTargetState(s, t);
/* 232 */       if (target == null) {
/* 233 */         target = computeTargetState(input, s, t);
/*     */       }
/*     */       
/* 236 */       if (target == ERROR) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 244 */       if (t != -1) {
/* 245 */         consume(input);
/*     */       }
/*     */       
/* 248 */       if (target.isAcceptState) {
/* 249 */         captureSimState(this.prevAccept, input, target);
/* 250 */         if (t == -1) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */       
/* 255 */       t = input.LA(1);
/* 256 */       s = target;
/*     */     } 
/*     */     
/* 259 */     return failOrAccept(this.prevAccept, input, s.configs, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DFAState getExistingTargetState(DFAState s, int t) {
/* 275 */     if (s.edges == null || t < 0 || t > 127) {
/* 276 */       return null;
/*     */     }
/*     */     
/* 279 */     DFAState target = s.edges[t - 0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     return target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DFAState computeTargetState(CharStream input, DFAState s, int t) {
/* 302 */     ATNConfigSet reach = new OrderedATNConfigSet();
/*     */ 
/*     */ 
/*     */     
/* 306 */     getReachableConfigSet(input, s.configs, reach, t);
/*     */     
/* 308 */     if (reach.isEmpty()) {
/* 309 */       if (!reach.hasSemanticContext)
/*     */       {
/*     */         
/* 312 */         addDFAEdge(s, t, ERROR);
/*     */       }
/*     */ 
/*     */       
/* 316 */       return ERROR;
/*     */     } 
/*     */ 
/*     */     
/* 320 */     return addDFAEdge(s, t, reach);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int failOrAccept(SimState prevAccept, CharStream input, ATNConfigSet reach, int t) {
/* 326 */     if (prevAccept.dfaState != null) {
/* 327 */       LexerActionExecutor lexerActionExecutor = prevAccept.dfaState.lexerActionExecutor;
/* 328 */       accept(input, lexerActionExecutor, this.startIndex, prevAccept.index, prevAccept.line, prevAccept.charPos);
/*     */       
/* 330 */       return prevAccept.dfaState.prediction;
/*     */     } 
/*     */ 
/*     */     
/* 334 */     if (t == -1 && input.index() == this.startIndex) {
/* 335 */       return -1;
/*     */     }
/*     */     
/* 338 */     throw new LexerNoViableAltException(this.recog, input, this.startIndex, reach);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void getReachableConfigSet(CharStream input, ATNConfigSet closure, ATNConfigSet reach, int t) {
/* 349 */     int skipAlt = 0;
/* 350 */     for (ATNConfig c : closure) {
/* 351 */       boolean currentAltReachedAcceptState = (c.alt == skipAlt);
/* 352 */       if (currentAltReachedAcceptState && ((LexerATNConfig)c).hasPassedThroughNonGreedyDecision()) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 360 */       int n = c.state.getNumberOfTransitions();
/* 361 */       for (int ti = 0; ti < n; ti++) {
/* 362 */         Transition trans = c.state.transition(ti);
/* 363 */         ATNState target = getReachableTarget(trans, t);
/* 364 */         if (target != null) {
/* 365 */           LexerActionExecutor lexerActionExecutor = ((LexerATNConfig)c).getLexerActionExecutor();
/* 366 */           if (lexerActionExecutor != null) {
/* 367 */             lexerActionExecutor = lexerActionExecutor.fixOffsetBeforeMatch(input.index() - this.startIndex);
/*     */           }
/*     */           
/* 370 */           boolean treatEofAsEpsilon = (t == -1);
/* 371 */           if (closure(input, new LexerATNConfig((LexerATNConfig)c, target, lexerActionExecutor), reach, currentAltReachedAcceptState, true, treatEofAsEpsilon)) {
/*     */ 
/*     */             
/* 374 */             skipAlt = c.alt;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void accept(CharStream input, LexerActionExecutor lexerActionExecutor, int startIndex, int index, int line, int charPos) {
/* 390 */     input.seek(index);
/* 391 */     this.line = line;
/* 392 */     this.charPositionInLine = charPos;
/*     */     
/* 394 */     if (lexerActionExecutor != null && this.recog != null) {
/* 395 */       lexerActionExecutor.execute(this.recog, input, startIndex);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected ATNState getReachableTarget(Transition trans, int t) {
/* 401 */     if (trans.matches(t, 0, 65535)) {
/* 402 */       return trans.target;
/*     */     }
/*     */     
/* 405 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ATNConfigSet computeStartState(CharStream input, ATNState p) {
/* 412 */     PredictionContext initialContext = PredictionContext.EMPTY;
/* 413 */     ATNConfigSet configs = new OrderedATNConfigSet();
/* 414 */     for (int i = 0; i < p.getNumberOfTransitions(); i++) {
/* 415 */       ATNState target = (p.transition(i)).target;
/* 416 */       LexerATNConfig c = new LexerATNConfig(target, i + 1, initialContext);
/* 417 */       closure(input, c, configs, false, false, false);
/*     */     } 
/* 419 */     return configs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean closure(CharStream input, LexerATNConfig config, ATNConfigSet configs, boolean currentAltReachedAcceptState, boolean speculative, boolean treatEofAsEpsilon) {
/* 437 */     if (config.state instanceof RuleStopState) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 447 */       if (config.context == null || config.context.hasEmptyPath()) {
/* 448 */         if (config.context == null || config.context.isEmpty()) {
/* 449 */           configs.add(config);
/* 450 */           return true;
/*     */         } 
/*     */         
/* 453 */         configs.add(new LexerATNConfig(config, config.state, PredictionContext.EMPTY));
/* 454 */         currentAltReachedAcceptState = true;
/*     */       } 
/*     */ 
/*     */       
/* 458 */       if (config.context != null && !config.context.isEmpty()) {
/* 459 */         for (int j = 0; j < config.context.size(); j++) {
/* 460 */           if (config.context.getReturnState(j) != Integer.MAX_VALUE) {
/* 461 */             PredictionContext newContext = config.context.getParent(j);
/* 462 */             ATNState returnState = this.atn.states.get(config.context.getReturnState(j));
/* 463 */             LexerATNConfig c = new LexerATNConfig(config, returnState, newContext);
/* 464 */             currentAltReachedAcceptState = closure(input, c, configs, currentAltReachedAcceptState, speculative, treatEofAsEpsilon);
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 469 */       return currentAltReachedAcceptState;
/*     */     } 
/*     */ 
/*     */     
/* 473 */     if (!config.state.onlyHasEpsilonTransitions() && (
/* 474 */       !currentAltReachedAcceptState || !config.hasPassedThroughNonGreedyDecision())) {
/* 475 */       configs.add(config);
/*     */     }
/*     */ 
/*     */     
/* 479 */     ATNState p = config.state;
/* 480 */     for (int i = 0; i < p.getNumberOfTransitions(); i++) {
/* 481 */       Transition t = p.transition(i);
/* 482 */       LexerATNConfig c = getEpsilonTarget(input, config, t, configs, speculative, treatEofAsEpsilon);
/* 483 */       if (c != null) {
/* 484 */         currentAltReachedAcceptState = closure(input, c, configs, currentAltReachedAcceptState, speculative, treatEofAsEpsilon);
/*     */       }
/*     */     } 
/*     */     
/* 488 */     return currentAltReachedAcceptState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LexerATNConfig getEpsilonTarget(CharStream input, LexerATNConfig config, Transition t, ATNConfigSet configs, boolean speculative, boolean treatEofAsEpsilon) {
/*     */     RuleTransition ruleTransition;
/*     */     PredictionContext newContext;
/*     */     PredicateTransition pt;
/* 500 */     LexerATNConfig c = null;
/* 501 */     switch (t.getSerializationType()) {
/*     */       case 3:
/* 503 */         ruleTransition = (RuleTransition)t;
/* 504 */         newContext = SingletonPredictionContext.create(config.context, ruleTransition.followState.stateNumber);
/*     */         
/* 506 */         c = new LexerATNConfig(config, t.target, newContext);
/*     */         break;
/*     */       
/*     */       case 10:
/* 510 */         throw new UnsupportedOperationException("Precedence predicates are not supported in lexers.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 531 */         pt = (PredicateTransition)t;
/*     */ 
/*     */ 
/*     */         
/* 535 */         configs.hasSemanticContext = true;
/* 536 */         if (evaluatePredicate(input, pt.ruleIndex, pt.predIndex, speculative)) {
/* 537 */           c = new LexerATNConfig(config, t.target);
/*     */         }
/*     */         break;
/*     */       
/*     */       case 6:
/* 542 */         if (config.context == null || config.context.hasEmptyPath()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 555 */           LexerActionExecutor lexerActionExecutor = LexerActionExecutor.append(config.getLexerActionExecutor(), this.atn.lexerActions[((ActionTransition)t).actionIndex]);
/* 556 */           c = new LexerATNConfig(config, t.target, lexerActionExecutor);
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 561 */         c = new LexerATNConfig(config, t.target);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 1:
/* 566 */         c = new LexerATNConfig(config, t.target);
/*     */         break;
/*     */       
/*     */       case 2:
/*     */       case 5:
/*     */       case 7:
/* 572 */         if (treatEofAsEpsilon && 
/* 573 */           t.matches(-1, 0, 65535)) {
/* 574 */           c = new LexerATNConfig(config, t.target);
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 582 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean evaluatePredicate(CharStream input, int ruleIndex, int predIndex, boolean speculative) {
/* 608 */     if (this.recog == null) {
/* 609 */       return true;
/*     */     }
/*     */     
/* 612 */     if (!speculative) {
/* 613 */       return this.recog.sempred(null, ruleIndex, predIndex);
/*     */     }
/*     */     
/* 616 */     int savedCharPositionInLine = this.charPositionInLine;
/* 617 */     int savedLine = this.line;
/* 618 */     int index = input.index();
/* 619 */     int marker = input.mark();
/*     */     try {
/* 621 */       consume(input);
/* 622 */       return this.recog.sempred(null, ruleIndex, predIndex);
/*     */     } finally {
/*     */       
/* 625 */       this.charPositionInLine = savedCharPositionInLine;
/* 626 */       this.line = savedLine;
/* 627 */       input.seek(index);
/* 628 */       input.release(marker);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void captureSimState(SimState settings, CharStream input, DFAState dfaState) {
/* 636 */     settings.index = input.index();
/* 637 */     settings.line = this.line;
/* 638 */     settings.charPos = this.charPositionInLine;
/* 639 */     settings.dfaState = dfaState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DFAState addDFAEdge(DFAState from, int t, ATNConfigSet q) {
/* 658 */     boolean suppressEdge = q.hasSemanticContext;
/* 659 */     q.hasSemanticContext = false;
/*     */ 
/*     */     
/* 662 */     DFAState to = addDFAState(q);
/*     */     
/* 664 */     if (suppressEdge) {
/* 665 */       return to;
/*     */     }
/*     */     
/* 668 */     addDFAEdge(from, t, to);
/* 669 */     return to;
/*     */   }
/*     */   
/*     */   protected void addDFAEdge(DFAState p, int t, DFAState q) {
/* 673 */     if (t < 0 || t > 127) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 682 */     synchronized (p) {
/* 683 */       if (p.edges == null)
/*     */       {
/* 685 */         p.edges = new DFAState[128];
/*     */       }
/* 687 */       p.edges[t - 0] = q;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DFAState addDFAState(ATNConfigSet configs) {
/* 701 */     assert !configs.hasSemanticContext;
/*     */     
/* 703 */     DFAState proposed = new DFAState(configs);
/* 704 */     ATNConfig firstConfigWithRuleStopState = null;
/* 705 */     for (ATNConfig c : configs) {
/* 706 */       if (c.state instanceof RuleStopState) {
/* 707 */         firstConfigWithRuleStopState = c;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 712 */     if (firstConfigWithRuleStopState != null) {
/* 713 */       proposed.isAcceptState = true;
/* 714 */       proposed.lexerActionExecutor = ((LexerATNConfig)firstConfigWithRuleStopState).getLexerActionExecutor();
/* 715 */       proposed.prediction = this.atn.ruleToTokenType[firstConfigWithRuleStopState.state.ruleIndex];
/*     */     } 
/*     */     
/* 718 */     DFA dfa = this.decisionToDFA[this.mode];
/* 719 */     synchronized (dfa.states) {
/* 720 */       DFAState existing = dfa.states.get(proposed);
/* 721 */       if (existing != null) return existing;
/*     */       
/* 723 */       DFAState newState = proposed;
/*     */       
/* 725 */       newState.stateNumber = dfa.states.size();
/* 726 */       configs.setReadonly(true);
/* 727 */       newState.configs = configs;
/* 728 */       dfa.states.put(newState, newState);
/* 729 */       return newState;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final DFA getDFA(int mode) {
/* 735 */     return this.decisionToDFA[mode];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(CharStream input) {
/* 743 */     return input.getText(Interval.of(this.startIndex, input.index() - 1));
/*     */   }
/*     */   
/*     */   public int getLine() {
/* 747 */     return this.line;
/*     */   }
/*     */   
/*     */   public void setLine(int line) {
/* 751 */     this.line = line;
/*     */   }
/*     */   
/*     */   public int getCharPositionInLine() {
/* 755 */     return this.charPositionInLine;
/*     */   }
/*     */   
/*     */   public void setCharPositionInLine(int charPositionInLine) {
/* 759 */     this.charPositionInLine = charPositionInLine;
/*     */   }
/*     */   
/*     */   public void consume(CharStream input) {
/* 763 */     int curChar = input.LA(1);
/* 764 */     if (curChar == 10) {
/* 765 */       this.line++;
/* 766 */       this.charPositionInLine = 0;
/*     */     } else {
/* 768 */       this.charPositionInLine++;
/*     */     } 
/* 770 */     input.consume();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTokenName(int t) {
/* 775 */     if (t == -1) return "EOF";
/*     */     
/* 777 */     return "'" + (char)t + "'";
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/LexerATNSimulator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */