/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum LexerActionType
/*    */ {
/* 43 */   CHANNEL,
/*    */ 
/*    */ 
/*    */   
/* 47 */   CUSTOM,
/*    */ 
/*    */ 
/*    */   
/* 51 */   MODE,
/*    */ 
/*    */ 
/*    */   
/* 55 */   MORE,
/*    */ 
/*    */ 
/*    */   
/* 59 */   POP_MODE,
/*    */ 
/*    */ 
/*    */   
/* 63 */   PUSH_MODE,
/*    */ 
/*    */ 
/*    */   
/* 67 */   SKIP,
/*    */ 
/*    */ 
/*    */   
/* 71 */   TYPE;
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/LexerActionType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */