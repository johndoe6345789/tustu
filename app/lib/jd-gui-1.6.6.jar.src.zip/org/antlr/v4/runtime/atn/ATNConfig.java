/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import org.antlr.v4.runtime.Recognizer;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ATNConfig
/*     */ {
/*     */   private static final int SUPPRESS_PRECEDENCE_FILTER = 1073741824;
/*     */   public final ATNState state;
/*     */   public final int alt;
/*     */   public PredictionContext context;
/*     */   public int reachesIntoOuterContext;
/*     */   public final SemanticContext semanticContext;
/*     */   
/*     */   public ATNConfig(ATNConfig old) {
/*  94 */     this.state = old.state;
/*  95 */     this.alt = old.alt;
/*  96 */     this.context = old.context;
/*  97 */     this.semanticContext = old.semanticContext;
/*  98 */     this.reachesIntoOuterContext = old.reachesIntoOuterContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig(ATNState state, int alt, PredictionContext context) {
/* 105 */     this(state, alt, context, SemanticContext.NONE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig(ATNState state, int alt, PredictionContext context, SemanticContext semanticContext) {
/* 113 */     this.state = state;
/* 114 */     this.alt = alt;
/* 115 */     this.context = context;
/* 116 */     this.semanticContext = semanticContext;
/*     */   }
/*     */   
/*     */   public ATNConfig(ATNConfig c, ATNState state) {
/* 120 */     this(c, state, c.context, c.semanticContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig(ATNConfig c, ATNState state, SemanticContext semanticContext) {
/* 126 */     this(c, state, c.context, semanticContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig(ATNConfig c, SemanticContext semanticContext) {
/* 132 */     this(c, c.state, c.context, semanticContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig(ATNConfig c, ATNState state, PredictionContext context) {
/* 138 */     this(c, state, context, c.semanticContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig(ATNConfig c, ATNState state, PredictionContext context, SemanticContext semanticContext) {
/* 145 */     this.state = state;
/* 146 */     this.alt = c.alt;
/* 147 */     this.context = context;
/* 148 */     this.semanticContext = semanticContext;
/* 149 */     this.reachesIntoOuterContext = c.reachesIntoOuterContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getOuterContextDepth() {
/* 158 */     return this.reachesIntoOuterContext & 0xBFFFFFFF;
/*     */   }
/*     */   
/*     */   public final boolean isPrecedenceFilterSuppressed() {
/* 162 */     return ((this.reachesIntoOuterContext & 0x40000000) != 0);
/*     */   }
/*     */   
/*     */   public final void setPrecedenceFilterSuppressed(boolean value) {
/* 166 */     if (value) {
/* 167 */       this.reachesIntoOuterContext |= 0x40000000;
/*     */     } else {
/*     */       
/* 170 */       this.reachesIntoOuterContext &= 0xBFFFFFFF;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 180 */     if (!(o instanceof ATNConfig)) {
/* 181 */       return false;
/*     */     }
/*     */     
/* 184 */     return equals((ATNConfig)o);
/*     */   }
/*     */   
/*     */   public boolean equals(ATNConfig other) {
/* 188 */     if (this == other)
/* 189 */       return true; 
/* 190 */     if (other == null) {
/* 191 */       return false;
/*     */     }
/*     */     
/* 194 */     return (this.state.stateNumber == other.state.stateNumber && this.alt == other.alt && (this.context == other.context || (this.context != null && this.context.equals(other.context))) && this.semanticContext.equals(other.semanticContext) && isPrecedenceFilterSuppressed() == other.isPrecedenceFilterSuppressed());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 203 */     int hashCode = MurmurHash.initialize(7);
/* 204 */     hashCode = MurmurHash.update(hashCode, this.state.stateNumber);
/* 205 */     hashCode = MurmurHash.update(hashCode, this.alt);
/* 206 */     hashCode = MurmurHash.update(hashCode, this.context);
/* 207 */     hashCode = MurmurHash.update(hashCode, this.semanticContext);
/* 208 */     hashCode = MurmurHash.finish(hashCode, 4);
/* 209 */     return hashCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 214 */     return toString(null, true);
/*     */   }
/*     */   
/*     */   public String toString(Recognizer<?, ?> recog, boolean showAlt) {
/* 218 */     StringBuilder buf = new StringBuilder();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     buf.append('(');
/* 224 */     buf.append(this.state);
/* 225 */     if (showAlt) {
/* 226 */       buf.append(",");
/* 227 */       buf.append(this.alt);
/*     */     } 
/* 229 */     if (this.context != null) {
/* 230 */       buf.append(",[");
/* 231 */       buf.append(this.context.toString());
/* 232 */       buf.append("]");
/*     */     } 
/* 234 */     if (this.semanticContext != null && this.semanticContext != SemanticContext.NONE) {
/* 235 */       buf.append(",");
/* 236 */       buf.append(this.semanticContext);
/*     */     } 
/* 238 */     if (getOuterContextDepth() > 0) {
/* 239 */       buf.append(",up=").append(getOuterContextDepth());
/*     */     }
/* 241 */     buf.append(')');
/* 242 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/ATNConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */