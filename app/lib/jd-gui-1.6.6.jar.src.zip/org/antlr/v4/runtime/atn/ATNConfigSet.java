/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.antlr.v4.runtime.misc.AbstractEqualityComparator;
/*     */ import org.antlr.v4.runtime.misc.Array2DHashSet;
/*     */ import org.antlr.v4.runtime.misc.DoubleKeyMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ATNConfigSet
/*     */   implements Set<ATNConfig>
/*     */ {
/*     */   public static class ConfigHashSet
/*     */     extends AbstractConfigHashSet
/*     */   {
/*     */     public ConfigHashSet() {
/*  61 */       super(ATNConfigSet.ConfigEqualityComparator.INSTANCE);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class ConfigEqualityComparator extends AbstractEqualityComparator<ATNConfig> {
/*  66 */     public static final ConfigEqualityComparator INSTANCE = new ConfigEqualityComparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode(ATNConfig o) {
/*  73 */       int hashCode = 7;
/*  74 */       hashCode = 31 * hashCode + o.state.stateNumber;
/*  75 */       hashCode = 31 * hashCode + o.alt;
/*  76 */       hashCode = 31 * hashCode + o.semanticContext.hashCode();
/*  77 */       return hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(ATNConfig a, ATNConfig b) {
/*  82 */       if (a == b) return true; 
/*  83 */       if (a == null || b == null) return false; 
/*  84 */       return (a.state.stateNumber == b.state.stateNumber && a.alt == b.alt && a.semanticContext.equals(b.semanticContext));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean readonly = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractConfigHashSet configLookup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public final ArrayList<ATNConfig> configs = new ArrayList<ATNConfig>(7);
/*     */ 
/*     */   
/*     */   public int uniqueAlt;
/*     */ 
/*     */   
/*     */   protected BitSet conflictingAlts;
/*     */ 
/*     */   
/*     */   public boolean hasSemanticContext;
/*     */ 
/*     */   
/*     */   public boolean dipsIntoOuterContext;
/*     */ 
/*     */   
/*     */   public final boolean fullCtx;
/*     */ 
/*     */   
/* 123 */   private int cachedHashCode = -1;
/*     */   
/*     */   public ATNConfigSet(boolean fullCtx) {
/* 126 */     this.configLookup = new ConfigHashSet();
/* 127 */     this.fullCtx = fullCtx;
/*     */   } public ATNConfigSet() {
/* 129 */     this(true);
/*     */   }
/*     */   public ATNConfigSet(ATNConfigSet old) {
/* 132 */     this(old.fullCtx);
/* 133 */     addAll(old);
/* 134 */     this.uniqueAlt = old.uniqueAlt;
/* 135 */     this.conflictingAlts = old.conflictingAlts;
/* 136 */     this.hasSemanticContext = old.hasSemanticContext;
/* 137 */     this.dipsIntoOuterContext = old.dipsIntoOuterContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(ATNConfig config) {
/* 142 */     return add(config, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(ATNConfig config, DoubleKeyMap<PredictionContext, PredictionContext, PredictionContext> mergeCache) {
/* 159 */     if (this.readonly) throw new IllegalStateException("This set is readonly"); 
/* 160 */     if (config.semanticContext != SemanticContext.NONE) {
/* 161 */       this.hasSemanticContext = true;
/*     */     }
/* 163 */     if (config.getOuterContextDepth() > 0) {
/* 164 */       this.dipsIntoOuterContext = true;
/*     */     }
/* 166 */     ATNConfig existing = this.configLookup.getOrAdd(config);
/* 167 */     if (existing == config) {
/* 168 */       this.cachedHashCode = -1;
/* 169 */       this.configs.add(config);
/* 170 */       return true;
/*     */     } 
/*     */     
/* 173 */     boolean rootIsWildcard = !this.fullCtx;
/* 174 */     PredictionContext merged = PredictionContext.merge(existing.context, config.context, rootIsWildcard, mergeCache);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 179 */     existing.reachesIntoOuterContext = Math.max(existing.reachesIntoOuterContext, config.reachesIntoOuterContext);
/*     */ 
/*     */ 
/*     */     
/* 183 */     if (config.isPrecedenceFilterSuppressed()) {
/* 184 */       existing.setPrecedenceFilterSuppressed(true);
/*     */     }
/*     */     
/* 187 */     existing.context = merged;
/* 188 */     return true;
/*     */   }
/*     */   
/*     */   public List<ATNConfig> elements() {
/* 192 */     return this.configs;
/*     */   }
/*     */   public Set<ATNState> getStates() {
/* 195 */     Set<ATNState> states = new HashSet<ATNState>();
/* 196 */     for (ATNConfig c : this.configs) {
/* 197 */       states.add(c.state);
/*     */     }
/* 199 */     return states;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BitSet getAlts() {
/* 212 */     BitSet alts = new BitSet();
/* 213 */     for (ATNConfig config : this.configs) {
/* 214 */       alts.set(config.alt);
/*     */     }
/* 216 */     return alts;
/*     */   }
/*     */   
/*     */   public List<SemanticContext> getPredicates() {
/* 220 */     List<SemanticContext> preds = new ArrayList<SemanticContext>();
/* 221 */     for (ATNConfig c : this.configs) {
/* 222 */       if (c.semanticContext != SemanticContext.NONE) {
/* 223 */         preds.add(c.semanticContext);
/*     */       }
/*     */     } 
/* 226 */     return preds;
/*     */   }
/*     */   public ATNConfig get(int i) {
/* 229 */     return this.configs.get(i);
/*     */   }
/*     */   public void optimizeConfigs(ATNSimulator interpreter) {
/* 232 */     if (this.readonly) throw new IllegalStateException("This set is readonly"); 
/* 233 */     if (this.configLookup.isEmpty())
/*     */       return; 
/* 235 */     for (ATNConfig config : this.configs)
/*     */     {
/* 237 */       config.context = interpreter.getCachedContext(config.context);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends ATNConfig> coll) {
/* 245 */     for (ATNConfig c : coll) add(c); 
/* 246 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 251 */     if (o == this) {
/* 252 */       return true;
/*     */     }
/* 254 */     if (!(o instanceof ATNConfigSet)) {
/* 255 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 259 */     ATNConfigSet other = (ATNConfigSet)o;
/* 260 */     boolean same = (this.configs != null && this.configs.equals(other.configs) && this.fullCtx == other.fullCtx && this.uniqueAlt == other.uniqueAlt && this.conflictingAlts == other.conflictingAlts && this.hasSemanticContext == other.hasSemanticContext && this.dipsIntoOuterContext == other.dipsIntoOuterContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 269 */     return same;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 274 */     if (isReadonly()) {
/* 275 */       if (this.cachedHashCode == -1) {
/* 276 */         this.cachedHashCode = this.configs.hashCode();
/*     */       }
/*     */       
/* 279 */       return this.cachedHashCode;
/*     */     } 
/*     */     
/* 282 */     return this.configs.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 287 */     return this.configs.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 292 */     return this.configs.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 297 */     if (this.configLookup == null) {
/* 298 */       throw new UnsupportedOperationException("This method is not implemented for readonly sets.");
/*     */     }
/*     */     
/* 301 */     return this.configLookup.contains(o);
/*     */   }
/*     */   
/*     */   public boolean containsFast(ATNConfig obj) {
/* 305 */     if (this.configLookup == null) {
/* 306 */       throw new UnsupportedOperationException("This method is not implemented for readonly sets.");
/*     */     }
/*     */     
/* 309 */     return this.configLookup.containsFast(obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<ATNConfig> iterator() {
/* 314 */     return this.configs.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 319 */     if (this.readonly) throw new IllegalStateException("This set is readonly"); 
/* 320 */     this.configs.clear();
/* 321 */     this.cachedHashCode = -1;
/* 322 */     this.configLookup.clear();
/*     */   }
/*     */   
/*     */   public boolean isReadonly() {
/* 326 */     return this.readonly;
/*     */   }
/*     */   
/*     */   public void setReadonly(boolean readonly) {
/* 330 */     this.readonly = readonly;
/* 331 */     this.configLookup = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 336 */     StringBuilder buf = new StringBuilder();
/* 337 */     buf.append(elements().toString());
/* 338 */     if (this.hasSemanticContext) buf.append(",hasSemanticContext=").append(this.hasSemanticContext); 
/* 339 */     if (this.uniqueAlt != 0) buf.append(",uniqueAlt=").append(this.uniqueAlt); 
/* 340 */     if (this.conflictingAlts != null) buf.append(",conflictingAlts=").append(this.conflictingAlts); 
/* 341 */     if (this.dipsIntoOuterContext) buf.append(",dipsIntoOuterContext"); 
/* 342 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig[] toArray() {
/* 349 */     return this.configLookup.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] a) {
/* 354 */     return (T[])this.configLookup.toArray((Object[])a);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 359 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> c) {
/* 364 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> c) {
/* 369 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 374 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public static abstract class AbstractConfigHashSet
/*     */     extends Array2DHashSet<ATNConfig> {
/*     */     public AbstractConfigHashSet(AbstractEqualityComparator<? super ATNConfig> comparator) {
/* 380 */       this(comparator, 16, 2);
/*     */     }
/*     */     
/*     */     public AbstractConfigHashSet(AbstractEqualityComparator<? super ATNConfig> comparator, int initialCapacity, int initialBucketCapacity) {
/* 384 */       super(comparator, initialCapacity, initialBucketCapacity);
/*     */     }
/*     */ 
/*     */     
/*     */     protected final ATNConfig asElementType(Object o) {
/* 389 */       if (!(o instanceof ATNConfig)) {
/* 390 */         return null;
/*     */       }
/*     */       
/* 393 */       return (ATNConfig)o;
/*     */     }
/*     */ 
/*     */     
/*     */     protected final ATNConfig[][] createBuckets(int capacity) {
/* 398 */       return new ATNConfig[capacity][];
/*     */     }
/*     */ 
/*     */     
/*     */     protected final ATNConfig[] createBucket(int capacity) {
/* 403 */       return new ATNConfig[capacity];
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/ATNConfigSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */