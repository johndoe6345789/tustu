/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.io.InvalidClassException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ import org.antlr.v4.runtime.misc.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ATNDeserializer
/*     */ {
/*  54 */   public static final int SERIALIZED_VERSION = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private static final UUID BASE_SERIALIZED_UUID = UUID.fromString("33761B2D-78BB-4A43-8B0B-4F5BEE8AACF3");
/*  87 */   private static final UUID ADDED_PRECEDENCE_TRANSITIONS = UUID.fromString("1DA0C57D-6C06-438A-9B27-10BCB3CE0F61");
/*  88 */   private static final UUID ADDED_LEXER_ACTIONS = UUID.fromString("AADB8D7E-AEEF-4415-AD2B-8204D6CF042E");
/*     */   
/*  90 */   private static final List<UUID> SUPPORTED_UUIDS = new ArrayList<UUID>(); static {
/*  91 */     SUPPORTED_UUIDS.add(BASE_SERIALIZED_UUID);
/*  92 */     SUPPORTED_UUIDS.add(ADDED_PRECEDENCE_TRANSITIONS);
/*  93 */     SUPPORTED_UUIDS.add(ADDED_LEXER_ACTIONS);
/*     */   }
/*  95 */   public static final UUID SERIALIZED_UUID = ADDED_LEXER_ACTIONS;
/*     */ 
/*     */   
/*     */   private final ATNDeserializationOptions deserializationOptions;
/*     */ 
/*     */   
/*     */   public ATNDeserializer() {
/* 102 */     this(ATNDeserializationOptions.getDefaultOptions());
/*     */   }
/*     */   
/*     */   public ATNDeserializer(ATNDeserializationOptions deserializationOptions) {
/* 106 */     if (deserializationOptions == null) {
/* 107 */       deserializationOptions = ATNDeserializationOptions.getDefaultOptions();
/*     */     }
/*     */     
/* 110 */     this.deserializationOptions = deserializationOptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isFeatureSupported(UUID feature, UUID actualUuid) {
/* 127 */     int featureIndex = SUPPORTED_UUIDS.indexOf(feature);
/* 128 */     if (featureIndex < 0) {
/* 129 */       return false;
/*     */     }
/*     */     
/* 132 */     return (SUPPORTED_UUIDS.indexOf(actualUuid) >= featureIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public ATN deserialize(char[] data) {
/* 137 */     data = (char[])data.clone();
/*     */     
/* 139 */     for (int i = 1; i < data.length; i++) {
/* 140 */       data[i] = (char)(data[i] - 2);
/*     */     }
/*     */     
/* 143 */     int p = 0;
/* 144 */     int version = toInt(data[p++]);
/* 145 */     if (version != SERIALIZED_VERSION) {
/* 146 */       String reason = String.format(Locale.getDefault(), "Could not deserialize ATN with version %d (expected %d).", new Object[] { Integer.valueOf(version), Integer.valueOf(SERIALIZED_VERSION) });
/* 147 */       throw new UnsupportedOperationException(new InvalidClassException(ATN.class.getName(), reason));
/*     */     } 
/*     */     
/* 150 */     UUID uuid = toUUID(data, p);
/* 151 */     p += 8;
/* 152 */     if (!SUPPORTED_UUIDS.contains(uuid)) {
/* 153 */       String reason = String.format(Locale.getDefault(), "Could not deserialize ATN with UUID %s (expected %s or a legacy UUID).", new Object[] { uuid, SERIALIZED_UUID });
/* 154 */       throw new UnsupportedOperationException(new InvalidClassException(ATN.class.getName(), reason));
/*     */     } 
/*     */     
/* 157 */     boolean supportsPrecedencePredicates = isFeatureSupported(ADDED_PRECEDENCE_TRANSITIONS, uuid);
/* 158 */     boolean supportsLexerActions = isFeatureSupported(ADDED_LEXER_ACTIONS, uuid);
/*     */     
/* 160 */     ATNType grammarType = ATNType.values()[toInt(data[p++])];
/* 161 */     int maxTokenType = toInt(data[p++]);
/* 162 */     ATN atn = new ATN(grammarType, maxTokenType);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     List<Pair<LoopEndState, Integer>> loopBackStateNumbers = new ArrayList<Pair<LoopEndState, Integer>>();
/* 168 */     List<Pair<BlockStartState, Integer>> endStateNumbers = new ArrayList<Pair<BlockStartState, Integer>>();
/* 169 */     int nstates = toInt(data[p++]);
/* 170 */     for (int j = 0; j < nstates; j++) {
/* 171 */       int stype = toInt(data[p++]);
/*     */       
/* 173 */       if (stype == 0) {
/* 174 */         atn.addState(null);
/*     */       }
/*     */       else {
/*     */         
/* 178 */         int ruleIndex = toInt(data[p++]);
/* 179 */         if (ruleIndex == 65535) {
/* 180 */           ruleIndex = -1;
/*     */         }
/*     */         
/* 183 */         ATNState s = stateFactory(stype, ruleIndex);
/* 184 */         if (stype == 12) {
/* 185 */           int loopBackStateNumber = toInt(data[p++]);
/* 186 */           loopBackStateNumbers.add(new Pair<LoopEndState, Integer>((LoopEndState)s, Integer.valueOf(loopBackStateNumber)));
/*     */         }
/* 188 */         else if (s instanceof BlockStartState) {
/* 189 */           int endStateNumber = toInt(data[p++]);
/* 190 */           endStateNumbers.add(new Pair<BlockStartState, Integer>((BlockStartState)s, Integer.valueOf(endStateNumber)));
/*     */         } 
/* 192 */         atn.addState(s);
/*     */       } 
/*     */     } 
/*     */     
/* 196 */     for (Pair<LoopEndState, Integer> pair : loopBackStateNumbers) {
/* 197 */       ((LoopEndState)pair.a).loopBackState = atn.states.get(((Integer)pair.b).intValue());
/*     */     }
/*     */     
/* 200 */     for (Pair<BlockStartState, Integer> pair : endStateNumbers) {
/* 201 */       ((BlockStartState)pair.a).endState = (BlockEndState)atn.states.get(((Integer)pair.b).intValue());
/*     */     }
/*     */     
/* 204 */     int numNonGreedyStates = toInt(data[p++]);
/* 205 */     for (int k = 0; k < numNonGreedyStates; k++) {
/* 206 */       int stateNumber = toInt(data[p++]);
/* 207 */       ((DecisionState)atn.states.get(stateNumber)).nonGreedy = true;
/*     */     } 
/*     */     
/* 210 */     if (supportsPrecedencePredicates) {
/* 211 */       int numPrecedenceStates = toInt(data[p++]);
/* 212 */       for (int i4 = 0; i4 < numPrecedenceStates; i4++) {
/* 213 */         int stateNumber = toInt(data[p++]);
/* 214 */         ((RuleStartState)atn.states.get(stateNumber)).isPrecedenceRule = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 221 */     int nrules = toInt(data[p++]);
/* 222 */     if (atn.grammarType == ATNType.LEXER) {
/* 223 */       atn.ruleToTokenType = new int[nrules];
/*     */     }
/*     */     
/* 226 */     atn.ruleToStartState = new RuleStartState[nrules];
/* 227 */     for (int m = 0; m < nrules; m++) {
/* 228 */       int s = toInt(data[p++]);
/* 229 */       RuleStartState startState = (RuleStartState)atn.states.get(s);
/* 230 */       atn.ruleToStartState[m] = startState;
/* 231 */       if (atn.grammarType == ATNType.LEXER) {
/* 232 */         int tokenType = toInt(data[p++]);
/* 233 */         if (tokenType == 65535) {
/* 234 */           tokenType = -1;
/*     */         }
/*     */         
/* 237 */         atn.ruleToTokenType[m] = tokenType;
/*     */         
/* 239 */         if (!isFeatureSupported(ADDED_LEXER_ACTIONS, uuid)) {
/*     */ 
/*     */           
/* 242 */           int actionIndexIgnored = toInt(data[p++]);
/* 243 */           if (actionIndexIgnored == 65535) {
/* 244 */             actionIndexIgnored = -1;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 250 */     atn.ruleToStopState = new RuleStopState[nrules];
/* 251 */     for (ATNState state : atn.states) {
/* 252 */       if (!(state instanceof RuleStopState)) {
/*     */         continue;
/*     */       }
/*     */       
/* 256 */       RuleStopState stopState = (RuleStopState)state;
/* 257 */       atn.ruleToStopState[state.ruleIndex] = stopState;
/* 258 */       (atn.ruleToStartState[state.ruleIndex]).stopState = stopState;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 264 */     int nmodes = toInt(data[p++]);
/* 265 */     for (int n = 0; n < nmodes; n++) {
/* 266 */       int s = toInt(data[p++]);
/* 267 */       atn.modeToStartState.add((TokensStartState)atn.states.get(s));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 273 */     List<IntervalSet> sets = new ArrayList<IntervalSet>();
/* 274 */     int nsets = toInt(data[p++]);
/* 275 */     for (int i1 = 0; i1 < nsets; i1++) {
/* 276 */       int nintervals = toInt(data[p]);
/* 277 */       p++;
/* 278 */       IntervalSet set = new IntervalSet(new int[0]);
/* 279 */       sets.add(set);
/*     */       
/* 281 */       boolean containsEof = (toInt(data[p++]) != 0);
/* 282 */       if (containsEof) {
/* 283 */         set.add(-1);
/*     */       }
/*     */       
/* 286 */       for (int i4 = 0; i4 < nintervals; i4++) {
/* 287 */         set.add(toInt(data[p]), toInt(data[p + 1]));
/* 288 */         p += 2;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 295 */     int nedges = toInt(data[p++]);
/* 296 */     for (int i2 = 0; i2 < nedges; i2++) {
/* 297 */       int src = toInt(data[p]);
/* 298 */       int trg = toInt(data[p + 1]);
/* 299 */       int ttype = toInt(data[p + 2]);
/* 300 */       int arg1 = toInt(data[p + 3]);
/* 301 */       int arg2 = toInt(data[p + 4]);
/* 302 */       int arg3 = toInt(data[p + 5]);
/* 303 */       Transition trans = edgeFactory(atn, ttype, src, trg, arg1, arg2, arg3, sets);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 308 */       ATNState srcState = atn.states.get(src);
/* 309 */       srcState.addTransition(trans);
/* 310 */       p += 6;
/*     */     } 
/*     */ 
/*     */     
/* 314 */     for (ATNState state : atn.states) {
/* 315 */       for (int i4 = 0; i4 < state.getNumberOfTransitions(); i4++) {
/* 316 */         Transition t = state.transition(i4);
/* 317 */         if (t instanceof RuleTransition) {
/*     */ 
/*     */ 
/*     */           
/* 321 */           RuleTransition ruleTransition = (RuleTransition)t;
/* 322 */           int outermostPrecedenceReturn = -1;
/* 323 */           if ((atn.ruleToStartState[ruleTransition.target.ruleIndex]).isPrecedenceRule && 
/* 324 */             ruleTransition.precedence == 0) {
/* 325 */             outermostPrecedenceReturn = ruleTransition.target.ruleIndex;
/*     */           }
/*     */ 
/*     */           
/* 329 */           EpsilonTransition returnTransition = new EpsilonTransition(ruleTransition.followState, outermostPrecedenceReturn);
/* 330 */           atn.ruleToStopState[ruleTransition.target.ruleIndex].addTransition(returnTransition);
/*     */         } 
/*     */       } 
/*     */     } 
/* 334 */     for (ATNState state : atn.states) {
/* 335 */       if (state instanceof BlockStartState) {
/*     */         
/* 337 */         if (((BlockStartState)state).endState == null) {
/* 338 */           throw new IllegalStateException();
/*     */         }
/*     */ 
/*     */         
/* 342 */         if (((BlockStartState)state).endState.startState != null) {
/* 343 */           throw new IllegalStateException();
/*     */         }
/*     */         
/* 346 */         ((BlockStartState)state).endState.startState = (BlockStartState)state;
/*     */       } 
/*     */       
/* 349 */       if (state instanceof PlusLoopbackState) {
/* 350 */         PlusLoopbackState loopbackState = (PlusLoopbackState)state;
/* 351 */         for (int i4 = 0; i4 < loopbackState.getNumberOfTransitions(); i4++) {
/* 352 */           ATNState target = (loopbackState.transition(i4)).target;
/* 353 */           if (target instanceof PlusBlockStartState)
/* 354 */             ((PlusBlockStartState)target).loopBackState = loopbackState; 
/*     */         } 
/*     */         continue;
/*     */       } 
/* 358 */       if (state instanceof StarLoopbackState) {
/* 359 */         StarLoopbackState loopbackState = (StarLoopbackState)state;
/* 360 */         for (int i4 = 0; i4 < loopbackState.getNumberOfTransitions(); i4++) {
/* 361 */           ATNState target = (loopbackState.transition(i4)).target;
/* 362 */           if (target instanceof StarLoopEntryState) {
/* 363 */             ((StarLoopEntryState)target).loopBackState = loopbackState;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 372 */     int ndecisions = toInt(data[p++]); int i3;
/* 373 */     for (i3 = 1; i3 <= ndecisions; i3++) {
/* 374 */       int s = toInt(data[p++]);
/* 375 */       DecisionState decState = (DecisionState)atn.states.get(s);
/* 376 */       atn.decisionToState.add(decState);
/* 377 */       decState.decision = i3 - 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 383 */     if (atn.grammarType == ATNType.LEXER) {
/* 384 */       if (supportsLexerActions) {
/* 385 */         atn.lexerActions = new LexerAction[toInt(data[p++])];
/* 386 */         for (i3 = 0; i3 < atn.lexerActions.length; i3++) {
/* 387 */           LexerActionType actionType = LexerActionType.values()[toInt(data[p++])];
/* 388 */           int data1 = toInt(data[p++]);
/* 389 */           if (data1 == 65535) {
/* 390 */             data1 = -1;
/*     */           }
/*     */           
/* 393 */           int data2 = toInt(data[p++]);
/* 394 */           if (data2 == 65535) {
/* 395 */             data2 = -1;
/*     */           }
/*     */           
/* 398 */           LexerAction lexerAction = lexerActionFactory(actionType, data1, data2);
/*     */           
/* 400 */           atn.lexerActions[i3] = lexerAction;
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 407 */         List<LexerAction> legacyLexerActions = new ArrayList<LexerAction>();
/* 408 */         for (ATNState state : atn.states) {
/* 409 */           for (int i4 = 0; i4 < state.getNumberOfTransitions(); i4++) {
/* 410 */             Transition transition = state.transition(i4);
/* 411 */             if (transition instanceof ActionTransition) {
/*     */ 
/*     */ 
/*     */               
/* 415 */               int ruleIndex = ((ActionTransition)transition).ruleIndex;
/* 416 */               int actionIndex = ((ActionTransition)transition).actionIndex;
/* 417 */               LexerCustomAction lexerAction = new LexerCustomAction(ruleIndex, actionIndex);
/* 418 */               state.setTransition(i4, new ActionTransition(transition.target, ruleIndex, legacyLexerActions.size(), false));
/* 419 */               legacyLexerActions.add(lexerAction);
/*     */             } 
/*     */           } 
/*     */         } 
/* 423 */         atn.lexerActions = legacyLexerActions.<LexerAction>toArray(new LexerAction[legacyLexerActions.size()]);
/*     */       } 
/*     */     }
/*     */     
/* 427 */     markPrecedenceDecisions(atn);
/*     */     
/* 429 */     if (this.deserializationOptions.isVerifyATN()) {
/* 430 */       verifyATN(atn);
/*     */     }
/*     */     
/* 433 */     if (this.deserializationOptions.isGenerateRuleBypassTransitions() && atn.grammarType == ATNType.PARSER) {
/* 434 */       atn.ruleToTokenType = new int[atn.ruleToStartState.length];
/* 435 */       for (i3 = 0; i3 < atn.ruleToStartState.length; i3++) {
/* 436 */         atn.ruleToTokenType[i3] = atn.maxTokenType + i3 + 1;
/*     */       }
/*     */       
/* 439 */       for (i3 = 0; i3 < atn.ruleToStartState.length; i3++) {
/* 440 */         ATNState endState; BasicBlockStartState bypassStart = new BasicBlockStartState();
/* 441 */         bypassStart.ruleIndex = i3;
/* 442 */         atn.addState(bypassStart);
/*     */         
/* 444 */         BlockEndState bypassStop = new BlockEndState();
/* 445 */         bypassStop.ruleIndex = i3;
/* 446 */         atn.addState(bypassStop);
/*     */         
/* 448 */         bypassStart.endState = bypassStop;
/* 449 */         atn.defineDecisionState(bypassStart);
/*     */         
/* 451 */         bypassStop.startState = bypassStart;
/*     */ 
/*     */         
/* 454 */         Transition excludeTransition = null;
/* 455 */         if ((atn.ruleToStartState[i3]).isPrecedenceRule) {
/*     */           
/* 457 */           endState = null;
/* 458 */           for (ATNState state : atn.states) {
/* 459 */             if (state.ruleIndex != i3) {
/*     */               continue;
/*     */             }
/*     */             
/* 463 */             if (!(state instanceof StarLoopEntryState)) {
/*     */               continue;
/*     */             }
/*     */             
/* 467 */             ATNState maybeLoopEndState = (state.transition(state.getNumberOfTransitions() - 1)).target;
/* 468 */             if (!(maybeLoopEndState instanceof LoopEndState)) {
/*     */               continue;
/*     */             }
/*     */             
/* 472 */             if (maybeLoopEndState.epsilonOnlyTransitions && (maybeLoopEndState.transition(0)).target instanceof RuleStopState) {
/* 473 */               endState = state;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 478 */           if (endState == null) {
/* 479 */             throw new UnsupportedOperationException("Couldn't identify final state of the precedence rule prefix section.");
/*     */           }
/*     */           
/* 482 */           excludeTransition = ((StarLoopEntryState)endState).loopBackState.transition(0);
/*     */         } else {
/*     */           
/* 485 */           endState = atn.ruleToStopState[i3];
/*     */         } 
/*     */ 
/*     */         
/* 489 */         for (ATNState state : atn.states) {
/* 490 */           for (Transition transition : state.transitions) {
/* 491 */             if (transition == excludeTransition) {
/*     */               continue;
/*     */             }
/*     */             
/* 495 */             if (transition.target == endState) {
/* 496 */               transition.target = bypassStop;
/*     */             }
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 502 */         while (atn.ruleToStartState[i3].getNumberOfTransitions() > 0) {
/* 503 */           Transition transition = atn.ruleToStartState[i3].removeTransition(atn.ruleToStartState[i3].getNumberOfTransitions() - 1);
/* 504 */           bypassStart.addTransition(transition);
/*     */         } 
/*     */ 
/*     */         
/* 508 */         atn.ruleToStartState[i3].addTransition(new EpsilonTransition(bypassStart));
/* 509 */         bypassStop.addTransition(new EpsilonTransition(endState));
/*     */         
/* 511 */         ATNState matchState = new BasicState();
/* 512 */         atn.addState(matchState);
/* 513 */         matchState.addTransition(new AtomTransition(bypassStop, atn.ruleToTokenType[i3]));
/* 514 */         bypassStart.addTransition(new EpsilonTransition(matchState));
/*     */       } 
/*     */       
/* 517 */       if (this.deserializationOptions.isVerifyATN())
/*     */       {
/* 519 */         verifyATN(atn);
/*     */       }
/*     */     } 
/*     */     
/* 523 */     return atn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void markPrecedenceDecisions(ATN atn) {
/* 534 */     for (ATNState state : atn.states) {
/* 535 */       if (!(state instanceof StarLoopEntryState)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 543 */       if ((atn.ruleToStartState[state.ruleIndex]).isPrecedenceRule) {
/* 544 */         ATNState maybeLoopEndState = (state.transition(state.getNumberOfTransitions() - 1)).target;
/* 545 */         if (maybeLoopEndState instanceof LoopEndState && 
/* 546 */           maybeLoopEndState.epsilonOnlyTransitions && (maybeLoopEndState.transition(0)).target instanceof RuleStopState) {
/* 547 */           ((StarLoopEntryState)state).precedenceRuleDecision = true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void verifyATN(ATN atn) {
/* 556 */     for (ATNState state : atn.states) {
/* 557 */       if (state == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 561 */       checkCondition((state.onlyHasEpsilonTransitions() || state.getNumberOfTransitions() <= 1));
/*     */       
/* 563 */       if (state instanceof PlusBlockStartState) {
/* 564 */         checkCondition((((PlusBlockStartState)state).loopBackState != null));
/*     */       }
/*     */       
/* 567 */       if (state instanceof StarLoopEntryState) {
/* 568 */         StarLoopEntryState starLoopEntryState = (StarLoopEntryState)state;
/* 569 */         checkCondition((starLoopEntryState.loopBackState != null));
/* 570 */         checkCondition((starLoopEntryState.getNumberOfTransitions() == 2));
/*     */         
/* 572 */         if ((starLoopEntryState.transition(0)).target instanceof StarBlockStartState) {
/* 573 */           checkCondition((starLoopEntryState.transition(1)).target instanceof LoopEndState);
/* 574 */           checkCondition(!starLoopEntryState.nonGreedy);
/*     */         }
/* 576 */         else if ((starLoopEntryState.transition(0)).target instanceof LoopEndState) {
/* 577 */           checkCondition((starLoopEntryState.transition(1)).target instanceof StarBlockStartState);
/* 578 */           checkCondition(starLoopEntryState.nonGreedy);
/*     */         } else {
/*     */           
/* 581 */           throw new IllegalStateException();
/*     */         } 
/*     */       } 
/*     */       
/* 585 */       if (state instanceof StarLoopbackState) {
/* 586 */         checkCondition((state.getNumberOfTransitions() == 1));
/* 587 */         checkCondition((state.transition(0)).target instanceof StarLoopEntryState);
/*     */       } 
/*     */       
/* 590 */       if (state instanceof LoopEndState) {
/* 591 */         checkCondition((((LoopEndState)state).loopBackState != null));
/*     */       }
/*     */       
/* 594 */       if (state instanceof RuleStartState) {
/* 595 */         checkCondition((((RuleStartState)state).stopState != null));
/*     */       }
/*     */       
/* 598 */       if (state instanceof BlockStartState) {
/* 599 */         checkCondition((((BlockStartState)state).endState != null));
/*     */       }
/*     */       
/* 602 */       if (state instanceof BlockEndState) {
/* 603 */         checkCondition((((BlockEndState)state).startState != null));
/*     */       }
/*     */       
/* 606 */       if (state instanceof DecisionState) {
/* 607 */         DecisionState decisionState = (DecisionState)state;
/* 608 */         checkCondition((decisionState.getNumberOfTransitions() <= 1 || decisionState.decision >= 0));
/*     */         continue;
/*     */       } 
/* 611 */       checkCondition((state.getNumberOfTransitions() <= 1 || state instanceof RuleStopState));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkCondition(boolean condition) {
/* 617 */     checkCondition(condition, null);
/*     */   }
/*     */   
/*     */   protected void checkCondition(boolean condition, String message) {
/* 621 */     if (!condition) {
/* 622 */       throw new IllegalStateException(message);
/*     */     }
/*     */   }
/*     */   
/*     */   protected static int toInt(char c) {
/* 627 */     return c;
/*     */   }
/*     */   
/*     */   protected static int toInt32(char[] data, int offset) {
/* 631 */     return data[offset] | data[offset + 1] << 16;
/*     */   }
/*     */   
/*     */   protected static long toLong(char[] data, int offset) {
/* 635 */     long lowOrder = toInt32(data, offset) & 0xFFFFFFFFL;
/* 636 */     return lowOrder | toInt32(data, offset + 2) << 32L;
/*     */   }
/*     */   
/*     */   protected static UUID toUUID(char[] data, int offset) {
/* 640 */     long leastSigBits = toLong(data, offset);
/* 641 */     long mostSigBits = toLong(data, offset + 4);
/* 642 */     return new UUID(mostSigBits, leastSigBits);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Transition edgeFactory(ATN atn, int type, int src, int trg, int arg1, int arg2, int arg3, List<IntervalSet> sets) {
/*     */     RuleTransition rt;
/*     */     PredicateTransition pt;
/*     */     ActionTransition a;
/* 651 */     ATNState target = atn.states.get(trg);
/* 652 */     switch (type) { case 1:
/* 653 */         return new EpsilonTransition(target);
/*     */       case 2:
/* 655 */         if (arg3 != 0) {
/* 656 */           return new RangeTransition(target, -1, arg2);
/*     */         }
/*     */         
/* 659 */         return new RangeTransition(target, arg1, arg2);
/*     */       
/*     */       case 3:
/* 662 */         rt = new RuleTransition((RuleStartState)atn.states.get(arg1), arg2, arg3, target);
/* 663 */         return rt;
/*     */       case 4:
/* 665 */         pt = new PredicateTransition(target, arg1, arg2, (arg3 != 0));
/* 666 */         return pt;
/*     */       case 10:
/* 668 */         return new PrecedencePredicateTransition(target, arg1);
/*     */       case 5:
/* 670 */         if (arg3 != 0) {
/* 671 */           return new AtomTransition(target, -1);
/*     */         }
/*     */         
/* 674 */         return new AtomTransition(target, arg1);
/*     */       
/*     */       case 6:
/* 677 */         a = new ActionTransition(target, arg1, arg2, (arg3 != 0));
/* 678 */         return a;
/* 679 */       case 7: return new SetTransition(target, sets.get(arg1));
/* 680 */       case 8: return new NotSetTransition(target, sets.get(arg1));
/* 681 */       case 9: return new WildcardTransition(target); }
/*     */ 
/*     */     
/* 684 */     throw new IllegalArgumentException("The specified transition type is not valid.");
/*     */   }
/*     */   
/*     */   protected ATNState stateFactory(int type, int ruleIndex) {
/*     */     ATNState s;
/* 689 */     switch (type) { case 0:
/* 690 */         return null;
/* 691 */       case 1: s = new BasicState();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 708 */         s.ruleIndex = ruleIndex;
/* 709 */         return s;case 2: s = new RuleStartState(); s.ruleIndex = ruleIndex; return s;case 3: s = new BasicBlockStartState(); s.ruleIndex = ruleIndex; return s;case 4: s = new PlusBlockStartState(); s.ruleIndex = ruleIndex; return s;case 5: s = new StarBlockStartState(); s.ruleIndex = ruleIndex; return s;case 6: s = new TokensStartState(); s.ruleIndex = ruleIndex; return s;case 7: s = new RuleStopState(); s.ruleIndex = ruleIndex; return s;case 8: s = new BlockEndState(); s.ruleIndex = ruleIndex; return s;case 9: s = new StarLoopbackState(); s.ruleIndex = ruleIndex; return s;case 10: s = new StarLoopEntryState(); s.ruleIndex = ruleIndex; return s;case 11: s = new PlusLoopbackState(); s.ruleIndex = ruleIndex; return s;case 12: s = new LoopEndState(); s.ruleIndex = ruleIndex; return s; }
/*     */     
/*     */     String message = String.format(Locale.getDefault(), "The specified state type %d is not valid.", new Object[] { Integer.valueOf(type) });
/*     */     throw new IllegalArgumentException(message); } protected LexerAction lexerActionFactory(LexerActionType type, int data1, int data2) {
/* 713 */     switch (type) {
/*     */       case CHANNEL:
/* 715 */         return new LexerChannelAction(data1);
/*     */       
/*     */       case CUSTOM:
/* 718 */         return new LexerCustomAction(data1, data2);
/*     */       
/*     */       case MODE:
/* 721 */         return new LexerModeAction(data1);
/*     */       
/*     */       case MORE:
/* 724 */         return LexerMoreAction.INSTANCE;
/*     */       
/*     */       case POP_MODE:
/* 727 */         return LexerPopModeAction.INSTANCE;
/*     */       
/*     */       case PUSH_MODE:
/* 730 */         return new LexerPushModeAction(data1);
/*     */       
/*     */       case SKIP:
/* 733 */         return LexerSkipAction.INSTANCE;
/*     */       
/*     */       case TYPE:
/* 736 */         return new LexerTypeAction(data1);
/*     */     } 
/*     */     
/* 739 */     String message = String.format(Locale.getDefault(), "The specified lexer action type %d is not valid.", new Object[] { type });
/* 740 */     throw new IllegalArgumentException(message);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/ATNDeserializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */