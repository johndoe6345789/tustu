/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.misc.IntervalSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RangeTransition
/*    */   extends Transition
/*    */ {
/*    */   public final int from;
/*    */   public final int to;
/*    */   
/*    */   public RangeTransition(ATNState target, int from, int to) {
/* 41 */     super(target);
/* 42 */     this.from = from;
/* 43 */     this.to = to;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 48 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public IntervalSet label() {
/* 53 */     return IntervalSet.of(this.from, this.to);
/*    */   }
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 57 */     return (symbol >= this.from && symbol <= this.to);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 62 */     return "'" + (char)this.from + "'..'" + (char)this.to + "'";
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/RangeTransition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */