/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.antlr.v4.runtime.misc.AbstractEqualityComparator;
/*     */ import org.antlr.v4.runtime.misc.FlexibleHashMap;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PredictionMode
/*     */ {
/*  71 */   SLL,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   LL,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   LL_EXACT_AMBIG_DETECTION;
/*     */   
/*     */   static class AltAndContextMap
/*     */     extends FlexibleHashMap<ATNConfig, BitSet> {
/*     */     public AltAndContextMap() {
/* 113 */       super(PredictionMode.AltAndContextConfigEqualityComparator.INSTANCE);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class AltAndContextConfigEqualityComparator extends AbstractEqualityComparator<ATNConfig> {
/* 118 */     public static final AltAndContextConfigEqualityComparator INSTANCE = new AltAndContextConfigEqualityComparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode(ATNConfig o) {
/* 129 */       int hashCode = MurmurHash.initialize(7);
/* 130 */       hashCode = MurmurHash.update(hashCode, o.state.stateNumber);
/* 131 */       hashCode = MurmurHash.update(hashCode, o.context);
/* 132 */       hashCode = MurmurHash.finish(hashCode, 2);
/* 133 */       return hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(ATNConfig a, ATNConfig b) {
/* 138 */       if (a == b) return true; 
/* 139 */       if (a == null || b == null) return false; 
/* 140 */       return (a.state.stateNumber == b.state.stateNumber && a.context.equals(b.context));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasSLLConflictTerminatingPrediction(PredictionMode mode, ATNConfigSet configs) {
/* 243 */     if (allConfigsInRuleStopStates(configs)) {
/* 244 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 248 */     if (mode == SLL)
/*     */     {
/*     */ 
/*     */       
/* 252 */       if (configs.hasSemanticContext) {
/*     */         
/* 254 */         ATNConfigSet dup = new ATNConfigSet();
/* 255 */         for (ATNConfig c : configs) {
/* 256 */           c = new ATNConfig(c, SemanticContext.NONE);
/* 257 */           dup.add(c);
/*     */         } 
/* 259 */         configs = dup;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 266 */     Collection<BitSet> altsets = getConflictingAltSubsets(configs);
/* 267 */     boolean heuristic = (hasConflictingAltSet(altsets) && !hasStateAssociatedWithOneAlt(configs));
/*     */     
/* 269 */     return heuristic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasConfigInRuleStopState(ATNConfigSet configs) {
/* 283 */     for (ATNConfig c : configs) {
/* 284 */       if (c.state instanceof RuleStopState) {
/* 285 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 289 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean allConfigsInRuleStopStates(ATNConfigSet configs) {
/* 303 */     for (ATNConfig config : configs) {
/* 304 */       if (!(config.state instanceof RuleStopState)) {
/* 305 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 309 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int resolvesToJustOneViableAlt(Collection<BitSet> altsets) {
/* 454 */     return getSingleViableAlt(altsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean allSubsetsConflict(Collection<BitSet> altsets) {
/* 466 */     return !hasNonConflictingAltSet(altsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasNonConflictingAltSet(Collection<BitSet> altsets) {
/* 478 */     for (BitSet alts : altsets) {
/* 479 */       if (alts.cardinality() == 1) {
/* 480 */         return true;
/*     */       }
/*     */     } 
/* 483 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasConflictingAltSet(Collection<BitSet> altsets) {
/* 495 */     for (BitSet alts : altsets) {
/* 496 */       if (alts.cardinality() > 1) {
/* 497 */         return true;
/*     */       }
/*     */     } 
/* 500 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean allSubsetsEqual(Collection<BitSet> altsets) {
/* 511 */     Iterator<BitSet> it = altsets.iterator();
/* 512 */     BitSet first = it.next();
/* 513 */     while (it.hasNext()) {
/* 514 */       BitSet next = it.next();
/* 515 */       if (!next.equals(first)) return false; 
/*     */     } 
/* 517 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getUniqueAlt(Collection<BitSet> altsets) {
/* 528 */     BitSet all = getAlts(altsets);
/* 529 */     if (all.cardinality() == 1) return all.nextSetBit(0); 
/* 530 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BitSet getAlts(Collection<BitSet> altsets) {
/* 542 */     BitSet all = new BitSet();
/* 543 */     for (BitSet alts : altsets) {
/* 544 */       all.or(alts);
/*     */     }
/* 546 */     return all;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<BitSet> getConflictingAltSubsets(ATNConfigSet configs) {
/* 559 */     AltAndContextMap configToAlts = new AltAndContextMap();
/* 560 */     for (ATNConfig c : configs) {
/* 561 */       BitSet alts = configToAlts.get(c);
/* 562 */       if (alts == null) {
/* 563 */         alts = new BitSet();
/* 564 */         configToAlts.put(c, alts);
/*     */       } 
/* 566 */       alts.set(c.alt);
/*     */     } 
/* 568 */     return configToAlts.values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<ATNState, BitSet> getStateToAltMap(ATNConfigSet configs) {
/* 580 */     Map<ATNState, BitSet> m = new HashMap<ATNState, BitSet>();
/* 581 */     for (ATNConfig c : configs) {
/* 582 */       BitSet alts = m.get(c.state);
/* 583 */       if (alts == null) {
/* 584 */         alts = new BitSet();
/* 585 */         m.put(c.state, alts);
/*     */       } 
/* 587 */       alts.set(c.alt);
/*     */     } 
/* 589 */     return m;
/*     */   }
/*     */   
/*     */   public static boolean hasStateAssociatedWithOneAlt(ATNConfigSet configs) {
/* 593 */     Map<ATNState, BitSet> x = getStateToAltMap(configs);
/* 594 */     for (BitSet alts : x.values()) {
/* 595 */       if (alts.cardinality() == 1) return true; 
/*     */     } 
/* 597 */     return false;
/*     */   }
/*     */   
/*     */   public static int getSingleViableAlt(Collection<BitSet> altsets) {
/* 601 */     BitSet viableAlts = new BitSet();
/* 602 */     for (BitSet alts : altsets) {
/* 603 */       int minAlt = alts.nextSetBit(0);
/* 604 */       viableAlts.set(minAlt);
/* 605 */       if (viableAlts.cardinality() > 1) {
/* 606 */         return 0;
/*     */       }
/*     */     } 
/* 609 */     return viableAlts.nextSetBit(0);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/PredictionMode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */