/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseInfo
/*     */ {
/*     */   protected final ProfilingATNSimulator atnSimulator;
/*     */   
/*     */   public ParseInfo(ProfilingATNSimulator atnSimulator) {
/*  49 */     this.atnSimulator = atnSimulator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DecisionInfo[] getDecisionInfo() {
/*  60 */     return this.atnSimulator.getDecisionInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Integer> getLLDecisions() {
/*  72 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/*  73 */     List<Integer> LL = new ArrayList<Integer>();
/*  74 */     for (int i = 0; i < decisions.length; i++) {
/*  75 */       long fallBack = (decisions[i]).LL_Fallback;
/*  76 */       if (fallBack > 0L) LL.add(Integer.valueOf(i)); 
/*     */     } 
/*  78 */     return LL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTotalTimeInPrediction() {
/*  87 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/*  88 */     long t = 0L;
/*  89 */     for (int i = 0; i < decisions.length; i++) {
/*  90 */       t += (decisions[i]).timeInPrediction;
/*     */     }
/*  92 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTotalSLLLookaheadOps() {
/* 101 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/* 102 */     long k = 0L;
/* 103 */     for (int i = 0; i < decisions.length; i++) {
/* 104 */       k += (decisions[i]).SLL_TotalLook;
/*     */     }
/* 106 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTotalLLLookaheadOps() {
/* 115 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/* 116 */     long k = 0L;
/* 117 */     for (int i = 0; i < decisions.length; i++) {
/* 118 */       k += (decisions[i]).LL_TotalLook;
/*     */     }
/* 120 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTotalSLLATNLookaheadOps() {
/* 128 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/* 129 */     long k = 0L;
/* 130 */     for (int i = 0; i < decisions.length; i++) {
/* 131 */       k += (decisions[i]).SLL_ATNTransitions;
/*     */     }
/* 133 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTotalLLATNLookaheadOps() {
/* 141 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/* 142 */     long k = 0L;
/* 143 */     for (int i = 0; i < decisions.length; i++) {
/* 144 */       k += (decisions[i]).LL_ATNTransitions;
/*     */     }
/* 146 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTotalATNLookaheadOps() {
/* 158 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/* 159 */     long k = 0L;
/* 160 */     for (int i = 0; i < decisions.length; i++) {
/* 161 */       k += (decisions[i]).SLL_ATNTransitions;
/* 162 */       k += (decisions[i]).LL_ATNTransitions;
/*     */     } 
/* 164 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDFASize() {
/* 172 */     int n = 0;
/* 173 */     DFA[] decisionToDFA = this.atnSimulator.decisionToDFA;
/* 174 */     for (int i = 0; i < decisionToDFA.length; i++) {
/* 175 */       n += getDFASize(i);
/*     */     }
/* 177 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDFASize(int decision) {
/* 185 */     DFA decisionToDFA = this.atnSimulator.decisionToDFA[decision];
/* 186 */     return decisionToDFA.states.size();
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/ParseInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */