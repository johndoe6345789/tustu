/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ATNDeserializationOptions
/*    */ {
/* 42 */   private static final ATNDeserializationOptions defaultOptions = new ATNDeserializationOptions(); static {
/* 43 */     defaultOptions.makeReadOnly();
/*    */   }
/*    */   
/*    */   private boolean readOnly;
/*    */   private boolean verifyATN;
/*    */   private boolean generateRuleBypassTransitions;
/*    */   
/*    */   public ATNDeserializationOptions() {
/* 51 */     this.verifyATN = true;
/* 52 */     this.generateRuleBypassTransitions = false;
/*    */   }
/*    */   
/*    */   public ATNDeserializationOptions(ATNDeserializationOptions options) {
/* 56 */     this.verifyATN = options.verifyATN;
/* 57 */     this.generateRuleBypassTransitions = options.generateRuleBypassTransitions;
/*    */   }
/*    */ 
/*    */   
/*    */   public static ATNDeserializationOptions getDefaultOptions() {
/* 62 */     return defaultOptions;
/*    */   }
/*    */   
/*    */   public final boolean isReadOnly() {
/* 66 */     return this.readOnly;
/*    */   }
/*    */   
/*    */   public final void makeReadOnly() {
/* 70 */     this.readOnly = true;
/*    */   }
/*    */   
/*    */   public final boolean isVerifyATN() {
/* 74 */     return this.verifyATN;
/*    */   }
/*    */   
/*    */   public final void setVerifyATN(boolean verifyATN) {
/* 78 */     throwIfReadOnly();
/* 79 */     this.verifyATN = verifyATN;
/*    */   }
/*    */   
/*    */   public final boolean isGenerateRuleBypassTransitions() {
/* 83 */     return this.generateRuleBypassTransitions;
/*    */   }
/*    */   
/*    */   public final void setGenerateRuleBypassTransitions(boolean generateRuleBypassTransitions) {
/* 87 */     throwIfReadOnly();
/* 88 */     this.generateRuleBypassTransitions = generateRuleBypassTransitions;
/*    */   }
/*    */   
/*    */   protected void throwIfReadOnly() {
/* 92 */     if (isReadOnly())
/* 93 */       throw new IllegalStateException("The object is read only."); 
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/ATNDeserializationOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */