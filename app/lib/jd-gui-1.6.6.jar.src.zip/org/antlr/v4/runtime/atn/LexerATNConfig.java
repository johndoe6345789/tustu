/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ import org.antlr.v4.runtime.misc.ObjectEqualityComparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LexerATNConfig
/*     */   extends ATNConfig
/*     */ {
/*     */   private final LexerActionExecutor lexerActionExecutor;
/*     */   private final boolean passedThroughNonGreedyDecision;
/*     */   
/*     */   public LexerATNConfig(ATNState state, int alt, PredictionContext context) {
/*  49 */     super(state, alt, context, SemanticContext.NONE);
/*  50 */     this.passedThroughNonGreedyDecision = false;
/*  51 */     this.lexerActionExecutor = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerATNConfig(ATNState state, int alt, PredictionContext context, LexerActionExecutor lexerActionExecutor) {
/*  59 */     super(state, alt, context, SemanticContext.NONE);
/*  60 */     this.lexerActionExecutor = lexerActionExecutor;
/*  61 */     this.passedThroughNonGreedyDecision = false;
/*     */   }
/*     */   
/*     */   public LexerATNConfig(LexerATNConfig c, ATNState state) {
/*  65 */     super(c, state, c.context, c.semanticContext);
/*  66 */     this.lexerActionExecutor = c.lexerActionExecutor;
/*  67 */     this.passedThroughNonGreedyDecision = checkNonGreedyDecision(c, state);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerATNConfig(LexerATNConfig c, ATNState state, LexerActionExecutor lexerActionExecutor) {
/*  73 */     super(c, state, c.context, c.semanticContext);
/*  74 */     this.lexerActionExecutor = lexerActionExecutor;
/*  75 */     this.passedThroughNonGreedyDecision = checkNonGreedyDecision(c, state);
/*     */   }
/*     */ 
/*     */   
/*     */   public LexerATNConfig(LexerATNConfig c, ATNState state, PredictionContext context) {
/*  80 */     super(c, state, context, c.semanticContext);
/*  81 */     this.lexerActionExecutor = c.lexerActionExecutor;
/*  82 */     this.passedThroughNonGreedyDecision = checkNonGreedyDecision(c, state);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final LexerActionExecutor getLexerActionExecutor() {
/*  90 */     return this.lexerActionExecutor;
/*     */   }
/*     */   
/*     */   public final boolean hasPassedThroughNonGreedyDecision() {
/*  94 */     return this.passedThroughNonGreedyDecision;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  99 */     int hashCode = MurmurHash.initialize(7);
/* 100 */     hashCode = MurmurHash.update(hashCode, this.state.stateNumber);
/* 101 */     hashCode = MurmurHash.update(hashCode, this.alt);
/* 102 */     hashCode = MurmurHash.update(hashCode, this.context);
/* 103 */     hashCode = MurmurHash.update(hashCode, this.semanticContext);
/* 104 */     hashCode = MurmurHash.update(hashCode, this.passedThroughNonGreedyDecision ? 1 : 0);
/* 105 */     hashCode = MurmurHash.update(hashCode, this.lexerActionExecutor);
/* 106 */     hashCode = MurmurHash.finish(hashCode, 6);
/* 107 */     return hashCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(ATNConfig other) {
/* 112 */     if (this == other) {
/* 113 */       return true;
/*     */     }
/* 115 */     if (!(other instanceof LexerATNConfig)) {
/* 116 */       return false;
/*     */     }
/*     */     
/* 119 */     LexerATNConfig lexerOther = (LexerATNConfig)other;
/* 120 */     if (this.passedThroughNonGreedyDecision != lexerOther.passedThroughNonGreedyDecision) {
/* 121 */       return false;
/*     */     }
/*     */     
/* 124 */     if (!ObjectEqualityComparator.INSTANCE.equals(this.lexerActionExecutor, lexerOther.lexerActionExecutor)) {
/* 125 */       return false;
/*     */     }
/*     */     
/* 128 */     return super.equals(other);
/*     */   }
/*     */   
/*     */   private static boolean checkNonGreedyDecision(LexerATNConfig source, ATNState target) {
/* 132 */     return (source.passedThroughNonGreedyDecision || (target instanceof DecisionState && ((DecisionState)target).nonGreedy));
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/LexerATNConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */