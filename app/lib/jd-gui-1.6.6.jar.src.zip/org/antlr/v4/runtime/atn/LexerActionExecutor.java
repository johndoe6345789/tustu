/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.antlr.v4.runtime.CharStream;
/*     */ import org.antlr.v4.runtime.Lexer;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LexerActionExecutor
/*     */ {
/*     */   private final LexerAction[] lexerActions;
/*     */   private final int hashCode;
/*     */   
/*     */   public LexerActionExecutor(LexerAction[] lexerActions) {
/*  67 */     this.lexerActions = lexerActions;
/*     */     
/*  69 */     int hash = MurmurHash.initialize();
/*  70 */     for (LexerAction lexerAction : lexerActions) {
/*  71 */       hash = MurmurHash.update(hash, lexerAction);
/*     */     }
/*     */     
/*  74 */     this.hashCode = MurmurHash.finish(hash, lexerActions.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LexerActionExecutor append(LexerActionExecutor lexerActionExecutor, LexerAction lexerAction) {
/*  93 */     if (lexerActionExecutor == null) {
/*  94 */       return new LexerActionExecutor(new LexerAction[] { lexerAction });
/*     */     }
/*     */     
/*  97 */     LexerAction[] lexerActions = Arrays.<LexerAction>copyOf(lexerActionExecutor.lexerActions, lexerActionExecutor.lexerActions.length + 1);
/*  98 */     lexerActions[lexerActions.length - 1] = lexerAction;
/*  99 */     return new LexerActionExecutor(lexerActions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerActionExecutor fixOffsetBeforeMatch(int offset) {
/* 132 */     LexerAction[] updatedLexerActions = null;
/* 133 */     for (int i = 0; i < this.lexerActions.length; i++) {
/* 134 */       if (this.lexerActions[i].isPositionDependent() && !(this.lexerActions[i] instanceof LexerIndexedCustomAction)) {
/* 135 */         if (updatedLexerActions == null) {
/* 136 */           updatedLexerActions = (LexerAction[])this.lexerActions.clone();
/*     */         }
/*     */         
/* 139 */         updatedLexerActions[i] = new LexerIndexedCustomAction(offset, this.lexerActions[i]);
/*     */       } 
/*     */     } 
/*     */     
/* 143 */     if (updatedLexerActions == null) {
/* 144 */       return this;
/*     */     }
/*     */     
/* 147 */     return new LexerActionExecutor(updatedLexerActions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerAction[] getLexerActions() {
/* 155 */     return this.lexerActions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(Lexer lexer, CharStream input, int startIndex) {
/* 178 */     boolean requiresSeek = false;
/* 179 */     int stopIndex = input.index();
/*     */     try {
/* 181 */       for (LexerAction lexerAction : this.lexerActions) {
/* 182 */         if (lexerAction instanceof LexerIndexedCustomAction) {
/* 183 */           int offset = ((LexerIndexedCustomAction)lexerAction).getOffset();
/* 184 */           input.seek(startIndex + offset);
/* 185 */           lexerAction = ((LexerIndexedCustomAction)lexerAction).getAction();
/* 186 */           requiresSeek = (startIndex + offset != stopIndex);
/*     */         }
/* 188 */         else if (lexerAction.isPositionDependent()) {
/* 189 */           input.seek(stopIndex);
/* 190 */           requiresSeek = false;
/*     */         } 
/*     */         
/* 193 */         lexerAction.execute(lexer);
/*     */       } 
/*     */     } finally {
/*     */       
/* 197 */       if (requiresSeek) {
/* 198 */         input.seek(stopIndex);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 205 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 210 */     if (obj == this) {
/* 211 */       return true;
/*     */     }
/* 213 */     if (!(obj instanceof LexerActionExecutor)) {
/* 214 */       return false;
/*     */     }
/*     */     
/* 217 */     LexerActionExecutor other = (LexerActionExecutor)obj;
/* 218 */     return (this.hashCode == other.hashCode && Arrays.equals((Object[])this.lexerActions, (Object[])other.lexerActions));
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/LexerActionExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */