/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.antlr.v4.runtime.Recognizer;
/*     */ import org.antlr.v4.runtime.RuleContext;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ import org.antlr.v4.runtime.misc.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SemanticContext
/*     */ {
/*  60 */   public static final SemanticContext NONE = new Predicate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SemanticContext evalPrecedence(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/*  96 */     return this;
/*     */   }
/*     */   
/*     */   public static class Predicate extends SemanticContext {
/*     */     public final int ruleIndex;
/*     */     public final int predIndex;
/*     */     public final boolean isCtxDependent;
/*     */     
/*     */     protected Predicate() {
/* 105 */       this.ruleIndex = -1;
/* 106 */       this.predIndex = -1;
/* 107 */       this.isCtxDependent = false;
/*     */     }
/*     */     
/*     */     public Predicate(int ruleIndex, int predIndex, boolean isCtxDependent) {
/* 111 */       this.ruleIndex = ruleIndex;
/* 112 */       this.predIndex = predIndex;
/* 113 */       this.isCtxDependent = isCtxDependent;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean eval(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/* 118 */       RuleContext localctx = this.isCtxDependent ? parserCallStack : null;
/* 119 */       return parser.sempred(localctx, this.ruleIndex, this.predIndex);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 124 */       int hashCode = MurmurHash.initialize();
/* 125 */       hashCode = MurmurHash.update(hashCode, this.ruleIndex);
/* 126 */       hashCode = MurmurHash.update(hashCode, this.predIndex);
/* 127 */       hashCode = MurmurHash.update(hashCode, this.isCtxDependent ? 1 : 0);
/* 128 */       hashCode = MurmurHash.finish(hashCode, 3);
/* 129 */       return hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 134 */       if (!(obj instanceof Predicate)) return false; 
/* 135 */       if (this == obj) return true; 
/* 136 */       Predicate p = (Predicate)obj;
/* 137 */       return (this.ruleIndex == p.ruleIndex && this.predIndex == p.predIndex && this.isCtxDependent == p.isCtxDependent);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 144 */       return "{" + this.ruleIndex + ":" + this.predIndex + "}?";
/*     */     }
/*     */   }
/*     */   
/*     */   public static class PrecedencePredicate extends SemanticContext implements Comparable<PrecedencePredicate> {
/*     */     public final int precedence;
/*     */     
/*     */     protected PrecedencePredicate() {
/* 152 */       this.precedence = 0;
/*     */     }
/*     */     
/*     */     public PrecedencePredicate(int precedence) {
/* 156 */       this.precedence = precedence;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean eval(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/* 161 */       return parser.precpred(parserCallStack, this.precedence);
/*     */     }
/*     */ 
/*     */     
/*     */     public SemanticContext evalPrecedence(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/* 166 */       if (parser.precpred(parserCallStack, this.precedence)) {
/* 167 */         return SemanticContext.NONE;
/*     */       }
/*     */       
/* 170 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(PrecedencePredicate o) {
/* 176 */       return this.precedence - o.precedence;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 181 */       int hashCode = 1;
/* 182 */       hashCode = 31 * hashCode + this.precedence;
/* 183 */       return hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 188 */       if (!(obj instanceof PrecedencePredicate)) {
/* 189 */         return false;
/*     */       }
/*     */       
/* 192 */       if (this == obj) {
/* 193 */         return true;
/*     */       }
/*     */       
/* 196 */       PrecedencePredicate other = (PrecedencePredicate)obj;
/* 197 */       return (this.precedence == other.precedence);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 203 */       return "{" + this.precedence + ">=prec}?";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class Operator
/*     */     extends SemanticContext
/*     */   {
/*     */     public abstract Collection<SemanticContext> getOperands();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AND
/*     */     extends Operator
/*     */   {
/*     */     public final SemanticContext[] opnds;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AND(SemanticContext a, SemanticContext b) {
/* 234 */       Set<SemanticContext> operands = new HashSet<SemanticContext>();
/* 235 */       if (a instanceof AND) { operands.addAll(Arrays.asList(((AND)a).opnds)); }
/* 236 */       else { operands.add(a); }
/* 237 */        if (b instanceof AND) { operands.addAll(Arrays.asList(((AND)b).opnds)); }
/* 238 */       else { operands.add(b); }
/*     */       
/* 240 */       List<SemanticContext.PrecedencePredicate> precedencePredicates = SemanticContext.filterPrecedencePredicates(operands);
/* 241 */       if (!precedencePredicates.isEmpty()) {
/*     */         
/* 243 */         SemanticContext.PrecedencePredicate reduced = Collections.<SemanticContext.PrecedencePredicate>min(precedencePredicates);
/* 244 */         operands.add(reduced);
/*     */       } 
/*     */       
/* 247 */       this.opnds = operands.<SemanticContext>toArray(new SemanticContext[operands.size()]);
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<SemanticContext> getOperands() {
/* 252 */       return Arrays.asList(this.opnds);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 257 */       if (this == obj) return true; 
/* 258 */       if (!(obj instanceof AND)) return false; 
/* 259 */       AND other = (AND)obj;
/* 260 */       return Arrays.equals((Object[])this.opnds, (Object[])other.opnds);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 265 */       return MurmurHash.hashCode(this.opnds, AND.class.hashCode());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean eval(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/* 277 */       for (SemanticContext opnd : this.opnds) {
/* 278 */         if (!opnd.eval(parser, parserCallStack)) return false; 
/*     */       } 
/* 280 */       return true;
/*     */     }
/*     */     
/*     */     public SemanticContext evalPrecedence(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/*     */       int j;
/* 285 */       boolean differs = false;
/* 286 */       List<SemanticContext> operands = new ArrayList<SemanticContext>();
/* 287 */       for (SemanticContext context : this.opnds) {
/* 288 */         SemanticContext evaluated = context.evalPrecedence(parser, parserCallStack);
/* 289 */         j = differs | ((evaluated != context) ? 1 : 0);
/* 290 */         if (evaluated == null)
/*     */         {
/* 292 */           return null;
/*     */         }
/* 294 */         if (evaluated != NONE)
/*     */         {
/* 296 */           operands.add(evaluated);
/*     */         }
/*     */       } 
/*     */       
/* 300 */       if (j == 0) {
/* 301 */         return this;
/*     */       }
/*     */       
/* 304 */       if (operands.isEmpty())
/*     */       {
/* 306 */         return NONE;
/*     */       }
/*     */       
/* 309 */       SemanticContext result = operands.get(0);
/* 310 */       for (int i = 1; i < operands.size(); i++) {
/* 311 */         result = SemanticContext.and(result, operands.get(i));
/*     */       }
/*     */       
/* 314 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 319 */       return Utils.join(Arrays.asList((Object[])this.opnds).iterator(), "&&");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class OR
/*     */     extends Operator
/*     */   {
/*     */     public final SemanticContext[] opnds;
/*     */ 
/*     */     
/*     */     public OR(SemanticContext a, SemanticContext b) {
/* 331 */       Set<SemanticContext> operands = new HashSet<SemanticContext>();
/* 332 */       if (a instanceof OR) { operands.addAll(Arrays.asList(((OR)a).opnds)); }
/* 333 */       else { operands.add(a); }
/* 334 */        if (b instanceof OR) { operands.addAll(Arrays.asList(((OR)b).opnds)); }
/* 335 */       else { operands.add(b); }
/*     */       
/* 337 */       List<SemanticContext.PrecedencePredicate> precedencePredicates = SemanticContext.filterPrecedencePredicates(operands);
/* 338 */       if (!precedencePredicates.isEmpty()) {
/*     */         
/* 340 */         SemanticContext.PrecedencePredicate reduced = Collections.<SemanticContext.PrecedencePredicate>max(precedencePredicates);
/* 341 */         operands.add(reduced);
/*     */       } 
/*     */       
/* 344 */       this.opnds = operands.<SemanticContext>toArray(new SemanticContext[operands.size()]);
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<SemanticContext> getOperands() {
/* 349 */       return Arrays.asList(this.opnds);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 354 */       if (this == obj) return true; 
/* 355 */       if (!(obj instanceof OR)) return false; 
/* 356 */       OR other = (OR)obj;
/* 357 */       return Arrays.equals((Object[])this.opnds, (Object[])other.opnds);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 362 */       return MurmurHash.hashCode(this.opnds, OR.class.hashCode());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean eval(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/* 374 */       for (SemanticContext opnd : this.opnds) {
/* 375 */         if (opnd.eval(parser, parserCallStack)) return true; 
/*     */       } 
/* 377 */       return false;
/*     */     }
/*     */     
/*     */     public SemanticContext evalPrecedence(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/*     */       int j;
/* 382 */       boolean differs = false;
/* 383 */       List<SemanticContext> operands = new ArrayList<SemanticContext>();
/* 384 */       for (SemanticContext context : this.opnds) {
/* 385 */         SemanticContext evaluated = context.evalPrecedence(parser, parserCallStack);
/* 386 */         j = differs | ((evaluated != context) ? 1 : 0);
/* 387 */         if (evaluated == NONE)
/*     */         {
/* 389 */           return NONE;
/*     */         }
/* 391 */         if (evaluated != null)
/*     */         {
/* 393 */           operands.add(evaluated);
/*     */         }
/*     */       } 
/*     */       
/* 397 */       if (j == 0) {
/* 398 */         return this;
/*     */       }
/*     */       
/* 401 */       if (operands.isEmpty())
/*     */       {
/* 403 */         return null;
/*     */       }
/*     */       
/* 406 */       SemanticContext result = operands.get(0);
/* 407 */       for (int i = 1; i < operands.size(); i++) {
/* 408 */         result = SemanticContext.or(result, operands.get(i));
/*     */       }
/*     */       
/* 411 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 416 */       return Utils.join(Arrays.asList((Object[])this.opnds).iterator(), "||");
/*     */     }
/*     */   }
/*     */   
/*     */   public static SemanticContext and(SemanticContext a, SemanticContext b) {
/* 421 */     if (a == null || a == NONE) return b; 
/* 422 */     if (b == null || b == NONE) return a; 
/* 423 */     AND result = new AND(a, b);
/* 424 */     if (result.opnds.length == 1) {
/* 425 */       return result.opnds[0];
/*     */     }
/*     */     
/* 428 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SemanticContext or(SemanticContext a, SemanticContext b) {
/* 436 */     if (a == null) return b; 
/* 437 */     if (b == null) return a; 
/* 438 */     if (a == NONE || b == NONE) return NONE; 
/* 439 */     OR result = new OR(a, b);
/* 440 */     if (result.opnds.length == 1) {
/* 441 */       return result.opnds[0];
/*     */     }
/*     */     
/* 444 */     return result;
/*     */   }
/*     */   
/*     */   private static List<PrecedencePredicate> filterPrecedencePredicates(Collection<? extends SemanticContext> collection) {
/* 448 */     ArrayList<PrecedencePredicate> result = null;
/* 449 */     for (Iterator<? extends SemanticContext> iterator = collection.iterator(); iterator.hasNext(); ) {
/* 450 */       SemanticContext context = iterator.next();
/* 451 */       if (context instanceof PrecedencePredicate) {
/* 452 */         if (result == null) {
/* 453 */           result = new ArrayList<PrecedencePredicate>();
/*     */         }
/*     */         
/* 456 */         result.add((PrecedencePredicate)context);
/* 457 */         iterator.remove();
/*     */       } 
/*     */     } 
/*     */     
/* 461 */     if (result == null) {
/* 462 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 465 */     return result;
/*     */   }
/*     */   
/*     */   public abstract boolean eval(Recognizer<?, ?> paramRecognizer, RuleContext paramRuleContext);
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/SemanticContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */