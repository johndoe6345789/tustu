/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.misc.IntervalSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetTransition
/*    */   extends Transition
/*    */ {
/*    */   public final IntervalSet set;
/*    */   
/*    */   public SetTransition(ATNState target, IntervalSet set) {
/* 43 */     super(target);
/* 44 */     if (set == null) set = IntervalSet.of(0); 
/* 45 */     this.set = set;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 50 */     return 7;
/*    */   }
/*    */ 
/*    */   
/*    */   public IntervalSet label() {
/* 55 */     return this.set;
/*    */   }
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 59 */     return this.set.contains(symbol);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     return this.set.toString();
/*    */   }
/*    */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/SetTransition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */