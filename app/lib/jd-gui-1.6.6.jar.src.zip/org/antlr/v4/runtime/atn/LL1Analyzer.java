/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.antlr.v4.runtime.RuleContext;
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LL1Analyzer
/*     */ {
/*     */   public static final int HIT_PRED = 0;
/*     */   public final ATN atn;
/*     */   
/*     */   public LL1Analyzer(ATN atn) {
/*  51 */     this.atn = atn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet[] getDecisionLookahead(ATNState s) {
/*  65 */     if (s == null) {
/*  66 */       return null;
/*     */     }
/*     */     
/*  69 */     IntervalSet[] look = new IntervalSet[s.getNumberOfTransitions()];
/*  70 */     for (int alt = 0; alt < s.getNumberOfTransitions(); alt++) {
/*  71 */       look[alt] = new IntervalSet(new int[0]);
/*  72 */       Set<ATNConfig> lookBusy = new HashSet<ATNConfig>();
/*  73 */       boolean seeThruPreds = false;
/*  74 */       _LOOK((s.transition(alt)).target, null, PredictionContext.EMPTY, look[alt], lookBusy, new BitSet(), seeThruPreds, false);
/*     */ 
/*     */ 
/*     */       
/*  78 */       if (look[alt].size() == 0 || look[alt].contains(0)) {
/*  79 */         look[alt] = null;
/*     */       }
/*     */     } 
/*  82 */     return look;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet LOOK(ATNState s, RuleContext ctx) {
/* 102 */     return LOOK(s, null, ctx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet LOOK(ATNState s, ATNState stopState, RuleContext ctx) {
/* 125 */     IntervalSet r = new IntervalSet(new int[0]);
/* 126 */     boolean seeThruPreds = true;
/* 127 */     PredictionContext lookContext = (ctx != null) ? PredictionContext.fromRuleContext(s.atn, ctx) : null;
/* 128 */     _LOOK(s, stopState, lookContext, r, new HashSet<ATNConfig>(), new BitSet(), seeThruPreds, true);
/*     */     
/* 130 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _LOOK(ATNState s, ATNState stopState, PredictionContext ctx, IntervalSet look, Set<ATNConfig> lookBusy, BitSet calledRuleStack, boolean seeThruPreds, boolean addEOF) {
/* 172 */     ATNConfig c = new ATNConfig(s, 0, ctx);
/* 173 */     if (!lookBusy.add(c))
/*     */       return; 
/* 175 */     if (s == stopState) {
/* 176 */       if (ctx == null) {
/* 177 */         look.add(-2); return;
/*     */       } 
/* 179 */       if (ctx.isEmpty() && addEOF) {
/* 180 */         look.add(-1);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 185 */     if (s instanceof RuleStopState) {
/* 186 */       if (ctx == null) {
/* 187 */         look.add(-2); return;
/*     */       } 
/* 189 */       if (ctx.isEmpty() && addEOF) {
/* 190 */         look.add(-1);
/*     */         
/*     */         return;
/*     */       } 
/* 194 */       if (ctx != PredictionContext.EMPTY) {
/*     */         
/* 196 */         for (int j = 0; j < ctx.size(); j++) {
/* 197 */           ATNState returnState = this.atn.states.get(ctx.getReturnState(j));
/*     */ 
/*     */           
/* 200 */           boolean removed = calledRuleStack.get(returnState.ruleIndex);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     int n = s.getNumberOfTransitions();
/* 216 */     for (int i = 0; i < n; i++) {
/* 217 */       Transition t = s.transition(i);
/* 218 */       if (t.getClass() == RuleTransition.class) {
/* 219 */         if (!calledRuleStack.get(((RuleTransition)t).target.ruleIndex))
/*     */         {
/*     */ 
/*     */           
/* 223 */           PredictionContext newContext = SingletonPredictionContext.create(ctx, ((RuleTransition)t).followState.stateNumber);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 234 */       else if (t instanceof AbstractPredicateTransition) {
/* 235 */         if (seeThruPreds) {
/* 236 */           _LOOK(t.target, stopState, ctx, look, lookBusy, calledRuleStack, seeThruPreds, addEOF);
/*     */         } else {
/*     */           
/* 239 */           look.add(0);
/*     */         }
/*     */       
/* 242 */       } else if (t.isEpsilon()) {
/* 243 */         _LOOK(t.target, stopState, ctx, look, lookBusy, calledRuleStack, seeThruPreds, addEOF);
/*     */       }
/* 245 */       else if (t.getClass() == WildcardTransition.class) {
/* 246 */         look.addAll(IntervalSet.of(1, this.atn.maxTokenType));
/*     */       }
/*     */       else {
/*     */         
/* 250 */         IntervalSet set = t.label();
/* 251 */         if (set != null) {
/* 252 */           if (t instanceof NotSetTransition) {
/* 253 */             set = set.complement(IntervalSet.of(1, this.atn.maxTokenType));
/*     */           }
/* 255 */           look.addAll(set);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/atn/LL1Analyzer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */