/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecognitionException
/*     */   extends RuntimeException
/*     */ {
/*     */   private final Recognizer<?, ?> recognizer;
/*     */   private final RuleContext ctx;
/*     */   private final IntStream input;
/*     */   private Token offendingToken;
/*  57 */   private int offendingState = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RecognitionException(Recognizer<?, ?> recognizer, IntStream input, ParserRuleContext ctx) {
/*  63 */     this.recognizer = recognizer;
/*  64 */     this.input = input;
/*  65 */     this.ctx = ctx;
/*  66 */     if (recognizer != null) this.offendingState = recognizer.getState();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RecognitionException(String message, Recognizer<?, ?> recognizer, IntStream input, ParserRuleContext ctx) {
/*  74 */     super(message);
/*  75 */     this.recognizer = recognizer;
/*  76 */     this.input = input;
/*  77 */     this.ctx = ctx;
/*  78 */     if (recognizer != null) this.offendingState = recognizer.getState();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffendingState() {
/*  91 */     return this.offendingState;
/*     */   }
/*     */   
/*     */   protected final void setOffendingState(int offendingState) {
/*  95 */     this.offendingState = offendingState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet getExpectedTokens() {
/* 109 */     if (this.recognizer != null) {
/* 110 */       return this.recognizer.getATN().getExpectedTokens(this.offendingState, this.ctx);
/*     */     }
/*     */     
/* 113 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleContext getCtx() {
/* 125 */     return this.ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntStream getInputStream() {
/* 139 */     return this.input;
/*     */   }
/*     */ 
/*     */   
/*     */   public Token getOffendingToken() {
/* 144 */     return this.offendingToken;
/*     */   }
/*     */   
/*     */   protected final void setOffendingToken(Token offendingToken) {
/* 148 */     this.offendingToken = offendingToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Recognizer<?, ?> getRecognizer() {
/* 160 */     return this.recognizer;
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/RecognitionException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */