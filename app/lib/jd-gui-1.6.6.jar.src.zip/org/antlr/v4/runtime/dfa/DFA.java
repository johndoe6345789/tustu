/*     */ package org.antlr.v4.runtime.dfa;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.antlr.v4.runtime.Vocabulary;
/*     */ import org.antlr.v4.runtime.VocabularyImpl;
/*     */ import org.antlr.v4.runtime.atn.ATNConfigSet;
/*     */ import org.antlr.v4.runtime.atn.DecisionState;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DFA
/*     */ {
/*  54 */   public final Map<DFAState, DFAState> states = new HashMap<DFAState, DFAState>();
/*     */ 
/*     */ 
/*     */   
/*     */   public volatile DFAState s0;
/*     */ 
/*     */   
/*     */   public final int decision;
/*     */ 
/*     */   
/*     */   public final DecisionState atnStartState;
/*     */ 
/*     */   
/*     */   private volatile boolean precedenceDfa;
/*     */ 
/*     */ 
/*     */   
/*     */   public DFA(DecisionState atnStartState) {
/*  72 */     this(atnStartState, 0);
/*     */   }
/*     */   
/*     */   public DFA(DecisionState atnStartState, int decision) {
/*  76 */     this.atnStartState = atnStartState;
/*  77 */     this.decision = decision;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isPrecedenceDfa() {
/*  92 */     return this.precedenceDfa;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DFAState getPrecedenceStartState(int precedence) {
/* 107 */     if (!isPrecedenceDfa()) {
/* 108 */       throw new IllegalStateException("Only precedence DFAs may contain a precedence start state.");
/*     */     }
/*     */ 
/*     */     
/* 112 */     if (precedence < 0 || precedence >= this.s0.edges.length) {
/* 113 */       return null;
/*     */     }
/*     */     
/* 116 */     return this.s0.edges[precedence];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setPrecedenceStartState(int precedence, DFAState startState) {
/* 131 */     if (!isPrecedenceDfa()) {
/* 132 */       throw new IllegalStateException("Only precedence DFAs may contain a precedence start state.");
/*     */     }
/*     */     
/* 135 */     if (precedence < 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 141 */     synchronized (this.s0) {
/*     */       
/* 143 */       if (precedence >= this.s0.edges.length) {
/* 144 */         this.s0.edges = Arrays.<DFAState>copyOf(this.s0.edges, precedence + 1);
/*     */       }
/*     */       
/* 147 */       this.s0.edges[precedence] = startState;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final synchronized void setPrecedenceDfa(boolean precedenceDfa) {
/* 169 */     if (this.precedenceDfa != precedenceDfa) {
/* 170 */       this.states.clear();
/* 171 */       if (precedenceDfa) {
/* 172 */         DFAState precedenceState = new DFAState(new ATNConfigSet());
/* 173 */         precedenceState.edges = new DFAState[0];
/* 174 */         precedenceState.isAcceptState = false;
/* 175 */         precedenceState.requiresFullContext = false;
/* 176 */         this.s0 = precedenceState;
/*     */       } else {
/*     */         
/* 179 */         this.s0 = null;
/*     */       } 
/*     */       
/* 182 */       this.precedenceDfa = precedenceDfa;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DFAState> getStates() {
/* 191 */     List<DFAState> result = new ArrayList<DFAState>(this.states.keySet());
/* 192 */     Collections.sort(result, new Comparator<DFAState>()
/*     */         {
/*     */           public int compare(DFAState o1, DFAState o2) {
/* 195 */             return o1.stateNumber - o2.stateNumber;
/*     */           }
/*     */         });
/*     */     
/* 199 */     return result;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 203 */     return toString(VocabularyImpl.EMPTY_VOCABULARY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String toString(String[] tokenNames) {
/* 210 */     if (this.s0 == null) return ""; 
/* 211 */     DFASerializer serializer = new DFASerializer(this, tokenNames);
/* 212 */     return serializer.toString();
/*     */   }
/*     */   
/*     */   public String toString(Vocabulary vocabulary) {
/* 216 */     if (this.s0 == null) {
/* 217 */       return "";
/*     */     }
/*     */     
/* 220 */     DFASerializer serializer = new DFASerializer(this, vocabulary);
/* 221 */     return serializer.toString();
/*     */   }
/*     */   
/*     */   public String toLexerString() {
/* 225 */     if (this.s0 == null) return ""; 
/* 226 */     DFASerializer serializer = new LexerDFASerializer(this);
/* 227 */     return serializer.toString();
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/dfa/DFA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */