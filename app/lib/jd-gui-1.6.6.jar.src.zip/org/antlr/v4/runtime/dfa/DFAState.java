/*     */ package org.antlr.v4.runtime.dfa;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.antlr.v4.runtime.atn.ATNConfig;
/*     */ import org.antlr.v4.runtime.atn.ATNConfigSet;
/*     */ import org.antlr.v4.runtime.atn.LexerActionExecutor;
/*     */ import org.antlr.v4.runtime.atn.SemanticContext;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DFAState
/*     */ {
/*  73 */   public int stateNumber = -1;
/*     */ 
/*     */   
/*  76 */   public ATNConfigSet configs = new ATNConfigSet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DFAState[] edges;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAcceptState = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public int prediction;
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerActionExecutor lexerActionExecutor;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresFullContext;
/*     */ 
/*     */ 
/*     */   
/*     */   public PredPrediction[] predicates;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DFAState() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PredPrediction
/*     */   {
/*     */     public SemanticContext pred;
/*     */ 
/*     */ 
/*     */     
/*     */     public int alt;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PredPrediction(SemanticContext pred, int alt) {
/* 123 */       this.alt = alt;
/* 124 */       this.pred = pred;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 128 */       return "(" + this.pred + ", " + this.alt + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public DFAState(int stateNumber) {
/* 134 */     this.stateNumber = stateNumber;
/*     */   } public DFAState(ATNConfigSet configs) {
/* 136 */     this.configs = configs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Integer> getAltSet() {
/* 142 */     Set<Integer> alts = new HashSet<Integer>();
/* 143 */     if (this.configs != null) {
/* 144 */       for (ATNConfig c : this.configs) {
/* 145 */         alts.add(Integer.valueOf(c.alt));
/*     */       }
/*     */     }
/* 148 */     if (alts.isEmpty()) return null; 
/* 149 */     return alts;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 154 */     int hash = MurmurHash.initialize(7);
/* 155 */     hash = MurmurHash.update(hash, this.configs.hashCode());
/* 156 */     hash = MurmurHash.finish(hash, 1);
/* 157 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 176 */     if (this == o) return true;
/*     */     
/* 178 */     if (!(o instanceof DFAState)) {
/* 179 */       return false;
/*     */     }
/*     */     
/* 182 */     DFAState other = (DFAState)o;
/*     */     
/* 184 */     boolean sameSet = this.configs.equals(other.configs);
/*     */     
/* 186 */     return sameSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 191 */     StringBuilder buf = new StringBuilder();
/* 192 */     buf.append(this.stateNumber).append(":").append(this.configs);
/* 193 */     if (this.isAcceptState) {
/* 194 */       buf.append("=>");
/* 195 */       if (this.predicates != null) {
/* 196 */         buf.append(Arrays.toString((Object[])this.predicates));
/*     */       } else {
/*     */         
/* 199 */         buf.append(this.prediction);
/*     */       } 
/*     */     } 
/* 202 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/dfa/DFAState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */