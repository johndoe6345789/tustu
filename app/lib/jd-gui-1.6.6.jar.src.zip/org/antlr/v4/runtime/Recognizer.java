/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.antlr.v4.runtime.atn.ATN;
/*     */ import org.antlr.v4.runtime.atn.ATNSimulator;
/*     */ import org.antlr.v4.runtime.atn.ParseInfo;
/*     */ import org.antlr.v4.runtime.misc.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Recognizer<Symbol, ATNInterpreter extends ATNSimulator>
/*     */ {
/*     */   public static final int EOF = -1;
/*  49 */   private static final Map<Vocabulary, Map<String, Integer>> tokenTypeMapCache = new WeakHashMap<Vocabulary, Map<String, Integer>>();
/*     */   
/*  51 */   private static final Map<String[], Map<String, Integer>> ruleIndexMapCache = (Map)new WeakHashMap<String, Map<String, Integer>>();
/*     */ 
/*     */ 
/*     */   
/*  55 */   private List<ANTLRErrorListener> _listeners = new CopyOnWriteArrayList<ANTLRErrorListener>()
/*     */     {
/*     */     
/*     */     };
/*     */   
/*     */   protected ATNInterpreter _interp;
/*     */   
/*  62 */   private int _stateNumber = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public abstract String[] getTokenNames();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String[] getRuleNames();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vocabulary getVocabulary() {
/*  83 */     return VocabularyImpl.fromTokenNames(getTokenNames());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getTokenTypeMap() {
/*  92 */     Vocabulary vocabulary = getVocabulary();
/*  93 */     synchronized (tokenTypeMapCache) {
/*  94 */       Map<String, Integer> result = tokenTypeMapCache.get(vocabulary);
/*  95 */       if (result == null) {
/*  96 */         result = new HashMap<String, Integer>();
/*  97 */         for (int i = 0; i < (getATN()).maxTokenType; i++) {
/*  98 */           String literalName = vocabulary.getLiteralName(i);
/*  99 */           if (literalName != null) {
/* 100 */             result.put(literalName, Integer.valueOf(i));
/*     */           }
/*     */           
/* 103 */           String symbolicName = vocabulary.getSymbolicName(i);
/* 104 */           if (symbolicName != null) {
/* 105 */             result.put(symbolicName, Integer.valueOf(i));
/*     */           }
/*     */         } 
/*     */         
/* 109 */         result.put("EOF", Integer.valueOf(-1));
/* 110 */         result = Collections.unmodifiableMap(result);
/* 111 */         tokenTypeMapCache.put(vocabulary, result);
/*     */       } 
/*     */       
/* 114 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getRuleIndexMap() {
/* 124 */     String[] ruleNames = getRuleNames();
/* 125 */     if (ruleNames == null) {
/* 126 */       throw new UnsupportedOperationException("The current recognizer does not provide a list of rule names.");
/*     */     }
/*     */     
/* 129 */     synchronized (ruleIndexMapCache) {
/* 130 */       Map<String, Integer> result = ruleIndexMapCache.get(ruleNames);
/* 131 */       if (result == null) {
/* 132 */         result = Collections.unmodifiableMap(Utils.toMap(ruleNames));
/* 133 */         ruleIndexMapCache.put(ruleNames, result);
/*     */       } 
/*     */       
/* 136 */       return result;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getTokenType(String tokenName) {
/* 141 */     Integer ttype = getTokenTypeMap().get(tokenName);
/* 142 */     if (ttype != null) return ttype.intValue(); 
/* 143 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSerializedATN() {
/* 154 */     throw new UnsupportedOperationException("there is no serialized ATN");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getGrammarFileName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ATN getATN();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNInterpreter getInterpreter() {
/* 175 */     return this._interp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseInfo getParseInfo() {
/* 184 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterpreter(ATNInterpreter interpreter) {
/* 194 */     this._interp = interpreter;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getErrorHeader(RecognitionException e) {
/* 199 */     int line = e.getOffendingToken().getLine();
/* 200 */     int charPositionInLine = e.getOffendingToken().getCharPositionInLine();
/* 201 */     return "line " + line + ":" + charPositionInLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getTokenErrorDisplay(Token t) {
/* 219 */     if (t == null) return "<no token>"; 
/* 220 */     String s = t.getText();
/* 221 */     if (s == null) {
/* 222 */       if (t.getType() == -1) {
/* 223 */         s = "<EOF>";
/*     */       } else {
/*     */         
/* 226 */         s = "<" + t.getType() + ">";
/*     */       } 
/*     */     }
/* 229 */     s = s.replace("\n", "\\n");
/* 230 */     s = s.replace("\r", "\\r");
/* 231 */     s = s.replace("\t", "\\t");
/* 232 */     return "'" + s + "'";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addErrorListener(ANTLRErrorListener listener) {
/* 239 */     if (listener == null) {
/* 240 */       throw new NullPointerException("listener cannot be null.");
/*     */     }
/*     */     
/* 243 */     this._listeners.add(listener);
/*     */   }
/*     */   
/*     */   public void removeErrorListener(ANTLRErrorListener listener) {
/* 247 */     this._listeners.remove(listener);
/*     */   }
/*     */   
/*     */   public void removeErrorListeners() {
/* 251 */     this._listeners.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends ANTLRErrorListener> getErrorListeners() {
/* 256 */     return this._listeners;
/*     */   }
/*     */   
/*     */   public ANTLRErrorListener getErrorListenerDispatch() {
/* 260 */     return new ProxyErrorListener(getErrorListeners());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean sempred(RuleContext _localctx, int ruleIndex, int actionIndex) {
/* 266 */     return true;
/*     */   }
/*     */   
/*     */   public boolean precpred(RuleContext localctx, int precedence) {
/* 270 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void action(RuleContext _localctx, int ruleIndex, int actionIndex) {}
/*     */   
/*     */   public final int getState() {
/* 277 */     return this._stateNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setState(int atnState) {
/* 289 */     this._stateNumber = atnState;
/*     */   }
/*     */   
/*     */   public abstract IntStream getInputStream();
/*     */   
/*     */   public abstract void setInputStream(IntStream paramIntStream);
/*     */   
/*     */   public abstract TokenFactory<?> getTokenFactory();
/*     */   
/*     */   public abstract void setTokenFactory(TokenFactory<?> paramTokenFactory);
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/Recognizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */