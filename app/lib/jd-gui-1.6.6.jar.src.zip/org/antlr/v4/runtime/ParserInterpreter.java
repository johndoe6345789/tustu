/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Deque;
/*     */ import org.antlr.v4.runtime.atn.ATN;
/*     */ import org.antlr.v4.runtime.atn.ATNState;
/*     */ import org.antlr.v4.runtime.atn.ActionTransition;
/*     */ import org.antlr.v4.runtime.atn.AtomTransition;
/*     */ import org.antlr.v4.runtime.atn.DecisionState;
/*     */ import org.antlr.v4.runtime.atn.ParserATNSimulator;
/*     */ import org.antlr.v4.runtime.atn.PrecedencePredicateTransition;
/*     */ import org.antlr.v4.runtime.atn.PredicateTransition;
/*     */ import org.antlr.v4.runtime.atn.PredictionContextCache;
/*     */ import org.antlr.v4.runtime.atn.RuleStartState;
/*     */ import org.antlr.v4.runtime.atn.RuleTransition;
/*     */ import org.antlr.v4.runtime.atn.StarLoopEntryState;
/*     */ import org.antlr.v4.runtime.atn.Transition;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ import org.antlr.v4.runtime.misc.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParserInterpreter
/*     */   extends Parser
/*     */ {
/*     */   protected final String grammarFileName;
/*     */   protected final ATN atn;
/*     */   protected final BitSet pushRecursionContextStates;
/*     */   protected final DFA[] decisionToDFA;
/*  75 */   protected final PredictionContextCache sharedContextCache = new PredictionContextCache();
/*     */   
/*     */   @Deprecated
/*     */   protected final String[] tokenNames;
/*     */   
/*     */   protected final String[] ruleNames;
/*     */   
/*     */   private final Vocabulary vocabulary;
/*     */   
/*  84 */   protected final Deque<Pair<ParserRuleContext, Integer>> _parentContextStack = new ArrayDeque<Pair<ParserRuleContext, Integer>>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ParserInterpreter(String grammarFileName, Collection<String> tokenNames, Collection<String> ruleNames, ATN atn, TokenStream input) {
/*  92 */     this(grammarFileName, VocabularyImpl.fromTokenNames(tokenNames.<String>toArray(new String[tokenNames.size()])), ruleNames, atn, input);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ParserInterpreter(String grammarFileName, Vocabulary vocabulary, Collection<String> ruleNames, ATN atn, TokenStream input) {
/*  98 */     super(input);
/*  99 */     this.grammarFileName = grammarFileName;
/* 100 */     this.atn = atn;
/* 101 */     this.tokenNames = new String[atn.maxTokenType]; int i;
/* 102 */     for (i = 0; i < this.tokenNames.length; i++) {
/* 103 */       this.tokenNames[i] = vocabulary.getDisplayName(i);
/*     */     }
/*     */     
/* 106 */     this.ruleNames = ruleNames.<String>toArray(new String[ruleNames.size()]);
/* 107 */     this.vocabulary = vocabulary;
/* 108 */     this.decisionToDFA = new DFA[atn.getNumberOfDecisions()];
/* 109 */     for (i = 0; i < this.decisionToDFA.length; i++) {
/* 110 */       this.decisionToDFA[i] = new DFA(atn.getDecisionState(i), i);
/*     */     }
/*     */ 
/*     */     
/* 114 */     this.pushRecursionContextStates = new BitSet(atn.states.size());
/* 115 */     for (ATNState state : atn.states) {
/* 116 */       if (!(state instanceof StarLoopEntryState)) {
/*     */         continue;
/*     */       }
/*     */       
/* 120 */       if (((StarLoopEntryState)state).precedenceRuleDecision) {
/* 121 */         this.pushRecursionContextStates.set(state.stateNumber);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 126 */     setInterpreter(new ParserATNSimulator(this, atn, this.decisionToDFA, this.sharedContextCache));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATN getATN() {
/* 133 */     return this.atn;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String[] getTokenNames() {
/* 139 */     return this.tokenNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vocabulary getVocabulary() {
/* 144 */     return this.vocabulary;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getRuleNames() {
/* 149 */     return this.ruleNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getGrammarFileName() {
/* 154 */     return this.grammarFileName;
/*     */   }
/*     */ 
/*     */   
/*     */   public ParserRuleContext parse(int startRuleIndex) {
/* 159 */     RuleStartState startRuleStartState = this.atn.ruleToStartState[startRuleIndex];
/*     */     
/* 161 */     InterpreterRuleContext rootContext = new InterpreterRuleContext(null, -1, startRuleIndex);
/* 162 */     if (startRuleStartState.isPrecedenceRule) {
/* 163 */       enterRecursionRule(rootContext, startRuleStartState.stateNumber, startRuleIndex, 0);
/*     */     } else {
/*     */       
/* 166 */       enterRule(rootContext, startRuleStartState.stateNumber, startRuleIndex);
/*     */     } 
/*     */     
/*     */     while (true) {
/* 170 */       ATNState p = getATNState();
/* 171 */       switch (p.getStateType()) {
/*     */         
/*     */         case 7:
/* 174 */           if (this._ctx.isEmpty()) {
/* 175 */             if (startRuleStartState.isPrecedenceRule) {
/* 176 */               ParserRuleContext result = this._ctx;
/* 177 */               Pair<ParserRuleContext, Integer> parentContext = this._parentContextStack.pop();
/* 178 */               unrollRecursionContexts((ParserRuleContext)parentContext.a);
/* 179 */               return result;
/*     */             } 
/*     */             
/* 182 */             exitRule();
/* 183 */             return rootContext;
/*     */           } 
/*     */ 
/*     */           
/* 187 */           visitRuleStopState(p);
/*     */           continue;
/*     */       } 
/*     */       
/*     */       try {
/* 192 */         visitState(p);
/*     */       }
/* 194 */       catch (RecognitionException e) {
/* 195 */         setState((this.atn.ruleToStopState[p.ruleIndex]).stateNumber);
/* 196 */         (getContext()).exception = e;
/* 197 */         getErrorHandler().reportError(this, e);
/* 198 */         getErrorHandler().recover(this, e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enterRecursionRule(ParserRuleContext localctx, int state, int ruleIndex, int precedence) {
/* 208 */     this._parentContextStack.push(new Pair<ParserRuleContext, Integer>(this._ctx, Integer.valueOf(localctx.invokingState)));
/* 209 */     super.enterRecursionRule(localctx, state, ruleIndex, precedence);
/*     */   }
/*     */   
/*     */   protected ATNState getATNState() {
/* 213 */     return this.atn.states.get(getState()); } protected void visitState(ATNState p) { int edge; RuleStartState ruleStartState;
/*     */     int ruleIndex;
/*     */     InterpreterRuleContext ctx;
/*     */     PredicateTransition predicateTransition;
/*     */     ActionTransition actionTransition;
/* 218 */     if (p.getNumberOfTransitions() > 1) {
/* 219 */       getErrorHandler().sync(this);
/* 220 */       edge = getInterpreter().adaptivePredict(this._input, ((DecisionState)p).decision, this._ctx);
/*     */     } else {
/*     */       
/* 223 */       edge = 1;
/*     */     } 
/*     */     
/* 226 */     Transition transition = p.transition(edge - 1);
/* 227 */     switch (transition.getSerializationType()) {
/*     */       case 1:
/* 229 */         if (this.pushRecursionContextStates.get(p.stateNumber) && !(transition.target instanceof org.antlr.v4.runtime.atn.LoopEndState)) {
/* 230 */           InterpreterRuleContext interpreterRuleContext = new InterpreterRuleContext((ParserRuleContext)((Pair)this._parentContextStack.peek()).a, ((Integer)((Pair)this._parentContextStack.peek()).b).intValue(), this._ctx.getRuleIndex());
/* 231 */           pushNewRecursionContext(interpreterRuleContext, (this.atn.ruleToStartState[p.ruleIndex]).stateNumber, this._ctx.getRuleIndex());
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 5:
/* 236 */         match(((AtomTransition)transition).label);
/*     */         break;
/*     */       
/*     */       case 2:
/*     */       case 7:
/*     */       case 8:
/* 242 */         if (!transition.matches(this._input.LA(1), 1, 65535)) {
/* 243 */           this._errHandler.recoverInline(this);
/*     */         }
/* 245 */         matchWildcard();
/*     */         break;
/*     */       
/*     */       case 9:
/* 249 */         matchWildcard();
/*     */         break;
/*     */       
/*     */       case 3:
/* 253 */         ruleStartState = (RuleStartState)transition.target;
/* 254 */         ruleIndex = ruleStartState.ruleIndex;
/* 255 */         ctx = new InterpreterRuleContext(this._ctx, p.stateNumber, ruleIndex);
/* 256 */         if (ruleStartState.isPrecedenceRule) {
/* 257 */           enterRecursionRule(ctx, ruleStartState.stateNumber, ruleIndex, ((RuleTransition)transition).precedence);
/*     */           break;
/*     */         } 
/* 260 */         enterRule(ctx, transition.target.stateNumber, ruleIndex);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/* 265 */         predicateTransition = (PredicateTransition)transition;
/* 266 */         if (!sempred(this._ctx, predicateTransition.ruleIndex, predicateTransition.predIndex)) {
/* 267 */           throw new FailedPredicateException(this);
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case 6:
/* 273 */         actionTransition = (ActionTransition)transition;
/* 274 */         action(this._ctx, actionTransition.ruleIndex, actionTransition.actionIndex);
/*     */         break;
/*     */       
/*     */       case 10:
/* 278 */         if (!precpred(this._ctx, ((PrecedencePredicateTransition)transition).precedence)) {
/* 279 */           throw new FailedPredicateException(this, String.format("precpred(_ctx, %d)", new Object[] { Integer.valueOf(((PrecedencePredicateTransition)transition).precedence) }));
/*     */         }
/*     */         break;
/*     */       
/*     */       default:
/* 284 */         throw new UnsupportedOperationException("Unrecognized ATN transition type.");
/*     */     } 
/*     */     
/* 287 */     setState(transition.target.stateNumber); }
/*     */ 
/*     */   
/*     */   protected void visitRuleStopState(ATNState p) {
/* 291 */     RuleStartState ruleStartState = this.atn.ruleToStartState[p.ruleIndex];
/* 292 */     if (ruleStartState.isPrecedenceRule) {
/* 293 */       Pair<ParserRuleContext, Integer> parentContext = this._parentContextStack.pop();
/* 294 */       unrollRecursionContexts((ParserRuleContext)parentContext.a);
/* 295 */       setState(((Integer)parentContext.b).intValue());
/*     */     } else {
/*     */       
/* 298 */       exitRule();
/*     */     } 
/*     */     
/* 301 */     RuleTransition ruleTransition = (RuleTransition)((ATNState)this.atn.states.get(getState())).transition(0);
/* 302 */     setState(ruleTransition.followState.stateNumber);
/*     */   }
/*     */ }


/* Location:              /home/rewrich/Downloads/TunerStudioMS/TunerStudioMS/!/jd-gui-1.6.6.jar!/org/antlr/v4/runtime/ParserInterpreter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */